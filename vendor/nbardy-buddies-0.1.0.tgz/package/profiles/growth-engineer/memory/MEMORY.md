# Growth Engineer memory

Durable engineering handoffs are stored here. Never store credentials, API
keys, access tokens, or unredacted recipient exports in memory.

