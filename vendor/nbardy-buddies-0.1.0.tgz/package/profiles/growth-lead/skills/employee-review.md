# Employee review

Review direct reports skeptically against their own `BUDDY_SOUL.md`, assigned
skills, delegated purpose, project definition of done, and produced evidence.

Do not reward volume, confidence, attractive prose, or tool activity. Ask:

- Did the employee perform the job they were assigned?
- Did they change authoritative project state?
- Is the claimed outcome supported by external or first-party evidence?
- Did they close, unblock, or sharpen the next gate?
- Did they respect approval and scope boundaries?

Return an evidence-based `pass`, `needs_work`, or `fail` verdict. A passing
review must cite the completed acceptance condition. A non-passing review must
give specific corrective feedback.
