#!/usr/bin/env node

import { existsSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { BuddiesStore } from "../src/index.js";

const BUDDIES_ROOT = fileURLToPath(new URL("..", import.meta.url));
function projectRoot(environmentName, directoryName) {
  const configured = process.env[environmentName]?.trim();
  if (configured) return configured;
  const candidates = [
    join(dirname(process.cwd()), directoryName),
    join(dirname(BUDDIES_ROOT), directoryName),
  ];
  const discovered = candidates.find((candidate) => existsSync(candidate));
  if (discovered) return discovered;
  throw new Error(
    `${environmentName} is required because ${directoryName} was not found beside the current checkout`,
  );
}
const MAGIC_GENIE_ROOT = projectRoot("MAGIC_GENIE_ROOT", "magic_genie");
const EVENTMAP_ROOT = projectRoot("EVENTMAP_ROOT", "event_calendars");
const SOUL_PATH = "profiles/growth-lead/BUDDY_SOUL.md";
const MEMORY_PATH = "profiles/growth-lead/memory";

const store = new BuddiesStore();

function ensureProject(input) {
  return store.getProject(input.slug) || store.createProject(input);
}

function ensureActiveSprint(project, name, goal) {
  return (
    store.getActiveSprint(project.id) ||
    store.createSprint({ project: project.id, name, goal, status: "active" })
  );
}

function seedWork(project, sprint, buddy, items) {
  return items.map((item) => {
    const legacy = store.upsertWorkItem({
      ...item,
      project: project.id,
      sprint: sprint.id,
      buddy: buddy.id,
      kind: "campaign",
    });
    const owned = store.upsertBuddyProject({
      buddy: buddy.id,
      workspace: project.id,
      sprint: sprint.id,
      title: item.title,
      objective: item.objective,
      definitionOfDone: item.definitionOfDone,
      status: item.status,
      priority: item.priority,
      nextAction: item.nextAction,
      blockedReason: item.blockedReason,
      sourcePath: item.sourcePath,
      externalKey: item.externalKey,
      todos: item.nextAction
        ? [
            {
              title: item.nextAction,
              status:
                item.status === "blocked"
                  ? "blocked"
                  : item.status === "in_progress"
                    ? "in_progress"
                    : "open",
              blockedReason:
                item.status === "blocked" ? item.blockedReason : undefined,
            },
          ]
        : [],
    });
    return { legacy, owned };
  });
}

function ensureBuddy({ homeWorkspace, slug, name, role, soulPath, memoryPath }) {
  const existing = store.getBuddy(slug);
  return existing
    ? store.updateBuddy(existing.id, {
        homeWorkspace: homeWorkspace.id,
        name,
        role,
        soulPath,
        memoryPath,
        provider: "codex",
        model: "gpt-5.6-luna",
        reasoningEffort: "high",
      })
    : store.createBuddy({
        project: homeWorkspace.id,
        slug,
        name,
        role,
        soulPath,
        memoryPath,
        provider: "codex",
        model: "gpt-5.6-luna",
        reasoningEffort: "high",
      });
}

try {
  const buddiesWorkspace = ensureProject({
    name: "Buddies",
    slug: "buddies",
    rootPath: BUDDIES_ROOT,
  });
  const magicGenie = ensureProject({
    name: "Magic Genie",
    slug: "magic-genie",
    rootPath: MAGIC_GENIE_ROOT,
  });
  const eventMap = ensureProject({
    name: "EventMap",
    slug: "eventmap",
    rootPath: EVENTMAP_ROOT,
  });

  const growthLead = ensureBuddy({
    homeWorkspace: buddiesWorkspace,
    slug: "growth-lead",
    name: "Growth Lead",
    role: "Own GTM campaign evidence, prioritization, execution, and closure",
    soulPath: SOUL_PATH,
    memoryPath: MEMORY_PATH,
  });
  const gtmCritic = ensureBuddy({
    homeWorkspace: buddiesWorkspace,
    slug: "gtm-critic",
    name: "Go-to-Market Critic",
    role: "Aggressively pressure-test buyer fit, switching behavior, distribution, and proof",
    soulPath: "profiles/gtm-critic/BUDDY_SOUL.md",
    memoryPath: "profiles/gtm-critic/memory",
  });
  const growthOperator = ensureBuddy({
    homeWorkspace: buddiesWorkspace,
    slug: "growth-operator",
    name: "Growth Operator",
    role: "Turn evidence-backed goals and critique into bounded executable campaigns",
    soulPath: "profiles/growth-operator/BUDDY_SOUL.md",
    memoryPath: "profiles/growth-operator/memory",
  });

  for (const employee of [growthLead, gtmCritic, growthOperator]) {
    store.assignBuddyToProject({
      buddy: employee.id,
      project: buddiesWorkspace.id,
      role: "Own persistent employee identity, memory, and operating standards",
    });
    store.assignBuddyToProject({
      buddy: employee.id,
      project: magicGenie.id,
      role:
        employee.id === growthLead.id
          ? "Own qualified demand and five-market proof"
          : employee.role,
    });
    store.assignBuddyToProject({
      buddy: employee.id,
      project: eventMap.id,
      role:
        employee.id === growthLead.id
          ? "Own partner, backlink, creator, and inbound growth"
          : employee.role,
    });
  }

  store.setBuddyRelationship({
    fromBuddy: growthLead.id,
    toBuddy: gtmCritic.id,
    kind: "manager",
  });
  store.setBuddyRelationship({
    fromBuddy: gtmCritic.id,
    toBuddy: growthLead.id,
    kind: "reports_to",
  });
  store.setBuddyRelationship({
    fromBuddy: growthLead.id,
    toBuddy: growthOperator.id,
    kind: "manager",
  });
  store.setBuddyRelationship({
    fromBuddy: growthOperator.id,
    toBuddy: growthLead.id,
    kind: "reports_to",
  });
  store.setBuddyRelationship({
    fromBuddy: gtmCritic.id,
    toBuddy: growthOperator.id,
    kind: "reviews",
  });

  store.assignBuddySkill({
    buddy: growthLead.id,
    name: "employee-review",
    instructionPath: "profiles/growth-lead/skills/employee-review.md",
    mode: "always",
  });
  store.assignBuddySkill({
    buddy: gtmCritic.id,
    name: "pmf-critique",
    instructionPath: "profiles/gtm-critic/skills/pmf-critique.md",
    mode: "always",
  });
  store.assignBuddySkill({
    buddy: growthOperator.id,
    name: "solution-design",
    instructionPath: "profiles/growth-operator/skills/solution-design.md",
    mode: "always",
  });

  const magicSprint = ensureActiveSprint(
    magicGenie,
    "GTM proof and search continuity — July 2026",
    "Restore trustworthy acquisition surfaces and move one campaign through a real proof gate",
  );
  const eventSprint = ensureActiveSprint(
    eventMap,
    "Outreach quality and campaign closure — July 2026",
    "Repair destination quality, adjudicate existing outreach, and authorize only evidence-backed next tests",
  );

  const magicItems = seedWork(magicGenie, magicSprint, growthLead, [
    {
      externalKey: "mg-analytics-write-integrity-2026-07-28",
      title: "Restore trustworthy growth analytics writes",
      sourcePath: "SEO_GROWTH_NOTES/2026-07-28_seo_growth/traffic-readout-7d.md",
      objective:
        "Make campaign decisions from reliable first-party events instead of a Cloudflare/client-data mismatch.",
      definitionOfDone:
        "The analytics write route no longer produces 500s, cache behavior is correct, a real browser journey records the expected events, and the 7d readout reconciles the evidence sources.",
      status: "ready",
      priority: 110,
      nextAction:
        "Diagnose the 855 Cloudflare 500 responses on /api/analytics/event and verify the July 26–27 visitor spike is real human traffic.",
    },
    {
      externalKey: "mg-seo-continuity-2026-07-26",
      title: "Deploy and verify the July 26 SEO continuity repair",
      sourcePath: "SEO_GROWTH_NOTES/2026-07-26_seo_growth/execution_brief.md",
      objective: "Recover lost search-intent URLs and stop advertising dead sitemap routes.",
      definitionOfDone:
        "Reviewed changes are deployed; production seo:continuity reports zero broken sitemap URLs; priority routes and health pass.",
      status: "in_progress",
      priority: 100,
      nextAction:
        "Isolate the reviewed SEO change set, deploy through the normal Cloudflare path, then run npm run seo:continuity.",
    },
    {
      externalKey: "mg-outrank-content-backfill",
      title: "Restore the historical Outrank article corpus in D1",
      sourcePath: "SEO_GROWTH_NOTES/2026-07-26_seo_growth/execution_brief.md",
      objective: "Make previously published article history available to the live blog and sitemap.",
      definitionOfDone:
        "A reviewed content-table dry run succeeds, the D1 backfill is explicitly approved and applied, and sample historical slugs render without replacing authored fallbacks.",
      status: "blocked",
      priority: 75,
      blockedReason: "Neon rejected the source read because the project exceeded its data-transfer quota.",
      nextAction: "Restore Neon read access or obtain a safe outrank_articles export.",
    },
    {
      externalKey: "mg-shopify-listing-image-rescue",
      title: "Shopify listing-image rescue proof cell",
      sourcePath:
        "growth/campaigns/2026-07-11_five_market_pilot/real_input_qa_queue.csv",
      objective: "Prove the Shopify listing-image workflow on buyer-like inputs and one real destination.",
      definitionOfDone:
        "Five route-bound QA cases pass truth review, one external destination use is recorded, and the exact cell has an adjudicated signal-test decision.",
      status: "blocked",
      priority: 95,
      blockedReason: "5/5 fixtures are ready, but provider execution and spend are not authorized.",
      nextAction: "Request approval for the bounded five-case provider run.",
    },
    {
      externalKey: "mg-hvac-seasonal-campaign",
      title: "HVAC seasonal campaign proof cell",
      sourcePath:
        "growth/campaigns/2026-07-11_five_market_pilot/real_input_qa_queue.csv",
      objective: "Validate a truth-preserving HVAC campaign packet for a real local-service moment.",
      definitionOfDone:
        "Five buyer-like cases pass, the live route and HVAC article handoff are measured, and one external-use result is adjudicated.",
      status: "blocked",
      priority: 90,
      blockedReason: "Only 2/5 fixtures are ready; three buyer-like inputs and provider authorization are missing.",
      nextAction: "Acquire the three missing local-proof inputs before requesting the five-case run.",
    },
    {
      externalKey: "mg-barber-chair-fill",
      title: "Barber chair-fill proof cell",
      sourcePath:
        "growth/campaigns/2026-07-11_five_market_pilot/real_input_qa_queue.csv",
      objective: "Test whether one expiring chair slot can produce a truthful booking-ready campaign.",
      definitionOfDone:
        "Five consented finished-cut cases pass truth review and one shop owner records destination use or rejects the offer.",
      status: "blocked",
      priority: 70,
      blockedReason: "0/5 approved buyer-like fixtures exist.",
      nextAction: "Obtain consented finished-cut inputs tied to real open slots and booking actions.",
    },
    {
      externalKey: "mg-real-estate-twilight",
      title: "Real-estate twilight review proof cell",
      sourcePath:
        "growth/campaigns/2026-07-11_five_market_pilot/real_input_qa_queue.csv",
      objective: "Validate daylight-to-twilight output without inventing property details.",
      definitionOfDone:
        "Five licensed daylight exteriors pass broker truth review and one listing workflow records a use decision.",
      status: "blocked",
      priority: 65,
      blockedReason: "Only 2/5 suitable fixtures are ready and provider/broker review is not authorized.",
      nextAction: "Acquire three distinct licensed daylight exteriors and assign a broker review owner.",
    },
    {
      externalKey: "mg-restaurant-menu-photo",
      title: "Restaurant menu-photo rescue proof cell",
      sourcePath:
        "growth/campaigns/2026-07-11_five_market_pilot/real_input_qa_queue.csv",
      objective: "Prove a truth-preserving dish-photo workflow for an actual menu or delivery destination.",
      definitionOfDone:
        "Five cases pass owner truth review, one restaurant records destination use, and the cell receives an evidence-backed decision.",
      status: "blocked",
      priority: 80,
      blockedReason: "5/5 fixtures are ready, but provider execution and restaurant-owner review are not authorized.",
      nextAction: "Request the bounded provider run and identify a restaurant-owner reviewer.",
    },
    {
      externalKey: "mg-three-seo-traffic-targets",
      title: "Build measurable feeders into the three current traffic targets",
      sourcePath: "SEO_GROWTH_NOTES/2026-07-26_seo_growth/report.md",
      objective:
        "Grow qualified discovery for HVAC ads, plumber quote cards, and the salon campaign creator without duplicate route sprawl.",
      definitionOfDone:
        "Each target has a live intent-matched feeder, direct measured handoff, clean canonical/indexing state, and a dated GSC/analytics readout.",
      status: "ready",
      priority: 60,
      nextAction: "Finish continuity deployment first, then baseline impressions and handoff events.",
    },
  ]);

  const eventItems = seedWork(eventMap, eventSprint, growthLead, [
    {
      externalKey: "eventmap-sender-ab-1k",
      title: "Adjudicate the 1,000-recipient sender-persona campaign",
      sourcePath: "company/growth/Outreach/HANDOFF.md",
      objective: "Turn delivery, reply, click, suppression, and destination-quality evidence into a final campaign decision.",
      definitionOfDone:
        "Replies and opt-outs are current, hard failures are suppressed, results are segmented by sender/city/page quality, and a carry-sharpen-kill decision is recorded.",
      status: "blocked",
      priority: 95,
      blockedReason:
        "Broad sending remains paused; 741 sent rows were affected by failed destination quality and links earned remain unproven.",
      nextAction: "Refresh replies and repair evidence, then rebuild the sender A/B decision report.",
    },
    {
      externalKey: "eventmap-p1-destination-repair",
      title: "Complete P1 destination-page repair",
      sourcePath: "company/growth/Outreach/HANDOFF.md",
      objective: "Make the seven highest-impact city destinations useful enough to support prior and future partner outreach.",
      definitionOfDone:
        "All seven P1 city pages have reviewed source-backed rows in production and pass the strict month-horizon audit.",
      status: "in_progress",
      priority: 100,
      nextAction: "Continue the controlled repair flow with Barcelona; Singapore is complete.",
    },
    {
      externalKey: "eventmap-inbound-proof-slice",
      title: "Review and adjudicate the 10-row inbound-link proof slice",
      sourcePath:
        "company/growth/Outreach/inbound-link-sprints/2026-06-29-backlink-prospecting/motion-split-20260701/city-resource-quality-proof-packet-20260701/",
      objective: "Test a tiny page-ready backlink ask without reopening broad outbound.",
      definitionOfDone:
        "All ten rows receive explicit human decisions, the launch gate is rerun, and any approved send has outcome tracking.",
      status: "review",
      priority: 85,
      nextAction: "Complete the human approval workbook; do not infer approval from the agent review.",
    },
    {
      externalKey: "eventmap-10x-multicategory",
      title: "Adjudicate the 10x multicategory backlink campaign",
      sourcePath:
        "company/growth/Outreach/data/generated/eventmap-backlink-multicategory-10x-20260712-v11/README.md",
      objective: "Reduce the 10,000-row package to an explicitly reviewed, page-safe proof cohort.",
      definitionOfDone:
        "The relevant cohort is human-reviewed, launch gates pass, and an explicit send-or-kill decision is recorded before any delivery.",
      status: "review",
      priority: 75,
      nextAction:
        "Prioritize review within the 3,742 review-ready rows; do not send while the package remains blocked.",
    },
    {
      externalKey: "eventmap-creator-media-top-50",
      title: "Verify the top 50 creator/media partnership candidates",
      sourcePath: "company/growth/Outreach/HANDOFF.md",
      objective: "Find a small set of real sponsor or collaboration paths instead of growing another raw list.",
      definitionOfDone:
        "Fifty candidates have verified rate-card, media-kit, sponsor, or contact-path evidence and a decision on whether a paid test may proceed.",
      status: "ready",
      priority: 55,
      nextAction: "Verify evidence candidate by candidate and write one custom note per viable partner.",
    },
    {
      externalKey: "eventmap-v36-monitoring",
      title: "Close the v36 digital-nomad resource-link campaign",
      sourcePath: "company/growth/growth_lead_log/current_initiatives.md",
      objective: "Decide whether the 243 successful sends produced enough qualified signal to continue, sharpen, or stop.",
      definitionOfDone:
        "Reply, delivery, click-quality, and links-earned evidence is current and a written decision addresses the remaining 757-row plan.",
      status: "blocked",
      priority: 65,
      blockedReason: "The existing send volume has weak signal and does not justify blind continuation.",
      nextAction: "Refresh outcome evidence and explicitly adjudicate the remaining continuation package.",
    },
  ]);

  console.log(
    JSON.stringify(
      {
        database: store.databasePath,
        buddy: growthLead,
        team: [gtmCritic, growthOperator],
        projects: store.listBuddyProjects(growthLead.id),
        seeded: {
          magicGenie: magicItems.length,
          eventMap: eventItems.length,
        },
      },
      null,
      2,
    ),
  );
} finally {
  store.close();
}
