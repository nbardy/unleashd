#!/usr/bin/env node

import { BuddiesStore } from "../src/index.js";

const store = new BuddiesStore();

// Keep this initializer structural. Identity, workspace assignments, reporting
// lines, and skills are durable; campaigns and provider choices belong in the
// product repository and Buddy project where they can change without rewriting
// the employee's identity.
function requiredWorkspace(slug) {
  const workspace = store.getProject(slug);
  if (!workspace) {
    throw new Error(`Required workspace is missing: ${slug}`);
  }
  return workspace;
}

try {
  const buddiesWorkspace = requiredWorkspace("buddies");
  const magicGenie = requiredWorkspace("magic-genie");
  const eventMap = requiredWorkspace("eventmap");
  const growthLead = store.getBuddy("growth-lead");
  if (!growthLead) {
    throw new Error("Required Buddy is missing: growth-lead");
  }

  const existing = store.getBuddy("growth-engineer");
  const growthEngineer = existing
    ? store.updateBuddy(existing.id, {
        homeWorkspace: buddiesWorkspace.id,
        name: "Growth Engineer",
        role:
          "Build and verify measurable, compliant, low-cost acquisition infrastructure",
        soulPath: "profiles/growth-engineer/BUDDY_SOUL.md",
        memoryPath: "profiles/growth-engineer/memory",
        provider: "codex",
        model: "gpt-5.6-luna",
        reasoningEffort: "high",
      })
    : store.createBuddy({
        project: buddiesWorkspace.id,
        slug: "growth-engineer",
        name: "Growth Engineer",
        role:
          "Build and verify measurable, compliant, low-cost acquisition infrastructure",
        soulPath: "profiles/growth-engineer/BUDDY_SOUL.md",
        memoryPath: "profiles/growth-engineer/memory",
        provider: "codex",
        model: "gpt-5.6-luna",
        reasoningEffort: "high",
      });

  store.assignBuddyToProject({
    buddy: growthEngineer.id,
    project: buddiesWorkspace.id,
    role: "Own persistent engineering identity, memory, and operating standards",
  });
  store.assignBuddyToProject({
    buddy: growthEngineer.id,
    project: eventMap.id,
    role:
      "Build and verify the qualified-inbound outreach transport and evidence pipeline",
  });
  store.assignBuddyToProject({
    buddy: growthEngineer.id,
    project: magicGenie.id,
    role:
      "Build and verify GTM campaign delivery, attribution, and landing evidence",
  });

  const managerRelationship = store.setBuddyRelationship({
    fromBuddy: growthLead.id,
    toBuddy: growthEngineer.id,
    kind: "manager",
  });
  const reportRelationship = store.setBuddyRelationship({
    fromBuddy: growthEngineer.id,
    toBuddy: growthLead.id,
    kind: "reports_to",
  });
  const skill = store.assignBuddySkill({
    buddy: growthEngineer.id,
    name: "email-growth-engineering",
    instructionPath:
      "profiles/growth-engineer/skills/email-growth-engineering.md",
    mode: "always",
  });

  console.log(
    JSON.stringify(
      {
        database: store.databasePath,
        buddy: growthEngineer,
        workspaces: store.listBuddyProjects(growthEngineer.id),
        relationships: [managerRelationship, reportRelationship],
        skill,
      },
      null,
      2,
    ),
  );
} finally {
  store.close();
}
