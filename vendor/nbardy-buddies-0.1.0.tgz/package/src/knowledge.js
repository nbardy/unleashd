import { MEMORY_DOCUMENT_CAPS } from './store.js';
import { createHash, randomUUID } from 'node:crypto';

const hash = (value) => createHash('sha256').update(JSON.stringify(value)).digest('hex');
const deny = () => { throw Object.assign(new Error('Knowledge is unavailable in this audience.'), { code: 'KNOWLEDGE_SCOPE_DENIED' }); };
export function migrateKnowledge(db) {
  if (db.prepare('PRAGMA user_version').get().user_version >= 26) return;
  db.exec('SAVEPOINT scoped_knowledge');
  try { db.exec(`CREATE TABLE IF NOT EXISTS buddy_knowledge (
    id TEXT PRIMARY KEY, buddy_id TEXT NOT NULL REFERENCES buddies(id), workspace_id TEXT NOT NULL REFERENCES projects(id),
    scope_kind TEXT NOT NULL, scope_id TEXT NOT NULL, kind TEXT NOT NULL, name TEXT NOT NULL,
    revision INTEGER NOT NULL, content TEXT NOT NULL, updated_at TEXT NOT NULL,
    UNIQUE(buddy_id,workspace_id,scope_kind,scope_id,kind,name)
  ) STRICT;
  CREATE TABLE IF NOT EXISTS buddy_knowledge_revisions (
    document_id TEXT NOT NULL REFERENCES buddy_knowledge(id), revision INTEGER NOT NULL, content TEXT NOT NULL,
    reason TEXT NOT NULL, author TEXT NOT NULL, provenance TEXT NOT NULL, created_at TEXT NOT NULL,
    PRIMARY KEY(document_id,revision)
  ) STRICT;
  PRAGMA user_version=26; RELEASE scoped_knowledge;`);
  } catch (error) { db.exec('ROLLBACK TO scoped_knowledge; RELEASE scoped_knowledge'); throw error; }
}

function identity(ref) {
  const scope = ref.scope;
  if (!scope || !['owner_thread','project','workspace'].includes(scope.kind) ||
    !['soul','working','long_term','shared','note'].includes(ref.kind) || !ref.targetBuddyId) deny();
  const scopeId = scope.kind === 'project' ? scope.projectId : scope.kind === 'workspace' ? scope.workspaceId : scope.conversationId;
  if (typeof scopeId !== 'string' || !scopeId || typeof (ref.name ?? '') !== 'string' || (ref.name ?? '').length > 200) deny();
  if (['shared','note'].includes(ref.kind) && !ref.name?.trim()) deny();
  return [ref.targetBuddyId, scope.kind, scopeId, ref.kind, ref.name ?? ''];
}

// Authority is host supplied. A model-facing resource never accepts it as input.
function authorize(store, ref, authority, write = false) {
  const [target, scopeKind, scopeId] = identity(ref);
  const { actor, workspaceId, conversationId, scope: activeScope } = authority;
  if (!store.getCoordinationMembership(target, workspaceId)) deny();
  if (actor !== 'owner' && !store.getCoordinationMembership(actor, workspaceId)) deny();
  if (scopeKind === 'workspace' && scopeId !== workspaceId) deny();
  if (scopeKind === 'project') {
    if (store.getBuddyProject(scopeId)?.workspace_id !== workspaceId) deny();
    if (actor !== 'owner' && !store.canReadCoordinationProject(actor, scopeId)) deny();
  }
  if (actor !== 'owner') {
    if (scopeKind === 'owner_thread') {
      if (conversationId !== scopeId || activeScope?.kind !== 'owner_thread') deny();
    } else if (activeScope?.kind !== scopeKind ||
      (scopeKind === 'project' ? activeScope.projectId : activeScope?.workspaceId) !== scopeId) deny();
    // Portable role briefs and published documents are deliberately readable to
    // their audience. Compact memory and notes remain private to their author.
    if (target !== actor && (write || !['shared','soul'].includes(ref.kind))) deny();
    // Work authored in this already-shared audience can be published by its author.
    // Importing private knowledge or changing a portable role still requires the owner.
    if (write && (ref.kind === 'soul' || (ref.kind === 'shared' && scopeKind === 'owner_thread'))) deny();
  }
}

function saveDocument(store, ref, input, authority, before) {
  const [target, kind, scopeId, docKind, name] = identity(ref);
  const id = before.id ?? `knowledge_${randomUUID()}`;
  const revision = before.revision + 1;
  const now = new Date().toISOString();
  store.db.prepare(`INSERT INTO buddy_knowledge VALUES (?,?,?,?,?,?,?,?,?,?)
    ON CONFLICT(id) DO UPDATE SET revision=excluded.revision,content=excluded.content,updated_at=excluded.updated_at`)
    .run(id,target,authority.workspaceId,kind,scopeId,docKind,name,revision,input.content,now);
  store.db.prepare('INSERT INTO buddy_knowledge_revisions VALUES (?,?,?,?,?,?,?)')
    .run(id,revision,input.content,input.reason,authority.actor,JSON.stringify(authority.provenance ?? {}),now);
  const audit = store.recordAuditEvent({ buddy: target, workspace: authority.workspaceId, operation: 'buddy.knowledge.replace',
    payload: { documentId: id, revision, scope: ref.scope, kind: ref.kind, reason: input.reason } });
  return { id, ref, revision, auditId: audit.id };
}

export const knowledgeMethods = {
  checkKnowledgeDocument(ref, authority, write = false) { authorize(this, ref, authority, write); },
  readKnowledgeDocument(ref, authority) {
    return this.coordinationTransaction(() => {
      authorize(this, ref, authority);
      const [target, kind, scopeId, docKind, name] = identity(ref);
      const row = this.db.prepare('SELECT * FROM buddy_knowledge WHERE buddy_id=? AND workspace_id=? AND scope_kind=? AND scope_id=? AND kind=? AND name=?')
        .get(target, authority.workspaceId, kind, scopeId, docKind, name);
      if (row) return { id: row.id, ref, revision: row.revision, content: row.content };
      const empty = { id: null, ref, revision: 0, content: '' };
      // Snapshot inherited owner memory once. Every consumer sees this same head,
      // including its CAS revision; a team audience never reaches legacy memory.
      if (kind === 'owner_thread' && ['working', 'long_term'].includes(docKind)) {
        const memory = this.readBuddyMemory(target);
        const content = docKind === 'working' ? memory.working : memory.longTerm;
        if (!content) return empty;
        const saved = saveDocument(this, ref, { content, reason: 'Initialize owner-thread memory from authorized legacy head' },
          { ...authority, actor: 'system:inherit', provenance: { legacyRevision: docKind === 'working' ? memory.workingRevision : memory.longTermRevision } }, empty);
        return { id: saved.id, ref, revision: saved.revision, content };
      }
      if (kind === 'owner_thread' && docKind === 'soul') {
        const soul = this.readBuddySoul(target);
        return { ...empty, content: soul.body, revision: soul.revision };
      }
      return empty;
    });
  },
  replaceKnowledgeDocument(ref, input, authority) {
    return this.coordinationTransaction(() => {
      authorize(this, ref, authority, true); // recheck before replay as well
      if (typeof input.content !== 'string' || input.content.length > (MEMORY_DOCUMENT_CAPS[ref.kind] ?? 32000) || !input.reason?.trim())
        throw new Error('Knowledge requires bounded content and a reason');
      return this.coordinationCommand({ actor: authority.actor, workspaceId: authority.workspaceId, key: input.key,
        payload: { operation: 'knowledge.replace', ref, ...input } }, () => {
        const before = this.readKnowledgeDocument(ref, authority);
        if (before.revision !== input.baseRevision) throw Object.assign(new Error('Knowledge revision conflict; read and reconcile.'), { code: 'REVISION_CONFLICT', current_content: before.content, current_version: before.revision });
        if (ref.kind === 'note' && before.revision) throw new Error('Notes are append-only; use a new name');
        return saveDocument(this, ref, input, authority, before);
      });
    });
  },
  listKnowledgeDocuments({ targetBuddyId = authority.actor, scope, pattern = '', limit = 20, since, kinds }, authority) {
    authorize(this, { targetBuddyId: authority.actor === 'owner' ? targetBuddyId : authority.actor, scope, kind: 'working' }, authority);
    const [, kind, scopeId] = identity({ targetBuddyId, scope, kind: 'working' });
    const rows = this.db.prepare(`SELECT * FROM buddy_knowledge WHERE workspace_id=? AND scope_kind=? AND scope_id=?
      AND (buddy_id=? OR kind IN ('shared','soul')) ORDER BY updated_at DESC,id`).iterate(authority.workspaceId,kind,scopeId,targetBuddyId);
    const documents = [];
    for (const row of rows) {
      const ref = { targetBuddyId: row.buddy_id, scope, kind: row.kind, ...(row.name ? { name: row.name } : {}) };
      try { authorize(this, ref, authority); } catch { continue; }
      if (kinds && !kinds.includes(row.kind)) continue;
      if (since && row.updated_at < since) continue;
      if (!row.content.includes(pattern) && !row.name.includes(pattern)) continue;
      documents.push({ id: row.id, ref, revision: row.revision, content: row.content });
      if (documents.length >= Math.min(100, Math.max(1, limit))) break;
    }
    return documents;
  },
  listKnowledgeScopes(targetBuddyId, authority) {
    const scopes = [{ kind: 'workspace', workspaceId: authority.workspaceId }];
    for (const row of this.db.prepare('SELECT DISTINCT scope_kind,scope_id FROM buddy_knowledge WHERE buddy_id=? AND workspace_id=? ORDER BY scope_kind,scope_id').all(targetBuddyId,authority.workspaceId)) {
      const scope = row.scope_kind === 'owner_thread' ? { kind: row.scope_kind, conversationId: row.scope_id }
        : row.scope_kind === 'project' ? { kind: row.scope_kind, projectId: row.scope_id } : {kind: row.scope_kind, workspaceId: row.scope_id};
      if (row.scope_kind !== 'workspace') scopes.push(scope);
    }
    return scopes.filter(scope => {
      try { authorize(this, { targetBuddyId, scope, kind: 'working' }, authority); return true; } catch { return false; }
    });
  },
  knowledgeAudienceRevision(authority) {
    const { actor, workspaceId, scope } = authority;
    if (!scope) deny();
    const ref = {targetBuddyId: actor, kind:'working',scope};
    authorize(this,ref,authority);
    // Hash disclosure authority, not the rows that happen to store it. Scheduler
    // pauses/limits and another employee's permissions do not change this reader.
    const membership = this.getCoordinationMembership(actor, workspaceId);
    const projects = this.db.prepare('SELECT id FROM owned_projects WHERE workspace_id=? ORDER BY id')
      .all(workspaceId).filter(project => this.canReadCoordinationProject(actor, project.id));
    // Use the canonical predicate so inherited project access, grant expiry,
    // target membership and employment status are reflected without hashing
    // unrelated global relationships, grant reasons or revision counters.
    const grants = this.db.prepare('SELECT target_id,capabilities FROM buddy_access_grants WHERE workspace_id=? AND grantee_id=? ORDER BY target_id')
      .all(workspaceId, actor).map(grant => ({
        target: grant.target_id,
        capabilities: JSON.parse(grant.capabilities).filter(capability => this.buddyCapability({
          actor, workspaceId, targetBuddyId: grant.target_id === workspaceId ? undefined : grant.target_id, capability,
        }).allowed).sort(),
      })).filter(grant => grant.capabilities.length);
    const [,kind,scopeId] = identity(ref);
    // Content learning preserves continuity. Only disclosure edits and access
    // changes invalidate reuse. Derive the last retraction from immutable revisions;
    // adding published content never discards a same-audience conversation.
    const documents = this.db.prepare(`SELECT k.id,MAX(r.revision) AS revision FROM buddy_knowledge k
      JOIN buddy_knowledge_revisions r ON r.document_id=k.id
      JOIN buddy_knowledge_revisions prior ON prior.document_id=k.id AND prior.revision=r.revision-1
      WHERE k.workspace_id=? AND k.scope_kind=? AND k.scope_id=? AND (k.buddy_id=? OR k.kind IN ('shared','soul'))
      AND (r.author='owner' OR k.kind IN ('shared','soul')) AND prior.content<>'' AND instr(r.content,prior.content)=0
      GROUP BY k.id ORDER BY k.id`).all(workspaceId,kind,scopeId,actor);
    // Removing a publisher from the workspace retracts its documents even when
    // the document revisions themselves have not changed. Additions remain safe
    // for continuity; only currently unavailable publishers enter this fence.
    const unavailablePublishers = this.db.prepare(`SELECT DISTINCT buddy_id FROM buddy_knowledge
      WHERE workspace_id=? AND scope_kind=? AND scope_id=? AND kind IN ('shared','soul') ORDER BY buddy_id`)
      .all(workspaceId,kind,scopeId).filter(row => !this.getCoordinationMembership(row.buddy_id, workspaceId));
    return hash([actor,workspaceId,scope,documents,
      scope.kind === 'project' ? this.getBuddyProject(scope.projectId)?.buddy_id : null,
      !!membership.read_all_work, projects, grants, unavailablePublishers]);
  },
};
