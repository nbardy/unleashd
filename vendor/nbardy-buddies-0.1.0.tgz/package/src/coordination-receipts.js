import { randomUUID } from 'node:crypto';

const now = () => new Date().toISOString();

export function migrateCoordinationReceipts(db) {
  if (db.prepare('PRAGMA user_version').get().user_version >= 27) return;
  db.exec('SAVEPOINT coordination_receipts');
  try {
    for (const name of ['acknowledged_at', 'execution_snapshot'])
      if (
        !db
          .prepare('PRAGMA table_info(buddy_runs)')
          .all()
          .some((c) => c.name === name)
      )
        db.exec(`ALTER TABLE buddy_runs ADD COLUMN ${name} TEXT`);
    db.exec(`CREATE TABLE IF NOT EXISTS buddy_checkpoints (
        id TEXT PRIMARY KEY, run_id TEXT NOT NULL REFERENCES buddy_runs(id),
        buddy_id TEXT NOT NULL, workspace_id TEXT NOT NULL, project_id TEXT,
        message_id TEXT, root_message_id TEXT, created_at TEXT NOT NULL,
        artifacts TEXT NOT NULL, effects TEXT NOT NULL, resume TEXT NOT NULL, visibility TEXT NOT NULL
      ) STRICT;
      CREATE INDEX IF NOT EXISTS checkpoints_run ON buddy_checkpoints(run_id,created_at);
      CREATE INDEX IF NOT EXISTS run_recovery_origin ON buddy_runs(json_extract(policy,'$.recovery_origin_message_id'));
      CREATE INDEX IF NOT EXISTS run_recovery_message ON buddy_runs(json_extract(policy,'$.recovery_of_message_id'));
      PRAGMA user_version=27; RELEASE coordination_receipts;`);
  } catch (error) {
    db.exec('ROLLBACK TO coordination_receipts; RELEASE coordination_receipts');
    throw error;
  }
}

export const coordinationReceiptMethods = {
  previewCoordinatedMessage(input, authority) {
    let preview;
    const rollback = new Error('preview rollback');
    try {
      this.coordinationTransaction(() => {
        const message = this.sendCoordinatedMessage(input, authority);
        const run = this.listBuddyRuns({
          buddyId: message.to_buddy_id,
          workspaceId: message.workspace_id,
          accept: (r) => r.input_id === message.id,
          limit: 1,
        })[0];
        preview = {
          preview: true,
          recipientId: message.to_buddy_id,
          workspaceId: message.workspace_id,
          projectId: message.buddy_project_id,
          conversationId: message.child_conversation_id,
          effectiveTurnCapSeconds: run?.policy.max_runtime_seconds ?? 600,
          admission: message.to_buddy_id
            ? this.inspectBuddyAdmission({
                buddyId: message.to_buddy_id,
                workspaceId: message.workspace_id,
                conversationId: message.child_conversation_id ?? undefined,
              })
            : null,
        };
        throw rollback;
      });
    } catch (error) {
      if (error !== rollback) throw error;
    }
    return preview;
  },

  recordRunExecution(id, claimToken, snapshot) {
    return this.coordinationTransaction(() => {
      const run = this.getBuddyRun(id);
      if (
        !run ||
        !['claimed', 'running'].includes(run.status) ||
        run.claim_token !== claimToken ||
        run.deadline <= now()
      )
        throw new Error('Run authority expired');
      this.db
        .prepare(
          'UPDATE buddy_runs SET execution_snapshot=COALESCE(execution_snapshot,?) WHERE id=?',
        )
        .run(JSON.stringify(snapshot), id);
    });
  },

  checkpointBuddyRun(
    id,
    { key, claimToken, artifacts, effects, resume, visibility = 'participants' },
  ) {
    const run = this.getBuddyRun(id);
    if (
      !run ||
      !key ||
      !Array.isArray(artifacts) ||
      !artifacts.length ||
      artifacts.length > 16 ||
      !Array.isArray(effects) ||
      effects.length > 16 ||
      typeof resume !== 'string' ||
      !resume.trim() ||
      resume.length > 4000
    )
      throw new Error('Invalid checkpoint');
    if (!['participants', 'team'].includes(visibility))
      throw new Error('Invalid checkpoint audience');
    for (const a of artifacts) {
      if (
        !a ||
        typeof a.ref !== 'string' ||
        !a.ref.trim() ||
        a.ref.length > 4000 ||
        typeof a.version !== 'string' ||
        !a.version.trim() ||
        a.version.length > 200 ||
        (a.sha256 != null && !/^[a-f0-9]{64}$/.test(a.sha256))
      )
        throw new Error('Invalid artifact reference/version/digest');
    }
    if (effects.some((e) => typeof e !== 'string' || !e.trim() || e.length > 4000))
      throw new Error('Invalid effect note');
    return this.withBuddyRunAuthority(id, claimToken, 'buddy.checkpoint', () =>
      this.coordinationCommand(
        {
          actor: run.buddy_id,
          workspaceId: run.workspace_id,
          key,
          payload: { id, artifacts, effects, resume, visibility },
        },
        () => {
          const checkpointId = `checkpoint_${randomUUID()}`;
          this.db
            .prepare('INSERT INTO buddy_checkpoints VALUES (?,?,?,?,?,?,?,?,?,?,?,?)')
            .run(
              checkpointId,
              id,
              run.buddy_id,
              run.workspace_id,
              run.project_id,
              run.input_kind === 'message_request' ? run.input_id : null,
              run.root_message_id,
              now(),
              JSON.stringify(artifacts),
              JSON.stringify(effects),
              resume,
              visibility,
            );
          this.recordAuditEvent({
            buddy: run.buddy_id,
            workspace: run.workspace_id,
            project: run.project_id,
            operation: 'buddy.checkpoint',
            payload: { checkpointId, runId: id },
          });
          return this.listRunCheckpoints(id).find((c) => c.id === checkpointId);
        },
      ),
    );
  },

  listRunCheckpoints(runId) {
    return this.db
      .prepare('SELECT * FROM buddy_checkpoints WHERE run_id=? ORDER BY created_at,rowid')
      .all(runId)
      .map((c) => ({
        ...c,
        artifacts: JSON.parse(c.artifacts),
        effects: JSON.parse(c.effects),
      }));
  },

  getMessageDeliveries(messageId) {
    return this.db
      .prepare(`SELECT id FROM buddy_runs WHERE (input_kind='message_reply' AND input_id=?)
      OR (input_kind='failure_notice' AND input_id IN (SELECT id FROM buddy_runs WHERE input_id=?))
      ORDER BY created_at,rowid`)
      .all(messageId, messageId)
      .map(({ id }) => {
        const r = this.getBuddyRun(id);
        return {
          runId: r.id,
          kind: r.input_kind,
          attempt: r.attempt,
          state: r.status,
          acknowledgedAt: r.acknowledged_at ?? null,
          createdAt: r.created_at,
          endedAt: r.ended_at,
          errorCode: r.error_code,
          error: r.error,
          retryOfRunId: r.retry_of_run_id,
        };
      });
  },

  getBuddyRunRecovery(id, actor) {
    const run = this.getBuddyRun(id);
    if (!run) throw new Error('Run not found');
    const inputRun = run.input_kind === 'failure_notice' ? this.getBuddyRun(run.input_id) : run;
    const message = inputRun ? this.getMessage(inputRun.input_id) : null;
    const root = run.root_message_id ? this.getMessage(run.root_message_id) : null;
    const controllerBuddyIds = [
      ...new Set(
        [
          message?.from_buddy_id,
          root?.from_buddy_id,
          ...(run.input_kind !== 'message_request' ? [run.buddy_id] : []),
        ].filter(Boolean),
      ),
    ];
    const work = run.input_kind === 'message_request' ? this.getBackgroundWork(run.input_id) : null;
    const remainingRuns = work ? Math.max(0, work.execution.maxRuns - work.runsUsed) : null;
    const remainingSeconds = work?.deadline
      ? Math.max(0, Math.floor((Date.parse(work.deadline) - Date.now()) / 1000))
      : (work?.execution.maxDurationSeconds ?? null);
    const successorRun = this.db
      .prepare(
        "SELECT id FROM buddy_runs WHERE json_extract(policy,'$.recovery_of_message_id')=? ORDER BY rowid LIMIT 1",
      )
      .get(message?.id ?? '');
    const closedTimeout =
      !!work &&
      message?.status === 'replied' &&
      message.outcome === 'failed' &&
      run.status === 'failed' &&
      run.error_code === 'max_runtime_timeout' &&
      work.latest?.id === run.id;
    let reason = null;
    if (
      actor !== 'owner' &&
      (!controllerBuddyIds.includes(actor) ||
        !this.getCoordinationMembership(actor, run.workspace_id))
    )
      reason = 'Only the original input sender or root requester can recover this branch';
    else if (
      actor !== 'owner' &&
      run.project_id &&
      run.input_kind === 'message_request' &&
      message?.expects_reply !== 0 &&
      !this.canManageCoordinationProject(actor, run.project_id)
    )
      reason = 'Current project supervision is required to recover work';
    else if (run.input_kind === 'chat') reason = 'Retry owner messages from their conversation';
    else if (!['failed', 'cancelled'].includes(run.status))
      reason = 'Only failed or cancelled attempts can be retried';
    else if (root?.root_stopped_at) reason = 'Stopped roots cannot be retried';
    else if (successorRun) reason = `Recovery already exists: ${successorRun.id}`;
    else if (closedTimeout && this.getBuddyProject(run.project_id)?.status === 'done')
      reason = 'Project is already complete';
    else if (
      closedTimeout &&
      this.db
        .prepare(
          "SELECT 1 FROM buddy_messages m JOIN buddy_runs r ON r.input_id=m.id WHERE m.buddy_project_id=? AND m.id<>? AND m.status IN ('pending','active') AND r.input_kind='message_request' AND json_extract(r.policy,'$.execution.mode')='until_done' LIMIT 1",
        )
        .get(run.project_id, message.id)
    )
      reason = 'Project already has open managed work';
    else if (
      this.db
        .prepare(
          "SELECT 1 FROM buddy_runs WHERE input_key=? AND status IN ('queued','claimed','running','cancel_requested')",
        )
        .get(run.input_key)
    )
      reason = 'Input already has a live attempt';
    else if (work && (remainingRuns === 0 || remainingSeconds === 0))
      reason = 'Original managed work limits are exhausted';
    else if (
      run.input_kind === 'message_request' &&
      (message?.superseded_by_message_id ||
        message?.status === 'cancelled' ||
        (message?.status === 'replied' && !closedTimeout))
    )
      reason = 'Request is no longer open';
    else {
      try {
        this.assertProjectExecution(run.project_id, run.project_epochs, {
          admission: true,
        });
      } catch (error) {
        reason = error.message;
      }
    }
    return {
      controllerBuddyIds,
      mode: closedTimeout ? 'successor_request' : 'attempt',
      successorRunId: successorRun?.id ?? null,
      canRetry: !reason,
      reason,
      remainingRuns,
      remainingSeconds,
      checkpointIds: this.listRunCheckpoints(id).map((c) => c.id),
      action: !reason ? { operation: 'retry_run', runId: id, requires: ['key', 'reason'] } : null,
    };
  },

  recoverClosedBackgroundMessage(run, { key, reason, checkpointId, conversationId }) {
    if (!reason?.trim())
      throw new Error('Recovery of a closed timeout requires a reason after inspecting effects');
    const old = this.getMessage(run.input_id);
    const message = this.sendMessage({
      fromBuddy: old.from_buddy_id,
      to: old.to_buddy_id,
      workspace: old.workspace_id,
      purpose: old.purpose,
      body: old.body,
      evidence: old.evidence,
      parentConversationId: old.parent_conversation_id,
    });
    this.db
      .prepare(`UPDATE buddy_messages SET buddy_project_id=?,source_project_id=?,source_workspace_id=?,
      root_message_id=?,caused_by_run_id=?,expects_reply=1,visibility=?,child_conversation_id=?,
      return_policy=?,command_key=?,status='active' WHERE id=?`)
      .run(
        old.buddy_project_id,
        old.source_project_id,
        old.source_workspace_id,
        old.root_message_id ?? old.id,
        old.caused_by_run_id,
        old.visibility,
        conversationId ?? run.conversation_id,
        old.return_policy,
        key,
        message.id,
      );
    const successor = this.enqueueBuddyRun({
      inputKey: `message:${message.id}:request`,
      inputKind: 'message_request',
      inputId: message.id,
      buddyId: run.buddy_id,
      workspaceId: run.workspace_id,
      conversationId: conversationId ?? run.conversation_id,
      projectId: run.project_id,
      rootMessageId: run.root_message_id,
      policy: {
        ...run.policy,
        max_runtime_seconds:run.policy.max_runtime_seconds ?? Math.min(3600,run.policy.execution.maxDurationSeconds),
        recovery_of_message_id: old.id,
        recovery_origin_message_id: run.policy.recovery_origin_message_id ?? old.id,
        ...(checkpointId ? { recovery_checkpoint_id: checkpointId } : {}),
      },
    });
    this.db.prepare('UPDATE buddy_runs SET retry_of_run_id=? WHERE id=?').run(run.id, successor.id);
    this.recordAuditEvent({
      buddy: old.from_buddy_id,
      workspace: run.workspace_id,
      project: run.project_id,
      operation: 'buddy.recover_closed_timeout',
      payload: {
        sourceMessageId: old.id,
        messageId: message.id,
        runId: successor.id,
        retryOfRunId: run.id,
        reason,
      },
    });
    return this.getBuddyRun(successor.id);
  },

  retryUndeliveredInputs() {
    // Only a recorded failure before admission is safe for automatic replay.
    const rows = this.db
      .prepare(`SELECT id FROM buddy_runs WHERE status='failed'
      AND acknowledged_at IS NULL AND error_code='delivery_pre_admission'
      AND attempt<3 AND ended_at<=? ORDER BY created_at,id LIMIT 100`)
      .all(new Date(Date.now() - 1000).toISOString());
    for (const { id } of rows) {
      const r = this.getBuddyRun(id);
      if (
        this.db
          .prepare('SELECT 1 FROM buddy_runs WHERE input_key=? AND attempt>?')
          .get(r.input_key, r.attempt)
      )
        continue;
      try {
        this.retryBuddyRun(id, {
          actor: 'owner',
          key: `delivery-retry:${id}`,
          reason: 'Retry known pre-admission delivery failure',
        });
      } catch {
        /* Terminal fences and exhausted budgets remain inspectable. */
      }
    }
  },
};
