export type BuddyStatus = "active" | "paused" | "archived";
export type SprintStatus = "planned" | "active" | "completed" | "cancelled";
export type WorkItemStatus =
  | "backlog" | "ready" | "in_progress" | "blocked" | "review" | "done" | "cancelled";
export type BuddyProjectStatus = WorkItemStatus;
export type BuddyTodoStatus = "open" | "in_progress" | "blocked" | "done" | "cancelled";
export type ConversationStatus = "active" | "complete" | "failed" | "cancelled";
export type AutomationScheduleKind = "cron" | "interval";
export type AutomationJobKind = "prompt" | "sequence" | "loop";
export type AutomationRunStatus =
  | "claimed"
  | "running"
  | "cancel_requested"
  | "complete"
  | "failed"
  | "cancelled";
export type BuddyRelationshipKind = "manager" | "reports_to" | "consults" | "reviews";
export type BuddySkillMode = "always" | "on_demand";
export type DelegationStatus = "pending" | "active" | "complete" | "failed" | "cancelled";
export type ReviewStatus = "draft" | "complete" | "cancelled";
export type ReviewVerdict = "needs_work" | "pass" | "fail";
export type ApprovalStatus = "pending" | "approved" | "rejected";

export interface Workspace {
  id: string;
  slug: string;
  name: string;
  root_path: string;
  created_at: string;
  updated_at: string;
  assignment_role?: string | null;
}
/** @deprecated Use Workspace. */
export type Project = Workspace;

export interface Buddy {
  employment_mode: "standing" | "worker";
  id: string;
  project_id: string;
  slug: string;
  name: string;
  role: string;
  status: BuddyStatus;
  soul_path: string | null;
  memory_path: string | null;
  provider: string | null;
  model: string | null;
  reasoning_effort: string | null;
  /** Legacy compatibility field. It no longer limits hiring or management relationships. */
  hire_quota: number;
  profile_revision: number;
  created_at: string;
  updated_at: string;
}

export interface BuddyBuilderCreationResult {
  creationKey: string;
  buddy: Buddy;
  homeWorkspace: Workspace;
  workspaces: Workspace[];
  requestFingerprint: string;
  replayed: boolean;
}

export interface Sprint {
  id: string;
  project_id: string;
  name: string;
  goal: string | null;
  status: SprintStatus;
  starts_at: string | null;
  ends_at: string | null;
  created_at: string;
  updated_at: string;
  project_slug?: string;
}

export interface BuddyTodo {
  id: string;
  buddy_project_id: string;
  title: string;
  status: BuddyTodoStatus;
  position: number;
  definition_of_done: string | null;
  completion_evidence: string[];
  next_action: string | null;
  blocked_reason: string | null;
  created_at: string;
  updated_at: string;
  completed_at: string | null;
}

export interface BuddyProject {
  parent_project_id:string|null;revision:number;execution_state:'enabled'|'paused'|'draining'|'cancelled';execution_epoch:number;pending_owner_id:string|null;completion_evidence:string;
  id: string;
  workspace_id: string;
  buddy_id: string;
  sprint_id: string | null;
  title: string;
  objective: string | null;
  definition_of_done: string;
  status: BuddyProjectStatus;
  priority: number;
  next_action: string | null;
  blocked_reason: string | null;
  source_path: string | null;
  external_key: string | null;
  created_at: string;
  updated_at: string;
  completed_at: string | null;
  todos?: BuddyTodo[];
  workspace_name?: string;
  workspace_slug?: string;
  buddy_name?: string;
  sprint_name?: string | null;
}
export type BuddyProjectWithTodos = BuddyProject & { todos: BuddyTodo[] };
export interface BuddyTaskComment {
  id: string;
  project_id: string;
  author: string;
  body: string;
  evidence: string[];
  created_at: string;
}

export interface WorkItem {
  id: string;
  project_id: string;
  sprint_id: string | null;
  buddy_id: string | null;
  title: string;
  kind: string;
  external_key: string | null;
  source_path: string | null;
  objective: string | null;
  definition_of_done: string;
  status: WorkItemStatus;
  priority: number;
  next_action: string | null;
  blocked_reason: string | null;
  created_at: string;
  updated_at: string;
  completed_at: string | null;
  buddy_name?: string | null;
  sprint_name?: string | null;
}

export interface ConversationLink {
  id: string;
  buddy_id: string;
  workspace_id: string;
  buddy_project_id: string | null;
  work_item_id: string | null;
  provider: string;
  provider_session_id: string | null;
  unleashd_conversation_id: string | null;
  status: ConversationStatus;
  started_at: string;
  last_active_at: string;
  ended_at: string | null;
  claim_token: string | null;
  claim_expires_at: string | null;
  claim_acquired?: boolean;
}

export interface BuddyRelationship {
  id: string; from_buddy_id: string; to_buddy_id: string;
  kind: BuddyRelationshipKind; created_at: string;
  from_buddy_name?: string; to_buddy_name?: string;
}
export interface BuddySkill {
  id: string; buddy_id: string; name: string; instruction_path: string;
  mode: BuddySkillMode; created_at: string; updated_at: string;
}
export interface BuddyDelegation {
  id: string; from_buddy_id: string; to_buddy_id: string; workspace_id: string;
  buddy_project_id: string | null; purpose: string;
  parent_conversation_id: string | null; child_conversation_id: string | null;
  status: DelegationStatus; outcome: string | null; created_at: string;
  updated_at: string; completed_at: string | null;
  dispatch_token: string | null; dispatch_expires_at: string | null;
  dispatch_claim_acquired?: boolean;
}
export interface BuddyReview {
  id: string; reviewer_buddy_id: string; subject_buddy_id: string;
  workspace_id: string; buddy_project_id: string | null;
  conversation_id: string | null; status: ReviewStatus;
  verdict: ReviewVerdict | null; score: number | null; summary: string | null;
  evidence: unknown[]; created_at: string; updated_at: string;
  completed_at: string | null;
}

export interface BuddyAuditEvent {
  id: string;
  buddy_id: string;
  workspace_id: string;
  buddy_project_id: string | null;
  operation: string;
  payload: unknown;
  created_at: string;
}

export interface BuddyActivity {
  id: string;
  buddy_id: string;
  workspace_id: string;
  buddy_project_id: string | null;
  operation: string;
  created_at: string;
  project_title: string | null;
}

export interface BuddyApprovalRequest {
  id: string;
  buddy_id: string;
  workspace_id: string;
  buddy_project_id: string | null;
  automation_run_id: string | null;
  conversation_id: string | null;
  action: string;
  reason: string;
  risk: string;
  status: ApprovalStatus;
  resolved_by: string | null;
  resolution_note: string | null;
  requested_at: string;
  resolved_at: string | null;
}

export type AutomationAllowedOperation =
  | "buddy.get_current_work"
  | "buddy.get_inbox"
  | "buddy.get_automations"
  | "buddy.set_automation"
  | "buddy.new_project"
  | "buddy.update_project"
  | "buddy.append_task_comment"
  | "buddy.list_task_comments"
  | "buddy.update_memory"
  | "buddy.remember_note"
  | "buddy.recall"
  | "buddy.send"
  | "buddy.reply"
  | "buddy.delegate"
  | "buddy.request_review"
  | "buddy.complete_delegation"
  | "buddy.complete_assignment"
  | "buddy.submit_review"
  | "buddy.request_human_approval";

export interface BuddyAutomationPolicy {
  max_runtime_seconds: number;
  max_iterations: number;
  max_tokens: number;
  max_cost_usd: number;
  allowed_operations: AutomationAllowedOperation[];
}

export type AutomationJobPayload =
  | { prompt: string }
  | { prompts: string[] }
  | { prompt: string; termination: {
      condition: string; max_iterations: number; max_duration_seconds: number;
    } };

export interface BuddyAutomation {
  id: string;
  buddy_id: string;
  workspace_id: string;
  buddy_project_id: string | null;
  name: string;
  schedule_kind: AutomationScheduleKind;
  schedule_expression: string;
  timezone: string;
  job_kind: AutomationJobKind;
  job_payload: AutomationJobPayload;
  policy: BuddyAutomationPolicy;
  enabled: boolean;
  archived_at: string | null;
  next_run_at: string | null;
  last_run_at: string | null;
  created_at: string;
  updated_at: string;
}

export interface BuddyAutomationRun {
  id: string;
  automation_id: string;
  scheduled_for: string;
  idempotency_key: string;
  status: AutomationRunStatus;
  conversation_id: string | null;
  iteration: number;
  tokens_used: number;
  cost_usd: number;
  policy: BuddyAutomationPolicy;
  outcome: string | null;
  error: string | null;
  claimed_at: string;
  started_at: string | null;
  ended_at: string | null;
}

export interface BuddyMemory {
  working: string;
  longTerm: string;
  workingRevision: number;
  longTermRevision: number;
  generation: number;
  summary: string;
  recentJournal: Array<{ path: string; content: string }>;
  migrationWarnings?: Array<{
    document_kind: "working" | "long_term";
    message: string;
    source_path: string | null;
  }>;
  operations?: { updateMemory: boolean; rememberNote: boolean; recall: boolean };
}

export interface BuddyMemoryRevision {
  buddy_id: string;
  document_kind: "working" | "long_term" | "soul";
  revision: number;
  base_revision_id: string | null;
  generation: number;
  body: string;
  reasoning: string;
  author_kind: string;
  requested_by: string | null;
  provenance: unknown;
  sha256: string;
  view_status: "current" | "stale";
  view_error?: string;
  created_at: string;
  updated_at: string;
}

export type ExportDocumentKind = "soul" | "working" | "long_term";
export type ExportDocumentStatus = "match" | "stale" | "missing" | "unconfigured";
export interface ExportDocumentReport {
  document: ExportDocumentKind;
  headRevision: number;
  headSha256: string;
  filePath: string | null;
  fileSha256: string | null;
  status: ExportDocumentStatus;
}
export interface ExportCheckReport {
  buddy_id: string;
  buddy_slug: string;
  clean: boolean;
  documents: ExportDocumentReport[];
}
export interface ExportFixReport extends ExportCheckReport {
  fixed: ExportDocumentKind[];
}

export interface BuddyMemoryNote {
  id: string;
  path: string;
  topic: string;
  kind: string;
  buddy_id: string;
  workspace_id: string;
  evidence: unknown[];
  content: string;
  written_at: string;
}

export interface BuddyContext {
  buddy: Buddy;
  relationships: BuddyRelationship[];
  skills: BuddySkill[];
  workspaces: Workspace[];
  workspace: Workspace | null;
  sprint: Sprint | null;
  project: BuddyProjectWithTodos | null;
  projects: BuddyProjectWithTodos[];
  legacyWorkItems: WorkItem[];
  soul: string;
  memory: BuddyMemory;
}

export interface BuddiesDashboard {
  projects: Workspace[];
  buddies: Array<Buddy & { projects: Workspace[]; conversations: ConversationLink[] }>;
  sprints: Sprint[];
  workItems: WorkItem[];
  buddyOwnedProjects: BuddyProjectWithTodos[];
}

/**
 * design §5.2. Directory membership is carried by the TYPE, not by a null.
 * `top_level` is exactly `overview().topLevel` membership.
 */
export type BuddyEmployment =
  | { kind: "top_level" }
  | { kind: "direct_report"; managerId: string };

/** design §9.1. hire canonicalizes to this sum once, then dispatches. */
export type HireTarget =
  | { kind: "vacant" }
  | { kind: "reactivatable"; sub: Buddy }
  | { kind: "held"; sub: Buddy }
  | { kind: "held_elsewhere"; sub: Buddy; managerId: string }
  | { kind: "slug_owned_by_top_level"; sub: Buddy };

/** `unchanged` is an idempotent replay: no seat consumed (design §8.1). */
export type HireOutcome = "hired" | "reactivated" | "unchanged";

export interface BuddyOverviewEmployee {
  buddy: Buddy;
  employment: BuddyEmployment;
  workspaces: Workspace[];
  team: Array<Pick<Buddy, "id" | "name" | "role" | "status">>;
  currentWork: {
    open: number;
    active: number;
    blocked: number;
    review: number;
    nextActionMissing: number;
  };
}

export interface BuddyOverview {
  generatedAt: string;
  employees: BuddyOverviewEmployee[];
  topLevel: BuddyOverviewEmployee[];
  recentRuns: Array<{
    conversationId: string;
    buddyId: string;
    buddyName: string;
    workspaceId: string;
    workspaceName: string;
    status: ConversationStatus;
    lastActiveAt: string;
  }>;
}

export interface BuddyRun {
  acknowledged_at:string|null;execution_snapshot:{provider:string;model:string|null;reasoningEffort:string|null;turnCapSeconds:number;deadline:string;limitingSource:string}|null;
  id:string; input_key:string; input_kind:string; input_id:string; attempt:number;
  buddy_id:string;workspace_id:string;conversation_id:string|null;project_id:string|null;root_message_id:string|null;
  ready_at:string;after_run_id:string|null;status:'queued'|'claimed'|'running'|'cancel_requested'|'complete'|'failed'|'cancelled';
  claim_token:string|null;claim_expires_at:string|null;deadline:string|null;created_at:string;started_at:string|null;ended_at:string|null;
  policy:{allowed_operations:string[];[key:string]:unknown};project_epochs:Array<{id:string;epoch:number}>;
  outcome:string|null;error:string|null;error_code:string|null;retry_of_run_id:string|null;
}
export type TeamCapability = 'staff.create' | 'relationship.write' | 'profile.read' | 'profile.write' | 'soul.read' | 'soul.write' | 'memory.read' | 'memory.write' | 'schedule.manage' | 'execution.manage';
export interface TeamAuthority { actor: string; workspaceId: string; conversationId?: string | null }
export interface TeamCapabilityDecision { allowed: boolean; code: string; reason: string; remedy: string | null; grantRevision?: number; expiresAt?: string | null; createdBuddyIncoming?: boolean }
export interface TeamAccessGrant { grantee_id: string; workspace_id: string; target_id: string; capabilities: TeamCapability[]; revision: number; expires_at: string | null; reason: string; updated_at: string; created_buddy_incoming: boolean }
export interface TeamProfile { buddyId: string; name: string; role: string; provider: string | null; model: string | null; reasoningEffort: string | null; revision: number }
export interface TeamProfileChange { targetBuddyId: string; key: string; baseRevision: number; reason: string; changes: {name?: string; role?: string; provider?: string; model?: string | null; reasoningEffort?: string | null; backgroundEnabled?: boolean} }
export interface TeamDocument { buddyId: string; doc: 'soul' | 'working' | 'long_term'; content: string; revision: number }
export interface BackgroundExecution {mode:'until_done';maxRuns?:number;maxDurationSeconds?:number}
export interface BackgroundExecutionView {mode:'until_done';disposition:string;maxRuns:number;maxDurationSeconds:number;runsUsed:number;startedAt:string|null;deadline:string|null;waitingMessageIds:string[]}
export interface MessageExecution { acknowledgedRunId:string|null;projectSnapshot:{id:string;revision:number;status:string;updatedAt:string;acceptedBy:string|null;acceptedAt:string|null;evidenceCount:number}|null;delivery:BuddyDelivery[]; background: BackgroundExecutionView | null; messageId: string; runId: string | null; projectId: string | null; state: string; code: string | null; reason: string | null; remedy: string | null; conversationId: string | null; acknowledgedAt: string | null; acceptedBy: string | null; acceptedAt: string | null; completionEvidence: string[]; outcome: string | null; error: string | null }

export type KnowledgeScope = { kind:'owner_thread'; conversationId:string } | {kind:'project';projectId:string} | {kind:'workspace';workspaceId:string};
export type KnowledgeRef = {targetBuddyId:string; kind:'soul'|'working'|'long_term'|'shared'|'note';scope:KnowledgeScope;name?:string};
export type KnowledgeAuthority = {actor:string;workspaceId:string;conversationId?:string;scope?:KnowledgeScope;provenance?:unknown};
export type KnowledgeDocument = {id:string|null;ref:KnowledgeRef;revision:number;content:string};
export interface MailEffect { id:string;actor_id:string;workspace_id:string;account_id:string;fingerprint:string;status:string;authorized:number;payload:Record<string,any>;provider_receipt:unknown; }
export type BuddyListAuthor = {kind:'buddy';buddyId:string} | {kind:'owner'};
export interface BuddyList { id:string;workspaceId:string;name:string;purpose:string;createdBy:BuddyListAuthor;createdAt:string; }
export interface BuddyListSummary extends BuddyList { postCount:number;latestPostAt:string|null; }
export interface BuddyListPost { id:string;listId:string;workspaceId:string;author:BuddyListAuthor;threadRootId:string|null;replyCount:number;latestReplyAt:string|null;purpose:string;body:string;evidence:string[];projectId:string|null;senderConversationId:string|null;senderRunId:string|null;createdAt:string; }
export interface BuddyListUnread { listId:string;name:string;unread:number;latestPostAt:string|null; }
export interface BuddyListRead { buddy_id:string;list_id:string;last_post_id:string;last_post_created_at:string;updated_at:string; }
export class BuddiesStore {
  prepareMailEffect(input:Record<string,unknown>,authority:{actor:string;workspaceId:string;key:string}):MailEffect;
  getMailEffect(id:string,authority:{actor:string;workspaceId:string}):MailEffect;
  authorizeMailEffect(input:{id:string;fingerprint:string;authorized:boolean;reason:string},authority:{actor:string;workspaceId:string;ownerInputId:string}):MailEffect;
  claimMailEffect(id:string,authority:{actor:string;workspaceId:string}):{claimed:boolean;effect:MailEffect};
  settleMailEffect(id:string,receipt:{status:'sent'|'not_sent'|'unknown';providerId?:string},authority:{actor:string;workspaceId:string}):MailEffect;
  recordInboundMail(input:{accountId:string;eventId:string;payload:unknown},authority:{workspaceId:string}):{accountId:string;eventId:string;duplicate:boolean};
  createList(input:{workspace:string;author:BuddyListAuthor;key:string;name:string;purpose:string}):{list:BuddyList};
  getList(id:string):BuddyList|null;
  listLists(input:{workspace:string}):BuddyListSummary[];
  createPost(input:{list:string;author:BuddyListAuthor;key:string;purpose:string;body:string;evidence?:string[];project?:string|null;threadRoot?:string|null;conversationId?:string|null;runId?:string|null}):{post:BuddyListPost};
  getPost(id:string):BuddyListPost|null;
  listPosts(input:{list?:string;workspace?:string;project?:string|null;limit?:number;offset?:number}):BuddyListPost[];
  listThread(input:{root:string;limit?:number}):{root:BuddyListPost;replies:BuddyListPost[]};
  searchPosts(input:{workspace:string;query:string;list?:string|null;author?:BuddyListAuthor|null;since?:string|null;limit?:number;offset?:number}):BuddyListPost[];
  newestListPost(input:{list:string}):BuddyListPost|null;
  listUnread(input:{buddy:string;workspace:string}):BuddyListUnread[];
  markListRead(input:{buddy:string;list:string;post:string}):BuddyListRead;
  checkKnowledgeDocument(ref:KnowledgeRef,authority:KnowledgeAuthority,write?:boolean):void;
  readKnowledgeDocument(ref:KnowledgeRef,authority:KnowledgeAuthority):KnowledgeDocument;
  replaceKnowledgeDocument(ref:KnowledgeRef,input:{key:string;baseRevision:number;content:string;reason:string},authority:KnowledgeAuthority):{id:string;ref:KnowledgeRef;revision:number;auditId:string};
  listKnowledgeDocuments(input:{targetBuddyId:string;scope:KnowledgeScope;pattern?:string;limit?:number;since?:string;kinds?:string[]},authority:KnowledgeAuthority):KnowledgeDocument[];
  listKnowledgeScopes(targetBuddyId:string,authority:KnowledgeAuthority):KnowledgeScope[];
  knowledgeAudienceRevision(authority:KnowledgeAuthority):string;
  setBuddyAccess(input: {granteeId: string; workspaceId: string; targetBuddyId?: string; capabilities: TeamCapability[]; baseRevision: number; key: string; reason: string; expiresAt?: string; createdBuddyIncoming?: boolean}): TeamAccessGrant;
  getBuddyAccess(granteeId: string, workspaceId: string, targetId: string): TeamAccessGrant | null;
  listBuddyAccess(granteeId: string, workspaceId: string): TeamAccessGrant[];
  getTeamContractVersion(): string;
  buddyCapability(input: TeamAuthority & {targetBuddyId?: string; capability: TeamCapability}): TeamCapabilityDecision;
  requireBuddyCapability(input: TeamAuthority & {targetBuddyId?: string; capability: TeamCapability}): TeamCapabilityDecision;
  createTeamBuddy(input: {name: string; role: string; soul: string; provider?: string; model?: string; reasoningEffort?: string; backgroundEnabled?: boolean; employmentMode?: "standing" | "worker"}, authority: TeamAuthority & {key: string}): BuddyBuilderCreationResult;
  setTeamRelationship(input: {fromBuddyId: string; toBuddyId: string; kind: 'manager' | 'consults'; key: string; present?: boolean}, authority: TeamAuthority): BuddyRelationship | {fromBuddyId: string; toBuddyId: string; kind: 'manager' | 'consults'; present: false};
  getTeamProfile(targetBuddyId: string): TeamProfile;
  updateTeamProfile(input: TeamProfileChange, authority: TeamAuthority): {before: TeamProfile; after: TeamProfile; execution: {backgroundEnabled: boolean}};
  readTeamDocument(input: {targetBuddyId: string; doc: 'soul' | 'working' | 'long_term'}, authority: TeamAuthority): TeamDocument;
  updateTeamDocument(input: {targetBuddyId: string; doc: 'soul' | 'working' | 'long_term'; content: string; baseVersion: number; reasoning: string; key: string; preview?: boolean}, authority: TeamAuthority): unknown;
  getMessageExecution(messageId: string): MessageExecution;
  previewCoordinatedMessage(input:Parameters<BuddiesStore['sendCoordinatedMessage']>[0],authority:Parameters<BuddiesStore['sendCoordinatedMessage']>[1]):unknown;
  recordRunExecution(id:string,token:string,snapshot:NonNullable<BuddyRun['execution_snapshot']>):void;
  checkpointBuddyRun(id:string,input:{key:string;claimToken:string;artifacts:Array<{ref:string;version:string;sha256?:string|null}>;effects:string[];resume:string;visibility?:'participants'|'team'}):BuddyCheckpoint;
  listRunCheckpoints(id:string):BuddyCheckpoint[];
  getBuddyRunRecovery(id:string,actor:string):BuddyRecovery;
  getMessageDeliveries(id:string):BuddyDelivery[];
  retryUndeliveredInputs():void;
  reconcileBackgroundWork(messageId?: string): MessageExecution[];
  getProjectBackgroundExecution(projectId:string):{message:BuddyMessage;runs:BuddyRun[]}|null;

  coordinationTransaction<T>(callback:()=>T):T;
  coordinationCommand<T>(input:{actor:string;workspaceId:string;key:string;payload:unknown},callback:()=>T):T;
  getCoordinatedMessageByKey(actor:string,workspaceId:string,key:string):BuddyMessage|null;
  beginBuddyChatRun(input:{buddyId:string;workspaceId:string;conversationId:string;projectId?:string;allowedOperations:string[];maxRuntimeSeconds?:number}):BuddyRun;
  sendCoordinatedMessage(input:Omit<Parameters<BuddiesStore['sendMessage']>[0], 'project'> & {config?:unknown;execution?:BackgroundExecution;project?:string|null;visibility?:'participants'|'project';key:string;continueFrom?:string;inReplyTo?:string;expectsReply?:boolean;notBefore?:string;approval?:unknown},authority?:{policy:BuddyRun['policy'];runId?:string;sourceProjectId?:string;sourceWorkspaceId?:string;returnConversationId?:string;assignmentConfig?:unknown;launch?:{through_message_id:string;tool_call_id?:string}}):BuddyMessage;
  enqueueBuddyRun(input:{inputKey:string;inputKind:string;inputId:string;buddyId:string;workspaceId:string;conversationId?:string;projectId?:string;rootMessageId?:string;readyAt?:string;afterRunId?:string;policy?:BuddyRun['policy']}):BuddyRun;
  getBuddyRun(id:string):BuddyRun|null;
  listBuddyRuns(input?:{order?:'newest'|'oldest';buddyId?:string;workspaceId?:string;conversationId?:string;projectId?:string;rootMessageId?:string;status?:BuddyRun['status'];limit?:number;offset?:number;accept?:(run:BuddyRun)=>boolean}):BuddyRun[];
  claimBuddyRun(id:string,input:{claimToken:string;conversationId?:string;maxRuntimeSeconds?:number;now?:string}):BuddyRun|null;
  startBuddyRun(id:string,token:string):BuddyRun;
  withBuddyRunAuthority<T>(id:string,token:string,operation:string,callback:(run:BuddyRun)=>T):T;
  finishBuddyRun(id:string,input:{claimToken:string;status:'complete'|'failed'|'cancelled';outcome?:string;error?:string;errorCode?:string}):BuddyRun;
  ensureInterruptionReport(sourceRunId:string):BuddyRun|null;
  reconcileInterruptionReports(at?:string):BuddyRun[];
  cancelBuddyRun(id:string):BuddyRun|null;
  stopBuddyMessageRoot(id:string):BuddyRun[];
  holdBuddyRun(id:string,reason:string):void;
  retryBuddyRun(id:string,input:{key:string;conversationId?:string;actor?:string;reason?:string;checkpointId?:string}):BuddyRun;
  repairBuddyRun(id:string,input:{key:string;conversationId:string}):BuddyRun;
  recoverBuddyRuns(input:{now?:string;confirmedDrainedIds:string[]}):BuddyRun[];
  getCoordinationMembership(buddyId:string,workspaceId:string):Record<string,unknown>|null;
  setCoordinationMembership(buddyId:string,workspaceId:string,patch:Record<string,unknown>):Record<string,unknown>;
  createCoordinatedProject(input:Omit<Parameters<BuddiesStore['newProject']>[0], 'buddy' | 'workspace'> & {
    workspaceId:string; ownerId?:string; parentProjectId?:string;
  },authority:{actor:string;key:string}):BuddyProjectWithTodos;
  appendTaskComment(input:{projectId:string;key:string;body:string;evidence?:string[]},authority:{actor:string;workspaceId:string;runId?:string}):BuddyTaskComment;
  listTaskComments(input:{projectId:string;limit?:number;cursor?:string},authority:{actor:string;workspaceId:string;runId?:string}):{items:BuddyTaskComment[];nextCursor:string|null};
  updateCoordinatedProject(id:string,input:Record<string,unknown>,authority:{actor:string;key:string;runId?:string}):BuddyProject;
  canReadCoordinationProject(buddyId:string,projectId:string):boolean;
  canManageCoordinationProject(buddyId:string,projectId:string):boolean;
  finishProjectHandoffs():string[];
  reparentBuddy(buddyId:string,input:{managerId:string;key:string}):unknown;

  sendMessage(input: { fromBuddy: string; to: string; workspace: string; project?: string; purpose: string; body: string; evidence?: string[]; parentConversationId?: string; waitUntil?: string }): BuddyMessage;
  getMessage(id: string): BuddyMessage | null;
  listMessages(input?: { buddy?: string; workspace?: string; toOwner?: boolean; limit?: number; offset?: number; order?: 'attention' | 'recent'; accept?: (message: BuddyMessage) => boolean }): BuddyMessage[];
  bindMessageConversation(id: string, conversationId: string): BuddyMessage;
  replyMessage(id: string, input: { buddy: string; conversationId: string; outcome: string; body: string; evidence: string[] }): BuddyMessage;
  replyToOwnerMessage(id: string, input: { outcome: string; body: string; evidence: string[] }): BuddyMessage;
  finishMessageWait(id: string, status?: 'cancelled' | 'timed_out'): BuddyMessage;
  cancelConversationMessageWaits(conversationId: string): number;
  finishConversationMessages(conversationId: string, reason?: string): number;
  failMessage(id: string, error: string): BuddyMessage;

  constructor(databasePath?: string);
  databasePath: string;
  close(): void;
  backupDatabase(destination: string): {
    database: string; backup: string; schemaVersion: number; createdAt: string;
  };
  createProject(input: { name: string; rootPath: string; slug?: string }): Workspace;
  getProject(idOrSlug: string): Workspace | null;
  listProjects(): Workspace[];
  createWorkspace(input: { name: string; rootPath: string; slug?: string }): Workspace;
  getWorkspace(idOrSlug: string): Workspace | null;
  listWorkspaces(): Workspace[];
  createBuddy(input: {
    project: string; name: string; role: string; slug?: string; status?: BuddyStatus;
    soulPath?: string; memoryPath?: string; provider?: string; model?: string;
    reasoningEffort?: string; hireQuota?: number;
  }): Buddy;
  createBuddyFromBuilder(input: {
    conversationId: string;
    creationKey?: string;
    requestFingerprint: string;
    project: string;
    additionalWorkspaces?: string[];
    managerBuddyId?: string;
    backgroundEnabled?: boolean;
    name: string;
    role: string;
    slug?: string;
    status?: BuddyStatus;
    soul?: string;
    provider?: string;
    model?: string;
    reasoningEffort?: string;
  }): BuddyBuilderCreationResult;
  getBuddyBuilderResult(conversationId: string, creationKey?: string): BuddyBuilderCreationResult | null;
  listBuddyBuilderResults(conversationId: string): BuddyBuilderCreationResult[];
  getBuddy(idOrSlug: string, project?: string): Buddy | null;
  updateBuddy(idOrSlug: string, changes?: Partial<{
    name: string; role: string; status: BuddyStatus; homeWorkspace: string;
    soulPath: string | null;
    memoryPath: string | null; provider: string | null; model: string | null;
    reasoningEffort: string | null; hireQuota: number;
  }>): Buddy;
  listBuddies(project?: string): Buddy[];
  assignBuddyToProject(input: { buddy: string; project: string; role?: string }): Workspace[];
  listBuddyProjects(buddy: string): Workspace[];
  assignBuddyToWorkspace(input: { buddy: string; workspace: string; role?: string }): Workspace[];
  listBuddyWorkspaces(buddy: string): Workspace[];
  /**
   * design §7.4. The only way to move `owned_projects.buddy_id`; re-checks that the
   * new owner belongs to the project's workspace and writes an audit event.
   */
  reassignOwnedProject(input: { project: string; toBuddy: string }): BuddyProjectWithTodos;
  /**
   * design §8.3. `reports_to A->B` is normalized to `manager B->A` on write, so the
   * returned row's `kind` is `manager` with `from`/`to` swapped.
   */
  setBuddyRelationship(input: {
    fromBuddy: string; toBuddy: string; kind: BuddyRelationshipKind;
  }): BuddyRelationship;
  /** design §7.5. Non-archived direct reports, deduped across both edge encodings. */
  countHeldDirectReports(manager: string): number;
  getBuddyTeamState(buddy: string): {
    employment: BuddyEmployment;
    manager: Pick<Buddy, "id" | "name" | "role" | "status"> | null;
    team: Array<Pick<Buddy, "id" | "name" | "role" | "status">>;
  };

  /** design §9.1. The single canonicalizer hire dispatches on. */
  resolveHireTarget(manager: string, slug: string, workspace: string): HireTarget;
  hireDirectReport(input: {
    managerBuddy: string; name: string; role: string; soul: string; workspace: string;
    additionalWorkspaces?: string[]; provider?: string; model?: string;
    reasoningEffort?: string;
  }): { buddy: Buddy; outcome: HireOutcome };
  retireDirectReport(input: {
    managerBuddy: string; subBuddy: string; reason?: string; reassignOpenWorkTo?: string;
  }): {
    buddy: Buddy;
    reassignedProjects: number;
    disabledAutomations: number;
    cancelledDelegations: number;
    cancelledReviews: number;
  };
  removeBuddyRelationship(id: string): boolean;
  listBuddyRelationships(buddy: string): BuddyRelationship[];
  recordAuditEvent(input: {
    buddy: string; workspace: string; project?: string;
    operation: string; payload?: unknown;
  }): BuddyAuditEvent;
  listBuddyActivity(input: {
    buddy: string; workspace?: string; project?: string; limit?: number;
  }): BuddyActivity[];
  summarizeMemoryWrites(input: {
    buddy: string; conversationId: string; since: string;
  }): { notes: number; working: number; longTerm: number };
  getAuditEvent(id: string): BuddyAuditEvent | null;
  listAuditEvents(input?: {
    buddy?: string; workspace?: string; project?: string; limit?: number;
  }): BuddyAuditEvent[];
  createApprovalRequest(input: {
    buddy: string; workspace: string; project?: string; automationRun?: string;
    conversationId?: string; action: string; reason: string; risk: string;
  }): BuddyApprovalRequest;
  getApprovalRequest(id: string): BuddyApprovalRequest | null;
  listApprovalRequests(input?: {
    buddy?: string; workspace?: string; project?: string; status?: ApprovalStatus;
    limit?: number;
  }): BuddyApprovalRequest[];
  resolveApprovalRequest(id: string, input: {
    decision: "approved" | "rejected"; resolvedBy: string; note?: string;
  }): BuddyApprovalRequest;
  assignBuddySkill(input: {
    buddy: string; name: string; instructionPath: string; mode?: BuddySkillMode;
  }): BuddySkill;
  removeBuddySkill(buddy: string, name: string): boolean;
  listBuddySkills(buddy: string): BuddySkill[];
  createDelegation(input: {
    fromBuddy: string; toBuddy: string; workspace: string; project?: string;
    purpose: string; parentConversationId?: string; childConversationId?: string;
    status?: DelegationStatus;
  }): BuddyDelegation;
  getDelegation(id: string): BuddyDelegation | null;
  claimDelegationDispatch(id: string, input: {
    claimToken: string; leaseSeconds?: number;
  }): BuddyDelegation;
  bindDelegationConversation(id: string, input: {
    claimToken: string; childConversationId: string;
  }): BuddyDelegation;
  failDelegationDispatch(id: string, input: {
    claimToken: string; error: string;
  }): BuddyDelegation;
  updateDelegation(id: string, changes: {
    status?: DelegationStatus; childConversationId?: string | null; outcome?: string | null;
  }): BuddyDelegation;
  listDelegations(input?: {
    buddy?: string; workspace?: string; status?: DelegationStatus;
  }): BuddyDelegation[];
  createReview(input: {
    reviewer: string; subject: string; workspace: string; project?: string;
    conversationId?: string; status?: ReviewStatus; verdict?: ReviewVerdict;
    score?: number; summary?: string; evidence?: unknown[];
  }): BuddyReview;
  getReview(id: string): BuddyReview | null;
  updateReview(id: string, changes?: Partial<{
    status: ReviewStatus; verdict: ReviewVerdict; score: number;
    summary: string; evidence: unknown[];
  }>): BuddyReview;
  listReviews(input?: {
    buddy?: string; workspace?: string; status?: ReviewStatus;
  }): BuddyReview[];
  createSprint(input: { project: string; name: string; goal?: string; status?: SprintStatus }): Sprint;
  getSprint(id: string): Sprint | null;
  getActiveSprint(project: string): Sprint | null;
  completeSprint(id: string): Sprint;
  newProject(input: {
    buddy: string; workspace: string; title: string; objective?: string;
    definitionOfDone: string; sprint?: string; status?: BuddyProjectStatus;
    priority?: number; nextAction?: string; blockedReason?: string; sourcePath?: string;
    externalKey?: string;
    todos?: Array<{
      title: string; status?: BuddyTodoStatus; definitionOfDone?: string; evidence?: string[];
      nextAction?: string; blockedReason?: string;
    }>;
  }): BuddyProjectWithTodos;
  upsertBuddyProject(input: {
    buddy: string; workspace: string; title: string; objective?: string;
    definitionOfDone: string; sprint?: string; status?: BuddyProjectStatus;
    priority?: number; nextAction?: string; blockedReason?: string; sourcePath?: string;
    externalKey: string;
    todos?: Array<{
      title: string; status?: BuddyTodoStatus; definitionOfDone?: string; evidence?: string[];
      nextAction?: string; blockedReason?: string;
    }>;
  }): BuddyProjectWithTodos;
  getBuddyProject(project: string): BuddyProjectWithTodos | null;
  listBuddyOwnedProjects(input?: {
    buddy?: string; workspace?: string; sprint?: string; includeClosed?: boolean;
  }): BuddyProjectWithTodos[];
  listTodos(project: string, options?: { includeClosed?: boolean }): BuddyTodo[];
  updateProject(project: string, changes?: {
    title?: string; objective?: string | null; definitionOfDone?: string; evidence?: string[];
    status?: BuddyProjectStatus; priority?: number; nextAction?: string | null;
    blockedReason?: string | null; sprint?: string | null; sourcePath?: string | null;
    todoOperations?: Array<
      | { operation: "add"; title: string; status?: BuddyTodoStatus;
          definitionOfDone?: string; evidence?: string[]; nextAction?: string; blockedReason?: string }
      | { operation: "update"; todoId: string; title?: string; status?: BuddyTodoStatus;
          position?: number; definitionOfDone?: string | null; evidence?: string[]; nextAction?: string | null;
          blockedReason?: string | null }
    >;
  }): BuddyProjectWithTodos;
  readBuddyMemory(buddy: string): BuddyMemory;
  updateMemory(buddy: string, input: {
    documentKind?: "working" | "long_term"; doc?: "working" | "long_term";
    content: string; reasoning: string; baseVersion: number; authorKind?: string;
    requestedBy?: string | null; provenance?: unknown;
  }): BuddyMemoryRevision;
  readBuddySoul(buddy: string): {
    buddy_id: string;
    body: string;
    revision: number;
    generation: number;
    reasoning: string;
    sha256: string;
    updated_at: string | null;
  };
  updateSoul(buddy: string, input: {
    content: string; reasoning: string; baseVersion: number;
    requestedBy: string; provenance?: unknown;
  }): BuddyMemoryRevision;
  exportCheck(buddy: string): ExportCheckReport;
  fixExport(buddy: string): ExportFixReport;
  rememberNote(buddy: string, input: {
    topic?: string; kind?: string; body?: string; content?: string; evidence?: unknown[];
    workspace?: string; scope?: "current" | "home" | "all"; date?: Date | string;
  }): BuddyMemoryNote;
  recall(buddy: string, input: {
    pattern: string; workspace?: string; scope?: "current" | "home" | "all";
    since?: string; limit?: number;
  }): { pattern: string; matches: Array<{ path: string; content: string; created_at: string | null; workspace_id: string; content_truncated?: boolean }>; truncated: boolean };
  getBuddyContext(buddy: string, input?: { workspace?: string; project?: string }): BuddyContext;
  createAutomation(input: {
    buddy: string; workspace?: string; project?: string; name: string;
    scheduleKind: AutomationScheduleKind; scheduleExpression: string; timezone?: string;
    jobKind: AutomationJobKind; jobPayload: AutomationJobPayload; enabled?: boolean;
    policy?: Partial<{
      maxRuntimeSeconds: number; maxIterations: number; maxTokens: number;
      maxCostUsd: number; allowedOperations: AutomationAllowedOperation[];
    }>;
    nextRunAt?: string;
  }): BuddyAutomation;
  getAutomation(id: string): BuddyAutomation | null;
  listAutomations(input?: {
    buddy?: string; enabled?: boolean; includeArchived?: boolean;
  }): BuddyAutomation[];
  updateAutomation(id: string, changes?: Partial<{
    name: string; scheduleKind: AutomationScheduleKind; scheduleExpression: string;
    timezone: string; jobKind: AutomationJobKind; jobPayload: AutomationJobPayload;
    policy: Partial<{
      maxRuntimeSeconds: number; maxIterations: number; maxTokens: number;
      maxCostUsd: number; allowedOperations: AutomationAllowedOperation[];
    }>;
    enabled: boolean; nextRunAt: string | null;
  }>): BuddyAutomation;
  deleteAutomation(id: string): BuddyAutomation;
  archiveAutomation(id: string): BuddyAutomation;
  listDueAutomations(at?: Date | string): BuddyAutomation[];
  claimAutomationRun(id: string, input?: {
    scheduledFor?: string; idempotencyKey?: string; claimToken?: string;
    leaseSeconds?: number;
  }): BuddyAutomationRun;
  getAutomationRun(id: string): BuddyAutomationRun | null;
  getAutomationRunByIdempotencyKey(key: string): BuddyAutomationRun | null;
  updateAutomationRun(id: string, changes: {
    status: AutomationRunStatus; conversationId?: string | null; iteration?: number;
    tokensUsed?: number; costUsd?: number;
    outcome?: string | null; error?: string | null; nextRunAt?: string | null;
    claimToken?: string;
  }): BuddyAutomationRun;
  listAutomationRuns(id: string, options?: { limit?: number }): BuddyAutomationRun[];
  getAutomationRunByConversationId(conversationId: string): BuddyAutomationRun | null;
  listNonterminalAutomationRuns(): BuddyAutomationRun[];
  assertAutomationOperationAllowed(
    id: string, operation: AutomationAllowedOperation, claimToken: string
  ): true;
  withAutomationRunAuthority<T>(
    id: string,
    operation: AutomationAllowedOperation,
    claimToken: string,
    callback: () => T,
  ): T;
  createWorkItem(input: Record<string, unknown>): WorkItem;
  upsertWorkItem(input: Record<string, unknown>): WorkItem;
  getWorkItem(id: string): WorkItem | null;
  updateWorkItemStatus(id: string, status: WorkItemStatus,
    options?: { blockedReason?: string; nextAction?: string }): WorkItem;
  listWorkItems(input?: {
    project?: string; buddy?: string; sprint?: string; includeClosed?: boolean;
  }): WorkItem[];
  currentWork(project: string): { project: Workspace; sprint: Sprint | null; workItems: WorkItem[] };
  auditWorkMigration(): {
    openLegacy: number;
    migrated: number;
    unmigrated: number;
    unmigratedItems: Array<Pick<
      WorkItem,
      "id" | "project_id" | "buddy_id" | "external_key" | "title" | "status"
    >>;
  };
  dashboard(): BuddiesDashboard;
  overview(options?: { recentSince?: Date | string }): BuddyOverview;
  linkConversation(input: {
    buddy: string; workspace?: string; project?: string; workItem?: string; provider: string;
    providerSessionId?: string; unleashdConversationId?: string; status?: ConversationStatus;
  }): ConversationLink;
  updateConversationLink(id: string, changes?: {
    status?: ConversationStatus; providerSessionId?: string;
  }): ConversationLink;
  getConversationLink(id: string): ConversationLink | null;
  listConversationLinks(buddy: string): ConversationLink[];
}

export const BUDDY_STATUSES: readonly BuddyStatus[];
export const SPRINT_STATUSES: readonly SprintStatus[];
export const WORK_ITEM_STATUSES: readonly WorkItemStatus[];
export const BUDDY_PROJECT_STATUSES: readonly BuddyProjectStatus[];
export const BUDDY_TODO_STATUSES: readonly BuddyTodoStatus[];
export const CONVERSATION_STATUSES: readonly ConversationStatus[];
export const AUTOMATION_SCHEDULE_KINDS: readonly AutomationScheduleKind[];
export const AUTOMATION_JOB_KINDS: readonly AutomationJobKind[];
export const AUTOMATION_ALLOWED_OPERATIONS: readonly AutomationAllowedOperation[];
export const AUTOMATION_RUN_STATUSES: readonly AutomationRunStatus[];
export const BUDDY_RELATIONSHIP_KINDS: readonly BuddyRelationshipKind[];
export const BUDDY_SKILL_MODES: readonly BuddySkillMode[];
export const DELEGATION_STATUSES: readonly DelegationStatus[];
export const REVIEW_STATUSES: readonly ReviewStatus[];
export const REVIEW_VERDICTS: readonly ReviewVerdict[];
export const APPROVAL_STATUSES: readonly ApprovalStatus[];
export const MEMORY_DOCUMENT_KINDS: readonly ("working" | "long_term")[];
export const MEMORY_DOCUMENT_CAPS: Readonly<{ working: 2000; long_term: 4000; soul: 32000 }>;
export const MEMORY_NOTE_MAX_BYTES: 16000;
export function defaultDatabasePath(): string;

export interface BuddyMessage {
  id: string; from_buddy_id: string; to_buddy_id: string | null; workspace_id: string;
  buddy_project_id: string | null; purpose: string; body: string; evidence: string[];
  parent_conversation_id: string | null; child_conversation_id: string | null;
  status: 'pending' | 'active' | 'replied' | 'failed' | 'cancelled';
  outcome: string | null; reply_body: string | null; reply_evidence: string[]; replied_by: string | null;
  wait_until: string | null; wait_status: 'none' | 'waiting' | 'replied' | 'timed_out' | 'cancelled';
  created_at: string; updated_at: string; replied_at: string | null;
}

export type BuddyConfigurationRef = {id: string} | {creationKey: string};
export type TeamConfigurationAccess = 'none' | 'read' | 'write' | 'write_only';
export interface TeamConfiguration {
  workspaceId: string; reason: string;
  create?: Array<{creationKey: string; name: string; role: string; soul: string; provider?: string; model?: string; reasoningEffort?: string}>;
  memberships?: Array<{buddy: BuddyConfigurationRef; present: true; incoming?: boolean; dispatch?: boolean; readAllWork?: boolean}>;
  relationships?: Array<{from: BuddyConfigurationRef; to: BuddyConfigurationRef; kind: 'manager' | 'consults'; present: boolean}>;
  access?: Array<{grantee: BuddyConfigurationRef; target: BuddyConfigurationRef; relationships?: boolean; profile?: TeamConfigurationAccess; soul?: TeamConfigurationAccess; memory?: TeamConfigurationAccess; incoming?: boolean; schedules?: boolean; baseRevision?: number; expiresAt?: string | null}>;
  staffing?: Array<{grantee: BuddyConfigurationRef; enabled: boolean; createdBuddyIncoming?: boolean; baseRevision?: number; expiresAt?: string | null}>;
}
export interface TeamSetupBlocker {code: string; path: string; reason: string; resolvableBy: 'owner' | 'lead' | 'runtime'; remedy: string}
export interface TeamConfigurationWork {messageId: string; runId: string | null; recipientId: string; state: string; code: string | null; projectId?: string | null; acknowledgedAt?: string | null; acceptedAt?: string | null; completionEvidence?: string[]}
export interface TeamReadiness {
  ready: boolean; blockers: TeamSetupBlocker[];
  participants: Array<{buddyId: string; name: string; incoming: boolean; dispatch: boolean; readAllWork: boolean; active: boolean}>;
  messages: Array<TeamConfigurationWork & {returnBuddyId: string | null; returnIncoming: boolean | null}>;
}
export interface TeamConfigurationBuddyEffect {name: string; role: string; status: string; provider: string | null; model: string | null; reasoningEffort: string | null; revision: number; soulHash?: string}
export interface TeamConfigurationMembershipEffect {present: boolean; incoming: boolean; dispatch: boolean; readAllWork: boolean; pausedReason: string | null; maxActiveRuns: number}
export interface TeamConfigurationRelationshipEffect {fromBuddyId: string; toBuddyId: string; kind: 'manager' | 'consults'; present: boolean; affectedWorkspaceIds: string[]}
export interface TeamConfigurationGrantEffect {granteeId: string; targetId: string; capabilities: string[]; revision: number; expiresAt: string | null; reason: string; createdBuddyIncoming: boolean; affectedWorkspaceIds: string[]}
export type TeamConfigurationEffect =
  | {resource: 'buddy'; id: string; before: TeamConfigurationBuddyEffect | null; after: TeamConfigurationBuddyEffect | null}
  | {resource: 'membership'; id: string; before: TeamConfigurationMembershipEffect | null; after: TeamConfigurationMembershipEffect | null}
  | {resource: 'relationship'; id: string; before: TeamConfigurationRelationshipEffect | null; after: TeamConfigurationRelationshipEffect | null}
  | {resource: 'grant'; id: string; before: TeamConfigurationGrantEffect | null; after: TeamConfigurationGrantEffect | null};
export interface TeamSetupResult {
  workspaceId: string; contractVersion: string; key: string; planHash: string; canApply: boolean; blockers: TeamSetupBlocker[];
  effects: TeamConfigurationEffect[]; resolvedBuddies: Array<{ref: BuddyConfigurationRef; id: string | null; name: string}>;
  affectedWork: TeamConfigurationWork[];
  queuedRuns: Array<{runId: string; inputKind: string; inputId: string; buddyId: string; state: string}>;
  receipt: null | {auditId: string; appliedAt: string; replayed: boolean}; readiness: TeamReadiness; drift: boolean;
}
export interface BuddiesStore {
  inspectBuddyAdmission(input: {buddyId: string; workspaceId: string; runId?: string; conversationId?: string; at?: string}): {allowed: boolean; blockers: TeamSetupBlocker[]};
  prepareTeamConfiguration(input: {key: string; configuration: TeamConfiguration}): TeamSetupResult;
  applyTeamConfiguration(input: {key: string; configuration: TeamConfiguration; expectedPlanHash?: string}, provenance: {ownerInputId: string; conversationId: string | null}): TeamSetupResult;
  getTeamConfiguration(input: {workspaceId: string; key: string}): TeamSetupResult | null;
  teamConfigurationReadiness(input: {workspaceId: string; buddyIds: string[]}): TeamReadiness;
}

export interface BuddyCheckpoint { id:string;run_id:string;buddy_id:string;workspace_id:string;project_id:string|null;message_id:string|null;root_message_id:string|null;created_at:string;artifacts:Array<{ref:string;version:string;sha256?:string|null}>;effects:string[];resume:string;visibility:'participants'|'team' }
export interface BuddyRecovery { mode:'attempt'|'successor_request';successorRunId:string|null;controllerBuddyIds:string[];canRetry:boolean;reason:string|null;remainingRuns:number|null;remainingSeconds:number|null;checkpointIds:string[];action:{operation:'retry_run';runId:string;requires:string[]}|null }
export interface BuddyDelivery {runId:string;kind:string;attempt:number;state:string;acknowledgedAt:string|null;createdAt:string;endedAt:string|null;errorCode:string|null;error:string|null;retryOfRunId:string|null}
