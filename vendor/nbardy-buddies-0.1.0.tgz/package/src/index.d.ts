export type BuddyStatus = "active" | "paused" | "archived";
export type SprintStatus = "planned" | "active" | "completed" | "cancelled";
export type WorkItemStatus =
  | "backlog" | "ready" | "in_progress" | "blocked" | "review" | "done" | "cancelled";
export type BuddyProjectStatus = WorkItemStatus;
export type BuddyTodoStatus = "open" | "in_progress" | "blocked" | "done" | "cancelled";
export type ConversationStatus = "active" | "complete" | "failed" | "cancelled";
export type AutomationScheduleKind = "cron" | "interval";
export type AutomationJobKind = "prompt" | "sequence" | "loop";
export type AutomationRunStatus =
  | "claimed"
  | "running"
  | "cancel_requested"
  | "complete"
  | "failed"
  | "cancelled";
export type BuddyRelationshipKind = "manager" | "reports_to" | "consults" | "reviews";
export type BuddySkillMode = "always" | "on_demand";
export type DelegationStatus = "pending" | "active" | "complete" | "failed" | "cancelled";
export type ReviewStatus = "draft" | "complete" | "cancelled";
export type ReviewVerdict = "needs_work" | "pass" | "fail";
export type ApprovalStatus = "pending" | "approved" | "rejected";

export interface Workspace {
  id: string;
  slug: string;
  name: string;
  root_path: string;
  created_at: string;
  updated_at: string;
  assignment_role?: string | null;
}
/** @deprecated Use Workspace. */
export type Project = Workspace;

export interface Buddy {
  id: string;
  project_id: string;
  slug: string;
  name: string;
  role: string;
  status: BuddyStatus;
  soul_path: string | null;
  memory_path: string | null;
  provider: string | null;
  model: string | null;
  reasoning_effort: string | null;
  /** design §6/§8.2: concurrent direct-report headcount ceiling. NOT NULL DEFAULT 0 since schema v13. */
  hire_quota: number;
  created_at: string;
  updated_at: string;
}

export interface BuddyBuilderCreationResult {
  buddy: Buddy;
  homeWorkspace: Workspace;
  workspaces: Workspace[];
  requestFingerprint: string;
  replayed: boolean;
}

export interface Sprint {
  id: string;
  project_id: string;
  name: string;
  goal: string | null;
  status: SprintStatus;
  starts_at: string | null;
  ends_at: string | null;
  created_at: string;
  updated_at: string;
  project_slug?: string;
}

export interface BuddyTodo {
  id: string;
  buddy_project_id: string;
  title: string;
  status: BuddyTodoStatus;
  position: number;
  definition_of_done: string | null;
  next_action: string | null;
  blocked_reason: string | null;
  created_at: string;
  updated_at: string;
  completed_at: string | null;
}

export interface BuddyProject {
  id: string;
  workspace_id: string;
  buddy_id: string;
  sprint_id: string | null;
  title: string;
  objective: string | null;
  definition_of_done: string;
  status: BuddyProjectStatus;
  priority: number;
  next_action: string | null;
  blocked_reason: string | null;
  source_path: string | null;
  external_key: string | null;
  created_at: string;
  updated_at: string;
  completed_at: string | null;
  todos?: BuddyTodo[];
  workspace_name?: string;
  workspace_slug?: string;
  buddy_name?: string;
  sprint_name?: string | null;
}
export type BuddyProjectWithTodos = BuddyProject & { todos: BuddyTodo[] };

export interface WorkItem {
  id: string;
  project_id: string;
  sprint_id: string | null;
  buddy_id: string | null;
  title: string;
  kind: string;
  external_key: string | null;
  source_path: string | null;
  objective: string | null;
  definition_of_done: string;
  status: WorkItemStatus;
  priority: number;
  next_action: string | null;
  blocked_reason: string | null;
  created_at: string;
  updated_at: string;
  completed_at: string | null;
  buddy_name?: string | null;
  sprint_name?: string | null;
}

export interface ConversationLink {
  id: string;
  buddy_id: string;
  workspace_id: string;
  buddy_project_id: string | null;
  work_item_id: string | null;
  provider: string;
  provider_session_id: string | null;
  unleashd_conversation_id: string | null;
  status: ConversationStatus;
  started_at: string;
  last_active_at: string;
  ended_at: string | null;
  claim_token: string | null;
  claim_expires_at: string | null;
  claim_acquired?: boolean;
}

export interface BuddyRelationship {
  id: string; from_buddy_id: string; to_buddy_id: string;
  kind: BuddyRelationshipKind; created_at: string;
  from_buddy_name?: string; to_buddy_name?: string;
}
export interface BuddySkill {
  id: string; buddy_id: string; name: string; instruction_path: string;
  mode: BuddySkillMode; created_at: string; updated_at: string;
}
export interface BuddyDelegation {
  id: string; from_buddy_id: string; to_buddy_id: string; workspace_id: string;
  buddy_project_id: string | null; purpose: string;
  parent_conversation_id: string | null; child_conversation_id: string | null;
  status: DelegationStatus; outcome: string | null; created_at: string;
  updated_at: string; completed_at: string | null;
  dispatch_token: string | null; dispatch_expires_at: string | null;
  dispatch_claim_acquired?: boolean;
}
export interface BuddyReview {
  id: string; reviewer_buddy_id: string; subject_buddy_id: string;
  workspace_id: string; buddy_project_id: string | null;
  conversation_id: string | null; status: ReviewStatus;
  verdict: ReviewVerdict | null; score: number | null; summary: string | null;
  evidence: unknown[]; created_at: string; updated_at: string;
  completed_at: string | null;
}

export interface BuddyAuditEvent {
  id: string;
  buddy_id: string;
  workspace_id: string;
  buddy_project_id: string | null;
  operation: string;
  payload: unknown;
  created_at: string;
}

export interface BuddyApprovalRequest {
  id: string;
  buddy_id: string;
  workspace_id: string;
  buddy_project_id: string | null;
  automation_run_id: string | null;
  conversation_id: string | null;
  action: string;
  reason: string;
  risk: string;
  status: ApprovalStatus;
  resolved_by: string | null;
  resolution_note: string | null;
  requested_at: string;
  resolved_at: string | null;
}

export type AutomationAllowedOperation =
  | "buddy.get_current_work"
  | "buddy.get_inbox"
  | "buddy.get_automations"
  | "buddy.set_automation"
  | "buddy.new_project"
  | "buddy.update_project"
  | "buddy.remember"
  | "buddy.compact_memory"
  | "buddy.delegate"
  | "buddy.request_review"
  | "buddy.complete_delegation"
  | "buddy.complete_assignment"
  | "buddy.submit_review"
  | "buddy.request_human_approval";

export interface BuddyAutomationPolicy {
  max_runtime_seconds: number;
  max_iterations: number;
  max_tokens: number;
  max_cost_usd: number;
  allowed_operations: AutomationAllowedOperation[];
}

export type AutomationJobPayload =
  | { prompt: string }
  | { prompts: string[] }
  | { prompt: string; termination: {
      condition: string; max_iterations: number; max_duration_seconds: number;
    } };

export interface BuddyAutomation {
  id: string;
  buddy_id: string;
  workspace_id: string;
  buddy_project_id: string | null;
  name: string;
  schedule_kind: AutomationScheduleKind;
  schedule_expression: string;
  timezone: string;
  job_kind: AutomationJobKind;
  job_payload: AutomationJobPayload;
  policy: BuddyAutomationPolicy;
  enabled: boolean;
  archived_at: string | null;
  next_run_at: string | null;
  last_run_at: string | null;
  created_at: string;
  updated_at: string;
}

export interface BuddyAutomationRun {
  id: string;
  automation_id: string;
  scheduled_for: string;
  idempotency_key: string;
  status: AutomationRunStatus;
  conversation_id: string | null;
  iteration: number;
  tokens_used: number;
  cost_usd: number;
  policy: BuddyAutomationPolicy;
  outcome: string | null;
  error: string | null;
  claimed_at: string;
  started_at: string | null;
  ended_at: string | null;
}

export interface BuddyMemory {
  summary: string;
  recentJournal: Array<{ path: string; content: string }>;
}

export interface BuddyContext {
  buddy: Buddy;
  relationships: BuddyRelationship[];
  skills: BuddySkill[];
  workspaces: Workspace[];
  workspace: Workspace | null;
  sprint: Sprint | null;
  project: BuddyProjectWithTodos | null;
  projects: BuddyProjectWithTodos[];
  legacyWorkItems: WorkItem[];
  soul: string;
  memory: BuddyMemory;
}

export interface BuddiesDashboard {
  projects: Workspace[];
  buddies: Array<Buddy & { projects: Workspace[]; conversations: ConversationLink[] }>;
  sprints: Sprint[];
  workItems: WorkItem[];
  buddyOwnedProjects: BuddyProjectWithTodos[];
}

/**
 * design §5.2. Directory membership is carried by the TYPE, not by a null.
 * `top_level` is exactly `overview().topLevel` membership.
 */
export type BuddyEmployment =
  | { kind: "top_level" }
  | { kind: "direct_report"; managerId: string };

/** design §9.1. hire canonicalizes to this sum once, then dispatches. */
export type HireTarget =
  | { kind: "vacant" }
  | { kind: "reactivatable"; sub: Buddy }
  | { kind: "held"; sub: Buddy }
  | { kind: "held_elsewhere"; sub: Buddy; managerId: string }
  | { kind: "slug_owned_by_top_level"; sub: Buddy };

/** `unchanged` is an idempotent replay: no seat consumed (design §8.1). */
export type HireOutcome = "hired" | "reactivated" | "unchanged";

export interface BuddyOverviewEmployee {
  buddy: Buddy;
  employment: BuddyEmployment;
  workspaces: Workspace[];
  team: Array<Pick<Buddy, "id" | "name" | "role" | "status">>;
  currentWork: {
    open: number;
    active: number;
    blocked: number;
    review: number;
    nextActionMissing: number;
  };
}

export interface BuddyOverview {
  generatedAt: string;
  employees: BuddyOverviewEmployee[];
  topLevel: BuddyOverviewEmployee[];
  recentRuns: Array<{
    conversationId: string;
    buddyId: string;
    buddyName: string;
    workspaceId: string;
    workspaceName: string;
    status: ConversationStatus;
    lastActiveAt: string;
  }>;
}

export class BuddiesStore {
  constructor(databasePath?: string);
  databasePath: string;
  close(): void;
  backupDatabase(destination: string): {
    database: string; backup: string; schemaVersion: number; createdAt: string;
  };
  createProject(input: { name: string; rootPath: string; slug?: string }): Workspace;
  getProject(idOrSlug: string): Workspace | null;
  listProjects(): Workspace[];
  createWorkspace(input: { name: string; rootPath: string; slug?: string }): Workspace;
  getWorkspace(idOrSlug: string): Workspace | null;
  listWorkspaces(): Workspace[];
  createBuddy(input: {
    project: string; name: string; role: string; slug?: string; status?: BuddyStatus;
    soulPath?: string; memoryPath?: string; provider?: string; model?: string;
    reasoningEffort?: string; hireQuota?: number;
  }): Buddy;
  createBuddyFromBuilder(input: {
    conversationId: string;
    requestFingerprint: string;
    project: string;
    additionalWorkspaces?: string[];
    name: string;
    role: string;
    slug?: string;
    status?: BuddyStatus;
    provider?: string;
    model?: string;
    reasoningEffort?: string;
  }): BuddyBuilderCreationResult;
  getBuddyBuilderResult(conversationId: string): BuddyBuilderCreationResult | null;
  getBuddy(idOrSlug: string, project?: string): Buddy | null;
  updateBuddy(idOrSlug: string, changes?: Partial<{
    name: string; role: string; status: BuddyStatus; homeWorkspace: string;
    soulPath: string | null;
    memoryPath: string | null; provider: string | null; model: string | null;
    reasoningEffort: string | null; hireQuota: number;
  }>): Buddy;
  listBuddies(project?: string): Buddy[];
  assignBuddyToProject(input: { buddy: string; project: string; role?: string }): Workspace[];
  listBuddyProjects(buddy: string): Workspace[];
  assignBuddyToWorkspace(input: { buddy: string; workspace: string; role?: string }): Workspace[];
  listBuddyWorkspaces(buddy: string): Workspace[];
  /**
   * design §7.4. The only way to move `owned_projects.buddy_id`; re-checks that the
   * new owner belongs to the project's workspace and writes an audit event.
   */
  reassignOwnedProject(input: { project: string; toBuddy: string }): BuddyProjectWithTodos;
  /**
   * design §8.3. `reports_to A->B` is normalized to `manager B->A` on write, so the
   * returned row's `kind` is `manager` with `from`/`to` swapped.
   */
  setBuddyRelationship(input: {
    fromBuddy: string; toBuddy: string; kind: BuddyRelationshipKind;
  }): BuddyRelationship;
  /** design §7.5. Non-archived direct reports, deduped across both edge encodings. */
  countHeldDirectReports(manager: string): number;
  /** design §9.1. The single canonicalizer hire dispatches on. */
  resolveHireTarget(manager: string, slug: string, workspace: string): HireTarget;
  hireDirectReport(input: {
    managerBuddy: string; name: string; role: string; soul: string; workspace: string;
    additionalWorkspaces?: string[]; provider?: string; model?: string;
    reasoningEffort?: string;
  }): { buddy: Buddy; outcome: HireOutcome };
  retireDirectReport(input: {
    managerBuddy: string; subBuddy: string; reason?: string; reassignOpenWorkTo?: string;
  }): {
    buddy: Buddy;
    reassignedProjects: number;
    disabledAutomations: number;
    cancelledDelegations: number;
    cancelledReviews: number;
  };
  removeBuddyRelationship(id: string): boolean;
  listBuddyRelationships(buddy: string): BuddyRelationship[];
  recordAuditEvent(input: {
    buddy: string; workspace: string; project?: string;
    operation: string; payload?: unknown;
  }): BuddyAuditEvent;
  getAuditEvent(id: string): BuddyAuditEvent | null;
  listAuditEvents(input?: {
    buddy?: string; workspace?: string; project?: string; limit?: number;
  }): BuddyAuditEvent[];
  createApprovalRequest(input: {
    buddy: string; workspace: string; project?: string; automationRun?: string;
    conversationId?: string; action: string; reason: string; risk: string;
  }): BuddyApprovalRequest;
  getApprovalRequest(id: string): BuddyApprovalRequest | null;
  listApprovalRequests(input?: {
    buddy?: string; workspace?: string; project?: string; status?: ApprovalStatus;
    limit?: number;
  }): BuddyApprovalRequest[];
  resolveApprovalRequest(id: string, input: {
    decision: "approved" | "rejected"; resolvedBy: string; note?: string;
  }): BuddyApprovalRequest;
  assignBuddySkill(input: {
    buddy: string; name: string; instructionPath: string; mode?: BuddySkillMode;
  }): BuddySkill;
  removeBuddySkill(buddy: string, name: string): boolean;
  listBuddySkills(buddy: string): BuddySkill[];
  createDelegation(input: {
    fromBuddy: string; toBuddy: string; workspace: string; project?: string;
    purpose: string; parentConversationId?: string; childConversationId?: string;
    status?: DelegationStatus;
  }): BuddyDelegation;
  getDelegation(id: string): BuddyDelegation | null;
  claimDelegationDispatch(id: string, input: {
    claimToken: string; leaseSeconds?: number;
  }): BuddyDelegation;
  bindDelegationConversation(id: string, input: {
    claimToken: string; childConversationId: string;
  }): BuddyDelegation;
  failDelegationDispatch(id: string, input: {
    claimToken: string; error: string;
  }): BuddyDelegation;
  updateDelegation(id: string, changes: {
    status?: DelegationStatus; childConversationId?: string | null; outcome?: string | null;
  }): BuddyDelegation;
  listDelegations(input?: {
    buddy?: string; workspace?: string; status?: DelegationStatus;
  }): BuddyDelegation[];
  createReview(input: {
    reviewer: string; subject: string; workspace: string; project?: string;
    conversationId?: string; status?: ReviewStatus; verdict?: ReviewVerdict;
    score?: number; summary?: string; evidence?: unknown[];
  }): BuddyReview;
  getReview(id: string): BuddyReview | null;
  updateReview(id: string, changes?: Partial<{
    status: ReviewStatus; verdict: ReviewVerdict; score: number;
    summary: string; evidence: unknown[];
  }>): BuddyReview;
  listReviews(input?: {
    buddy?: string; workspace?: string; status?: ReviewStatus;
  }): BuddyReview[];
  createSprint(input: { project: string; name: string; goal?: string; status?: SprintStatus }): Sprint;
  getSprint(id: string): Sprint | null;
  getActiveSprint(project: string): Sprint | null;
  completeSprint(id: string): Sprint;
  newProject(input: {
    buddy: string; workspace: string; title: string; objective?: string;
    definitionOfDone: string; sprint?: string; status?: BuddyProjectStatus;
    priority?: number; nextAction?: string; blockedReason?: string; sourcePath?: string;
    externalKey?: string;
    todos?: Array<{
      title: string; status?: BuddyTodoStatus; definitionOfDone?: string;
      nextAction?: string; blockedReason?: string;
    }>;
  }): BuddyProjectWithTodos;
  upsertBuddyProject(input: {
    buddy: string; workspace: string; title: string; objective?: string;
    definitionOfDone: string; sprint?: string; status?: BuddyProjectStatus;
    priority?: number; nextAction?: string; blockedReason?: string; sourcePath?: string;
    externalKey: string;
    todos?: Array<{
      title: string; status?: BuddyTodoStatus; definitionOfDone?: string;
      nextAction?: string; blockedReason?: string;
    }>;
  }): BuddyProjectWithTodos;
  getBuddyProject(project: string): BuddyProjectWithTodos | null;
  listBuddyOwnedProjects(input?: {
    buddy?: string; workspace?: string; sprint?: string; includeClosed?: boolean;
  }): BuddyProjectWithTodos[];
  listTodos(project: string, options?: { includeClosed?: boolean }): BuddyTodo[];
  updateProject(project: string, changes?: {
    title?: string; objective?: string | null; definitionOfDone?: string;
    status?: BuddyProjectStatus; priority?: number; nextAction?: string | null;
    blockedReason?: string | null; sprint?: string | null; sourcePath?: string | null;
    todoOperations?: Array<
      | { operation: "add"; title: string; status?: BuddyTodoStatus;
          definitionOfDone?: string; nextAction?: string; blockedReason?: string }
      | { operation: "update"; todoId: string; title?: string; status?: BuddyTodoStatus;
          position?: number; definitionOfDone?: string | null; nextAction?: string | null;
          blockedReason?: string | null }
    >;
  }): BuddyProjectWithTodos;
  readBuddyMemory(buddy: string, options?: { recentJournalLimit?: number }): BuddyMemory;
  remember(buddy: string, input: {
    content: string; kind?: "journal" | "curated"; date?: Date | string;
  }): { buddy_id: string; kind: string; path: string; content: string; written_at: string };
  compactMemory(buddy: string, input?: {
    summary?: string; retainDays?: number; maxActiveCharacters?: number;
    dryRun?: boolean; date?: Date | string;
  }): {
    buddyId: string; dryRun: boolean; compact: boolean;
    retainedJournalFiles: number;
    archivedJournalFiles: Array<{ path: string; sha256: string; characters: number }>;
    alreadyCompacted?: boolean; compactedAt?: string; indexPath?: string;
    summaryPath?: string; signature?: string;
  };
  getBuddyContext(buddy: string, input?: { workspace?: string; project?: string }): BuddyContext;
  createAutomation(input: {
    buddy: string; workspace?: string; project?: string; name: string;
    scheduleKind: AutomationScheduleKind; scheduleExpression: string; timezone?: string;
    jobKind: AutomationJobKind; jobPayload: AutomationJobPayload; enabled?: boolean;
    policy?: Partial<{
      maxRuntimeSeconds: number; maxIterations: number; maxTokens: number;
      maxCostUsd: number; allowedOperations: AutomationAllowedOperation[];
    }>;
    nextRunAt?: string;
  }): BuddyAutomation;
  getAutomation(id: string): BuddyAutomation | null;
  listAutomations(input?: {
    buddy?: string; enabled?: boolean; includeArchived?: boolean;
  }): BuddyAutomation[];
  updateAutomation(id: string, changes?: Partial<{
    name: string; scheduleKind: AutomationScheduleKind; scheduleExpression: string;
    timezone: string; jobKind: AutomationJobKind; jobPayload: AutomationJobPayload;
    policy: Partial<{
      maxRuntimeSeconds: number; maxIterations: number; maxTokens: number;
      maxCostUsd: number; allowedOperations: AutomationAllowedOperation[];
    }>;
    enabled: boolean; nextRunAt: string | null;
  }>): BuddyAutomation;
  deleteAutomation(id: string): BuddyAutomation;
  archiveAutomation(id: string): BuddyAutomation;
  listDueAutomations(at?: Date | string): BuddyAutomation[];
  claimAutomationRun(id: string, input?: {
    scheduledFor?: string; idempotencyKey?: string; claimToken?: string;
    leaseSeconds?: number;
  }): BuddyAutomationRun;
  getAutomationRun(id: string): BuddyAutomationRun | null;
  getAutomationRunByIdempotencyKey(key: string): BuddyAutomationRun | null;
  updateAutomationRun(id: string, changes: {
    status: AutomationRunStatus; conversationId?: string | null; iteration?: number;
    tokensUsed?: number; costUsd?: number;
    outcome?: string | null; error?: string | null; nextRunAt?: string | null;
    claimToken?: string;
  }): BuddyAutomationRun;
  listAutomationRuns(id: string, options?: { limit?: number }): BuddyAutomationRun[];
  getAutomationRunByConversationId(conversationId: string): BuddyAutomationRun | null;
  listNonterminalAutomationRuns(): BuddyAutomationRun[];
  assertAutomationOperationAllowed(
    id: string, operation: AutomationAllowedOperation, claimToken: string
  ): true;
  withAutomationRunAuthority<T>(
    id: string,
    operation: AutomationAllowedOperation,
    claimToken: string,
    callback: () => T,
  ): T;
  createWorkItem(input: Record<string, unknown>): WorkItem;
  upsertWorkItem(input: Record<string, unknown>): WorkItem;
  getWorkItem(id: string): WorkItem | null;
  updateWorkItemStatus(id: string, status: WorkItemStatus,
    options?: { blockedReason?: string; nextAction?: string }): WorkItem;
  listWorkItems(input?: {
    project?: string; buddy?: string; sprint?: string; includeClosed?: boolean;
  }): WorkItem[];
  currentWork(project: string): { project: Workspace; sprint: Sprint | null; workItems: WorkItem[] };
  auditWorkMigration(): {
    openLegacy: number;
    migrated: number;
    unmigrated: number;
    unmigratedItems: Array<Pick<
      WorkItem,
      "id" | "project_id" | "buddy_id" | "external_key" | "title" | "status"
    >>;
  };
  dashboard(): BuddiesDashboard;
  overview(options?: { recentSince?: Date | string }): BuddyOverview;
  linkConversation(input: {
    buddy: string; workspace?: string; project?: string; workItem?: string; provider: string;
    providerSessionId?: string; unleashdConversationId?: string; status?: ConversationStatus;
  }): ConversationLink;
  updateConversationLink(id: string, changes?: {
    status?: ConversationStatus; providerSessionId?: string;
  }): ConversationLink;
  getConversationLink(id: string): ConversationLink | null;
  listConversationLinks(buddy: string): ConversationLink[];
}

export const BUDDY_STATUSES: readonly BuddyStatus[];
export const SPRINT_STATUSES: readonly SprintStatus[];
export const WORK_ITEM_STATUSES: readonly WorkItemStatus[];
export const BUDDY_PROJECT_STATUSES: readonly BuddyProjectStatus[];
export const BUDDY_TODO_STATUSES: readonly BuddyTodoStatus[];
export const CONVERSATION_STATUSES: readonly ConversationStatus[];
export const AUTOMATION_SCHEDULE_KINDS: readonly AutomationScheduleKind[];
export const AUTOMATION_JOB_KINDS: readonly AutomationJobKind[];
export const AUTOMATION_ALLOWED_OPERATIONS: readonly AutomationAllowedOperation[];
export const AUTOMATION_RUN_STATUSES: readonly AutomationRunStatus[];
export const BUDDY_RELATIONSHIP_KINDS: readonly BuddyRelationshipKind[];
export const BUDDY_SKILL_MODES: readonly BuddySkillMode[];
export const DELEGATION_STATUSES: readonly DelegationStatus[];
export const REVIEW_STATUSES: readonly ReviewStatus[];
export const REVIEW_VERDICTS: readonly ReviewVerdict[];
export const APPROVAL_STATUSES: readonly ApprovalStatus[];
export function defaultDatabasePath(): string;
