import { migrateCoordinationReceipts, coordinationReceiptMethods } from './coordination-receipts.js';
import { migrateMailbox, mailboxMethods } from './mailbox.js';
import { migrateKnowledge, knowledgeMethods } from './knowledge.js';
import { migrateBackgroundWork, backgroundWorkMethods } from './background-work.js';
import { migrateTeamAccess, teamAccessMethods } from './team-access.js';
import { migrateTeamConfiguration, teamConfigurationMethods } from './team-configuration.js';
import { coordinationWorkMethods } from "./coordination-work.js";
import { coordinationApprovalMethods } from './coordination-approvals.js';
import { migrateCoordination, coordinationMethods } from "./coordination.js";
import {
  closeSync,
  constants,
  existsSync,
  fstatSync,
  mkdirSync,
  openSync,
  readFileSync,
  readSync,
  readdirSync,
  realpathSync,
  renameSync,
  rmSync,
  statSync,
  writeFileSync,
} from "node:fs";
import { homedir } from "node:os";
import { dirname, isAbsolute, join, relative, resolve } from "node:path";
import { createHash, randomBytes, randomUUID } from "node:crypto";
import { DatabaseSync } from "node:sqlite";
import { spawnSync } from "node:child_process";

export const BUDDY_STATUSES = ["active", "paused", "archived"];
export const SPRINT_STATUSES = ["planned", "active", "completed", "cancelled"];
export const WORK_ITEM_STATUSES = [
  "backlog",
  "ready",
  "in_progress",
  "blocked",
  "review",
  "done",
  "cancelled",
];
export const CONVERSATION_STATUSES = ["active", "complete", "failed", "cancelled"];
export const BUDDY_PROJECT_STATUSES = [...WORK_ITEM_STATUSES];
export const BUDDY_TODO_STATUSES = [
  "open",
  "in_progress",
  "blocked",
  "done",
  "cancelled",
];
export const AUTOMATION_SCHEDULE_KINDS = ["cron", "interval"];
export const AUTOMATION_JOB_KINDS = ["prompt", "sequence", "loop"];
export const AUTOMATION_RUN_STATUSES = [
  "claimed",
  "running",
  "cancel_requested",
  "complete",
  "failed",
  "cancelled",
];
export const BUDDY_RELATIONSHIP_KINDS = [
  "manager",
  "reports_to",
  "consults",
  "reviews",
];
// design §8.3. `manager A->B` and `reports_to B->A` are inverse encodings of ONE
// edge. When both are stored, overview() derives the pairs {A:B} AND {B:A}, so
// BOTH buddies drop out of `topLevel` permanently with no UI signal. This table
// is the single normalization point: `reports_to` survives as input vocabulary
// only and no `reports_to` row is ever written again. Keys mirror
// BUDDY_RELATIONSHIP_KINDS; assertOneOf runs first, so a missing key is
// unreachable rather than a silent fallback.
const CANONICAL_RELATIONSHIP = {
  manager: (from, to) => ({ from, to, kind: "manager" }),
  reports_to: (from, to) => ({ from: to, to: from, kind: "manager" }),
  consults: (from, to) => ({ from, to, kind: "consults" }),
  reviews: (from, to) => ({ from, to, kind: "reviews" }),
};

// design §5.2. Directory membership is a SUM, not a null check. Frozen and
// shared: a consumer that tries to bolt `managerId` onto a top-level employee
// throws instead of silently inventing a manager.
const TOP_LEVEL_EMPLOYMENT = Object.freeze({ kind: "top_level" });

export const BUDDY_SKILL_MODES = ["always", "on_demand"];
export const DELEGATION_STATUSES = ["pending", "active", "complete", "failed", "cancelled"];
export const REVIEW_STATUSES = ["draft", "complete", "cancelled"];
export const REVIEW_VERDICTS = ["needs_work", "pass", "fail"];
export const APPROVAL_STATUSES = ["pending", "approved", "rejected"];
export const AUTOMATION_ALLOWED_OPERATIONS = [
  "buddy.get_current_work",
  "buddy.get_inbox",
  "buddy.get_automations",
  "buddy.set_automation",
  "buddy.new_project",
  "buddy.update_project",
  "buddy.update_memory",
  "buddy.remember_note",
  "buddy.recall",
  "buddy.send",
  "buddy.reply",
  "buddy.delegate",
  "buddy.request_review",
  "buddy.complete_delegation",
  "buddy.complete_assignment",
  "buddy.submit_review",
  "buddy.request_human_approval",
];

export const MEMORY_DOCUMENT_KINDS = ["working", "long_term"];
export const MEMORY_DOCUMENT_CAPS = Object.freeze({
  working: 2_000,
  long_term: 4_000,
  soul: 32_000,
});
// Body bytes are independent of server-stamped provenance and Markdown headers.
export const MEMORY_NOTE_MAX_BYTES = 16_000;
const MEMORY_NOTE_METADATA_MAX_BYTES = 8_000;
const MEMORY_RECALL_MAX_MATCH_BYTES = 16_000;
const MEMORY_RECALL_MAX_TOTAL_BYTES = 256_000;
const MEMORY_RECALL_MAX_FILES = 5_000;
const MEMORY_RECALL_TIMEOUT_MS = 2_000;
const CURRENT_SCHEMA_VERSION = 27;
const ULID_ALPHABET = "0123456789ABCDEFGHJKMNPQRSTVWXYZ";
const DEFAULT_AUTOMATION_MAX_RUNTIME_SECONDS = 600;
const DEFAULT_AUTOMATION_MAX_ITERATIONS = 10;
const DEFAULT_AUTOMATION_MAX_TOKENS = 50_000;
const DEFAULT_AUTOMATION_MAX_COST_USD = 2;
const DEFAULT_AUTOMATION_ALLOWED_OPERATIONS = ["buddy.get_current_work"];

// Direct reports (§8.4). slugify() can return "", and `profiles/${""}/BUDDY_SOUL.md`
// normalises to `<workspace>/profiles/BUDDY_SOUL.md`, so an unchecked slug turns the
// post-commit rename into a rename of the profiles/ directory itself.
const DIRECT_REPORT_SLUG_RE = /^[a-z0-9][a-z0-9-]{0,62}$/;
const MAX_DIRECT_REPORT_SOUL_BYTES = 32_000;
const MAX_BUILDER_SOUL_BYTES = 10_000;
const STAGING_GC_MIN_AGE_MS = 60 * 60 * 1000;
// §9.3. The soul-file state sum maps to the staged-profile action sum through a
// table, so neither #repairProfile nor the promote/discard dispatch branches on
// "what did we find on disk?".
const PROFILE_ACTION_BY_SOUL_STATE = {
  absent: { kind: "promote" },
  materialized: { kind: "discard" },
};

export function defaultDatabasePath() {
  const buddiesHome =
    process.env.BUDDIES_HOME?.trim() || join(homedir(), ".buddies");
  return join(resolve(buddiesHome), "buddies.sqlite");
}

function now() {
  return new Date().toISOString();
}

function id(prefix) {
  return `${prefix}_${randomUUID()}`;
}

function ulid(timestamp) {
  let milliseconds = BigInt(timestamp);
  let timePart = "";
  for (let index = 0; index < 10; index += 1) {
    timePart = ULID_ALPHABET[Number(milliseconds & 31n)] + timePart;
    milliseconds >>= 5n;
  }
  let randomPart = "";
  let randomValue = BigInt(`0x${randomBytes(10).toString("hex")}`);
  for (let index = 0; index < 16; index += 1) {
    randomPart = ULID_ALPHABET[Number(randomValue & 31n)] + randomPart;
    randomValue >>= 5n;
  }
  return `${timePart}${randomPart}`;
}

function assertOneOf(label, value, allowed) {
  if (!allowed.includes(value)) {
    throw new Error(`${label} must be one of: ${allowed.join(", ")}`);
  }
}

function required(label, value) {
  if (typeof value !== "string" || value.trim() === "") {
    throw new Error(`${label} is required`);
  }
  return value.trim();
}

function requireNonNegativeInteger(label, value) {
  if (!Number.isInteger(value) || value < 0) {
    throw new Error(`${label} must be a non-negative integer`);
  }
  return value;
}

function slugify(value) {
  return required("name", value)
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "");
}

function splitUtf8(content, maxBytes) {
  const chunks = [];
  let chunk = "";
  let bytes = 0;
  for (const character of content) {
    const size = Buffer.byteLength(character, "utf8");
    if (bytes + size > maxBytes) {
      chunks.push(chunk);
      chunk = "";
      bytes = 0;
    }
    chunk += character;
    bytes += size;
  }
  if (chunk || chunks.length === 0) chunks.push(chunk);
  return chunks;
}

function readNotePrefix(path) {
  const descriptor = openSync(path, constants.O_RDONLY | constants.O_NOFOLLOW);
  try {
    const bytes = Buffer.alloc(MEMORY_RECALL_MAX_MATCH_BYTES);
    const count = readSync(descriptor, bytes, 0, bytes.length, 0);
    return { content: bytes.subarray(0, count).toString("utf8"), size: fstatSync(descriptor).size };
  } finally {
    closeSync(descriptor);
  }
}

function rows(statement, ...params) {
  return statement.all(...params).map((row) => ({ ...row }));
}

export class BuddiesStore {
  /** Depth for #tx: 0 opens a real transaction, deeper opens a SAVEPOINT. */
  #txDepth = 0;

  constructor(databasePath = defaultDatabasePath()) {
    this.databasePath = databasePath === ":memory:" ? databasePath : resolve(databasePath);
    if (this.databasePath !== ":memory:") {
      mkdirSync(dirname(this.databasePath), { recursive: true });
    }
    this.db = new DatabaseSync(this.databasePath);
    // B5: busy_timeout FIRST, and for every database. SQLite's default is 0, so
    // under WAL the second concurrent writer gets SQLITE_BUSY immediately - and
    // `PRAGMA journal_mode = WAL` itself takes an exclusive lock, so setting the
    // timeout after it means a concurrent open can throw "database is locked"
    // before the timeout it needs has been set.
    this.db.exec("PRAGMA busy_timeout = 5000");
    this.db.exec("PRAGMA foreign_keys = ON");
    if (this.databasePath !== ":memory:") {
      this.db.exec("PRAGMA journal_mode = WAL");
    }
    // §9.3(2): must exist before #gcStagedProfiles runs.
    this.stagingGcErrors = [];
    this.#migrate();
    Object.assign(this, coordinationReceiptMethods, coordinationMethods, coordinationWorkMethods, coordinationApprovalMethods, teamAccessMethods, backgroundWorkMethods, teamConfigurationMethods, knowledgeMethods, mailboxMethods);
    this.#migrateLegacyMemoryPolicies();
    this.#initializeMemoryDocuments();
    this.#gcStagedProfiles();
  }

  coordinationTransaction(callback) {
    return this.#tx(callback);
  }

  close() {
    this.db.close();
  }

  backupDatabase(destination) {
    if (this.databasePath === ":memory:") {
      throw new Error("in-memory Buddy databases cannot be backed up");
    }
    const target = resolve(required("backup destination", destination));
    if (existsSync(target)) throw new Error(`backup destination already exists: ${target}`);
    mkdirSync(dirname(target), { recursive: true });
    this.db.prepare("VACUUM INTO ?").run(target);
    return {
      database: this.databasePath,
      backup: target,
      schemaVersion: this.db.prepare("PRAGMA user_version").get().user_version,
      createdAt: now(),
    };
  }

  #migrate() {
    let version = this.db.prepare("PRAGMA user_version").get().user_version;
    if (version > CURRENT_SCHEMA_VERSION) {
      throw new Error(
        `Database schema ${version} is newer than this Buddies version (${CURRENT_SCHEMA_VERSION})`,
      );
    }
    if (version === 0) {
      this.db.exec(`
        BEGIN;

        CREATE TABLE projects (
          id TEXT PRIMARY KEY,
          slug TEXT NOT NULL UNIQUE,
          name TEXT NOT NULL,
          root_path TEXT NOT NULL UNIQUE,
          created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL
        ) STRICT;

        CREATE TABLE buddies (
          id TEXT PRIMARY KEY,
          project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
          slug TEXT NOT NULL,
          name TEXT NOT NULL,
          role TEXT NOT NULL,
          status TEXT NOT NULL CHECK (status IN ('active', 'paused', 'archived')),
          soul_path TEXT,
          memory_path TEXT,
          provider TEXT,
          model TEXT,
          reasoning_effort TEXT,
          created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL,
          UNIQUE(project_id, slug)
        ) STRICT;

        CREATE TABLE buddy_projects (
          buddy_id TEXT NOT NULL REFERENCES buddies(id) ON DELETE CASCADE,
          project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
          assignment_role TEXT,
          created_at TEXT NOT NULL,
          PRIMARY KEY (buddy_id, project_id)
        ) STRICT;

        CREATE TABLE sprints (
          id TEXT PRIMARY KEY,
          project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
          name TEXT NOT NULL,
          goal TEXT,
          status TEXT NOT NULL CHECK (status IN ('planned', 'active', 'completed', 'cancelled')),
          starts_at TEXT,
          ends_at TEXT,
          created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL
        ) STRICT;

        CREATE UNIQUE INDEX one_active_sprint_per_project
          ON sprints(project_id) WHERE status = 'active';

        CREATE TABLE work_items (
          id TEXT PRIMARY KEY,
          project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
          sprint_id TEXT REFERENCES sprints(id) ON DELETE SET NULL,
          buddy_id TEXT REFERENCES buddies(id) ON DELETE SET NULL,
          title TEXT NOT NULL,
          kind TEXT NOT NULL DEFAULT 'task',
          external_key TEXT,
          source_path TEXT,
          objective TEXT,
          definition_of_done TEXT NOT NULL,
          status TEXT NOT NULL CHECK (
            status IN ('backlog', 'ready', 'in_progress', 'blocked', 'review', 'done', 'cancelled')
          ),
          priority INTEGER NOT NULL DEFAULT 0,
          next_action TEXT,
          blocked_reason TEXT,
          created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL,
          completed_at TEXT
        ) STRICT;

        CREATE UNIQUE INDEX work_items_by_external_key
          ON work_items(project_id, external_key)
          WHERE external_key IS NOT NULL;

        CREATE INDEX work_items_by_project_status
          ON work_items(project_id, status, priority DESC, created_at);
        CREATE INDEX work_items_by_buddy_status
          ON work_items(buddy_id, status, priority DESC, created_at);

        CREATE TABLE conversation_links (
          id TEXT PRIMARY KEY,
          buddy_id TEXT NOT NULL REFERENCES buddies(id) ON DELETE CASCADE,
          work_item_id TEXT REFERENCES work_items(id) ON DELETE SET NULL,
          provider TEXT NOT NULL,
          provider_session_id TEXT,
          unleashd_conversation_id TEXT,
          status TEXT NOT NULL CHECK (status IN ('active', 'complete', 'failed', 'cancelled')),
          started_at TEXT NOT NULL,
          last_active_at TEXT NOT NULL,
          ended_at TEXT,
          CHECK (provider_session_id IS NOT NULL OR unleashd_conversation_id IS NOT NULL)
        ) STRICT;

        CREATE UNIQUE INDEX conversation_links_by_unleashd_id
          ON conversation_links(unleashd_conversation_id)
          WHERE unleashd_conversation_id IS NOT NULL;

        PRAGMA user_version = 3;
        COMMIT;
      `);
      version = 3;
    }
    if (version === 1) {
      this.db.exec(`
        BEGIN;
        CREATE TABLE buddy_projects (
          buddy_id TEXT NOT NULL REFERENCES buddies(id) ON DELETE CASCADE,
          project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
          assignment_role TEXT,
          created_at TEXT NOT NULL,
          PRIMARY KEY (buddy_id, project_id)
        ) STRICT;
        INSERT INTO buddy_projects (buddy_id, project_id, assignment_role, created_at)
          SELECT id, project_id, role, created_at FROM buddies;
        PRAGMA user_version = 2;
        COMMIT;
      `);
      version = 2;
    }
    if (version === 2) {
      this.db.exec(`
        BEGIN;
        ALTER TABLE work_items ADD COLUMN kind TEXT NOT NULL DEFAULT 'task';
        ALTER TABLE work_items ADD COLUMN external_key TEXT;
        ALTER TABLE work_items ADD COLUMN source_path TEXT;
        CREATE UNIQUE INDEX work_items_by_external_key
          ON work_items(project_id, external_key)
          WHERE external_key IS NOT NULL;
        PRAGMA user_version = 3;
        COMMIT;
      `);
      version = 3;
    }
    if (version === 3) {
      this.db.exec(`
        BEGIN;

        CREATE TABLE owned_projects (
          id TEXT PRIMARY KEY,
          workspace_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
          buddy_id TEXT NOT NULL REFERENCES buddies(id) ON DELETE CASCADE,
          sprint_id TEXT REFERENCES sprints(id) ON DELETE SET NULL,
          title TEXT NOT NULL,
          objective TEXT,
          definition_of_done TEXT NOT NULL,
          status TEXT NOT NULL CHECK (
            status IN ('backlog', 'ready', 'in_progress', 'blocked', 'review', 'done', 'cancelled')
          ),
          priority INTEGER NOT NULL DEFAULT 0,
          next_action TEXT,
          blocked_reason TEXT,
          source_path TEXT,
          external_key TEXT,
          created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL,
          completed_at TEXT
        ) STRICT;

        CREATE UNIQUE INDEX owned_projects_by_external_key
          ON owned_projects(workspace_id, external_key)
          WHERE external_key IS NOT NULL;
        CREATE INDEX owned_projects_by_buddy_status
          ON owned_projects(buddy_id, status, priority DESC, created_at);

        CREATE TABLE buddy_todos (
          id TEXT PRIMARY KEY,
          buddy_project_id TEXT NOT NULL REFERENCES owned_projects(id) ON DELETE CASCADE,
          title TEXT NOT NULL,
          status TEXT NOT NULL CHECK (
            status IN ('open', 'in_progress', 'blocked', 'done', 'cancelled')
          ),
          position INTEGER NOT NULL,
          definition_of_done TEXT,
          next_action TEXT,
          blocked_reason TEXT,
          created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL,
          completed_at TEXT
        ) STRICT;
        CREATE INDEX buddy_todos_by_project_position
          ON buddy_todos(buddy_project_id, position, created_at);

        CREATE TABLE buddy_automations (
          id TEXT PRIMARY KEY,
          buddy_id TEXT NOT NULL REFERENCES buddies(id) ON DELETE CASCADE,
          workspace_id TEXT REFERENCES projects(id) ON DELETE CASCADE,
          buddy_project_id TEXT REFERENCES owned_projects(id) ON DELETE CASCADE,
          name TEXT NOT NULL,
          schedule_kind TEXT NOT NULL CHECK (schedule_kind IN ('cron', 'interval')),
          schedule_expression TEXT NOT NULL,
          timezone TEXT NOT NULL,
          job_kind TEXT NOT NULL CHECK (job_kind IN ('prompt', 'sequence', 'loop')),
          job_payload TEXT NOT NULL,
          enabled INTEGER NOT NULL DEFAULT 1 CHECK (enabled IN (0, 1)),
          next_run_at TEXT,
          last_run_at TEXT,
          created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL
        ) STRICT;
        CREATE INDEX buddy_automations_due
          ON buddy_automations(enabled, next_run_at);

        CREATE TABLE buddy_automation_runs (
          id TEXT PRIMARY KEY,
          automation_id TEXT NOT NULL REFERENCES buddy_automations(id) ON DELETE CASCADE,
          scheduled_for TEXT NOT NULL,
          idempotency_key TEXT NOT NULL UNIQUE,
          status TEXT NOT NULL CHECK (
            status IN ('claimed', 'running', 'complete', 'failed', 'cancelled')
          ),
          conversation_id TEXT,
          iteration INTEGER NOT NULL DEFAULT 0,
          outcome TEXT,
          error TEXT,
          claimed_at TEXT NOT NULL,
          started_at TEXT,
          ended_at TEXT
        ) STRICT;
        CREATE INDEX buddy_automation_runs_by_automation
          ON buddy_automation_runs(automation_id, claimed_at DESC);

        ALTER TABLE conversation_links
          ADD COLUMN buddy_project_id TEXT REFERENCES owned_projects(id) ON DELETE SET NULL;

        PRAGMA user_version = 4;
        COMMIT;
      `);
      version = 4;
    }
    if (version === 4) {
      this.db.exec(`
        BEGIN;

        ALTER TABLE conversation_links
          ADD COLUMN workspace_id TEXT REFERENCES projects(id) ON DELETE CASCADE;
        UPDATE conversation_links
        SET workspace_id = COALESCE(
          (SELECT workspace_id FROM owned_projects
            WHERE owned_projects.id = conversation_links.buddy_project_id),
          (SELECT project_id FROM work_items
            WHERE work_items.id = conversation_links.work_item_id),
          (SELECT project_id FROM buddies
            WHERE buddies.id = conversation_links.buddy_id)
        );

        CREATE TABLE buddy_relationships (
          id TEXT PRIMARY KEY,
          from_buddy_id TEXT NOT NULL REFERENCES buddies(id) ON DELETE CASCADE,
          to_buddy_id TEXT NOT NULL REFERENCES buddies(id) ON DELETE CASCADE,
          kind TEXT NOT NULL CHECK (
            kind IN ('manager', 'reports_to', 'consults', 'reviews')
          ),
          created_at TEXT NOT NULL,
          UNIQUE(from_buddy_id, to_buddy_id, kind),
          CHECK(from_buddy_id != to_buddy_id)
        ) STRICT;

        CREATE TABLE buddy_skills (
          id TEXT PRIMARY KEY,
          buddy_id TEXT NOT NULL REFERENCES buddies(id) ON DELETE CASCADE,
          name TEXT NOT NULL,
          instruction_path TEXT NOT NULL,
          mode TEXT NOT NULL CHECK (mode IN ('always', 'on_demand')),
          created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL,
          UNIQUE(buddy_id, name)
        ) STRICT;

        CREATE TABLE buddy_delegations (
          id TEXT PRIMARY KEY,
          from_buddy_id TEXT NOT NULL REFERENCES buddies(id) ON DELETE CASCADE,
          to_buddy_id TEXT NOT NULL REFERENCES buddies(id) ON DELETE CASCADE,
          workspace_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
          buddy_project_id TEXT REFERENCES owned_projects(id) ON DELETE SET NULL,
          purpose TEXT NOT NULL,
          parent_conversation_id TEXT,
          child_conversation_id TEXT,
          status TEXT NOT NULL CHECK (
            status IN ('pending', 'active', 'complete', 'failed', 'cancelled')
          ),
          outcome TEXT,
          created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL,
          completed_at TEXT,
          CHECK(from_buddy_id != to_buddy_id)
        ) STRICT;

        CREATE TABLE buddy_reviews (
          id TEXT PRIMARY KEY,
          reviewer_buddy_id TEXT NOT NULL REFERENCES buddies(id) ON DELETE CASCADE,
          subject_buddy_id TEXT NOT NULL REFERENCES buddies(id) ON DELETE CASCADE,
          workspace_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
          buddy_project_id TEXT REFERENCES owned_projects(id) ON DELETE SET NULL,
          conversation_id TEXT,
          status TEXT NOT NULL CHECK (status IN ('draft', 'complete', 'cancelled')),
          verdict TEXT CHECK (verdict IN ('needs_work', 'pass', 'fail')),
          score REAL,
          summary TEXT,
          evidence TEXT NOT NULL DEFAULT '[]',
          created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL,
          completed_at TEXT
        ) STRICT;

        PRAGMA user_version = 5;
        COMMIT;
      `);
      version = 5;
    }
    if (version === 5) {
      this.db.exec(`
        BEGIN;

        UPDATE conversation_links
        SET workspace_id = (
          SELECT project_id FROM buddies
          WHERE buddies.id = conversation_links.buddy_id
        )
        WHERE workspace_id IS NULL;

        UPDATE buddy_automations
        SET workspace_id = (
          SELECT project_id FROM buddies
          WHERE buddies.id = buddy_automations.buddy_id
        )
        WHERE workspace_id IS NULL;

        CREATE TRIGGER conversation_links_workspace_required_insert
        BEFORE INSERT ON conversation_links
        WHEN NEW.workspace_id IS NULL
        BEGIN
          SELECT RAISE(ABORT, 'conversation workspace is required');
        END;

        CREATE TRIGGER conversation_links_workspace_required_update
        BEFORE UPDATE OF workspace_id ON conversation_links
        WHEN NEW.workspace_id IS NULL
        BEGIN
          SELECT RAISE(ABORT, 'conversation workspace is required');
        END;

        CREATE TRIGGER buddy_automations_workspace_required_insert
        BEFORE INSERT ON buddy_automations
        WHEN NEW.workspace_id IS NULL
        BEGIN
          SELECT RAISE(ABORT, 'automation workspace is required');
        END;

        CREATE TRIGGER buddy_automations_workspace_required_update
        BEFORE UPDATE OF workspace_id ON buddy_automations
        WHEN NEW.workspace_id IS NULL
        BEGIN
          SELECT RAISE(ABORT, 'automation workspace is required');
        END;

        PRAGMA user_version = 6;
        COMMIT;
      `);
      version = 6;
    }
    if (version === 6) {
      this.db.exec(`
        BEGIN;

        CREATE TABLE buddy_audit_events (
          id TEXT PRIMARY KEY,
          buddy_id TEXT NOT NULL REFERENCES buddies(id) ON DELETE CASCADE,
          workspace_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
          buddy_project_id TEXT REFERENCES owned_projects(id) ON DELETE SET NULL,
          operation TEXT NOT NULL,
          payload TEXT NOT NULL,
          created_at TEXT NOT NULL
        ) STRICT;
        CREATE INDEX buddy_audit_events_by_buddy
          ON buddy_audit_events(buddy_id, created_at DESC);
        CREATE INDEX buddy_audit_events_by_project
          ON buddy_audit_events(buddy_project_id, created_at DESC);

        PRAGMA user_version = 7;
        COMMIT;
      `);
      version = 7;
    }
    if (version === 7) {
      this.db.exec(`
        BEGIN;

        CREATE TABLE buddy_automation_policies (
          automation_id TEXT PRIMARY KEY
            REFERENCES buddy_automations(id) ON DELETE CASCADE,
          max_runtime_seconds INTEGER NOT NULL CHECK (max_runtime_seconds > 0),
          max_iterations INTEGER NOT NULL CHECK (max_iterations > 0),
          max_tokens INTEGER NOT NULL CHECK (max_tokens > 0),
          max_cost_usd REAL NOT NULL CHECK (max_cost_usd > 0),
          allowed_operations TEXT NOT NULL CHECK (
            json_valid(allowed_operations) AND json_type(allowed_operations) = 'array'
          ),
          created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL
        ) STRICT;

        INSERT INTO buddy_automation_policies (
          automation_id, max_runtime_seconds, max_iterations, max_tokens,
          max_cost_usd, allowed_operations, created_at, updated_at
        )
        SELECT
          id,
          600,
          CASE job_kind
            WHEN 'prompt' THEN 1
            WHEN 'sequence' THEN
              MIN(10, MAX(1, json_array_length(json_extract(job_payload, '$.prompts'))))
            WHEN 'loop' THEN
              MIN(10, MAX(1, CAST(json_extract(job_payload, '$.termination.max_iterations') AS INTEGER)))
          END,
          50000,
          2.0,
          '["buddy.get_current_work"]',
          created_at,
          updated_at
        FROM buddy_automations;

        CREATE TABLE buddy_automation_run_policies (
          run_id TEXT PRIMARY KEY
            REFERENCES buddy_automation_runs(id) ON DELETE CASCADE,
          max_runtime_seconds INTEGER NOT NULL CHECK (max_runtime_seconds > 0),
          max_iterations INTEGER NOT NULL CHECK (max_iterations > 0),
          max_tokens INTEGER NOT NULL CHECK (max_tokens > 0),
          max_cost_usd REAL NOT NULL CHECK (max_cost_usd > 0),
          allowed_operations TEXT NOT NULL CHECK (
            json_valid(allowed_operations) AND json_type(allowed_operations) = 'array'
          ),
          tokens_used INTEGER NOT NULL DEFAULT 0 CHECK (tokens_used >= 0),
          cost_usd REAL NOT NULL DEFAULT 0 CHECK (cost_usd >= 0)
        ) STRICT;

        INSERT INTO buddy_automation_run_policies (
          run_id, max_runtime_seconds, max_iterations, max_tokens,
          max_cost_usd, allowed_operations, tokens_used, cost_usd
        )
        SELECT
          runs.id, policies.max_runtime_seconds, policies.max_iterations,
          policies.max_tokens, policies.max_cost_usd, policies.allowed_operations,
          0, 0
        FROM buddy_automation_runs AS runs
        JOIN buddy_automation_policies AS policies
          ON policies.automation_id = runs.automation_id;

        CREATE TABLE buddy_approval_requests (
          id TEXT PRIMARY KEY,
          buddy_id TEXT NOT NULL REFERENCES buddies(id) ON DELETE CASCADE,
          workspace_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
          buddy_project_id TEXT REFERENCES owned_projects(id) ON DELETE SET NULL,
          automation_run_id TEXT REFERENCES buddy_automation_runs(id) ON DELETE SET NULL,
          conversation_id TEXT,
          action TEXT NOT NULL,
          reason TEXT NOT NULL,
          risk TEXT NOT NULL,
          status TEXT NOT NULL CHECK (status IN ('pending', 'approved', 'rejected')),
          resolved_by TEXT,
          resolution_note TEXT,
          requested_at TEXT NOT NULL,
          resolved_at TEXT,
          CHECK (
            (status = 'pending' AND resolved_by IS NULL AND resolved_at IS NULL)
            OR
            (status IN ('approved', 'rejected') AND resolved_by IS NOT NULL AND resolved_at IS NOT NULL)
          )
        ) STRICT;
        CREATE INDEX buddy_approval_requests_by_buddy
          ON buddy_approval_requests(buddy_id, status, requested_at DESC);
        CREATE INDEX buddy_approval_requests_by_workspace
          ON buddy_approval_requests(workspace_id, status, requested_at DESC);

        PRAGMA user_version = 8;
        COMMIT;
      `);
      version = 8;
    }
    if (version === 8) {
      const runColumns = new Set(
        rows(this.db.prepare("PRAGMA table_info(buddy_automation_runs)")).map(
          (column) => column.name,
        ),
      );
      this.db.exec("BEGIN");
      try {
        if (!runColumns.has("claim_token")) {
          this.db.exec("ALTER TABLE buddy_automation_runs ADD COLUMN claim_token TEXT");
        }
        if (!runColumns.has("claim_expires_at")) {
          this.db.exec(
            "ALTER TABLE buddy_automation_runs ADD COLUMN claim_expires_at TEXT",
          );
        }
        this.db.exec(`
          CREATE INDEX IF NOT EXISTS buddy_automation_runs_by_claim_expiry
            ON buddy_automation_runs(status, claim_expires_at);
          PRAGMA user_version = 9;
          COMMIT;
        `);
      } catch (error) {
        this.db.exec("ROLLBACK");
        throw error;
      }
      version = 9;
    }
    if (version === 9) {
      const delegationColumns = new Set(
        rows(this.db.prepare("PRAGMA table_info(buddy_delegations)")).map(
          (column) => column.name,
        ),
      );
      this.db.exec("BEGIN");
      try {
        if (!delegationColumns.has("dispatch_token")) {
          this.db.exec("ALTER TABLE buddy_delegations ADD COLUMN dispatch_token TEXT");
        }
        if (!delegationColumns.has("dispatch_expires_at")) {
          this.db.exec(
            "ALTER TABLE buddy_delegations ADD COLUMN dispatch_expires_at TEXT",
          );
        }
        this.db.exec(`
          CREATE INDEX IF NOT EXISTS buddy_delegations_by_dispatch_expiry
            ON buddy_delegations(status, dispatch_expires_at);
          PRAGMA user_version = 10;
          COMMIT;
        `);
      } catch (error) {
        this.db.exec("ROLLBACK");
        throw error;
      }
      version = 10;
    }
    if (version === 10) {
      this.db.exec(`
        BEGIN;

        CREATE TABLE IF NOT EXISTS buddy_builder_creations (
          conversation_id TEXT PRIMARY KEY,
          buddy_id TEXT NOT NULL UNIQUE REFERENCES buddies(id) ON DELETE CASCADE,
          workspace_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
          request_fingerprint TEXT NOT NULL,
          created_at TEXT NOT NULL
        ) STRICT;

        PRAGMA user_version = 11;
        COMMIT;
      `);
      version = 11;
    }
    if (version === 11) {
      // Historical. v12 shipped `hire_quota` nullable and without the one-manager
      // indexes; it is kept verbatim so a database already at 12 and a database
      // replaying the ladder converge on the same physical schema. v13 below is
      // where the column is corrected. The PRAGMA table_info guard follows the
      // v9/v10 precedent and is load-bearing: test/v1.test.js resets user_version
      // to 5 on a physically newer database, so the ladder re-runs over a table
      // that already has the column.
      const buddyColumns = new Set(
        rows(this.db.prepare("PRAGMA table_info(buddies)")).map(
          (column) => column.name,
        ),
      );
      this.db.exec("BEGIN");
      try {
        if (!buddyColumns.has("hire_quota")) {
          this.db.exec(
            "ALTER TABLE buddies ADD COLUMN hire_quota INTEGER CHECK (hire_quota IS NULL OR hire_quota >= 0)",
          );
        }
        this.db.exec(`
          PRAGMA user_version = 12;
          COMMIT;
        `);
      } catch (error) {
        this.db.exec("ROLLBACK");
        throw error;
      }
      version = 12;
    }
    if (version === 12) {
      // §6, landed as v13 rather than v12 because commit fc7751a already consumed
      // 12 with the WRONG physical schema and shipped it (databases in the field,
      // including ~/.buddies/buddies.sqlite, sit at user_version 12 with a nullable
      // hire_quota and no indexes). A rewritten `version === 11` block would never
      // be re-entered on those, leaving a store that reports a schema it does not
      // have - exactly the silent fallback T4 forbids. One rung, one path, for
      // fresh and already-12 databases alike.
      //
      // SQLite cannot add NOT NULL to an existing column, hence RENAME/ADD/COPY/DROP.
      const buddyColumns = new Set(
        rows(this.db.prepare("PRAGMA table_info(buddies)")).map(
          (column) => column.name,
        ),
      );
      if (!buddyColumns.has("hire_quota")) {
        throw new Error(
          "schema 12 is missing buddies.hire_quota; refusing to migrate an inconsistent database",
        );
      }
      this.db.exec("BEGIN");
      try {
        this.db.exec("ALTER TABLE buddies RENAME COLUMN hire_quota TO hire_quota_v12");
        this.db.exec(
          "ALTER TABLE buddies ADD COLUMN hire_quota INTEGER NOT NULL DEFAULT 0 CHECK (hire_quota >= 0)",
        );
        this.db.exec("UPDATE buddies SET hire_quota = COALESCE(hire_quota_v12, 0)");
        this.db.exec("ALTER TABLE buddies DROP COLUMN hire_quota_v12");
        // Order matters: normalize the dual encoding first so the collapse sees
        // one edge per relationship, then collapse, then create the indexes -
        // they are a constraint and fail outright on data that violates them.
        this.#normalizeReportsToEdges();
        this.#collapseDuplicateManagerEdges();
        this.db.exec(`
          CREATE UNIQUE INDEX IF NOT EXISTS buddy_one_manager_fwd
            ON buddy_relationships(to_buddy_id) WHERE kind = 'manager';
          CREATE UNIQUE INDEX IF NOT EXISTS buddy_one_manager_rev
            ON buddy_relationships(from_buddy_id) WHERE kind = 'reports_to';
          PRAGMA user_version = 13;
          COMMIT;
        `);
      } catch (error) {
        this.db.exec("ROLLBACK");
        throw error;
      }
      version = 13;
    }
    if (version === 13) {
      // Explicit archival replaces the old enabled=0,next_run_at=NULL sentinel.
      // The backfill preserves the behavior of databases which already used
      // deleteAutomation as archive. See
      // agent_notes/2026-08-24_automation-execution-ownership-design.md I9 in
      // the Unleashd repository.
      const automationColumns = new Set(
        rows(this.db.prepare("PRAGMA table_info(buddy_automations)")).map(
          (column) => column.name,
        ),
      );
      this.db.exec("BEGIN");
      try {
        if (!automationColumns.has("archived_at")) {
          this.db.exec("ALTER TABLE buddy_automations ADD COLUMN archived_at TEXT");
        }
        this.db.exec(`
          UPDATE buddy_automations
          SET archived_at = COALESCE(archived_at, updated_at)
          WHERE enabled = 0 AND next_run_at IS NULL;
          PRAGMA user_version = 14;
          COMMIT;
        `);
      } catch (error) {
        this.db.exec("ROLLBACK");
        throw error;
      }
      version = 14;
    }
    if (version === 14) {
      // SQLite bakes the run-state vocabulary into the table CHECK, so adding
      // durable cancellation is a table migration rather than a TypeScript-only
      // enum edit. `cancel_requested` deliberately remains nonterminal: it keeps
      // the single-run lease occupied while immediately revoking operation
      // authority. See the Unleashd repository's
      // agent_notes/2026-08-24_automation-execution-ownership-design.md.
      this.db.exec("PRAGMA foreign_keys = OFF");
      this.db.exec("BEGIN");
      try {
        this.db.exec(`
          CREATE TABLE buddy_automation_runs_v15 (
            id TEXT PRIMARY KEY,
            automation_id TEXT NOT NULL REFERENCES buddy_automations(id) ON DELETE CASCADE,
            scheduled_for TEXT NOT NULL,
            idempotency_key TEXT NOT NULL UNIQUE,
            status TEXT NOT NULL CHECK (
              status IN (
                'claimed', 'running', 'cancel_requested',
                'complete', 'failed', 'cancelled'
              )
            ),
            conversation_id TEXT,
            iteration INTEGER NOT NULL DEFAULT 0,
            outcome TEXT,
            error TEXT,
            claimed_at TEXT NOT NULL,
            started_at TEXT,
            ended_at TEXT,
            claim_token TEXT,
            claim_expires_at TEXT
          ) STRICT;
          INSERT INTO buddy_automation_runs_v15 (
            id, automation_id, scheduled_for, idempotency_key, status,
            conversation_id, iteration, outcome, error, claimed_at,
            started_at, ended_at, claim_token, claim_expires_at
          )
          SELECT
            id, automation_id, scheduled_for, idempotency_key, status,
            conversation_id, iteration, outcome, error, claimed_at,
            started_at, ended_at, claim_token, claim_expires_at
          FROM buddy_automation_runs;
          DROP TABLE buddy_automation_runs;
          ALTER TABLE buddy_automation_runs_v15 RENAME TO buddy_automation_runs;
          CREATE INDEX buddy_automation_runs_by_automation
            ON buddy_automation_runs(automation_id, claimed_at DESC);
          CREATE INDEX buddy_automation_runs_by_claim_expiry
            ON buddy_automation_runs(status, claim_expires_at);
          PRAGMA user_version = 15;
          COMMIT;
        `);
      } catch (error) {
        this.db.exec("ROLLBACK");
        throw error;
      } finally {
        this.db.exec("PRAGMA foreign_keys = ON");
      }
      const foreignKeyViolation = this.db.prepare("PRAGMA foreign_key_check").get();
      if (foreignKeyViolation) {
        throw new Error(`automation run migration broke a foreign key: ${foreignKeyViolation.table}`);
      }
      version = 15;
    }
    if (version === 15) {
      this.db.exec(`
        BEGIN;
        CREATE TABLE IF NOT EXISTS buddy_memory_revisions (
          id TEXT PRIMARY KEY,
          buddy_id TEXT NOT NULL REFERENCES buddies(id) ON DELETE CASCADE,
          document_kind TEXT NOT NULL CHECK (document_kind IN ('working', 'long_term')),
          revision INTEGER NOT NULL CHECK (revision > 0),
          base_revision_id TEXT REFERENCES buddy_memory_revisions(id),
          body TEXT NOT NULL,
          reasoning TEXT NOT NULL,
          author_kind TEXT NOT NULL,
          requested_by TEXT,
          provenance_json TEXT NOT NULL DEFAULT '{}',
          sha256 TEXT NOT NULL,
          created_at TEXT NOT NULL,
          UNIQUE(buddy_id, document_kind, revision)
        ) STRICT;
        CREATE INDEX IF NOT EXISTS buddy_memory_revisions_by_buddy_document
          ON buddy_memory_revisions(buddy_id, document_kind, revision DESC);

        CREATE TABLE IF NOT EXISTS buddy_memory_heads (
          buddy_id TEXT NOT NULL REFERENCES buddies(id) ON DELETE CASCADE,
          document_kind TEXT NOT NULL CHECK (document_kind IN ('working', 'long_term')),
          revision_id TEXT NOT NULL REFERENCES buddy_memory_revisions(id),
          generation INTEGER NOT NULL CHECK (generation > 0),
          updated_at TEXT NOT NULL,
          PRIMARY KEY (buddy_id, document_kind)
        ) STRICT;

        PRAGMA user_version = 16;
        COMMIT;
      `);
      version = 16;
    }
    if (version === 16) {
      // Soul revisions share the immutable ledger, but remain outside the
      // Buddy operation surface. Widen the schema CHECK with a copy migration.
      this.db.exec("PRAGMA foreign_keys = OFF");
      this.db.exec("BEGIN");
      try {
        this.db.exec(`
          CREATE TABLE buddy_memory_revisions_v17 (
            id TEXT PRIMARY KEY,
            buddy_id TEXT NOT NULL REFERENCES buddies(id) ON DELETE CASCADE,
            document_kind TEXT NOT NULL CHECK (document_kind IN ('working', 'long_term', 'soul')),
            revision INTEGER NOT NULL CHECK (revision > 0),
            base_revision_id TEXT REFERENCES buddy_memory_revisions_v17(id),
            body TEXT NOT NULL,
            reasoning TEXT NOT NULL,
            author_kind TEXT NOT NULL,
            requested_by TEXT,
            provenance_json TEXT NOT NULL DEFAULT '{}',
            sha256 TEXT NOT NULL,
            created_at TEXT NOT NULL,
            UNIQUE(buddy_id, document_kind, revision)
          ) STRICT;
          INSERT INTO buddy_memory_revisions_v17 (
            id, buddy_id, document_kind, revision, base_revision_id, body, reasoning,
            author_kind, requested_by, provenance_json, sha256, created_at
          )
          SELECT id, buddy_id, document_kind, revision, base_revision_id, body, reasoning,
            author_kind, requested_by, provenance_json, sha256, created_at
          FROM buddy_memory_revisions;
          DROP INDEX IF EXISTS buddy_memory_revisions_v17_by_buddy_document;
          CREATE INDEX buddy_memory_revisions_v17_by_buddy_document
            ON buddy_memory_revisions_v17(buddy_id, document_kind, revision DESC);
          DROP TABLE buddy_memory_revisions;
          ALTER TABLE buddy_memory_revisions_v17 RENAME TO buddy_memory_revisions;

          CREATE TABLE buddy_memory_heads_v17 (
            buddy_id TEXT NOT NULL REFERENCES buddies(id) ON DELETE CASCADE,
            document_kind TEXT NOT NULL CHECK (document_kind IN ('working', 'long_term', 'soul')),
            revision_id TEXT NOT NULL REFERENCES buddy_memory_revisions(id),
            generation INTEGER NOT NULL CHECK (generation > 0),
            updated_at TEXT NOT NULL,
            PRIMARY KEY (buddy_id, document_kind)
          ) STRICT;
          INSERT INTO buddy_memory_heads_v17
            (buddy_id, document_kind, revision_id, generation, updated_at)
          SELECT buddy_id, document_kind, revision_id, generation, updated_at
          FROM buddy_memory_heads;
          DROP TABLE buddy_memory_heads;
          ALTER TABLE buddy_memory_heads_v17 RENAME TO buddy_memory_heads;
          PRAGMA user_version = 17;
          COMMIT;
        `);
      } catch (error) {
        this.db.exec("ROLLBACK");
        throw error;
      } finally {
        this.db.exec("PRAGMA foreign_keys = ON");
      }
      const foreignKeyViolation = this.db.prepare("PRAGMA foreign_key_check").get();
      if (foreignKeyViolation) {
        throw new Error(`memory migration broke a foreign key: ${foreignKeyViolation.table}`);
      }
      version = 17;
    }
    if (version < 19) {
      // Two independent builds used v18: one introduced messages, the other
      // multi-hire Builder results. Converge either physical shape in one
      // transaction, preserving every existing message and creation slot.
      this.db.exec(`
        BEGIN IMMEDIATE;
        CREATE TABLE IF NOT EXISTS buddy_messages (
          id TEXT PRIMARY KEY,
          from_buddy_id TEXT NOT NULL REFERENCES buddies(id),
          to_buddy_id TEXT REFERENCES buddies(id),
          workspace_id TEXT NOT NULL REFERENCES projects(id),
          buddy_project_id TEXT REFERENCES owned_projects(id),
          purpose TEXT NOT NULL, body TEXT NOT NULL, evidence TEXT NOT NULL,
          parent_conversation_id TEXT, child_conversation_id TEXT UNIQUE,
          status TEXT NOT NULL CHECK(status IN ('pending','active','replied','failed','cancelled')),
          outcome TEXT, reply_body TEXT, reply_evidence TEXT NOT NULL DEFAULT '[]',
          replied_by TEXT, wait_until TEXT,
          wait_status TEXT NOT NULL CHECK(wait_status IN ('none','waiting','replied','timed_out','cancelled')),
          created_at TEXT NOT NULL, updated_at TEXT NOT NULL, replied_at TEXT
        );
        CREATE INDEX IF NOT EXISTS buddy_messages_sender ON buddy_messages(from_buddy_id, workspace_id, created_at DESC);
        CREATE INDEX IF NOT EXISTS buddy_messages_recipient ON buddy_messages(to_buddy_id, workspace_id, created_at DESC);
        CREATE INDEX IF NOT EXISTS buddy_messages_waits ON buddy_messages(wait_status, wait_until);
        CREATE TABLE IF NOT EXISTS buddy_builder_hires (
          conversation_id TEXT NOT NULL,
          creation_key TEXT NOT NULL DEFAULT 'default',
          buddy_id TEXT NOT NULL UNIQUE REFERENCES buddies(id) ON DELETE CASCADE,
          workspace_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
          request_fingerprint TEXT NOT NULL,
          created_at TEXT NOT NULL,
          PRIMARY KEY (conversation_id, creation_key)
        ) STRICT;
        INSERT OR IGNORE INTO buddy_builder_hires
          (conversation_id, buddy_id, workspace_id, request_fingerprint, created_at)
        SELECT conversation_id, buddy_id, workspace_id, request_fingerprint, created_at
        FROM buddy_builder_creations;
        PRAGMA user_version = 19;
        COMMIT;
      `);
    }
    migrateCoordination(this.db);
    migrateTeamAccess(this.db);
    migrateBackgroundWork(this.db);
    migrateTeamConfiguration(this.db);
    migrateKnowledge(this.db);
    migrateMailbox(this.db);
    migrateCoordinationReceipts(this.db);
  }

  #migrateLegacyMemoryPolicies() {
    // Only future automation policy is upgraded. Claimed runs retain their
    // immutable capability snapshot; a restart cannot widen a live run's grants.
    this.#tx(() => {
      const policies = rows(this.db.prepare(`
        SELECT automation_id, allowed_operations FROM buddy_automation_policies
        WHERE EXISTS (
          SELECT 1 FROM json_each(allowed_operations)
          WHERE value IN ('buddy.remember', 'buddy.compact_memory')
        )
      `));
      const replacements = {
        "buddy.remember": "buddy.remember_note",
        "buddy.compact_memory": "buddy.update_memory",
      };
      for (const policy of policies) {
        const operations = [...new Set(JSON.parse(policy.allowed_operations)
          .map((operation) => replacements[operation] || operation))];
        this.db.prepare(`
          UPDATE buddy_automation_policies SET allowed_operations = ?, updated_at = ?
          WHERE automation_id = ?
        `).run(JSON.stringify(operations), now(), policy.automation_id);
      }
    });
  }

  #initializeMemoryDocuments(buddyIds = null) {
    const buddies = buddyIds
      ? buddyIds.map((buddyId) => this.getBuddy(buddyId)).filter(Boolean)
      : rows(
          this.db.prepare(
            "SELECT id, project_id, slug, name, memory_path, soul_path FROM buddies ORDER BY id",
          ),
        );
    const findHead = this.db.prepare(
      "SELECT revision_id FROM buddy_memory_heads WHERE buddy_id = ? AND document_kind = ?",
    );
    for (const buddy of buddies) {
      for (const documentKind of MEMORY_DOCUMENT_KINDS) {
        const initialized = this.#tx(() => {
          if (findHead.get(buddy.id, documentKind)) return null;
          const legacy = documentKind === "long_term" ? this.#readLegacySummary(buddy) : "";
          const body = this.#migrateMemoryBody(legacy, documentKind);
          const revisionId = id("memory_revision");
          const timestamp = now();
          this.db
            .prepare(`
              INSERT INTO buddy_memory_revisions (
                id, buddy_id, document_kind, revision, base_revision_id, body, reasoning,
                author_kind, requested_by, provenance_json, sha256, created_at
              ) VALUES (?, ?, ?, 1, NULL, ?, ?, 'migration', NULL, ?, ?, ?)
            `)
            .run(
              revisionId,
              buddy.id,
              documentKind,
              body,
              legacy.length > MEMORY_DOCUMENT_CAPS[documentKind]
                ? `Legacy ${documentKind === "long_term" ? "MEMORY.md" : "memory"} exceeded the ${MEMORY_DOCUMENT_CAPS[documentKind]}-character cap; it remains available for manual migration and was not silently truncated.`
                : legacy
                  ? `Migrated legacy ${documentKind === "long_term" ? "MEMORY.md" : "memory"} into the v2 document chain.`
                : `Initialized empty ${documentKind} memory document for v2.`,
              JSON.stringify(
                legacy
                  ? { source: "legacy_memory_file", migrated: body.length > 0 }
                  : { source: "initialization" },
              ),
              createHash("sha256").update(body).digest("hex"),
              timestamp,
            );
          this.db
            .prepare(`
              INSERT INTO buddy_memory_heads
                (buddy_id, document_kind, revision_id, generation, updated_at)
              VALUES (?, ?, ?, 1, ?)
            `)
            .run(buddy.id, documentKind, revisionId, timestamp);
          return { body, revision: 1, timestamp };
        });
        if (initialized) {
          this.#materializeMemoryDocument(buddy.id, documentKind);
        }
      }
      const initializedSoul = this.#initializeSoulDocument(buddy);
      if (initializedSoul && buddy.soul_path) {
        this.#materializeMemoryDocument(buddy.id, "soul");
      }
      this.#migrateLegacyNotes(buddy);
    }
  }

  #initializeSoulDocument(buddy, supplied = null) {
    return this.#tx(() => {
      if (this.#memoryHead(buddy.id, "soul")) return null;
      const body = supplied?.body ?? this.#readLegacySoul(buddy);
      const revisionId = id("memory_revision");
      const timestamp = now();
      this.db.prepare(`
        INSERT INTO buddy_memory_revisions (
          id, buddy_id, document_kind, revision, base_revision_id, body, reasoning,
          author_kind, requested_by, provenance_json, sha256, created_at
        ) VALUES (?, ?, 'soul', 1, NULL, ?, ?, ?, ?, ?, ?, ?)
      `).run(
        revisionId, buddy.id, body,
        supplied?.reasoning ?? (body
          ? "Imported the existing Buddy soul into the revision ledger."
          : "Initialized an empty Buddy soul."),
        supplied ? "owner" : "migration",
        supplied?.requestedBy ?? null,
        JSON.stringify(supplied?.provenance ?? (body
          ? { source: "legacy_soul_file", migrated: true }
          : { source: "initialization" })),
        createHash("sha256").update(body).digest("hex"), timestamp,
      );
      this.db.prepare(`
        INSERT INTO buddy_memory_heads
          (buddy_id, document_kind, revision_id, generation, updated_at)
        VALUES (?, 'soul', ?, 1, ?)
      `).run(buddy.id, revisionId, timestamp);
      return { body, revision: 1, timestamp };
    });
  }

  #ensureMemoryDocuments(buddy) {
    const missing = [...MEMORY_DOCUMENT_KINDS, "soul"].some(
      (documentKind) => !this.#memoryHead(buddy.id, documentKind),
    );
    if (missing) this.#initializeMemoryDocuments([buddy.id]);
  }

  #readLegacySummary(buddy) {
    if (!buddy.memory_path) return "";
    const path = this.#containedPath(this.#memoryRoot(buddy), "MEMORY.md");
    try {
      return readFileSync(path, "utf8");
    } catch (error) {
      if (error.code !== "ENOENT") throw error;
      return "";
    }
  }

  #readLegacySoul(buddy) {
    if (!buddy.soul_path) return "";
    try {
      return readFileSync(buddy.soul_path, "utf8");
    } catch (error) {
      if (error.code !== "ENOENT") throw error;
      return "";
    }
  }

  #migrateMemoryBody(body, documentKind) {
    const cap = MEMORY_DOCUMENT_CAPS[documentKind];
    return body.length <= cap ? body : "";
  }

  #memoryHead(buddy, documentKind) {
    const row = this.db
      .prepare(`
        SELECT h.buddy_id, h.document_kind, h.revision_id, h.generation,
               h.updated_at, r.revision, r.body, r.reasoning, r.author_kind,
               r.requested_by, r.provenance_json, r.sha256, r.created_at
        FROM buddy_memory_heads h
        JOIN buddy_memory_revisions r ON r.id = h.revision_id
        WHERE h.buddy_id = ? AND h.document_kind = ?
      `)
      .get(buddy, documentKind);
    return row ? { ...row } : null;
  }

  #renderMemoryDocument(documentKind, body, revision, timestamp) {
    return `---\nversion: ${revision}\nupdated: ${timestamp}\ndocument: ${documentKind}\n---\n\n${body.trimEnd()}\n`;
  }

  #materializeMemoryDocument(buddy, documentKind) {
    // Another writer may commit between our revision commit and this projection.
    // Hold the same SQLite writer lock through latest-head read and rename, so
    // an older caller cannot overwrite a newer generated view.
    return this.#tx(() => {
      const ownerBuddy = this.#requireBuddy(buddy);
      const head = this.#memoryHead(ownerBuddy.id, documentKind);
      if (!head) throw new Error(`memory document is not initialized: ${documentKind}`);
      const root = this.#memoryRoot(ownerBuddy);
      mkdirSync(root, { recursive: true });
      const filename =
        documentKind === "working"
          ? "WORKING_MEMORY.md"
          : documentKind === "long_term"
            ? "LONG_TERM_MEMORY.md"
            : "BUDDY_SOUL.md";
      const target =
        documentKind === "soul"
          ? this.#projectPath(this.#requireProject(ownerBuddy.project_id), ownerBuddy.soul_path)
          : this.#containedPath(root, filename);
      const temporary = this.#containedPath(root, `.${filename}.${randomUUID()}.tmp`);
      const rendered = this.#renderMemoryDocument(documentKind, head.body, head.revision, head.updated_at);
      try {
        writeFileSync(temporary, rendered, "utf8");
        renameSync(temporary, target);
      } catch (error) {
        rmSync(temporary, { force: true });
        throw error;
      }
      return target;
    });
  }

  /**
   * §8.3 item 2, applied to rows written before setBuddyRelationship normalized.
   * `manager A->B` and `reports_to B->A` are inverse encodings of one edge; while
   * both exist, overview() derives pairs {A:B} and {B:A} and BOTH buddies vanish
   * from `topLevel` with no UI signal, and the partial unique indexes below
   * constrain each encoding separately so neither one catches it.
   *
   * Rewrite every `reports_to` row as the equivalent `manager` row, then drop the
   * encoding entirely. Raw SQL rather than setBuddyRelationship: a migration must
   * not depend on the public API surface it is migrating toward.
   */
  #normalizeReportsToEdges() {
    const converted = this.db
      .prepare(`
        INSERT INTO buddy_relationships (id, from_buddy_id, to_buddy_id, kind, created_at)
        SELECT 'relationship_norm_' || id, to_buddy_id, from_buddy_id, 'manager', created_at
        FROM buddy_relationships WHERE kind = 'reports_to'
        ON CONFLICT(from_buddy_id, to_buddy_id, kind) DO NOTHING
      `)
      .run().changes;
    this.db.prepare("DELETE FROM buddy_relationships WHERE kind = 'reports_to'").run();
    return converted;
  }

  /**
   * §6 backfill. v13's partial unique indexes are a constraint, not an assertion,
   * so CREATE INDEX fails outright on a database that already holds two manager
   * edges into one report. `UNIQUE(from_buddy_id, to_buddy_id, kind)` only ever
   * constrained the pair, never the report's in-degree, and the relationships
   * route writes edges directly, so duplicates are reachable today.
   *
   * Keep the earliest edge per report and delete the rest. `ORDER BY created_at,
   * id` (not `created_at` alone): created_at is millisecond ISO, so ties have no
   * stable order and can flip after `VACUUM INTO`, which would make the surviving
   * manager nondeterministic.
   *
   * Raw INSERT rather than recordAuditEvent, for the same reason as above.
   */
  #collapseDuplicateManagerEdges() {
    const losers = rows(
      this.db.prepare(`
        SELECT edge.id, edge.created_at,
               edge.to_buddy_id AS report_id, edge.from_buddy_id AS manager_id,
               report.project_id AS workspace_id
        FROM buddy_relationships AS edge
        JOIN buddies AS report ON report.id = edge.to_buddy_id
        WHERE edge.kind = 'manager'
          AND edge.id <> (
            SELECT winner.id FROM buddy_relationships AS winner
            WHERE winner.kind = 'manager' AND winner.to_buddy_id = edge.to_buddy_id
            ORDER BY winner.created_at, winner.id
            LIMIT 1
          )
        ORDER BY edge.created_at, edge.id
      `),
    );
    const deleteEdge = this.db.prepare("DELETE FROM buddy_relationships WHERE id = ?");
    const insertAudit = this.db.prepare(`
      INSERT INTO buddy_audit_events (
        id, buddy_id, workspace_id, buddy_project_id, operation, payload, created_at
      ) VALUES (?, ?, ?, NULL, 'buddy.migration_collapsed_manager_edge', ?, ?)
    `);
    const timestamp = now();
    for (const edge of losers) {
      deleteEdge.run(edge.id);
      insertAudit.run(
        id("audit"),
        edge.report_id,
        edge.workspace_id,
        JSON.stringify({
          relationshipId: edge.id,
          managerId: edge.manager_id,
          reportId: edge.report_id,
          createdAt: edge.created_at,
          reason: "schema v13 enforces one manager per report",
        }),
        timestamp,
      );
    }
    return losers.length;
  }

  /**
   * §7.1. Re-entrant transaction. `node:sqlite` has no `db.transaction()` (this
   * store is DatabaseSync, not better-sqlite3), so nesting was hand-rolled and
   * broken (B2): an inner `BEGIN` threw "cannot start a transaction within a
   * transaction", the inner catch's `ROLLBACK` destroyed the CALLER's transaction,
   * and the caller's own `ROLLBACK` then threw "no transaction is active",
   * masking the real error.
   *
   * Depth 0 opens BEGIN IMMEDIATE: the write lock is taken up front, so a decision
   * read inside the body cannot be invalidated by another connection before the
   * write lands (B4). Deeper calls open a depth-NAMED savepoint - a single shared
   * name would release the wrong one at depth 3.
   *
   * The catch arm is guarded on `this.db.isTransaction` because a statement that
   * aborts the transaction (or a failed COMMIT) leaves none active, and an
   * unguarded ROLLBACK would throw and replace the root cause. The inner catch
   * swallows only the rollback's own error, never the caller's.
   */
  #tx(fn) {
    const depth = this.#txDepth;
    const nested = depth > 0 || this.db.isTransaction;
    const savepoint = `buddies_sp_${depth}`;
    this.db.exec(!nested ? "BEGIN IMMEDIATE" : `SAVEPOINT ${savepoint}`);
    this.#txDepth = depth + 1;
    try {
      const result = fn();
      this.db.exec(!nested ? "COMMIT" : `RELEASE ${savepoint}`);
      return result;
    } catch (error) {
      if (this.db.isTransaction) {
        try {
          this.db.exec(
            !nested
              ? "ROLLBACK"
              : `ROLLBACK TO ${savepoint}; RELEASE ${savepoint};`,
          );
        } catch {
          // The rollback failed; the caller's error is the one worth reporting.
        }
      }
      throw error;
    } finally {
      this.#txDepth = depth;
    }
  }

  createProject({ name, rootPath, slug = slugify(name) }) {
    const timestamp = now();
    const project = {
      id: id("project"),
      slug: required("project slug", slug),
      name: required("project name", name),
      rootPath: resolve(required("project root path", rootPath)),
      createdAt: timestamp,
      updatedAt: timestamp,
    };
    this.db
      .prepare(`
        INSERT INTO projects (id, slug, name, root_path, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?)
      `)
      .run(
        project.id,
        project.slug,
        project.name,
        project.rootPath,
        project.createdAt,
        project.updatedAt,
      );
    return this.getProject(project.id);
  }

  getProject(idOrSlug) {
    const row = this.db
      .prepare("SELECT * FROM projects WHERE id = ? OR slug = ?")
      .get(idOrSlug, idOrSlug);
    return row ? { ...row } : null;
  }

  listProjects() {
    return rows(this.db.prepare("SELECT * FROM projects ORDER BY name"));
  }

  createWorkspace(input) {
    return this.createProject(input);
  }

  getWorkspace(idOrSlug) {
    return this.getProject(idOrSlug);
  }

  listWorkspaces() {
    return this.listProjects();
  }

  createBuddy({
    project,
    name,
    role,
    slug = slugify(name),
    status = "active",
    soulPath,
    memoryPath,
    provider,
    model,
    reasoningEffort,
    hireQuota = 0,
  }) {
    assertOneOf("buddy status", status, BUDDY_STATUSES);
    const ownerProject = this.#requireProject(project);
    const timestamp = now();
    const buddy = {
      id: id("buddy"),
      projectId: ownerProject.id,
      slug: required("buddy slug", slug),
      name: required("buddy name", name),
      role: required("buddy role", role),
      status,
      soulPath: soulPath ? this.#projectPath(ownerProject, soulPath) : null,
      memoryPath: memoryPath ? this.#projectPath(ownerProject, memoryPath) : null,
      provider: provider || null,
      model: model || null,
      reasoningEffort: reasoningEffort || null,
      // Legacy compatibility only. Hiring no longer uses a headcount quota.
      hireQuota: requireNonNegativeInteger("hire quota", hireQuota),
      createdAt: timestamp,
      updatedAt: timestamp,
    };
    // #tx-routed because hire calls createBuddy from inside its own transaction.
    this.#tx(() => {
      this.db
        .prepare(`
          INSERT INTO buddies (
            id, project_id, slug, name, role, status, soul_path, memory_path,
            provider, model, reasoning_effort, hire_quota, created_at, updated_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `)
        .run(
          buddy.id,
          buddy.projectId,
          buddy.slug,
          buddy.name,
          buddy.role,
          buddy.status,
          buddy.soulPath,
          buddy.memoryPath,
          buddy.provider,
          buddy.model,
          buddy.reasoningEffort,
          buddy.hireQuota,
          buddy.createdAt,
          buddy.updatedAt,
        );
      this.db
        .prepare(`
          INSERT INTO buddy_projects (buddy_id, project_id, assignment_role, created_at)
          VALUES (?, ?, ?, ?)
        `)
        .run(buddy.id, buddy.projectId, buddy.role, timestamp);
    });
    return this.getBuddy(buddy.id);
  }

  /**
   * One transaction owns Builder idempotency, identity, and every workspace
   * assignment. Application code should not rebuild this with lookup/create
   * sequences: those can race across MCP processes.
   */
  createBuddyFromBuilder({
    conversationId,
    creationKey = "default",
    requestFingerprint,
    project,
    additionalWorkspaces = [],
    managerBuddyId,
    backgroundEnabled = false,
    deferProjection = false,
    name,
    role,
    slug = slugify(name),
    status = "active",
    soul,
    provider,
    model,
    reasoningEffort,
  }) {
    const builderConversationId = required("Builder conversation", conversationId);
    const builderCreationKey = required("Builder creation key", creationKey);
    const fingerprint = required("Builder request fingerprint", requestFingerprint);
    const replay = () => {
      const result = this.getBuddyBuilderResult(builderConversationId, builderCreationKey);
      if (!result) return null;
      if (result.requestFingerprint !== fingerprint) {
        throw new Error("this Builder creation key already created a different Buddy; use a new creationKey for another hire");
      }
      if (!deferProjection) this.#repairBuilderSoul(result.buddy, soul, builderConversationId);
      return result;
    };
    // A receipt proves a completed transition. Manager status and later
    // profile changes must not invalidate or mutate a retry of that transition.
    const existing = replay();
    if (existing) return existing;

    const soulBody = soul === undefined || soul === null ? null : required("Builder soul", soul);
    if (soulBody !== null && Buffer.byteLength(soulBody, "utf8") > MAX_BUILDER_SOUL_BYTES) {
      throw new Error(`Builder soul exceeds ${MAX_BUILDER_SOUL_BYTES} bytes`);
    }
    assertOneOf("buddy status", status, BUDDY_STATUSES);
    if (typeof backgroundEnabled !== "boolean") throw new Error("Builder backgroundEnabled must be a boolean");
    const homeWorkspace = this.#requireProject(project);
    const assignedWorkspaces = [
      homeWorkspace,
      ...additionalWorkspaces.map((workspace) => this.#requireProject(workspace)),
    ].filter((workspace, index, all) =>
      all.findIndex((candidate) => candidate.id === workspace.id) === index);
    const buddySlug = required("buddy slug", slug);
    const soulPath = soulBody
      ? this.#containedPath(homeWorkspace.root_path, "profiles", buddySlug, "BUDDY_SOUL.md")
      : null;
    let created = false;
    try {
      this.#tx(() => {
        // Recheck under the writer lock before any authority checks or inserts.
        const raced = this.db.prepare(`
          SELECT request_fingerprint FROM buddy_builder_hires
          WHERE conversation_id = ? AND creation_key = ?
        `).get(builderConversationId, builderCreationKey);
        if (raced) {
          if (raced.request_fingerprint !== fingerprint) {
            throw new Error("this Builder creation key already created a different Buddy; use a new creationKey for another hire");
          }
          return;
        }
        let manager = null;
        if (managerBuddyId !== undefined) {
          const receipt = this.db.prepare(`
            SELECT buddy_id FROM buddy_builder_hires
            WHERE conversation_id = ? AND buddy_id = ?
          `).get(builderConversationId, required("Builder manager", managerBuddyId));
          if (!receipt) throw new Error("Builder manager must be created in this Builder conversation");
          manager = this.#requireBuddy(receipt.buddy_id);
          if (manager.status !== "active") throw new Error("Builder manager must be active");
          const memberships = new Set(this.listBuddyWorkspaces(manager.id).map((entry) => entry.id));
          for (const workspace of assignedWorkspaces) {
            if (!memberships.has(workspace.id)) {
              throw new Error(`manager ${manager.slug} is not assigned to workspace ${workspace.slug}`);
            }
          }
        }
        const buddy = this.createBuddy({
          project: homeWorkspace.id, name, role, slug: buddySlug, status,
          soulPath, provider, model, reasoningEffort,
        });
        for (const workspace of assignedWorkspaces.slice(1)) {
          this.assignBuddyToWorkspace({ buddy: buddy.id, workspace: workspace.id, role });
        }
        for (const workspace of assignedWorkspaces) {
          this.setCoordinationMembership(buddy.id, workspace.id, { background_enabled: backgroundEnabled });
        }
        if (manager) {
          this.setBuddyRelationship({ fromBuddy: manager.id, toBuddy: buddy.id, kind: "manager" });
        }
        if (soulBody !== null) {
          // The canonical soul commits with the identity. Files are projections,
          // so a crash before materialization cannot initialize an empty soul.
          this.#initializeSoulDocument(buddy, this.#builderSoul(soulBody, buddySlug, builderConversationId));
        }
        this.db.prepare(`
          INSERT INTO buddy_builder_hires
            (conversation_id, creation_key, buddy_id, workspace_id, request_fingerprint, created_at)
          VALUES (?, ?, ?, ?, ?, ?)
        `).run(builderConversationId, builderCreationKey, buddy.id, homeWorkspace.id, fingerprint, now());
        created = true;
      });
    } catch (error) {
      // A concurrent process may have committed this receipt before SQLite
      // reported BUSY/UNIQUE. Only the identical receipt is safe to replay.
      const raced = this.getBuddyBuilderResult(builderConversationId, builderCreationKey);
      if (raced?.requestFingerprint === fingerprint) return replay();
      throw error;
    }
    const result = replay();
    if (!result) throw new Error("Buddy Builder creation did not produce a receipt");
    return { ...result, replayed: !created };
  }

  #builderSoul(soul, slug, conversationId) {
    const body = [
      "<!--", `  authored_by: builder (${conversationId})`,
      `  at: ${now()}`, `  hired_as: ${slug}`, "-->", "", soul, "",
    ].join("\n");
    return {
      body,
      reasoning: "Created the Buddy soul from the owner's Builder request.",
      requestedBy: `builder:${conversationId}`,
      provenance: { source: "buddy_builder", conversationId },
    };
  }

  #repairBuilderSoul(buddy, suppliedSoul, conversationId) {
    if (!buddy.soul_path) return;
    this.#tx(() => {
      // Existing files may have been refined. A replay only fills a missing view
      // and always uses the latest ledger head when one exists.
      let head = this.#memoryHead(buddy.id, "soul");
      if (!head && existsSync(buddy.soul_path)) {
        // Older Builder hires imported their file lazily. Preserve that file,
        // including refinements made before the first ledger read.
        this.#initializeSoulDocument(buddy);
        head = this.#memoryHead(buddy.id, "soul");
      }
      const untouchedEmpty = head?.revision === 1 && head.body === "" &&
        head.author_kind === "migration" && JSON.parse(head.provenance_json).source === "initialization";
      if ((!head || untouchedEmpty) && suppliedSoul !== undefined && suppliedSoul !== null) {
        const soul = required("Builder soul", suppliedSoul);
        if (Buffer.byteLength(soul, "utf8") > MAX_BUILDER_SOUL_BYTES) {
          throw new Error(`Builder soul exceeds ${MAX_BUILDER_SOUL_BYTES} bytes`);
        }
        const supplied = this.#builderSoul(soul, buddy.slug, conversationId);
        if (untouchedEmpty) {
          this.updateSoul(buddy.id, {
            content: supplied.body, baseVersion: head.revision,
            reasoning: "Recovered the original Builder soul after interrupted profile materialization.",
            requestedBy: supplied.requestedBy, provenance: supplied.provenance,
          });
        } else {
          this.#initializeSoulDocument(buddy, supplied);
        }
        head = this.#memoryHead(buddy.id, "soul");
      }
      if (head && !existsSync(buddy.soul_path)) this.#materializeMemoryDocument(buddy.id, "soul");
    });
  }

  getBuddyBuilderResult(conversationId, creationKey = "default") {
    const creation = this.db
      .prepare("SELECT * FROM buddy_builder_hires WHERE conversation_id = ? AND creation_key = ?")
      .get(required("Builder conversation", conversationId), required("Builder creation key", creationKey));
    if (!creation) return null;
    const buddy = this.getBuddy(creation.buddy_id);
    if (!buddy) return null;
    return {
      creationKey: creation.creation_key,
      buddy,
      homeWorkspace: this.getWorkspace(creation.workspace_id),
      workspaces: this.listBuddyWorkspaces(buddy.id),
      requestFingerprint: creation.request_fingerprint,
      replayed: true,
    };
  }

  listBuddyBuilderResults(conversationId) {
    const builderConversationId = required("Builder conversation", conversationId);
    return rows(
      this.db.prepare(`
        SELECT creation_key FROM buddy_builder_hires
        WHERE conversation_id = ? ORDER BY created_at, rowid
      `),
      builderConversationId,
    ).map((creation) => this.getBuddyBuilderResult(builderConversationId, creation.creation_key))
      .filter(Boolean);
  }

  getBuddy(idOrSlug, project) {
    let row;
    if (project) {
      const ownerProject = this.#requireProject(project);
      row = this.db
        .prepare(`
          SELECT buddies.*
          FROM buddies
          JOIN buddy_projects ON buddy_projects.buddy_id = buddies.id
          WHERE buddy_projects.project_id = ? AND (buddies.id = ? OR buddies.slug = ?)
        `)
        .get(ownerProject.id, idOrSlug, idOrSlug);
    } else {
      row = this.db.prepare("SELECT * FROM buddies WHERE id = ?").get(idOrSlug);
      if (!row) {
        const matches = rows(
          this.db.prepare("SELECT * FROM buddies WHERE slug = ? ORDER BY project_id"),
          idOrSlug,
        );
        if (matches.length > 1) {
          throw new Error(
            `buddy slug is ambiguous across workspaces: ${idOrSlug}; use the Buddy id or provide a workspace`,
          );
        }
        row = matches[0];
      }
    }
    return row ? { ...row } : null;
  }

  updateBuddy(buddy, {
    name,
    role,
    status,
    homeWorkspace,
    soulPath,
    memoryPath,
    provider,
    model,
    reasoningEffort,
    hireQuota,
  } = {}) {
    const current = this.#requireBuddy(buddy);
    const workspace =
      homeWorkspace === undefined
        ? this.#requireProject(current.project_id)
        : this.#requireProject(homeWorkspace);
    const nextStatus = status ?? current.status;
    assertOneOf("buddy status", nextStatus, BUDDY_STATUSES);
    const nextSoulPath =
      soulPath === undefined
        ? homeWorkspace === undefined || !current.soul_path
          ? current.soul_path
          : this.#projectPath(workspace, current.soul_path)
        : soulPath
          ? this.#projectPath(workspace, soulPath)
          : null;
    const nextMemoryPath =
      memoryPath === undefined
        ? homeWorkspace === undefined || !current.memory_path
          ? current.memory_path
          : this.#projectPath(workspace, current.memory_path)
        : memoryPath
          ? this.#projectPath(workspace, memoryPath)
          : null;
    // Preserve the legacy field for old callers; it grants or limits no authority.
    const nextHireQuota =
      hireQuota === undefined
        ? current.hire_quota
        : requireNonNegativeInteger("hire quota", hireQuota);
    const timestamp = now();
    // #tx-routed because hire's `reactivatable` arm calls updateBuddy from inside
    // hire's transaction.
    this.#tx(() => {
      this.db
        .prepare(`
          UPDATE buddies SET
            project_id = ?, name = ?, role = ?, status = ?, soul_path = ?, memory_path = ?,
            provider = ?, model = ?, reasoning_effort = ?, hire_quota = ?, updated_at = ?,
            profile_revision = profile_revision + ?
          WHERE id = ?
        `)
        .run(
          workspace.id,
          name === undefined ? current.name : required("buddy name", name),
          role === undefined ? current.role : required("buddy role", role),
          nextStatus,
          nextSoulPath,
          nextMemoryPath,
          provider === undefined ? current.provider : provider || null,
          model === undefined ? current.model : model || null,
          reasoningEffort === undefined
            ? current.reasoning_effort
            : reasoningEffort || null,
          nextHireQuota,
          timestamp,
          Number([name, role, provider, model, reasoningEffort].some(value => value !== undefined)),
          current.id,
        );
      this.db
        .prepare(`
          INSERT INTO buddy_projects (buddy_id, project_id, assignment_role, created_at)
          VALUES (?, ?, ?, ?)
          ON CONFLICT(buddy_id, project_id) DO NOTHING
        `)
        .run(current.id, workspace.id, role ?? current.role, timestamp);
    });
    return this.getBuddy(current.id);
  }

  listBuddies(project) {
    if (!project) {
      return rows(
        this.db.prepare(`
          SELECT buddies.*, projects.slug AS project_slug
          FROM buddies
          JOIN projects ON projects.id = buddies.project_id
          ORDER BY projects.name, buddies.name
        `),
      );
    }
    const ownerProject = this.#requireProject(project);
    return rows(
      this.db.prepare(`
        SELECT buddies.*, buddy_projects.assignment_role
        FROM buddies
        JOIN buddy_projects ON buddy_projects.buddy_id = buddies.id
        WHERE buddy_projects.project_id = ?
        ORDER BY buddies.name
      `),
      ownerProject.id,
    );
  }

  assignBuddyToProject({ buddy, project, role }) {
    const ownerBuddy = this.#requireBuddy(buddy);
    const ownerProject = this.#requireProject(project);
    this.db
      .prepare(`
        INSERT INTO buddy_projects (buddy_id, project_id, assignment_role, created_at)
        VALUES (?, ?, ?, ?)
        ON CONFLICT(buddy_id, project_id) DO UPDATE SET
          assignment_role = excluded.assignment_role
      `)
      .run(ownerBuddy.id, ownerProject.id, role?.trim() || ownerBuddy.role, now());
    return this.listBuddyProjects(ownerBuddy.id);
  }

  listBuddyProjects(buddy) {
    const ownerBuddy = this.#requireBuddy(buddy);
    return rows(
      this.db.prepare(`
        SELECT projects.*, buddy_projects.assignment_role
        FROM buddy_projects
        JOIN projects ON projects.id = buddy_projects.project_id
        WHERE buddy_projects.buddy_id = ?
        ORDER BY projects.name
      `),
      ownerBuddy.id,
    );
  }

  assignBuddyToWorkspace({ buddy, workspace, role }) {
    return this.assignBuddyToProject({ buddy, project: workspace, role });
  }

  listBuddyWorkspaces(buddy) {
    return this.listBuddyProjects(buddy);
  }

  /**
   * §7.4. The only way to move `owned_projects.buddy_id` (B3). `updateProject` has
   * a fixed column list without it, `upsertBuddyProject` throws "external key
   * belongs to another Buddy", and `newProject` inserts once and never updates.
   *
   * Workspace membership is re-checked HERE rather than trusted from the caller:
   * `newProject` guards ownership with `#requireBuddy(buddy, ownerWorkspace)`, so a
   * raw UPDATE would silently produce an owner outside its project's workspace and
   * `getBuddyContext` would then throw "buddy does not belong to the workspace"
   * every time that project is opened. The error names the workspace so the caller
   * can act on it.
   *
   * One project per call, not a bulk move: the caller (retire) already has the list
   * from `listBuddyOwnedProjects` and needs a per-project audit trail.
   */
  reassignOwnedProject({ project, toBuddy }) {
    const ownerProject = this.#requireBuddyProject(project);
    const workspace = this.#requireProject(ownerProject.workspace_id);
    const nextOwner = this.#requireBuddy(toBuddy);
    if (nextOwner.id === ownerProject.buddy_id) {
      throw new Error("Buddy project is already owned by that Buddy");
    }
    if (nextOwner.status === "archived") {
      throw new Error(`cannot reassign work to an archived Buddy: ${nextOwner.slug}`);
    }
    if (!this.#buddyHasProject(nextOwner.id, workspace.id)) {
      throw new Error(
        `buddy ${nextOwner.slug} does not belong to workspace ${workspace.slug}; assign it there before reassigning work`,
      );
    }
    const timestamp = now();
    return this.#tx(() => {
      this.db
        .prepare("UPDATE owned_projects SET buddy_id = ?, updated_at = ? WHERE id = ?")
        .run(nextOwner.id, timestamp, ownerProject.id);
      this.recordAuditEvent({
        buddy: nextOwner.id,
        workspace: workspace.id,
        project: ownerProject.id,
        operation: "buddy.reassign_owned_project",
        payload: {
          projectId: ownerProject.id,
          fromBuddyId: ownerProject.buddy_id,
          toBuddyId: nextOwner.id,
        },
      });
      return this.getBuddyProject(ownerProject.id);
    });
  }

  /**
   * The single choke point for the hierarchy: the relationships route bypasses
   * hire entirely and lands here, so normalization and the cycle rule live here,
   * not in hire. Callers asking for `reports_to` get back a `manager` row with
   * from/to swapped - that is the point (§8.3), not a bug.
   */
  setBuddyRelationship({ fromBuddy, toBuddy, kind }) {
    assertOneOf("relationship kind", kind, BUDDY_RELATIONSHIP_KINDS);
    const from = this.#requireBuddy(fromBuddy);
    const to = this.#requireBuddy(toBuddy);
    if (from.id === to.id) throw new Error("a Buddy cannot relate to itself");
    // Canonicalize once, up front; nothing below asks "which direction was this
    // written in?".
    const edge = CANONICAL_RELATIONSHIP[kind](from.id, to.id);
    const relationshipId = id("relationship");
    // BEGIN IMMEDIATE via #tx: the cycle walk and the insert are one write. Two
    // concurrent "A manages B" / "B manages A" calls would otherwise both read a
    // cycle-free graph and both commit.
    this.#tx(() => {
      // Dispatch on the canonical kind: only hierarchy edges can form the cycle
      // that empties `topLevel`. `consults`/`reviews` cycles are legal.
      if (edge.kind === "manager") this.#assertNoManagementCycle(edge.from, edge.to);
      this.db
        .prepare(`
          INSERT INTO buddy_relationships (
            id, from_buddy_id, to_buddy_id, kind, created_at
          ) VALUES (?, ?, ?, ?, ?)
          ON CONFLICT(from_buddy_id, to_buddy_id, kind) DO NOTHING
        `)
        .run(relationshipId, edge.from, edge.to, edge.kind, now());
    });
    return this.db
      .prepare(`
        SELECT * FROM buddy_relationships
        WHERE from_buddy_id = ? AND to_buddy_id = ? AND kind = ?
      `)
      .get(edge.from, edge.to, edge.kind);
  }

  /**
   * §8.3. A management cycle has no top_level member, so every buddy in it vanishes
   * from the directory - the same invisible failure as the dual encoding. Walk UP
   * from the prospective manager; reaching the report means the new edge closes a
   * loop. Both encodings are read because a database can still hold `reports_to`
   * rows written before v13's normalization (a direct SQLite write, §10 path 2).
   * `seen` bounds the walk so a cycle already present in the data terminates
   * instead of hanging the process.
   */
  #assertNoManagementCycle(managerId, reportId) {
    const managersOf = this.db.prepare(`
      SELECT from_buddy_id AS manager_id FROM buddy_relationships
       WHERE kind = 'manager' AND to_buddy_id = ?
      UNION
      SELECT to_buddy_id AS manager_id FROM buddy_relationships
       WHERE kind = 'reports_to' AND from_buddy_id = ?
    `);
    const seen = new Set();
    const queue = [managerId];
    while (queue.length > 0) {
      const cursor = queue.shift();
      if (cursor === reportId) {
        throw new Error(
          `a Buddy cannot manage its own manager: ${reportId} already manages ${managerId} directly or transitively`,
        );
      }
      if (seen.has(cursor)) continue;
      seen.add(cursor);
      for (const row of rows(managersOf, cursor, cursor)) queue.push(row.manager_id);
    }
  }

  removeBuddyRelationship(relationship) {
    const result = this.db
      .prepare("DELETE FROM buddy_relationships WHERE id = ?")
      .run(required("relationship", relationship));
    return result.changes > 0;
  }

  listBuddyRelationships(buddy) {
    const ownerBuddy = this.#requireBuddy(buddy);
    return rows(
      this.db.prepare(`
        SELECT buddy_relationships.*,
          from_buddy.name AS from_buddy_name, to_buddy.name AS to_buddy_name
        FROM buddy_relationships
        JOIN buddies AS from_buddy ON from_buddy.id = from_buddy_id
        JOIN buddies AS to_buddy ON to_buddy.id = to_buddy_id
        WHERE from_buddy_id = ? OR to_buddy_id = ?
        ORDER BY created_at
      `),
      ownerBuddy.id,
      ownerBuddy.id,
    );
  }

  recordAuditEvent({ buddy, workspace, project, operation, payload = {} }) {
    const ownerWorkspace = this.#requireProject(workspace);
    const ownerBuddy = this.#requireBuddy(buddy, ownerWorkspace);
    const ownerProject = project ? this.#requireBuddyProject(project) : null;
    if (ownerProject && ownerProject.workspace_id !== ownerWorkspace.id) {
      throw new Error("audit project does not belong to the workspace");
    }
    const event = {
      id: id("audit"),
      buddyId: ownerBuddy.id,
      workspaceId: ownerWorkspace.id,
      buddyProjectId: ownerProject?.id || null,
      operation: required("audit operation", operation),
      payload: JSON.stringify(payload ?? {}),
      createdAt: now(),
    };
    this.db
      .prepare(`
        INSERT INTO buddy_audit_events (
          id, buddy_id, workspace_id, buddy_project_id,
          operation, payload, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?)
      `)
      .run(
        event.id,
        event.buddyId,
        event.workspaceId,
        event.buddyProjectId,
        event.operation,
        event.payload,
        event.createdAt,
      );
    return this.getAuditEvent(event.id);
  }

  getAuditEvent(event) {
    const row = this.db
      .prepare("SELECT * FROM buddy_audit_events WHERE id = ?")
      .get(required("audit event", event));
    return row
      ? {
          ...row,
          payload: JSON.parse(row.payload),
        }
      : null;
  }

  listAuditEvents({ buddy, workspace, project, limit = 100 } = {}) {
    const conditions = [];
    const params = [];
    if (buddy) {
      conditions.push("buddy_id = ?");
      params.push(this.#requireBuddy(buddy).id);
    }
    if (workspace) {
      conditions.push("workspace_id = ?");
      params.push(this.#requireProject(workspace).id);
    }
    if (project) {
      conditions.push("buddy_project_id = ?");
      params.push(this.#requireBuddyProject(project).id);
    }
    const where = conditions.length ? `WHERE ${conditions.join(" AND ")}` : "";
    const safeLimit = Math.max(1, Math.min(1000, Number(limit) || 100));
    return rows(
      this.db.prepare(`
        SELECT * FROM buddy_audit_events
        ${where}
        ORDER BY created_at DESC, id DESC
        LIMIT ?
      `),
      ...params,
      safeLimit,
    ).map((row) => ({
      ...row,
      payload: JSON.parse(row.payload),
    }));
  }

  /** Recent mutations, scoped before LIMIT; payloads never become briefing text. */
  listBuddyActivity({ buddy, workspace, project, limit = 12 } = {}) {
    const ownerBuddy = this.#requireBuddy(buddy);
    const ownerWorkspace = workspace ? this.#requireProject(workspace) : null;
    const ownerProject = project ? this.#requireBuddyProject(project) : null;
    if (ownerWorkspace && !this.#buddyHasProject(ownerBuddy.id, ownerWorkspace.id)) {
      throw new Error("Buddy does not belong to the requested activity workspace");
    }
    if (ownerProject && ownerWorkspace && ownerProject.workspace_id !== ownerWorkspace.id) {
      throw new Error("activity project does not belong to the workspace");
    }
    const conditions = [
      "a.buddy_id = ?",
      "a.operation NOT GLOB 'buddy.get_*'",
      "a.operation NOT GLOB 'buddy.list_*'",
      "a.operation <> 'buddy.recall'",
      "a.operation <> 'memory.legacy_migrated'",
    ];
    const params = [ownerBuddy.id];
    if (ownerWorkspace) {
      conditions.push("a.workspace_id = ?");
      params.push(ownerWorkspace.id);
    }
    if (ownerProject) {
      conditions.push("a.buddy_project_id = ?");
      params.push(ownerProject.id);
    }
    const safeLimit = Math.max(1, Math.min(100, Math.floor(Number(limit) || 12)));
    return rows(
      this.db.prepare(`
        SELECT a.id, a.buddy_id, a.workspace_id, a.buddy_project_id,
               a.operation, a.created_at, p.title AS project_title
        FROM buddy_audit_events a
        LEFT JOIN owned_projects p ON p.id = a.buddy_project_id
        WHERE ${conditions.join(" AND ")}
        ORDER BY a.created_at DESC, a.id DESC LIMIT ?
      `),
      ...params,
      safeLimit,
    );
  }

  summarizeMemoryWrites({ buddy, conversationId, since } = {}) {
    const ownerBuddy = this.#requireBuddy(buddy);
    const conversation = required("memory write conversation", conversationId);
    const timestamp = new Date(required("memory write since", since));
    if (Number.isNaN(timestamp.getTime())) throw new Error("memory write since is invalid");
    return {
      ...this.db.prepare(`
        SELECT
          COUNT(CASE WHEN operation = 'buddy.remember_note' THEN 1 END) AS notes,
          COUNT(CASE WHEN operation = 'buddy.update_memory'
            AND json_extract(payload, '$.doc') = 'working' THEN 1 END) AS working,
          COUNT(CASE WHEN operation = 'buddy.update_memory'
            AND json_extract(payload, '$.doc') = 'long_term' THEN 1 END) AS longTerm
        FROM buddy_audit_events
        WHERE buddy_id = ? AND created_at >= ?
          AND operation IN ('buddy.remember_note', 'buddy.update_memory')
          AND json_extract(payload, '$.conversation_id') = ?
      `).get(ownerBuddy.id, timestamp.toISOString(), conversation),
    };
  }

  createApprovalRequest({
    buddy,
    workspace,
    project,
    automationRun,
    conversationId,
    action,
    reason,
    risk,
  }) {
    const ownerWorkspace = this.#requireProject(workspace);
    const ownerBuddy = this.#requireBuddy(buddy, ownerWorkspace);
    const ownerRun = automationRun ? this.#requireAutomationRun(automationRun) : null;
    const runAutomation = ownerRun ? this.#requireAutomation(ownerRun.automation_id) : null;
    const ownerProject = project
      ? this.#requireBuddyProject(project)
      : runAutomation?.buddy_project_id
        ? this.#requireBuddyProject(runAutomation.buddy_project_id)
        : null;
    if (ownerProject && ownerProject.workspace_id !== ownerWorkspace.id) {
      throw new Error("approval project does not belong to the workspace");
    }
    if (ownerProject && ownerProject.buddy_id !== ownerBuddy.id) {
      throw new Error("approval project does not belong to the Buddy");
    }
    if (ownerRun) {
      if (
        runAutomation.buddy_id !== ownerBuddy.id ||
        runAutomation.workspace_id !== ownerWorkspace.id ||
        (ownerProject && runAutomation.buddy_project_id !== ownerProject.id)
      ) {
        throw new Error("automation run does not belong to the approval scope");
      }
    }
    const conversation = conversationId
      ? this.db
          .prepare(`
            SELECT * FROM conversation_links
            WHERE id = ? OR unleashd_conversation_id = ? OR provider_session_id = ?
          `)
          .get(conversationId, conversationId, conversationId)
      : null;
    if (conversationId && !conversation) {
      throw new Error("approval conversation is not linked to the Buddy");
    }
    if (
      conversation &&
      (conversation.buddy_id !== ownerBuddy.id ||
        conversation.workspace_id !== ownerWorkspace.id ||
        (ownerProject && conversation.buddy_project_id !== ownerProject.id))
    ) {
      throw new Error("conversation does not belong to the approval scope");
    }
    const approvalId = id("approval");
    const timestamp = now();
    const request = {
      id: approvalId,
      buddyId: ownerBuddy.id,
      workspaceId: ownerWorkspace.id,
      buddyProjectId: ownerProject?.id || null,
      automationRunId: ownerRun?.id || null,
      conversationId: conversationId?.trim() || null,
      action: required("approval action", action),
      reason: required("approval reason", reason),
      risk: required("approval risk", risk),
      requestedAt: timestamp,
    };
    this.#tx(() => {
      this.db
        .prepare(`
          INSERT INTO buddy_approval_requests (
            id, buddy_id, workspace_id, buddy_project_id, automation_run_id,
            conversation_id, action, reason, risk, status, resolved_by,
            resolution_note, requested_at, resolved_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending', NULL, NULL, ?, NULL)
        `)
        .run(
          request.id,
          request.buddyId,
          request.workspaceId,
          request.buddyProjectId,
          request.automationRunId,
          request.conversationId,
          request.action,
          request.reason,
          request.risk,
          request.requestedAt,
        );
      this.recordAuditEvent({
        buddy: ownerBuddy.id,
        workspace: ownerWorkspace.id,
        project: ownerProject?.id,
        operation: "buddy.request_human_approval",
        payload: {
          approvalId,
          automationRunId: request.automationRunId,
          conversationId: request.conversationId,
          action: request.action,
          reason: request.reason,
          risk: request.risk,
          status: "pending",
        },
      });
    });
    return this.getApprovalRequest(approvalId);
  }

  getApprovalRequest(approval) {
    const row = this.db
      .prepare("SELECT * FROM buddy_approval_requests WHERE id = ?")
      .get(required("approval request", approval));
    return row ? { ...row } : null;
  }

  listApprovalRequests({ buddy, workspace, project, status, limit = 100 } = {}) {
    const conditions = [];
    const params = [];
    if (buddy) {
      conditions.push("buddy_id = ?");
      params.push(this.#requireBuddy(buddy).id);
    }
    if (workspace) {
      conditions.push("workspace_id = ?");
      params.push(this.#requireProject(workspace).id);
    }
    if (project) {
      conditions.push("buddy_project_id = ?");
      params.push(this.#requireBuddyProject(project).id);
    }
    if (status) {
      assertOneOf("approval status", status, APPROVAL_STATUSES);
      conditions.push("status = ?");
      params.push(status);
    }
    return rows(
      this.db.prepare(`
        SELECT * FROM buddy_approval_requests
        ${conditions.length ? `WHERE ${conditions.join(" AND ")}` : ""}
        ORDER BY requested_at DESC, id DESC
        LIMIT ?
      `),
      ...params,
      Math.max(1, Math.min(1000, Number(limit) || 100)),
    );
  }

  resolveApprovalRequest(approval, { decision, resolvedBy, note } = {}) {
    assertOneOf("approval decision", decision, ["approved", "rejected"]);
    const current = this.getApprovalRequest(approval);
    if (!current) throw new Error(`approval request not found: ${approval}`);
    if (current.status !== "pending") {
      throw new Error(`approval request is already ${current.status}`);
    }
    const actor = required("approval resolver", resolvedBy);
    const timestamp = now();
    this.#tx(() => {
      const result = this.db
        .prepare(`
          UPDATE buddy_approval_requests
          SET status = ?, resolved_by = ?, resolution_note = ?, resolved_at = ?
          WHERE id = ? AND status = 'pending'
        `)
        .run(decision, actor, note?.trim() || null, timestamp, current.id);
      if (result.changes !== 1) {
        throw new Error("approval request was resolved concurrently");
      }
      this.recordAuditEvent({
        buddy: current.buddy_id,
        workspace: current.workspace_id,
        project: current.buddy_project_id || undefined,
        operation: "buddy.resolve_human_approval",
        payload: {
          approvalId: current.id,
          decision,
          resolvedBy: actor,
          note: note?.trim() || null,
        },
      });
    });
    return this.getApprovalRequest(current.id);
  }

  assignBuddySkill({ buddy, name, instructionPath, mode = "on_demand" }) {
    assertOneOf("skill mode", mode, BUDDY_SKILL_MODES);
    const ownerBuddy = this.#requireBuddy(buddy);
    const rootWorkspace = this.#requireProject(ownerBuddy.project_id);
    const path = this.#projectPath(rootWorkspace, instructionPath);
    const timestamp = now();
    this.db
      .prepare(`
        INSERT INTO buddy_skills (
          id, buddy_id, name, instruction_path, mode, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(buddy_id, name) DO UPDATE SET
          instruction_path = excluded.instruction_path,
          mode = excluded.mode,
          updated_at = excluded.updated_at
      `)
      .run(id("skill"), ownerBuddy.id, required("skill name", name), path, mode, timestamp, timestamp);
    return this.db
      .prepare("SELECT * FROM buddy_skills WHERE buddy_id = ? AND name = ?")
      .get(ownerBuddy.id, name.trim());
  }

  removeBuddySkill(buddy, name) {
    const ownerBuddy = this.#requireBuddy(buddy);
    return (
      this.db
        .prepare("DELETE FROM buddy_skills WHERE buddy_id = ? AND name = ?")
        .run(ownerBuddy.id, required("skill name", name)).changes > 0
    );
  }

  listBuddySkills(buddy) {
    const ownerBuddy = this.#requireBuddy(buddy);
    return rows(
      this.db.prepare("SELECT * FROM buddy_skills WHERE buddy_id = ? ORDER BY name"),
      ownerBuddy.id,
    );
  }

  /** One durable mailbox. Null recipient means the authenticated human owner. */
  sendMessage({ fromBuddy, to, workspace, project, purpose, body, evidence = [], parentConversationId, waitUntil }) {
    return this.#tx(() => {
      const from = this.#requireBuddy(fromBuddy);
      const ownerWorkspace = this.#requireProject(workspace);
      this.#requireBuddy(from, ownerWorkspace);
      if (from.status !== "active") throw new Error("Sender Buddy is not active");
      const recipient = to === "owner" ? null : this.#requireBuddy(to, ownerWorkspace);
      if (recipient?.status && recipient.status !== "active") throw new Error("Recipient Buddy is not active");
      if (recipient?.id === from.id && waitUntil) throw new Error("A Buddy cannot wait on itself");
      const ownerProject = project ? this.#requireBuddyProject(project) : null;
      if (ownerProject && (ownerProject.workspace_id !== ownerWorkspace.id || ownerProject.buddy_id !== from.id)) {
        throw new Error("Message project is outside the sender scope");
      }
      const timestamp = now();
      const until = waitUntil ? new Date(waitUntil).toISOString() : null;
      if (until && (until <= timestamp || Date.parse(until) - Date.parse(timestamp) > 600_000)) {
        throw new Error("Message wait deadline must be within the next 600 seconds");
      }
      if (until && !parentConversationId) throw new Error("A message wait requires its parent conversation");
      // Expired waits cease to be dependency edges even after an owning process dies.
      this.db.prepare("UPDATE buddy_messages SET wait_status = 'timed_out', updated_at = ? WHERE wait_status = 'waiting' AND wait_until <= ?").run(timestamp, timestamp);
      if (until && recipient) {
        const cycle = this.db.prepare(`
          WITH RECURSIVE dependencies(buddy) AS (
            SELECT ?
            UNION
            SELECT m.to_buddy_id FROM buddy_messages m JOIN dependencies d ON m.from_buddy_id = d.buddy
            WHERE m.wait_status = 'waiting' AND m.wait_until > ? AND m.to_buddy_id IS NOT NULL
          ) SELECT 1 FROM dependencies WHERE buddy = ? LIMIT 1
        `).get(recipient.id, timestamp, from.id);
        if (cycle) throw new Error("Message wait would create a dependency cycle");
      }
      const messageId = id("message");
      const messageBody = required("message body", body);
      if (Buffer.byteLength(messageBody, "utf8") > 32_000) throw new Error("Message body exceeds 32000 bytes");
      if (!Array.isArray(evidence) || evidence.length > 32 || evidence.some((item) => typeof item !== "string" || !item.trim() || Buffer.byteLength(item) > 4_000)) throw new Error("Message evidence must contain at most 32 bounded references");
      this.db.prepare(`
        INSERT INTO buddy_messages (id, from_buddy_id, to_buddy_id, workspace_id, buddy_project_id,
          purpose, body, evidence, parent_conversation_id, status, wait_until, wait_status, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending', ?, ?, ?, ?)
      `).run(messageId, from.id, recipient?.id ?? null, ownerWorkspace.id, ownerProject?.id ?? null,
        required("message purpose", purpose), messageBody, JSON.stringify(evidence), parentConversationId ?? null,
        until, until ? "waiting" : "none", timestamp, timestamp);
      this.recordAuditEvent({ buddy: from.id, workspace: ownerWorkspace.id, project: ownerProject?.id,
        operation: "buddy.send", payload: { messageId, to: recipient?.id ?? "owner", purpose } });
      return this.getMessage(messageId);
    });
  }

  getMessage(message) {
    const row = this.db.prepare("SELECT * FROM buddy_messages WHERE id = ?").get(message);
    if (!row) return null;
    // The durable deadline is authoritative even if the waiting process died
    // before persisting its terminal wait status. Reads need no cleanup write.
    const waitStatus = row.wait_status === "waiting" && row.wait_until <= now()
      ? "timed_out" : row.wait_status;
    const approval=this.db.prepare("SELECT id,operation,arguments_json,expires_at,status,consumed_by_run_id FROM buddy_approval_requests WHERE message_id=?").get(row.id);
    return { ...row, approval:approval ? {...approval,arguments:JSON.parse(approval.arguments_json)} : null, wait_status: waitStatus, evidence: JSON.parse(row.evidence), reply_evidence: JSON.parse(row.reply_evidence) };
  }

  listMessages({ buddy, workspace, toOwner = false, limit = 100, offset = 0, accept = () => true } = {}) {
    const conditions = [];
    const values = [];
    if (buddy) { const b = this.#requireBuddy(buddy); conditions.push("(from_buddy_id = ? OR to_buddy_id = ?)"); values.push(b.id, b.id); }
    if (workspace) { conditions.push("workspace_id = ?"); values.push(this.#requireProject(workspace).id); }
    if (toOwner) conditions.push("to_buddy_id IS NULL");
    const bounded = Math.min(200, Math.max(1, Math.floor(Number(limit) || 100)));
    // Apply scope and outstanding-work priority before the bound so recent
    // settled history cannot bury an unanswered owner request.
    const result = [];
    let skipped = 0;
    const start = Math.max(0, Math.floor(Number(offset) || 0));
    for (const row of this.db.prepare(`
      SELECT id FROM buddy_messages ${conditions.length ? `WHERE ${conditions.join(" AND ")}` : ""}
      ORDER BY CASE WHEN status IN ('pending', 'active') THEN 0 ELSE 1 END,
        CASE WHEN status IN ('pending', 'active') THEN created_at END ASC,
        CASE WHEN status NOT IN ('pending', 'active') THEN created_at END DESC,
        id DESC
    `).iterate(...values)) {
      const message = this.getMessage(row.id);
      if (!accept(message)) continue;
      if (skipped++ < start) continue;
      result.push(message);
      if (result.length === bounded) break;
    }
    return result;
  }

  bindMessageConversation(message, conversationId) {
    const updated = this.db.prepare("UPDATE buddy_messages SET child_conversation_id = ?, status = 'active', updated_at = ? WHERE id = ? AND status = 'pending' AND to_buddy_id IS NOT NULL AND child_conversation_id IS NULL")
      .run(required("message conversation", conversationId), now(), message);
    if (updated.changes !== 1) throw new Error("Message is no longer awaiting dispatch");
    return this.getMessage(message);
  }

  replyMessage(message, { buddy, conversationId, outcome, body, evidence = [] }) {
    return this.#tx(() => {
      const current = this.getMessage(message);
      if (!current) throw new Error("Message not found");
      const actor = this.#requireBuddy(buddy);
      if (!current.to_buddy_id || current.to_buddy_id !== actor.id || current.child_conversation_id !== conversationId) {
        throw new Error("Message reply is outside this Buddy conversation scope");
      }
      this.assertBackgroundReply(current, outcome);
      return this.#replyMessage(current, actor.id, outcome, body, evidence);
    });
  }

  /** Host-only entry point. Never expose owner authority as a Buddy tool input. */
  replyToOwnerMessage(message, { outcome, body, evidence = [] }) {
    return this.#tx(() => {
      const current = this.getMessage(message);
      if (!current || current.to_buddy_id !== null) throw new Error("Owner message not found");
      return this.#replyMessage(current, "owner", outcome, body, evidence);
    });
  }

  #replyMessage(current, actor, outcome, body, evidence) {
    if (current.expects_reply === 0) throw new Error("Informational messages do not accept replies");
    const replyBody = required("reply body", body);
    const replyOutcome = required("reply outcome", outcome);
    if (Buffer.byteLength(replyBody) > 32_000) throw new Error("Reply body exceeds 32000 bytes");
    if (!Array.isArray(evidence) || evidence.length < 1 || evidence.length > 32 || evidence.some((item) => typeof item !== "string" || !item.trim() || Buffer.byteLength(item) > 4_000)) throw new Error("Reply requires 1 to 32 bounded evidence references");
    if (current.status === "replied") {
      if (current.replied_by === actor && current.outcome === replyOutcome && current.reply_body === replyBody && JSON.stringify(current.reply_evidence) === JSON.stringify(evidence)) return current;
      throw new Error("Message already has a durable reply");
    }
    if (!["pending", "active"].includes(current.status)) throw new Error("Message is terminal");
    const timestamp = now();
    this.db.prepare(`UPDATE buddy_messages SET status = 'replied', outcome = ?, reply_body = ?, reply_evidence = ?,
      replied_by = ?, replied_at = ?, updated_at = ?, wait_status = CASE WHEN wait_status = 'waiting' THEN CASE WHEN wait_until > ? THEN 'replied' ELSE 'timed_out' END ELSE wait_status END WHERE id = ?`)
      .run(replyOutcome, replyBody, JSON.stringify(evidence), actor, timestamp, timestamp, timestamp, current.id);
    this.recordAuditEvent({ buddy: actor === "owner" ? current.from_buddy_id : actor, workspace: current.workspace_id,
      project: current.buddy_project_id ?? undefined, operation: "buddy.reply", payload: { messageId: current.id, repliedBy: actor, outcome: replyOutcome } });
    const settled = this.getMessage(current.id);
    this.resolveMessageApproval(settled);
      this.enqueueMessageReply(settled);
    return settled;
  }

  finishMessageWait(message, status = "cancelled") {
    assertOneOf("message wait status", status, ["cancelled", "timed_out"]);
    this.db.prepare("UPDATE buddy_messages SET wait_status = ?, updated_at = ? WHERE id = ? AND wait_status = 'waiting'")
      .run(status, now(), message);
    return this.getMessage(message);
  }

  cancelConversationMessageWaits(conversationId) {
    return this.db.prepare("UPDATE buddy_messages SET wait_status = 'cancelled', updated_at = ? WHERE parent_conversation_id = ? AND wait_status = 'waiting'")
      .run(now(), conversationId).changes;
  }

  finishConversationMessages(conversationId, reason = "Conversation ended without replying") {
    return this.#tx(() => {
      this.cancelConversationMessageWaits(conversationId);
      return this.db.prepare("UPDATE buddy_messages SET status = 'failed', outcome = ?, updated_at = ?, wait_status = CASE WHEN wait_status = 'waiting' THEN 'cancelled' ELSE wait_status END WHERE child_conversation_id = ? AND command_key IS NULL AND status IN ('pending','active')")
        .run(reason, now(), conversationId).changes;
    });
  }

  failMessage(message, error) {
    this.db.prepare("UPDATE buddy_messages SET status = 'failed', outcome = ?, updated_at = ?, wait_status = CASE WHEN wait_status = 'waiting' THEN 'cancelled' ELSE wait_status END WHERE id = ? AND status IN ('pending','active')")
      .run(required("message failure", error), now(), message);
    return this.getMessage(message);
  }

  createDelegation({
    fromBuddy,
    toBuddy,
    workspace,
    project,
    purpose,
    parentConversationId,
    childConversationId,
    status = "pending",
  }) {
    assertOneOf("delegation status", status, DELEGATION_STATUSES);
    const from = this.#requireBuddy(fromBuddy);
    const to = this.#requireBuddy(toBuddy);
    if (from.id === to.id) throw new Error("a Buddy cannot delegate to itself");
    const ownerWorkspace = this.#requireProject(workspace);
    this.#requireBuddy(from, ownerWorkspace);
    this.#requireBuddy(to, ownerWorkspace);
    const ownerProject = project ? this.#requireBuddyProject(project) : null;
    if (ownerProject && ownerProject.workspace_id !== ownerWorkspace.id) {
      throw new Error("Buddy project does not belong to the delegation workspace");
    }
    if (ownerProject && ownerProject.buddy_id !== from.id) {
      throw new Error("Buddy project does not belong to the delegating Buddy");
    }
    const timestamp = now();
    const delegationId = id("delegation");
    this.db
      .prepare(`
        INSERT INTO buddy_delegations (
          id, from_buddy_id, to_buddy_id, workspace_id, buddy_project_id,
          purpose, parent_conversation_id, child_conversation_id, status,
          outcome, created_at, updated_at, completed_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NULL, ?, ?, ?)
      `)
      .run(
        delegationId, from.id, to.id, ownerWorkspace.id, ownerProject?.id || null,
        required("delegation purpose", purpose), parentConversationId || null,
        childConversationId || null, status, timestamp, timestamp,
        ["complete", "failed", "cancelled"].includes(status) ? timestamp : null,
      );
    return this.getDelegation(delegationId);
  }

  getDelegation(delegation) {
    const row = this.db.prepare("SELECT * FROM buddy_delegations WHERE id = ?").get(delegation);
    return row ? { ...row } : null;
  }

  claimDelegationDispatch(delegation, { claimToken, leaseSeconds = 120 } = {}) {
    const current = this.getDelegation(delegation);
    if (!current) throw new Error(`delegation not found: ${delegation}`);
    const token = required("delegation dispatch claim token", claimToken);
    const claimedAt = now();
    const expiresAt = new Date(
      Date.parse(claimedAt) + Math.max(1, Number(leaseSeconds) || 120) * 1000,
    ).toISOString();
    const result = this.db
      .prepare(`
        UPDATE buddy_delegations
        SET dispatch_token = ?, dispatch_expires_at = ?, updated_at = ?
        WHERE id = ?
          AND status = 'pending'
          AND child_conversation_id IS NULL
          AND (
            dispatch_token IS NULL
            OR dispatch_expires_at IS NULL
            OR dispatch_expires_at <= ?
          )
      `)
      .run(token, expiresAt, claimedAt, current.id, claimedAt);
    return {
      ...this.getDelegation(current.id),
      dispatch_claim_acquired: result.changes === 1,
    };
  }

  bindDelegationConversation(delegation, { claimToken, childConversationId }) {
    const current = this.getDelegation(delegation);
    if (!current) throw new Error(`delegation not found: ${delegation}`);
    const token = required("delegation dispatch claim token", claimToken);
    const conversation = required("delegation child conversation", childConversationId);
    if (current.child_conversation_id === conversation && current.status === "active") {
      return current;
    }
    const timestamp = now();
    const result = this.db
      .prepare(`
        UPDATE buddy_delegations
        SET status = 'active', child_conversation_id = ?,
          dispatch_token = NULL, dispatch_expires_at = NULL, updated_at = ?
        WHERE id = ?
          AND status = 'pending'
          AND child_conversation_id IS NULL
          AND dispatch_token = ?
      `)
      .run(conversation, timestamp, current.id, token);
    if (result.changes !== 1) {
      throw new Error("delegation dispatch claim is not owned by this executor");
    }
    return this.getDelegation(current.id);
  }

  failDelegationDispatch(delegation, { claimToken, error }) {
    const current = this.getDelegation(delegation);
    if (!current) throw new Error(`delegation not found: ${delegation}`);
    const token = required("delegation dispatch claim token", claimToken);
    const timestamp = now();
    const result = this.db
      .prepare(`
        UPDATE buddy_delegations
        SET status = 'failed', outcome = ?, dispatch_token = NULL,
          dispatch_expires_at = NULL, updated_at = ?, completed_at = ?
        WHERE id = ?
          AND status = 'pending'
          AND child_conversation_id IS NULL
          AND dispatch_token = ?
      `)
      .run(String(error || "Delegation dispatch failed"), timestamp, timestamp, current.id, token);
    if (result.changes !== 1) {
      throw new Error("delegation dispatch claim is not owned by this executor");
    }
    return this.getDelegation(current.id);
  }

  updateDelegation(delegation, {
    status,
    childConversationId,
    outcome,
  }) {
    const current = this.getDelegation(delegation);
    if (!current) throw new Error(`delegation not found: ${delegation}`);
    const nextStatus = status ?? current.status;
    assertOneOf("delegation status", nextStatus, DELEGATION_STATUSES);
    const timestamp = now();
    this.db
      .prepare(`
        UPDATE buddy_delegations SET status = ?, child_conversation_id = ?,
          outcome = ?, updated_at = ?, completed_at = ? WHERE id = ?
      `)
      .run(
        nextStatus,
        childConversationId === undefined ? current.child_conversation_id : childConversationId || null,
        outcome === undefined ? current.outcome : outcome || null,
        timestamp,
        ["complete", "failed", "cancelled"].includes(nextStatus)
          ? current.completed_at || timestamp
          : null,
        current.id,
      );
    return this.getDelegation(current.id);
  }

  listDelegations({ buddy, workspace, status } = {}) {
    const conditions = [];
    const params = [];
    if (buddy) {
      const ownerBuddy = this.#requireBuddy(buddy);
      conditions.push("(from_buddy_id = ? OR to_buddy_id = ?)");
      params.push(ownerBuddy.id, ownerBuddy.id);
    }
    if (workspace) {
      conditions.push("workspace_id = ?");
      params.push(this.#requireProject(workspace).id);
    }
    if (status) {
      assertOneOf("delegation status", status, DELEGATION_STATUSES);
      conditions.push("status = ?");
      params.push(status);
    }
    return rows(
      this.db.prepare(`
        SELECT * FROM buddy_delegations
        ${conditions.length ? `WHERE ${conditions.join(" AND ")}` : ""}
        ORDER BY created_at DESC
      `),
      ...params,
    );
  }

  createReview({
    reviewer,
    subject,
    workspace,
    project,
    conversationId,
    status = "draft",
    verdict,
    score,
    summary,
    evidence = [],
  }) {
    assertOneOf("review status", status, REVIEW_STATUSES);
    if (verdict) assertOneOf("review verdict", verdict, REVIEW_VERDICTS);
    if (status === "complete" && (!verdict || !summary?.trim())) {
      throw new Error("a completed review requires verdict and summary");
    }
    if (!Array.isArray(evidence)) throw new Error("review evidence must be an array");
    if (status === "complete" && evidence.length === 0) {
      throw new Error("a completed review requires evidence");
    }
    const reviewerBuddy = this.#requireBuddy(reviewer);
    const subjectBuddy = this.#requireBuddy(subject);
    if (reviewerBuddy.id === subjectBuddy.id) {
      throw new Error("a Buddy cannot review itself");
    }
    const ownerWorkspace = this.#requireProject(workspace);
    this.#requireBuddy(reviewerBuddy, ownerWorkspace);
    this.#requireBuddy(subjectBuddy, ownerWorkspace);
    const ownerProject = project ? this.#requireBuddyProject(project) : null;
    if (ownerProject && ownerProject.workspace_id !== ownerWorkspace.id) {
      throw new Error("Buddy project does not belong to the review workspace");
    }
    if (ownerProject && ownerProject.buddy_id !== subjectBuddy.id) {
      throw new Error("Buddy project does not belong to the reviewed Buddy");
    }
    const timestamp = now();
    const reviewId = id("review");
    this.db
      .prepare(`
        INSERT INTO buddy_reviews (
          id, reviewer_buddy_id, subject_buddy_id, workspace_id,
          buddy_project_id, conversation_id, status, verdict, score, summary,
          evidence, created_at, updated_at, completed_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `)
      .run(
        reviewId, reviewerBuddy.id, subjectBuddy.id, ownerWorkspace.id,
        ownerProject?.id || null, conversationId || null, status, verdict || null,
        score === undefined ? null : Number(score), summary?.trim() || null,
        JSON.stringify(evidence), timestamp, timestamp,
        status === "complete" ? timestamp : null,
      );
    return this.getReview(reviewId);
  }

  getReview(review) {
    const row = this.db.prepare("SELECT * FROM buddy_reviews WHERE id = ?").get(review);
    return row ? { ...row, evidence: JSON.parse(row.evidence) } : null;
  }

  updateReview(review, changes = {}) {
    const current = this.getReview(review);
    if (!current) throw new Error(`review not found: ${review}`);
    const status = changes.status ?? current.status;
    const verdict = changes.verdict === undefined ? current.verdict : changes.verdict;
    const summary = changes.summary === undefined ? current.summary : changes.summary?.trim() || null;
    assertOneOf("review status", status, REVIEW_STATUSES);
    if (verdict) assertOneOf("review verdict", verdict, REVIEW_VERDICTS);
    if (status === "complete" && (!verdict || !summary)) {
      throw new Error("a completed review requires verdict and summary");
    }
    const evidence = changes.evidence === undefined ? current.evidence : changes.evidence;
    if (!Array.isArray(evidence)) throw new Error("review evidence must be an array");
    if (status === "complete" && evidence.length === 0) {
      throw new Error("a completed review requires evidence");
    }
    const timestamp = now();
    this.db
      .prepare(`
        UPDATE buddy_reviews SET status = ?, verdict = ?, score = ?, summary = ?,
          evidence = ?, updated_at = ?, completed_at = ? WHERE id = ?
      `)
      .run(
        status, verdict || null,
        changes.score === undefined ? current.score : Number(changes.score),
        summary, JSON.stringify(evidence), timestamp,
        status === "complete" ? current.completed_at || timestamp : null,
        current.id,
      );
    return this.getReview(current.id);
  }

  listReviews({ buddy, workspace, status } = {}) {
    const conditions = [];
    const params = [];
    if (buddy) {
      const ownerBuddy = this.#requireBuddy(buddy);
      conditions.push("(reviewer_buddy_id = ? OR subject_buddy_id = ?)");
      params.push(ownerBuddy.id, ownerBuddy.id);
    }
    if (workspace) {
      conditions.push("workspace_id = ?");
      params.push(this.#requireProject(workspace).id);
    }
    if (status) {
      assertOneOf("review status", status, REVIEW_STATUSES);
      conditions.push("status = ?");
      params.push(status);
    }
    return rows(
      this.db.prepare(`
        SELECT * FROM buddy_reviews
        ${conditions.length ? `WHERE ${conditions.join(" AND ")}` : ""}
        ORDER BY created_at DESC
      `),
      ...params,
    ).map((row) => ({ ...row, evidence: JSON.parse(row.evidence) }));
  }

  createSprint({ project, name, goal, status = "planned" }) {
    assertOneOf("sprint status", status, SPRINT_STATUSES);
    const ownerProject = this.#requireProject(project);
    const timestamp = now();
    const sprint = {
      id: id("sprint"),
      projectId: ownerProject.id,
      name: required("sprint name", name),
      goal: goal?.trim() || null,
      status,
      startsAt: status === "active" ? timestamp : null,
      createdAt: timestamp,
      updatedAt: timestamp,
    };
    this.db
      .prepare(`
        INSERT INTO sprints (
          id, project_id, name, goal, status, starts_at, ends_at, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, NULL, ?, ?)
      `)
      .run(
        sprint.id,
        sprint.projectId,
        sprint.name,
        sprint.goal,
        sprint.status,
        sprint.startsAt,
        sprint.createdAt,
        sprint.updatedAt,
      );
    return this.getSprint(sprint.id);
  }

  getSprint(id) {
    const row = this.db.prepare("SELECT * FROM sprints WHERE id = ?").get(id);
    return row ? { ...row } : null;
  }

  getActiveSprint(project) {
    const ownerProject = this.#requireProject(project);
    const row = this.db
      .prepare("SELECT * FROM sprints WHERE project_id = ? AND status = 'active'")
      .get(ownerProject.id);
    return row ? { ...row } : null;
  }

  completeSprint(sprintId) {
    const sprint = this.#requireSprint(sprintId);
    const timestamp = now();
    this.db
      .prepare(`
        UPDATE sprints
        SET status = 'completed', ends_at = ?, updated_at = ?
        WHERE id = ?
      `)
      .run(timestamp, timestamp, sprint.id);
    return this.getSprint(sprint.id);
  }

  newProject({
    buddy,
    workspace,
    title,
    objective,
    definitionOfDone,
    sprint,
    status = "backlog",
    priority = 0,
    nextAction,
    blockedReason,
    sourcePath,
    externalKey,
    todos = [],
  }) {
    assertOneOf("Buddy project status", status, BUDDY_PROJECT_STATUSES);
    if (status === "blocked" && !blockedReason?.trim()) {
      throw new Error("blocked reason is required when blocking a Buddy project");
    }
    const ownerWorkspace = this.#requireProject(workspace);
    const ownerBuddy = this.#requireBuddy(buddy, ownerWorkspace);
    const ownerSprint = sprint ? this.#requireSprint(sprint, ownerWorkspace) : null;
    if (!Array.isArray(todos)) throw new Error("todos must be an array");
    const timestamp = now();
    const projectId = id("buddy_project");
    this.#tx(() => {
      this.db
        .prepare(`
          INSERT INTO owned_projects (
            id, workspace_id, buddy_id, sprint_id, title, objective,
            definition_of_done, status, priority, next_action, blocked_reason,
            source_path, external_key, created_at, updated_at, completed_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `)
        .run(
          projectId,
          ownerWorkspace.id,
          ownerBuddy.id,
          ownerSprint?.id || null,
          required("Buddy project title", title),
          objective?.trim() || null,
          required("definition of done", definitionOfDone),
          status,
          Number(priority) || 0,
          nextAction?.trim() || null,
          status === "blocked" ? blockedReason.trim() : null,
          sourcePath ? this.#projectPath(ownerWorkspace, sourcePath) : null,
          externalKey?.trim() || null,
          timestamp,
          timestamp,
          ["done", "cancelled"].includes(status) ? timestamp : null,
        );
      for (let position = 0; position < todos.length; position += 1) {
        const todo = todos[position];
        this.#insertTodo(projectId, {
          ...todo,
          position,
        }, timestamp);
      }
    });
    return this.getBuddyProject(projectId);
  }

  upsertBuddyProject(input) {
    const externalKey = required("external key", input.externalKey);
    const ownerWorkspace = this.#requireProject(input.workspace);
    const ownerBuddy = this.#requireBuddy(input.buddy, ownerWorkspace);
    const existing = this.db
      .prepare(
        "SELECT * FROM owned_projects WHERE workspace_id = ? AND external_key = ?",
      )
      .get(ownerWorkspace.id, externalKey);

    if (!existing) {
      return this.newProject({
        ...input,
        buddy: ownerBuddy.id,
        workspace: ownerWorkspace.id,
        externalKey,
      });
    }
    if (existing.buddy_id !== ownerBuddy.id) {
      throw new Error("external key belongs to another Buddy");
    }

    const existingTodos = this.listTodos(existing.id, { includeClosed: true });
    const existingTodoTitles = new Set(existingTodos.map((todo) => todo.title));
    const todoOperations = (input.todos || [])
      .filter((todo) => !existingTodoTitles.has(required("todo title", todo.title)))
      .map((todo) => ({ operation: "add", ...todo }));

    return this.updateProject(existing.id, {
      title: input.title,
      objective: input.objective,
      definitionOfDone: input.definitionOfDone,
      sprint: input.sprint,
      status: input.status,
      priority: input.priority,
      nextAction: input.nextAction,
      blockedReason: input.blockedReason,
      sourcePath: input.sourcePath,
      todoOperations,
    });
  }

  getBuddyProject(project) {
    const row =
      typeof project === "object" && project?.id
        ? project
        : this.db.prepare("SELECT * FROM owned_projects WHERE id = ?").get(project);
    if (!row) return null;
    return {
      ...row,
      todos: this.listTodos(row.id, { includeClosed: true }),
    };
  }

  listBuddyOwnedProjects({ buddy, workspace, sprint, includeClosed = false } = {}) {
    const conditions = [];
    const params = [];
    if (buddy) {
      conditions.push("owned_projects.buddy_id = ?");
      params.push(this.#requireBuddy(buddy).id);
    }
    if (workspace) {
      conditions.push("owned_projects.workspace_id = ?");
      params.push(this.#requireProject(workspace).id);
    }
    if (sprint) {
      conditions.push("owned_projects.sprint_id = ?");
      params.push(this.#requireSprint(sprint).id);
    }
    if (!includeClosed) {
      conditions.push("owned_projects.status NOT IN ('done', 'cancelled')");
    }
    const where = conditions.length ? `WHERE ${conditions.join(" AND ")}` : "";
    return rows(
      this.db.prepare(`
        SELECT owned_projects.*, projects.name AS workspace_name,
          projects.slug AS workspace_slug, buddies.name AS buddy_name,
          sprints.name AS sprint_name
        FROM owned_projects
        JOIN projects ON projects.id = owned_projects.workspace_id
        JOIN buddies ON buddies.id = owned_projects.buddy_id
        LEFT JOIN sprints ON sprints.id = owned_projects.sprint_id
        ${where}
        ORDER BY owned_projects.priority DESC, owned_projects.created_at
      `),
      ...params,
    ).map((project) => ({
      ...project,
      todos: this.listTodos(project.id, { includeClosed: true }),
    }));
  }

  listTodos(project, { includeClosed = false } = {}) {
    const ownerProject = this.#requireBuddyProject(project);
    return rows(
      this.db.prepare(`
        SELECT * FROM buddy_todos
        WHERE buddy_project_id = ?
          ${includeClosed ? "" : "AND status NOT IN ('done', 'cancelled')"}
        ORDER BY position, created_at
      `),
      ownerProject.id,
    ).map(todo => ({...todo, completion_evidence: JSON.parse(todo.completion_evidence || "[]")}));
  }

  updateProject(project, changes = {}) {
    const ownerProject = this.#requireBuddyProject(project);
    const timestamp = now();
    const criteriaChanged = changes.definitionOfDone !== undefined && changes.definitionOfDone.trim() !== ownerProject.definition_of_done;
    const requestedStatus = changes.status ?? ownerProject.status;
    const nextStatus = criteriaChanged && requestedStatus === "done" && !changes.evidence?.length ? "in_progress" : requestedStatus;
    assertOneOf("Buddy project status", nextStatus, BUDDY_PROJECT_STATUSES);
    const nextBlockedReason =
      nextStatus === "blocked"
        ? changes.blockedReason?.trim() || ownerProject.blocked_reason
        : null;
    if (nextStatus === "blocked" && !nextBlockedReason) {
      throw new Error("blocked reason is required when blocking a Buddy project");
    }
    const workspace = this.#requireProject(ownerProject.workspace_id);
    const sprint =
      changes.sprint === null
        ? null
        : changes.sprint
          ? this.#requireSprint(changes.sprint, workspace)
          : undefined;
    if (changes.todoOperations && !Array.isArray(changes.todoOperations)) {
      throw new Error("todoOperations must be an array");
    }
    this.#tx(() => {
      this.db
        .prepare(`
          UPDATE owned_projects SET
            title = ?, objective = ?, definition_of_done = ?, status = ?,
            priority = ?, next_action = ?, blocked_reason = ?, sprint_id = ?,
            source_path = ?, updated_at = ?, completed_at = ?
          WHERE id = ?
        `)
        .run(
          changes.title === undefined
            ? ownerProject.title
            : required("Buddy project title", changes.title),
          changes.objective === undefined
            ? ownerProject.objective
            : changes.objective?.trim() || null,
          changes.definitionOfDone === undefined
            ? ownerProject.definition_of_done
            : required("definition of done", changes.definitionOfDone),
          nextStatus,
          changes.priority === undefined
            ? ownerProject.priority
            : Number(changes.priority) || 0,
          changes.nextAction === undefined
            ? ownerProject.next_action
            : changes.nextAction?.trim() || null,
          nextBlockedReason,
          sprint === undefined ? ownerProject.sprint_id : sprint?.id || null,
          changes.sourcePath === undefined
            ? ownerProject.source_path
            : changes.sourcePath
              ? this.#projectPath(workspace, changes.sourcePath)
              : null,
          timestamp,
          ["done", "cancelled"].includes(nextStatus)
            ? (criteriaChanged ? timestamp : ownerProject.completed_at || timestamp)
            : null,
          ownerProject.id,
        );
      if (criteriaChanged) this.db.prepare("UPDATE owned_projects SET completion_evidence='[]' WHERE id=?").run(ownerProject.id);
      for (const operation of changes.todoOperations || []) {
        if (operation.operation === "add") {
          const nextPosition =
            this.db
              .prepare(
                "SELECT COALESCE(MAX(position), -1) + 1 AS position FROM buddy_todos WHERE buddy_project_id = ?",
              )
              .get(ownerProject.id).position;
          this.#insertTodo(ownerProject.id, { ...operation, position: nextPosition }, timestamp);
        } else if (operation.operation === "update") {
          this.#updateTodo(ownerProject.id, operation, timestamp);
        } else {
          throw new Error(`unknown todo operation: ${operation.operation}`);
        }
      }
      if (nextStatus === "done" && changes.status !== "done" && changes.todoOperations?.some(op => op.operation === "add" || op.definitionOfDone !== undefined || (op.status && !["done","cancelled"].includes(op.status))) && this.listTodos(ownerProject.id).length) {
        this.db.prepare("UPDATE owned_projects SET status='in_progress',completed_at=NULL,completion_evidence='[]' WHERE id=?").run(ownerProject.id);
      }
    });
    return this.getBuddyProject(ownerProject.id);
  }

  /**
   * Rewrite one bounded v2 memory document through the SQLite authority. The
   * Markdown file is only a generated view; a failed materialization is
   * reported without undoing the committed revision.
   */
  updateMemory(
    buddy,
    { documentKind, doc, content, reasoning, baseVersion, authorKind = "buddy", requestedBy = null, provenance = {} } = {},
  ) {
    if (documentKind !== undefined && doc !== undefined && documentKind !== doc) {
      throw new Error("documentKind and doc must match when both are supplied");
    }
    const kind = documentKind || doc;
    assertOneOf("memory document", kind, MEMORY_DOCUMENT_KINDS);
    return this.#updateMemoryDocument(buddy, kind, {
      content,
      reasoning,
      baseVersion,
      authorKind,
      requestedBy,
      provenance,
    });
  }

  /** Owner-only soul mutation; soul is never exposed as a Buddy operation. */
  updateSoul(
    buddy,
    { content, reasoning, baseVersion, requestedBy, authorKind = "owner", provenance = {} } = {},
  ) {
    if (!requestedBy) throw new Error("owner principal is required for soul updates");
    const ownerBuddy = this.#requireBuddy(buddy);
    if (!ownerBuddy.soul_path) throw new Error("Buddy soul is not configured");
    return this.#updateMemoryDocument(ownerBuddy, "soul", {
      content,
      reasoning,
      baseVersion,
      authorKind,
      requestedBy,
      provenance,
    });
  }

  /**
   * Share-cleanliness check: verify the git-shareable workspace views
   * (profiles/<slug>/BUDDY_SOUL.md plus memory/WORKING_MEMORY.md and
   * memory/LONG_TERM_MEMORY.md) match the SQLite ledger heads that briefings
   * are served from. A file rewrite alone never moves a head, so a
   * hand-edited view reads as stale until the owner rematerializes it.
   */
  exportCheck(buddy) {
    const ownerBuddy = this.#requireBuddy(buddy);
    this.#ensureMemoryDocuments(ownerBuddy);
    const documents = ["soul", "working", "long_term"].map((documentKind) =>
      this.#exportDocumentStatus(ownerBuddy, documentKind),
    );
    return {
      buddy_id: ownerBuddy.id,
      buddy_slug: ownerBuddy.slug,
      clean: documents.every(
        (entry) => entry.status === "match" || entry.status === "unconfigured",
      ),
      documents,
    };
  }

  /**
   * Rematerialize every stale/missing view from its ledger head, then
   * re-report. Unconfigured documents (no soul_path, empty head) are left
   * alone; a view with no resolvable file path is reported, not written.
   */
  fixExport(buddy) {
    const ownerBuddy = this.#requireBuddy(buddy);
    this.#ensureMemoryDocuments(ownerBuddy);
    const fixed = [];
    for (const documentKind of ["soul", "working", "long_term"]) {
      const status = this.#exportDocumentStatus(ownerBuddy, documentKind);
      if (
        (status.status === "stale" || status.status === "missing") &&
        status.filePath !== null
      ) {
        const head = this.#memoryHead(ownerBuddy.id, documentKind);
        if (!head) continue;
        this.#materializeMemoryDocument(ownerBuddy, documentKind);
        fixed.push(documentKind);
      }
    }
    return { ...this.exportCheck(ownerBuddy.id), fixed };
  }

  #exportDocumentStatus(buddy, documentKind) {
    const head = this.#memoryHead(buddy.id, documentKind);
    const headRevision = head?.revision ?? 0;
    const headSha256 = head?.sha256 ?? createHash("sha256").update("").digest("hex");
    const filePath =
      documentKind === "soul"
        ? buddy.soul_path
          ? this.#projectPath(this.#requireProject(buddy.project_id), buddy.soul_path)
          : null
        : this.#containedPath(
            this.#memoryRoot(buddy),
            documentKind === "working" ? "WORKING_MEMORY.md" : "LONG_TERM_MEMORY.md",
          );
    if (filePath === null) {
      const empty = (head?.body ?? "").trim() === "";
      return {
        document: documentKind,
        headRevision,
        headSha256,
        filePath: null,
        fileSha256: null,
        status: empty ? "unconfigured" : "missing",
      };
    }
    let fileContent;
    try {
      fileContent = readFileSync(filePath, "utf8");
    } catch (error) {
      if (error.code !== "ENOENT") throw error;
      return {
        document: documentKind,
        headRevision,
        headSha256,
        filePath,
        fileSha256: null,
        status: "missing",
      };
    }
    const fileSha256 = createHash("sha256").update(fileContent).digest("hex");
    const expected = head
      ? this.#renderMemoryDocument(documentKind, head.body, head.revision, head.updated_at)
      : null;
    return {
      document: documentKind,
      headRevision,
      headSha256,
      filePath,
      fileSha256,
      status: expected !== null && fileContent === expected ? "match" : "stale",
    };
  }

  #updateMemoryDocument(
    buddy,
    kind,
    { content, reasoning, baseVersion, authorKind = "buddy", requestedBy = null, provenance = {} } = {},
  ) {
    const ownerBuddy = this.#requireBuddy(buddy);
    if (typeof content !== "string") throw new Error("memory content is required");
    const body = content;
    const explanation = required("memory reasoning", reasoning);
    const cap = MEMORY_DOCUMENT_CAPS[kind];
    if (body.length > cap) {
      throw new Error(`${kind} memory exceeds ${cap} characters`);
    }
    if (!Number.isInteger(baseVersion) || baseVersion < 0) {
      throw new Error("baseVersion must be a non-negative integer");
    }
    this.#ensureMemoryDocuments(ownerBuddy);
    const result = this.#tx(() => {
      const head = this.#memoryHead(ownerBuddy.id, kind);
      if (!head) throw new Error(`memory document is not initialized: ${kind}`);
      if (head.revision !== baseVersion) {
        const error = new Error(
          `StaleMemoryWrite: ${kind} memory is at revision ${head.revision}; supplied base ${baseVersion}`,
        );
        error.code = "STALE_MEMORY_WRITE";
        error.currentVersion = head.revision;
        error.currentBody = head.body;
        error.documentKind = kind;
        error.yourBase = baseVersion;
        throw error;
      }
      const revision = head.revision + 1;
      const revisionId = id("memory_revision");
      const timestamp = now();
      const sha256 = createHash("sha256").update(body).digest("hex");
      const author = required("memory author", authorKind);
      const provenanceJson = JSON.stringify(provenance ?? {});
      this.db
        .prepare(`
          INSERT INTO buddy_memory_revisions (
            id, buddy_id, document_kind, revision, base_revision_id, body, reasoning,
            author_kind, requested_by, provenance_json, sha256, created_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `)
        .run(
          revisionId,
          ownerBuddy.id,
          kind,
          revision,
          head.revision_id,
          body,
          explanation,
          author,
          requestedBy,
          provenanceJson,
          sha256,
          timestamp,
        );
      const result = this.db
        .prepare(`
          UPDATE buddy_memory_heads
          SET revision_id = ?, generation = generation + 1, updated_at = ?
          WHERE buddy_id = ? AND document_kind = ? AND revision_id = ?
        `)
        .run(revisionId, timestamp, ownerBuddy.id, kind, head.revision_id);
      if (result.changes !== 1) {
        const current = this.#memoryHead(ownerBuddy.id, kind);
        const error = new Error("StaleMemoryWrite: memory head changed during update");
        error.code = "STALE_MEMORY_WRITE";
        error.currentVersion = current?.revision;
        error.currentBody = current?.body;
        error.documentKind = kind;
        error.yourBase = baseVersion;
        throw error;
      }
      return {
        buddy_id: ownerBuddy.id,
        document_kind: kind,
        revision,
        base_revision_id: head.revision_id,
        generation: head.generation + 1,
        body,
        reasoning: explanation,
        author_kind: author,
        requested_by: requestedBy,
        provenance: provenance ?? {},
        sha256,
        updated_at: timestamp,
        created_at: timestamp,
      };
    });
    let viewStatus = "current";
    let viewError = null;
    try {
      this.#materializeMemoryDocument(ownerBuddy.id, kind);
    } catch (error) {
      viewStatus = "stale";
      viewError = error instanceof Error ? error.message : String(error);
    }
    return { ...result, view_status: viewStatus, ...(viewError ? { view_error: viewError } : {}) };
  }

  readBuddySoul(buddy) {
    const ownerBuddy = this.#requireBuddy(buddy);
    this.#ensureMemoryDocuments(ownerBuddy);
    const soul = this.#memoryHead(ownerBuddy.id, "soul");
    return {
      buddy_id: ownerBuddy.id,
      body: soul?.body ?? "",
      revision: soul?.revision ?? 0,
      generation: soul?.generation ?? 0,
      reasoning: soul?.reasoning ?? "",
      sha256: soul?.sha256 ?? createHash("sha256").update("").digest("hex"),
      updated_at: soul?.updated_at ?? null,
    };
  }

  /** Append one immutable note. Dense documents use updateMemory instead. */
  rememberNote(
    buddy,
    { topic = "memory", kind = "note", body, content, evidence = [], workspace, scope = "current", date = new Date() } = {},
  ) {
    const ownerBuddy = this.#requireBuddy(buddy);
    const noteBody = body ?? content;
    required("note body", noteBody);
    if (Buffer.byteLength(noteBody, "utf8") > MEMORY_NOTE_MAX_BYTES) {
      throw new Error(`note body exceeds ${MEMORY_NOTE_MAX_BYTES} UTF-8 bytes`);
    }
    if (!Array.isArray(evidence)) throw new Error("note evidence must be an array");
    const timestamp = this.#memoryTimestamp(date);
    const workspaces = this.#noteWorkspaces(ownerBuddy, workspace, scope);
    return this.#writeMemoryNote({
      buddy: ownerBuddy,
      workspace: workspaces[0],
      topic,
      kind,
      body: noteBody,
      evidence,
      timestamp,
    });
  }

  #memoryTimestamp(date) {
    const timestamp = date instanceof Date ? date.toISOString() : new Date(date).toISOString();
    if (Number.isNaN(Date.parse(timestamp))) throw new Error("note date is invalid");
    return timestamp;
  }

  #writeMemoryNote({ buddy, workspace, topic, kind, body, evidence, timestamp, legacySource, legacyPart, legacyParts, legacyHash }) {
    const noteKind = required("note kind", kind);
    if (/[\r\n]/.test(noteKind)) throw new Error("note kind cannot contain newlines");
    const evidenceJson = JSON.stringify(evidence ?? []);
    const topicSlug =
      String(topic)
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, "-")
        .replace(/^-|-$/g, "")
        .slice(0, 48) || "memory";
    const buddySlug =
      String(/^builder-/.test(buddy.slug) ? buddy.name || buddy.slug : buddy.slug)
        .toLowerCase()
        .replace(/[^a-z0-9._-]+/g, "-")
        .replace(/^-|-$/g, "")
        .slice(0, 48) || "buddy";
    const shortBuddyId = buddy.id.replace(/[^a-zA-Z0-9]/g, "").slice(-8) || "buddy";
    const noteId = ulid(Date.parse(timestamp));
    const stamp = new Date(timestamp).toISOString().slice(0, 19).replace(/[-:]/g, "") + "Z";
    const notesRoot = this.#containedPath(workspace.root_path, "agent_notes");
    mkdirSync(notesRoot, { recursive: true });
    const notePath = this.#containedPath(
      notesRoot,
      `${stamp}_${noteId}_${topicSlug}_${buddySlug}_${shortBuddyId}.md`,
    );
    const frontmatter = [
      "---",
      `kind: ${JSON.stringify(noteKind)}`,
      `buddy_id: ${JSON.stringify(buddy.id)}`,
      `buddy_slug: ${JSON.stringify(buddy.slug)}`,
      `workspace_id: ${JSON.stringify(workspace.id)}`,
      `created_at: ${timestamp}`,
      "trust: workspace_source",
      `evidence: ${evidenceJson}`,
      ...(legacySource ? [
        `legacy_source: ${JSON.stringify(legacySource)}`,
        `legacy_part: ${legacyPart || 1}`,
        `legacy_parts: ${legacyParts || 1}`,
        `legacy_sha256: ${JSON.stringify(legacyHash || null)}`,
      ] : []),
      "---",
      "",
    ].join("\n");
    if (Buffer.byteLength(body, "utf8") > MEMORY_NOTE_MAX_BYTES) {
      throw new Error(`note body exceeds ${MEMORY_NOTE_MAX_BYTES} UTF-8 bytes`);
    }
    if (Buffer.byteLength(frontmatter, "utf8") > MEMORY_NOTE_METADATA_MAX_BYTES) {
      throw new Error(`note metadata exceeds ${MEMORY_NOTE_METADATA_MAX_BYTES} UTF-8 bytes`);
    }
    const rendered = `${frontmatter}${body}\n`;
    try {
      writeFileSync(notePath, rendered, { encoding: "utf8", flag: "wx" });
    } catch (error) {
      if (error.code === "EEXIST") throw new Error("note identity collision; retry the write");
      throw error;
    }
    return {
      id: noteId,
      path: notePath,
      topic: topicSlug,
      kind: noteKind,
      buddy_id: buddy.id,
      workspace_id: workspace.id,
      evidence: evidence ?? [],
      content: body,
      written_at: timestamp,
    };
  }

  #migrateLegacyNotes(buddy) {
    const root = this.#memoryRoot(buddy);
    // One completed migration per configured root. Legacy files are retained
    // as evidence but never scanned again during briefing assembly or restart.
    if (this.db.prepare(`
      SELECT 1 FROM buddy_audit_events WHERE buddy_id = ?
        AND operation = 'memory.legacy_migrated'
        AND json_extract(payload, '$.source_root') = ? LIMIT 1
    `).get(buddy.id, root)) return;
    if (!["journal", "archive"].some((name) => existsSync(this.#containedPath(root, name)))) {
      return;
    }
    const workspace = this.#requireProject(buddy.project_id);
    const notesRoot = this.#containedPath(workspace.root_path, "agent_notes");
    const existing = new Map();
    for (const notePath of this.#walkNoteFiles(notesRoot)) {
      const content = readFileSync(notePath, "utf8");
      const boundary = content.indexOf("\n---\n", 4);
      if (!content.startsWith("---\n") || boundary < 0) continue;
      const header = content.slice(4, boundary);
      const field = (key) => {
        const encoded = header.match(new RegExp(`^${key}:\\s*(.+)$`, "m"))?.[1];
        if (!encoded) return null;
        try { return JSON.parse(encoded); } catch { return null; }
      };
      if (field("buddy_id") !== buddy.id) continue;
      const source = field("legacy_source");
      if (!source) continue;
      existing.set(`${source}:${field("legacy_part") || 1}`, {
        hash: field("legacy_sha256"),
        body: content.slice(boundary + 5).trimEnd(),
      });
    }
    let migrated = 0;
    for (const directory of ["journal", "archive"]) {
      const sourceRoot = this.#containedPath(root, directory);
      for (const sourcePath of this.#walkNoteFiles(sourceRoot)) {
        const day = sourcePath.match(/(\d{4}-\d{2}-\d{2})\.md$/)?.[1];
        if (!day || Number.isNaN(Date.parse(`${day}T00:00:00.000Z`))) continue;
        const source = `memory/${relative(root, sourcePath)}`;
        const content = readFileSync(sourcePath, "utf8");
        const hash = createHash("sha256").update(content).digest("hex");
        const previous = existing.get(`${source}:1`);
        if (!previous?.hash && previous?.body === content.trimEnd()) continue;
        const chunks = splitUtf8(content, MEMORY_NOTE_MAX_BYTES);
        for (let index = 0; index < chunks.length; index += 1) {
          if (existing.get(`${source}:${index + 1}`)?.hash === hash) continue;
          this.#writeMemoryNote({
            buddy,
            workspace,
            topic: "legacy-journal",
            kind: "legacy_journal",
            body: chunks[index],
            evidence: [source],
            timestamp: `${day}T00:00:00.000Z`,
            legacySource: source,
            legacyPart: index + 1,
            legacyParts: chunks.length,
            legacyHash: hash,
          });
          migrated += 1;
        }
      }
    }
    this.recordAuditEvent({
      buddy: buddy.id,
      workspace: workspace.id,
      operation: "memory.legacy_migrated",
      payload: { source_root: root, notes: migrated },
    });
  }

  /** Pull-only bounded ripgrep search across trusted current/home note roots. */
  recall(buddy, { pattern, workspace, scope = "all", since, limit = 20 } = {}) {
    const ownerBuddy = this.#requireBuddy(buddy);
    const query = required("recall pattern", pattern);
    if (Buffer.byteLength(query, "utf8") > 2_000) throw new Error("recall pattern exceeds 2000 bytes");
    const maxResults = Math.min(100, Math.max(1, Math.floor(Number(limit) || 20)));
    const after = since === undefined ? null : Date.parse(since);
    if (since !== undefined && Number.isNaN(after)) throw new Error("recall since is invalid");
    const candidates = this.#noteWorkspaces(ownerBuddy, workspace, scope).flatMap((root) =>
      this.#walkNoteFiles(this.#containedPath(root.root_path, "agent_notes"))
        .map((path) => ({ path, workspace_id: root.id })),
    ).sort((left, right) => right.path.localeCompare(left.path));
    if (candidates.length > MEMORY_RECALL_MAX_FILES) {
      throw new Error(`recall scope exceeds ${MEMORY_RECALL_MAX_FILES} files; narrow the workspace scope`);
    }
    const deadline = Date.now() + MEMORY_RECALL_TIMEOUT_MS;
    // The Rust regex engine is bounded and does not support catastrophic JS
    // backtracking or PCRE lookarounds. Arguments never pass through a shell.
    const matchingPaths = new Set(this.#recallSearch(query, ["--null-data", "-"], {
      input: candidates.map((file) => file.path).join("\0"),
      deadline,
    }).split("\0").filter(Boolean));
    for (let offset = 0; offset < candidates.length; offset += 200) {
      const batch = candidates.slice(offset, offset + 200).map((file) => file.path);
      const result = this.#recallSearch(query, ["--files-with-matches", "--null", "--text", "--", ...batch], { deadline });
      for (const path of result.split("\0").filter(Boolean)) matchingPaths.add(path);
    }
    const matches = [];
    let truncated = false;
    let totalBytes = 0;
    for (const candidate of candidates) {
      if (!matchingPaths.has(candidate.path)) continue;
      const { content, size } = readNotePrefix(candidate.path);
      const boundary = content.startsWith("---\n") ? content.indexOf("\n---\n", 4) : -1;
      const header = boundary < 0 ? "" : content.slice(4, boundary);
      const createdAt = header.match(/^created_at:\s*(.+)$/m)?.[1]?.trim();
      const createdMilliseconds = createdAt ? Date.parse(createdAt) : NaN;
      if (after !== null && (!Number.isFinite(createdMilliseconds) || createdMilliseconds < after)) continue;
      if (matches.length >= maxResults) {
        truncated = true;
        break;
      }
      const remainingBytes = MEMORY_RECALL_MAX_TOTAL_BYTES - totalBytes;
      if (remainingBytes <= 0) {
        truncated = true;
        break;
      }
      const allowedBytes = Math.min(MEMORY_RECALL_MAX_MATCH_BYTES, remainingBytes);
      const contentTruncated = size > allowedBytes;
      const boundedContent = contentTruncated
        ? `${splitUtf8(content, Math.max(1, allowedBytes - 32))[0]}\n… [truncated]`
        : content;
      totalBytes += Buffer.byteLength(boundedContent, "utf8");
      matches.push({
        ...candidate,
        content: boundedContent,
        created_at: Number.isFinite(createdMilliseconds) ? createdAt : null,
        ...(contentTruncated ? { content_truncated: true } : {}),
      });
      if (contentTruncated) {
        truncated = true;
        break;
      }
    }
    return { pattern: query, matches, truncated };
  }

  #recallSearch(pattern, args, { input, deadline }) {
    const timeout = deadline - Date.now();
    if (timeout <= 0) throw new Error("recall search timed out; narrow the workspace scope");
    const result = spawnSync("rg", [
      "--no-config", "--engine", "default", "--ignore-case", "--color", "never",
      "--regexp", pattern, ...args,
    ], { input, encoding: "utf8", timeout, maxBuffer: 4_000_000 });
    if (result.error?.code === "ENOENT") {
      throw new Error("recall requires ripgrep (rg) on PATH");
    }
    if (result.error) throw new Error(`recall search failed: ${result.error.message}`);
    if (result.status !== 0 && result.status !== 1) {
      throw new Error(`recall pattern or search is invalid: ${result.stderr.trim()}`);
    }
    return result.stdout;
  }

  #noteWorkspaces(buddy, workspace, scope) {
    const home = this.#requireProject(buddy.project_id);
    const selected = workspace
      ? this.#requireProject(typeof workspace === "object" ? workspace.id : workspace)
      : home;
    if (selected.id !== home.id && !this.#buddyHasProject(buddy.id, selected.id)) {
      throw new Error("Buddy does not belong to the requested note workspace");
    }
    if (scope === "home") return [home];
    if (scope === "current") return [selected];
    if (scope !== "all") throw new Error("note scope must be current, home, or all");
    return selected.id === home.id ? [home] : [selected, home];
  }

  #walkNoteFiles(root) {
    if (!existsSync(root)) return [];
    const files = [];
    const visit = (directory) => {
      for (const entry of readdirSync(directory, { withFileTypes: true })) {
        const path = this.#containedPath(root, relative(root, join(directory, entry.name)));
        if (entry.isDirectory()) visit(path);
        else if (entry.isFile() && entry.name.endsWith(".md")) files.push(path);
      }
    };
    visit(root);
    return files.sort();
  }

  readBuddyMemory(buddy) {
    const ownerBuddy = this.#requireBuddy(buddy);
    this.#ensureMemoryDocuments(ownerBuddy);
    const working = this.#memoryHead(ownerBuddy.id, "working");
    const longTerm = this.#memoryHead(ownerBuddy.id, "long_term");
    const migrationWarnings = [
      ["working", working],
      ["long_term", longTerm],
    ].flatMap(([documentKind, head]) => {
      if (!head?.reasoning.startsWith("Legacy ")) return [];
      return [
        {
          document_kind: documentKind,
          message: head.reasoning,
          source_path:
            documentKind === "long_term"
              ? ownerBuddy.memory_path
                ? this.#containedPath(this.#memoryRoot(ownerBuddy), "MEMORY.md")
                : null
              : null,
        },
      ];
    });
    return {
      working: working.body,
      longTerm: longTerm.body,
      workingRevision: working.revision,
      longTermRevision: longTerm.revision,
      generation: working.generation + longTerm.generation,
      // Read-only aliases keep persisted clients compatible during the upgrade.
      summary: longTerm.body,
      recentJournal: [],
      ...(migrationWarnings.length ? { migrationWarnings } : {}),
      operations: { updateMemory: true, rememberNote: true, recall: true },
    };
  }

  createWorkItem({
    project,
    title,
    definitionOfDone,
    objective,
    buddy,
    sprint,
    status = "backlog",
    priority = 0,
    nextAction,
    kind = "task",
    externalKey,
    sourcePath,
    blockedReason,
  }) {
    assertOneOf("work item status", status, WORK_ITEM_STATUSES);
    if (status === "blocked" && !blockedReason?.trim()) {
      throw new Error("blocked reason is required when creating blocked work");
    }
    const ownerProject = this.#requireProject(project);
    const ownerBuddy = buddy ? this.#requireBuddy(buddy, ownerProject) : null;
    const ownerSprint = sprint ? this.#requireSprint(sprint, ownerProject) : null;
    const timestamp = now();
    const workItem = {
      id: id("work"),
      projectId: ownerProject.id,
      sprintId: ownerSprint?.id || null,
      buddyId: ownerBuddy?.id || null,
      title: required("work item title", title),
      kind: required("work item kind", kind),
      externalKey: externalKey?.trim() || null,
      sourcePath: sourcePath ? this.#projectPath(ownerProject, sourcePath) : null,
      objective: objective?.trim() || null,
      definitionOfDone: required("definition of done", definitionOfDone),
      status,
      priority: Number(priority) || 0,
      nextAction: nextAction?.trim() || null,
      blockedReason: status === "blocked" ? blockedReason.trim() : null,
      createdAt: timestamp,
      updatedAt: timestamp,
      completedAt: status === "done" ? timestamp : null,
    };
    this.db
      .prepare(`
        INSERT INTO work_items (
          id, project_id, sprint_id, buddy_id, title, kind, external_key, source_path, objective,
          definition_of_done, status, priority, next_action, blocked_reason,
          created_at, updated_at, completed_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `)
      .run(
        workItem.id,
        workItem.projectId,
        workItem.sprintId,
        workItem.buddyId,
        workItem.title,
        workItem.kind,
        workItem.externalKey,
        workItem.sourcePath,
        workItem.objective,
        workItem.definitionOfDone,
        workItem.status,
        workItem.priority,
        workItem.nextAction,
        workItem.blockedReason,
        workItem.createdAt,
        workItem.updatedAt,
        workItem.completedAt,
      );
    return this.getWorkItem(workItem.id);
  }

  upsertWorkItem(input) {
    if (!input.externalKey?.trim()) {
      return this.createWorkItem(input);
    }
    const ownerProject = this.#requireProject(input.project);
    const existing = this.db
      .prepare("SELECT * FROM work_items WHERE project_id = ? AND external_key = ?")
      .get(ownerProject.id, input.externalKey.trim());
    if (!existing) return this.createWorkItem(input);

    const ownerBuddy = input.buddy ? this.#requireBuddy(input.buddy, ownerProject) : null;
    const ownerSprint = input.sprint ? this.#requireSprint(input.sprint, ownerProject) : null;
    assertOneOf("work item status", input.status, WORK_ITEM_STATUSES);
    if (input.status === "blocked" && !input.blockedReason?.trim()) {
      throw new Error("blocked reason is required when blocking a work item");
    }
    const timestamp = now();
    this.db
      .prepare(`
        UPDATE work_items SET
          sprint_id = ?, buddy_id = ?, title = ?, kind = ?, source_path = ?,
          objective = ?, definition_of_done = ?, status = ?, priority = ?,
          next_action = ?, blocked_reason = ?, updated_at = ?, completed_at = ?
        WHERE id = ?
      `)
      .run(
        ownerSprint?.id || null,
        ownerBuddy?.id || null,
        required("work item title", input.title),
        required("work item kind", input.kind || "task"),
        input.sourcePath ? this.#projectPath(ownerProject, input.sourcePath) : null,
        input.objective?.trim() || null,
        required("definition of done", input.definitionOfDone),
        input.status,
        Number(input.priority) || 0,
        input.nextAction?.trim() || null,
        input.status === "blocked" ? input.blockedReason.trim() : null,
        timestamp,
        input.status === "done" ? timestamp : null,
        existing.id,
      );
    return this.getWorkItem(existing.id);
  }

  getWorkItem(id) {
    const row = this.db.prepare("SELECT * FROM work_items WHERE id = ?").get(id);
    return row ? { ...row } : null;
  }

  updateWorkItemStatus(id, status, { blockedReason, nextAction } = {}) {
    assertOneOf("work item status", status, WORK_ITEM_STATUSES);
    this.#requireWorkItem(id);
    if (status === "blocked" && !blockedReason?.trim()) {
      throw new Error("blocked reason is required when blocking a work item");
    }
    const timestamp = now();
    this.db
      .prepare(`
        UPDATE work_items
        SET status = ?,
            blocked_reason = ?,
            next_action = COALESCE(?, next_action),
            completed_at = ?,
            updated_at = ?
        WHERE id = ?
      `)
      .run(
        status,
        status === "blocked" ? blockedReason.trim() : null,
        nextAction?.trim() || null,
        status === "done" ? timestamp : null,
        timestamp,
        id,
      );
    return this.getWorkItem(id);
  }

  listWorkItems({ project, buddy, sprint, includeClosed = false } = {}) {
    const conditions = [];
    const params = [];
    if (project) {
      conditions.push("work_items.project_id = ?");
      params.push(this.#requireProject(project).id);
    }
    if (buddy) {
      conditions.push("work_items.buddy_id = ?");
      params.push(this.#requireBuddy(buddy).id);
    }
    if (sprint) {
      conditions.push("work_items.sprint_id = ?");
      params.push(this.#requireSprint(sprint).id);
    }
    if (!includeClosed) {
      conditions.push("work_items.status NOT IN ('done', 'cancelled')");
    }
    const where = conditions.length ? `WHERE ${conditions.join(" AND ")}` : "";
    return rows(
      this.db.prepare(`
        SELECT work_items.*, buddies.name AS buddy_name, sprints.name AS sprint_name
        FROM work_items
        LEFT JOIN buddies ON buddies.id = work_items.buddy_id
        LEFT JOIN sprints ON sprints.id = work_items.sprint_id
        ${where}
        ORDER BY work_items.priority DESC, work_items.created_at
      `),
      ...params,
    );
  }

  currentWork(project) {
    const ownerProject = this.#requireProject(project);
    const activeSprint = this.getActiveSprint(ownerProject.id);
    const workItems = activeSprint
      ? this.listWorkItems({ project: ownerProject.id, sprint: activeSprint.id })
      : this.listWorkItems({ project: ownerProject.id });
    return {
      project: ownerProject,
      sprint: activeSprint,
      workItems,
    };
  }

  auditWorkMigration() {
    const summary = this.db
      .prepare(`
        SELECT
          COUNT(*) AS open_legacy,
          SUM(CASE WHEN owned_projects.id IS NOT NULL THEN 1 ELSE 0 END) AS migrated,
          SUM(CASE WHEN owned_projects.id IS NULL THEN 1 ELSE 0 END) AS unmigrated
        FROM work_items
        LEFT JOIN owned_projects
          ON owned_projects.workspace_id = work_items.project_id
          AND owned_projects.external_key = work_items.external_key
        WHERE work_items.status NOT IN ('done', 'cancelled')
      `)
      .get();
    const unmigratedItems = rows(
      this.db.prepare(`
        SELECT work_items.id, work_items.project_id, work_items.buddy_id,
          work_items.external_key, work_items.title, work_items.status
        FROM work_items
        LEFT JOIN owned_projects
          ON owned_projects.workspace_id = work_items.project_id
          AND owned_projects.external_key = work_items.external_key
        WHERE work_items.status NOT IN ('done', 'cancelled')
          AND owned_projects.id IS NULL
        ORDER BY work_items.priority DESC, work_items.created_at
      `),
    );
    return {
      openLegacy: Number(summary.open_legacy) || 0,
      migrated: Number(summary.migrated) || 0,
      unmigrated: Number(summary.unmigrated) || 0,
      unmigratedItems,
    };
  }

  dashboard() {
    const projects = this.listProjects();
    const buddies = this.listBuddies().map((buddy) => ({
      ...buddy,
      projects: this.listBuddyProjects(buddy.id),
      conversations: this.listConversationLinks(buddy.id),
    }));
    const sprints = rows(
      this.db.prepare(`
        SELECT sprints.*, projects.slug AS project_slug
        FROM sprints
        JOIN projects ON projects.id = sprints.project_id
        ORDER BY
          CASE sprints.status WHEN 'active' THEN 0 WHEN 'planned' THEN 1 ELSE 2 END,
          sprints.created_at DESC
      `),
    );
    return {
      projects,
      buddies,
      sprints,
      workItems: this.listWorkItems({ includeClosed: true }),
      buddyOwnedProjects: this.listBuddyOwnedProjects({ includeClosed: true }),
    };
  }

  getBuddyTeamState(buddy) {
    const manager = this.#requireBuddy(buddy);
    const employment = this.#employmentOf(manager.id);
    const team = this.listBuddies()
      .filter((candidate) => {
        const candidateEmployment = this.#employmentOf(candidate.id);
        return candidateEmployment.kind === "direct_report" &&
          candidateEmployment.managerId === manager.id;
      })
      .map(({ id, name, role, status }) => ({ id, name, role, status }));
    const supervisor = employment.kind === "direct_report"
      ? this.getBuddy(employment.managerId)
      : null;
    return {
      employment,
      manager: supervisor ? {
        id: supervisor.id, name: supervisor.name, role: supervisor.role, status: supervisor.status,
      } : null,
      team,
    };
  }

  overview({ recentSince } = {}) {
    const buddies = this.listBuddies();
    const workspaces = this.listProjects();
    const workspaceById = new Map(workspaces.map((workspace) => [workspace.id, workspace]));
    const relationships = rows(
      this.db.prepare(`
        SELECT * FROM buddy_relationships
        WHERE kind IN ('manager', 'reports_to')
        ORDER BY created_at, id
      `),
    );
    const managementPairs = new Map();
    for (const relationship of relationships) {
      const managerId =
        relationship.kind === "manager"
          ? relationship.from_buddy_id
          : relationship.to_buddy_id;
      const reportId =
        relationship.kind === "manager"
          ? relationship.to_buddy_id
          : relationship.from_buddy_id;
      managementPairs.set(`${managerId}:${reportId}`, { managerId, reportId });
    }
    // §5.1. Visibility is a property of the PAIR, not the row, and the gate is on
    // the MANAGER side only. Dropping an edge whose manager is archived lets the
    // report fall back to top_level; without that, archiving a manager leaves its
    // still-active reports in `employees` but out of `topLevel` - invisible in the
    // whole overview and unreachable in the UI, while their automations keep
    // firing. Gating the REPORT side too would be wrong: archived members must stay
    // in `team[]` (they carry `status`, and the client counts with buddyCardMetrics).
    const visibleBuddies = buddies.filter((buddy) => buddy.status !== "archived");
    const visibleIds = new Set(visibleBuddies.map((buddy) => buddy.id));
    // §5.2. Seeded top_level for EVERY buddy so the read in employee() is total: no
    // `?? {kind:"top_level"}`, no nullable local to re-derive.
    const employmentByBuddy = new Map(
      buddies.map((buddy) => [buddy.id, TOP_LEVEL_EMPLOYMENT]),
    );
    const reportsByManager = new Map();
    for (const { managerId, reportId } of managementPairs.values()) {
      if (!visibleIds.has(managerId)) continue;
      const reports = reportsByManager.get(managerId) || new Set();
      reports.add(reportId);
      reportsByManager.set(managerId, reports);
      // First surviving edge wins - the same canonical-manager rule the old
      // managerByReport had. v13's partial unique indexes make in-degree > 1
      // impossible for rows written through the store.
      if (employmentByBuddy.get(reportId).kind === "direct_report") continue;
      employmentByBuddy.set(reportId, { kind: "direct_report", managerId });
    }

    // Deliberately over ALL buddies, not visibleBuddies: `team[]` keeps archived
    // members so the client can count and label them (§12).
    const buddyById = new Map(buddies.map((buddy) => [buddy.id, buddy]));
    const openProjects = this.listBuddyOwnedProjects();
    const workByBuddy = new Map();
    for (const project of openProjects) {
      const work = workByBuddy.get(project.buddy_id) || [];
      work.push(project);
      workByBuddy.set(project.buddy_id, work);
    }
    const employee = (buddy) => {
      const work = workByBuddy.get(buddy.id) || [];
      const reportIds = reportsByManager.get(buddy.id) || new Set();
      return {
        buddy,
        employment: employmentByBuddy.get(buddy.id),
        workspaces: this.listBuddyWorkspaces(buddy.id),
        team: [...reportIds]
          .map((reportId) => buddyById.get(reportId))
          .filter(Boolean)
          .map(({ id: reportId, name, role, status }) => ({
            id: reportId,
            name,
            role,
            status,
          })),
        currentWork: {
          open: work.length,
          active: work.filter((project) => project.status === "in_progress").length,
          blocked: work.filter((project) => project.status === "blocked").length,
          review: work.filter((project) => project.status === "review").length,
          nextActionMissing: work.filter((project) => !project.next_action).length,
        },
      };
    };
    const employees = visibleBuddies.map(employee);
    const cutoff =
      recentSince === undefined
        ? Date.now() - 7 * 24 * 60 * 60 * 1000
        : new Date(recentSince).getTime();
    if (!Number.isFinite(cutoff)) throw new Error("recentSince must be a valid date");
    const recentRuns = [];
    // §5.1. This loop iterates buddies, not employees, so it needs its own filter -
    // otherwise a retired report keeps surfacing in the feed.
    for (const buddy of visibleBuddies) {
      for (const conversation of this.listConversationLinks(buddy.id)) {
        if (new Date(conversation.last_active_at).getTime() < cutoff) continue;
        const workspace = workspaceById.get(conversation.workspace_id);
        recentRuns.push({
          conversationId:
            conversation.unleashd_conversation_id ||
            conversation.provider_session_id ||
            conversation.id,
          buddyId: buddy.id,
          buddyName: buddy.name,
          workspaceId: conversation.workspace_id,
          workspaceName: workspace?.name || "General",
          status: conversation.status,
          lastActiveAt: conversation.last_active_at,
        });
      }
    }
    recentRuns.sort(
      (left, right) =>
        new Date(right.lastActiveAt).getTime() - new Date(left.lastActiveAt).getTime(),
    );
    return {
      generatedAt: now(),
      employees,
      topLevel: employees.filter((item) => item.employment.kind === "top_level"),
      recentRuns,
    };
  }

  getBuddyContext(buddy, { workspace, project } = {}) {
    const ownerBuddy = this.#requireBuddy(buddy);
    const homeWorkspace = this.#requireProject(ownerBuddy.project_id);
    const workspaces = this.listBuddyWorkspaces(ownerBuddy.id);
    const selectedWorkspace = workspace
      ? this.#requireProject(workspace)
      : workspaces.find((item) => item.id === ownerBuddy.project_id) || workspaces[0];
    if (selectedWorkspace && !this.#buddyHasProject(ownerBuddy.id, selectedWorkspace.id)) {
      throw new Error("buddy does not belong to the workspace");
    }
    const selectedProject = project ? this.#requireBuddyProject(project) : null;
    if (selectedProject && selectedProject.buddy_id !== ownerBuddy.id) {
      throw new Error("Buddy project does not belong to the buddy");
    }
    if (selectedProject && selectedWorkspace?.id !== selectedProject.workspace_id) {
      throw new Error("Buddy project does not belong to the workspace");
    }
    const soul = this.readBuddySoul(ownerBuddy).body;
    const skills = this.listBuddySkills(ownerBuddy.id).map((skill) => ({
      ...skill,
      instruction_path: this.#projectPath(homeWorkspace, skill.instruction_path),
    }));
    return {
      buddy: ownerBuddy,
      relationships: this.listBuddyRelationships(ownerBuddy.id),
      skills,
      workspaces,
      workspace: selectedWorkspace || null,
      sprint: selectedWorkspace ? this.getActiveSprint(selectedWorkspace.id) : null,
      project: selectedProject ? this.getBuddyProject(selectedProject.id) : null,
      projects: selectedWorkspace
        ? this.listBuddyOwnedProjects({
            buddy: ownerBuddy.id,
            workspace: selectedWorkspace.id,
          })
        : [],
      legacyWorkItems: selectedWorkspace
        ? this.listWorkItems({ buddy: ownerBuddy.id, project: selectedWorkspace.id })
        : [],
      soul,
      memory: this.readBuddyMemory(ownerBuddy),
    };
  }

  createAutomation({
    buddy,
    workspace,
    project,
    name,
    scheduleKind,
    scheduleExpression,
    timezone = "UTC",
    jobKind,
    jobPayload,
    policy,
    enabled = true,
    nextRunAt,
  }) {
    const ownerBuddy = this.#requireBuddy(buddy);
    const ownerWorkspace = this.#requireProject(workspace || ownerBuddy.project_id);
    if (!this.#buddyHasProject(ownerBuddy.id, ownerWorkspace.id)) {
      throw new Error("buddy does not belong to the workspace");
    }
    const ownerProject = project ? this.#requireBuddyProject(project) : null;
    if (ownerProject && ownerProject.buddy_id !== ownerBuddy.id) {
      throw new Error("Buddy project does not belong to the buddy");
    }
    if (ownerProject && ownerWorkspace && ownerProject.workspace_id !== ownerWorkspace.id) {
      throw new Error("Buddy project does not belong to the workspace");
    }
    const definition = this.#validateAutomationDefinition({
      scheduleKind,
      scheduleExpression,
      timezone,
      jobKind,
      jobPayload,
    });
    const automationPolicy = this.#validateAutomationPolicy(
      policy,
      definition.jobKind,
      definition.jobPayload,
    );
    const timestamp = now();
    const automationId = id("automation");
    this.#tx(() => {
      this.db
        .prepare(`
          INSERT INTO buddy_automations (
            id, buddy_id, workspace_id, buddy_project_id, name, schedule_kind,
            schedule_expression, timezone, job_kind, job_payload, enabled,
            next_run_at, last_run_at, created_at, updated_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NULL, ?, ?)
        `)
        .run(
          automationId,
          ownerBuddy.id,
          ownerWorkspace.id,
          ownerProject?.id || null,
          required("automation name", name),
          definition.scheduleKind,
          definition.scheduleExpression,
          definition.timezone,
          definition.jobKind,
          JSON.stringify(definition.jobPayload),
          enabled ? 1 : 0,
          nextRunAt ? new Date(nextRunAt).toISOString() : null,
          timestamp,
          timestamp,
        );
      this.#insertAutomationPolicy(automationId, automationPolicy, timestamp);
    });
    return this.getAutomation(automationId);
  }

  getAutomation(automation) {
    const row =
      typeof automation === "object" && automation?.id
        ? automation
        : this.db.prepare("SELECT * FROM buddy_automations WHERE id = ?").get(automation);
    return row ? this.#automationRow(row) : null;
  }

  listAutomations({ buddy, enabled, includeArchived = false } = {}) {
    const conditions = [];
    const params = [];
    if (buddy) {
      conditions.push("buddy_id = ?");
      params.push(this.#requireBuddy(buddy).id);
    }
    if (enabled !== undefined) {
      conditions.push("enabled = ?");
      params.push(enabled ? 1 : 0);
    }
    if (!includeArchived) {
      conditions.push("archived_at IS NULL");
    }
    return rows(
      this.db.prepare(`
        SELECT * FROM buddy_automations
        ${conditions.length ? `WHERE ${conditions.join(" AND ")}` : ""}
        ORDER BY created_at
      `),
      ...params,
    ).map((row) => this.#automationRow(row));
  }

  updateAutomation(automation, changes = {}) {
    const current = this.#requireAutomation(automation);
    if (current.archived_at) {
      throw new Error("archived automation definitions are immutable");
    }
    const definition = this.#validateAutomationDefinition({
      scheduleKind: changes.scheduleKind ?? current.schedule_kind,
      scheduleExpression: changes.scheduleExpression ?? current.schedule_expression,
      timezone: changes.timezone ?? current.timezone,
      jobKind: changes.jobKind ?? current.job_kind,
      jobPayload: changes.jobPayload ?? current.job_payload,
    });
    const automationPolicy = this.#validateAutomationPolicy(
      changes.policy,
      definition.jobKind,
      definition.jobPayload,
      current.policy,
    );
    const nextRunAt =
      changes.nextRunAt === undefined
        ? current.next_run_at
        : changes.nextRunAt
          ? new Date(changes.nextRunAt).toISOString()
          : null;
    const timestamp = now();
    this.#tx(() => {
      this.db
        .prepare(`
          UPDATE buddy_automations SET
            name = ?, schedule_kind = ?, schedule_expression = ?, timezone = ?,
            job_kind = ?, job_payload = ?, enabled = ?, next_run_at = ?, updated_at = ?
          WHERE id = ?
        `)
        .run(
          changes.name === undefined ? current.name : required("automation name", changes.name),
          definition.scheduleKind,
          definition.scheduleExpression,
          definition.timezone,
          definition.jobKind,
          JSON.stringify(definition.jobPayload),
          changes.enabled === undefined ? (current.enabled ? 1 : 0) : changes.enabled ? 1 : 0,
          nextRunAt,
          timestamp,
          current.id,
        );
      this.db
        .prepare(`
          UPDATE buddy_automation_policies SET
            max_runtime_seconds = ?, max_iterations = ?, max_tokens = ?,
            max_cost_usd = ?, allowed_operations = ?, updated_at = ?
          WHERE automation_id = ?
        `)
        .run(
          automationPolicy.max_runtime_seconds,
          automationPolicy.max_iterations,
          automationPolicy.max_tokens,
          automationPolicy.max_cost_usd,
          JSON.stringify(automationPolicy.allowed_operations),
          timestamp,
          current.id,
        );
    });
    return this.getAutomation(current.id);
  }

  deleteAutomation(automation) {
    return this.archiveAutomation(automation);
  }

  archiveAutomation(automation) {
    const current = this.#requireAutomation(automation);
    if (current.archived_at) return current;
    const timestamp = now();
    // "Delete" is deliberately an archive operation. The definition owns the
    // immutable execution ledger through a foreign key, so physical deletion
    // would erase the evidence needed to explain prior Buddy actions. See
    // agent_notes/2026-08-24_automation-execution-ownership-design.md.
    this.db
      .prepare(`
        UPDATE buddy_automations
        SET enabled = 0, next_run_at = NULL, archived_at = ?, updated_at = ?
        WHERE id = ?
      `)
      .run(timestamp, timestamp, current.id);
    return this.getAutomation(current.id);
  }

  /**
   * §10.1. `enabled = 0` (set by retire) was the ONLY thing keeping a retired
   * Buddy's schedule quiet - zero defence in depth. updateBuddy never touches
   * automations, so a *paused* Buddy kept firing, and re-enabling an archived
   * identity resurrected its schedule.
   *
   * `buddy_automations.*` rather than `*` is load-bearing: across this join a bare
   * `*` returns buddies.id LAST, so the row's `id` becomes the buddy id and
   * #automationRow then throws "automation policy not found". `created_at` would be
   * clobbered too. `buddy_automations.buddy_id` is NOT NULL REFERENCES buddies(id),
   * so the INNER JOIN cannot lose a legitimate row.
   */
  listDueAutomations(at = new Date()) {
    const due = at instanceof Date ? at.toISOString() : new Date(at).toISOString();
    return rows(
      this.db.prepare(`
        SELECT buddy_automations.*
        FROM buddy_automations
        JOIN buddies ON buddies.id = buddy_automations.buddy_id
        WHERE buddies.status = 'active'
          AND buddy_automations.enabled = 1
          AND buddy_automations.next_run_at IS NOT NULL
          AND buddy_automations.next_run_at <= ?
        ORDER BY buddy_automations.next_run_at, buddy_automations.created_at
      `),
      due,
    ).map((row) => this.#automationRow(row));
  }

  claimAutomationRun(
    automation,
    { scheduledFor, idempotencyKey, claimToken, leaseSeconds } = {},
  ) {
    const ownerAutomation = this.#requireAutomation(automation);
    const occurrence = scheduledFor || ownerAutomation.next_run_at || now();
    const scheduled = new Date(occurrence).toISOString();
    const key = idempotencyKey?.trim() || `${ownerAutomation.id}:${scheduled}`;
    const timestamp = now();
    const runId = id("automation_run");
    const token = claimToken?.trim() || id("automation_claim");
    const requestedLeaseSeconds =
      leaseSeconds === undefined
        ? ownerAutomation.policy.max_runtime_seconds + 60
        : Number(leaseSeconds);
    if (!Number.isInteger(requestedLeaseSeconds) || requestedLeaseSeconds < 1) {
      throw new Error("automation claim lease seconds must be a positive integer");
    }
    const claimExpiresAt = new Date(
      Date.parse(timestamp) + requestedLeaseSeconds * 1000,
    ).toISOString();
    let blockedBy = null;
    this.#tx(() => {
      // Serialize admission against retirement. A definition read before this
      // transaction cannot authorize a run after its Buddy was archived.
      const executor = this.#requireBuddy(ownerAutomation.buddy_id);
      if (executor.status !== "active") {
        throw new Error(`automation Buddy is not active: ${executor.status}`);
      }

      const active = this.db
        .prepare(`
          SELECT * FROM buddy_automation_runs
          WHERE automation_id = ? AND status IN ('claimed', 'running', 'cancel_requested')
          ORDER BY claimed_at
          LIMIT 1
        `)
        .get(ownerAutomation.id);
      if (active) {
        // We intentionally do not transfer an expired lease. Without a durable
        // worker/adoption protocol the old process may still be alive, and a
        // takeover would create two writers with plausible authority. Recovery
        // closes the old occurrence; it never replays it. See
        // agent_notes/2026-08-24_automation-execution-ownership-design.md.
        if (
          !active.claim_token ||
          !active.claim_expires_at ||
          active.claim_expires_at <= timestamp
        ) {
          this.db
            .prepare(`
              UPDATE buddy_automation_runs
              SET status = 'failed', error = ?, ended_at = ?
              WHERE id = ? AND status IN ('claimed', 'running', 'cancel_requested')
            `)
            .run("Automation interrupted after its executor lease expired", timestamp, active.id);
          this.db
            .prepare(`
              UPDATE buddy_automations
              SET last_run_at = ?, updated_at = ?
              WHERE id = ?
            `)
            .run(timestamp, timestamp, ownerAutomation.id);
          blockedBy = active.id;
          return;
        }
        blockedBy = active.id;
        return;
      }
      if(!this.getAutomationRunByIdempotencyKey(key)) {
        const activeRuns=this.coordinationActiveCounts();
        const membership=this.getCoordinationMembership(ownerAutomation.buddy_id,ownerAutomation.workspace_id);
        if(activeRuns.length>=8 || activeRuns.filter(r=>r.buddy_id===ownerAutomation.buddy_id).length>=(membership?.max_active_runs ?? 2)) throw new Error('Active Buddy run limit reached');
        this.assertProjectExecution(ownerAutomation.buddy_project_id,null,{admission:true});
      }
      const inserted = this.db
        .prepare(`
          INSERT INTO buddy_automation_runs (
            id, automation_id, scheduled_for, idempotency_key, status,
            conversation_id, iteration, outcome, error, claimed_at, started_at, ended_at,
            claim_token, claim_expires_at
          ) VALUES (?, ?, ?, ?, 'claimed', NULL, 0, NULL, NULL, ?, NULL, NULL, ?, ?)
          ON CONFLICT(idempotency_key) DO NOTHING
        `)
        .run(runId, ownerAutomation.id, scheduled, key, timestamp, token, claimExpiresAt);
      if (inserted.changes === 1) {
        this.db
          .prepare(`
            INSERT INTO buddy_automation_run_policies (
              run_id, max_runtime_seconds, max_iterations, max_tokens,
              max_cost_usd, allowed_operations, tokens_used, cost_usd
            ) VALUES (?, ?, ?, ?, ?, ?, 0, 0)
          `)
          .run(
            runId,
            ownerAutomation.policy.max_runtime_seconds,
            ownerAutomation.policy.max_iterations,
            ownerAutomation.policy.max_tokens,
            ownerAutomation.policy.max_cost_usd,
            JSON.stringify(ownerAutomation.policy.allowed_operations),
          );
      }
    });
    if (blockedBy) {
      return { ...this.getAutomationRun(blockedBy), claim_acquired: false };
    }
    const claimed = this.getAutomationRunByIdempotencyKey(key);
    if (claimed?.automation_id !== ownerAutomation.id) {
      throw new Error("idempotency key is already claimed by another automation");
    }
    return {
      ...claimed,
      claim_acquired: claimed.claim_token === token,
    };
  }

  getAutomationRun(run) {
    const row =
      typeof run === "object" && run?.id
        ? run
        : this.db.prepare("SELECT * FROM buddy_automation_runs WHERE id = ?").get(run);
    return row ? this.#automationRunRow(row) : null;
  }

  getAutomationRunByIdempotencyKey(key) {
    const row = this.db
      .prepare("SELECT * FROM buddy_automation_runs WHERE idempotency_key = ?")
      .get(required("idempotency key", key));
    return row ? this.#automationRunRow(row) : null;
  }

  updateAutomationRun(run, {
    status,
    conversationId,
    iteration,
    outcome,
    error,
    nextRunAt,
    tokensUsed,
    costUsd,
    claimToken,
  }) {
    const current = this.#requireAutomationRun(run);
    assertOneOf("automation run status", status, AUTOMATION_RUN_STATUSES);
    if (current.claim_token && claimToken !== current.claim_token) {
      throw new Error("automation run claim is not owned by this executor");
    }
    const terminalStatuses = ["complete", "failed", "cancelled"];
    if (terminalStatuses.includes(current.status)) {
      if (status !== current.status) {
        throw new Error(
          `terminal automation run cannot transition from ${current.status} to ${status}`,
        );
      }
      // Recovery terminalizes an expired occurrence inside claimAutomationRun,
      // then the scheduler computes the schedule-kind-specific next occurrence.
      // Permit that one idempotent terminal write; never reopen the run itself.
      if (nextRunAt === undefined) return current;
    }
    if (
      current.status === "cancel_requested" &&
      !["cancelled", "failed"].includes(status)
    ) {
      throw new Error(
        `cancel-requested automation run cannot transition to ${status}`,
      );
    }
    const timestamp = now();
    const startedAt =
      status === "running" ? current.started_at || timestamp : current.started_at;
    const endedAt = terminalStatuses.includes(status)
      ? current.ended_at || timestamp
      : null;
    const nextIteration =
      iteration === undefined ? current.iteration : Math.max(0, Number(iteration) || 0);
    const nextTokensUsed =
      tokensUsed === undefined ? current.tokens_used : Number(tokensUsed);
    const nextCostUsd = costUsd === undefined ? current.cost_usd : Number(costUsd);
    if (!Number.isInteger(nextTokensUsed) || nextTokensUsed < 0) {
      throw new Error("automation tokens used must be a non-negative integer");
    }
    if (!Number.isFinite(nextCostUsd) || nextCostUsd < 0) {
      throw new Error("automation cost used must be non-negative");
    }
    if (nextIteration < current.iteration) {
      throw new Error("automation iteration cannot decrease");
    }
    if (nextTokensUsed < current.tokens_used) {
      throw new Error("automation tokens used cannot decrease");
    }
    if (nextCostUsd < current.cost_usd) {
      throw new Error("automation cost used cannot decrease");
    }
    if (nextIteration > current.policy.max_iterations) {
      throw new Error("automation iteration budget exceeded");
    }
    if (nextTokensUsed > current.policy.max_tokens) {
      throw new Error("automation token budget exceeded");
    }
    if (nextCostUsd > current.policy.max_cost_usd) {
      throw new Error("automation cost budget exceeded");
    }
    if (
      status === "running" &&
      startedAt &&
      Date.parse(timestamp) - Date.parse(startedAt) >
        current.policy.max_runtime_seconds * 1000
    ) {
      throw new Error("automation runtime budget exceeded");
    }
    this.#tx(() => {
      this.db
        .prepare(`
          UPDATE buddy_automation_runs SET
            status = ?, conversation_id = ?, iteration = ?, outcome = ?,
            error = ?, started_at = ?, ended_at = ?
          WHERE id = ?
        `)
        .run(
          status,
          conversationId === undefined ? current.conversation_id : conversationId || null,
          nextIteration,
          outcome === undefined ? current.outcome : outcome || null,
          error === undefined ? current.error : error || null,
          startedAt,
          endedAt,
          current.id,
        );
      this.db
        .prepare(`
          UPDATE buddy_automation_run_policies
          SET tokens_used = ?, cost_usd = ?
          WHERE run_id = ?
        `)
        .run(nextTokensUsed, nextCostUsd, current.id);
      if (terminalStatuses.includes(status)) {
        const automation = this.#requireAutomation(current.automation_id);
        const scheduledNextRun =
          nextRunAt === undefined
            ? automation.next_run_at
            : nextRunAt
              ? new Date(nextRunAt).toISOString()
              : null;
        this.db
          .prepare(`
            UPDATE buddy_automations
            SET last_run_at = ?, next_run_at = ?, updated_at = ?
            WHERE id = ?
          `)
          .run(
            timestamp,
            scheduledNextRun,
            timestamp,
            current.automation_id,
          );
      }
    });
    return this.getAutomationRun(current.id);
  }

  listAutomationRuns(automation, { limit = 50 } = {}) {
    const ownerAutomation = this.#requireAutomation(automation);
    return rows(
      this.db.prepare(`
        SELECT * FROM buddy_automation_runs
        WHERE automation_id = ?
        ORDER BY claimed_at DESC
        LIMIT ?
      `),
      ownerAutomation.id,
      Math.max(1, Number(limit) || 50),
    ).map((row) => this.#automationRunRow(row));
  }

  getAutomationRunByConversationId(conversationId) {
    const value = required("conversation id", conversationId);
    const row = this.db
      .prepare("SELECT * FROM buddy_automation_runs WHERE conversation_id = ? LIMIT 1")
      .get(value);
    return row ? this.#automationRunRow(row) : null;
  }

  listNonterminalAutomationRuns() {
    return rows(
      this.db.prepare(`
        SELECT * FROM buddy_automation_runs
        WHERE status IN ('claimed', 'running', 'cancel_requested')
        ORDER BY claimed_at, id
      `),
    ).map((row) => this.#automationRunRow(row));
  }

  assertAutomationOperationAllowed(run, operation, claimToken) {
    const ownerRun = this.#requireAutomationRun(run);
    const name = required("automation operation", operation);
    this.assertProjectExecution(this.getAutomation(ownerRun.automation_id).buddy_project_id, null, { operation: name });
    // The operation allowlist is only half the authority decision. A saved
    // conversation is durable, but execution authority is not: terminal,
    // cancelled and expired runs must never regain mutation rights on resume.
    // See agent_notes/2026-08-24_automation-execution-ownership-design.md.
    if (ownerRun.status !== "running") {
      throw new Error(`automation run is not active: ${ownerRun.status}`);
    }
    if (!ownerRun.claim_token || ownerRun.claim_token !== claimToken) {
      throw new Error("automation run claim is not owned by this executor");
    }
    if (
      !ownerRun.claim_expires_at ||
      Date.parse(ownerRun.claim_expires_at) <= Date.now()
    ) {
      throw new Error("automation run authority has expired");
    }
    if (!ownerRun.policy.allowed_operations.includes(name)) {
      throw new Error(`automation operation is not allowed: ${name}`);
    }
    return true;
  }

  withAutomationRunAuthority(run, operation, claimToken, callback) {
    if (typeof callback !== "function") throw new Error("automation callback is required");
    // The authority read and every synchronous store mutation in callback share
    // one BEGIN IMMEDIATE transaction. The second assertion prevents callback
    // code from terminalising its own run and then committing a mutation. Never
    // accept a Promise here: a database write lock is not an async mutex.
    // See agent_notes/2026-08-24_automation-execution-ownership-design.md I2.
    return this.#tx(() => {
      this.assertAutomationOperationAllowed(run, operation, claimToken);
      const result = callback();
      if (result && typeof result.then === "function") {
        throw new Error("automation authority callbacks must be synchronous");
      }
      this.assertAutomationOperationAllowed(run, operation, claimToken);
      return result;
    });
  }

  linkConversation({
    buddy,
    workspace,
    project,
    workItem,
    provider,
    providerSessionId,
    unleashdConversationId,
    status = "active",
  }) {
    assertOneOf("conversation status", status, CONVERSATION_STATUSES);
    if (!providerSessionId && !unleashdConversationId) {
      throw new Error("provider session id or Unleashd conversation id is required");
    }
    const ownerBuddy = this.#requireBuddy(buddy);
    const item = workItem ? this.#requireWorkItem(workItem) : null;
    const ownerProject = project ? this.#requireBuddyProject(project) : null;
    if (ownerProject && ownerProject.buddy_id !== ownerBuddy.id) {
      throw new Error("Buddy project does not belong to the buddy");
    }
    const ownerWorkspace = this.#requireProject(
      workspace || ownerProject?.workspace_id || item?.project_id || ownerBuddy.project_id,
    );
    this.#requireBuddy(ownerBuddy, ownerWorkspace);
    if (item && item.project_id !== ownerWorkspace.id) {
      throw new Error("legacy work item does not belong to the conversation workspace");
    }
    if (ownerProject && ownerProject.workspace_id !== ownerWorkspace.id) {
      throw new Error("Buddy project does not belong to the conversation workspace");
    }
    return this.coordinationTransaction(() => {
    const existing = unleashdConversationId ? this.db.prepare(
      'SELECT * FROM conversation_links WHERE unleashd_conversation_id=?'
    ).get(unleashdConversationId) : null;
    if (existing) {
      if (existing.buddy_id !== ownerBuddy.id || existing.workspace_id !== ownerWorkspace.id ||
          existing.buddy_project_id !== (ownerProject?.id || null) || existing.work_item_id !== (item?.id || null))
        throw Object.assign(new Error('Conversation already has a different Buddy/workspace/project binding'), {code:'conversation_link_conflict'});
      return this.getConversationLink(existing.id);
    }
    const timestamp = now();
    const link = {
      id: id("conversation"),
      buddyId: ownerBuddy.id,
      workspaceId: ownerWorkspace.id,
      buddyProjectId: ownerProject?.id || null,
      workItemId: item?.id || null,
      provider: required("provider", provider),
      providerSessionId: providerSessionId || null,
      unleashdConversationId: unleashdConversationId || null,
      status,
      startedAt: timestamp,
      lastActiveAt: timestamp,
      endedAt: status === "active" ? null : timestamp,
    };
    this.db
      .prepare(`
        INSERT INTO conversation_links (
          id, buddy_id, workspace_id, buddy_project_id, work_item_id, provider, provider_session_id,
          unleashd_conversation_id, status, started_at, last_active_at, ended_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `)
      .run(
        link.id,
        link.buddyId,
        link.workspaceId,
        link.buddyProjectId,
        link.workItemId,
        link.provider,
        link.providerSessionId,
        link.unleashdConversationId,
        link.status,
        link.startedAt,
        link.lastActiveAt,
        link.endedAt,
      );
    return this.getConversationLink(link.id);
    });
  }

  updateConversationLink(idOrConversationId, {
    status,
    providerSessionId,
  } = {}) {
    const current = this.db
      .prepare(`
        SELECT * FROM conversation_links
        WHERE id = ? OR unleashd_conversation_id = ? OR provider_session_id = ?
      `)
      .get(idOrConversationId, idOrConversationId, idOrConversationId);
    if (!current) throw new Error(`conversation link not found: ${idOrConversationId}`);
    const nextStatus = status || current.status;
    assertOneOf("conversation status", nextStatus, CONVERSATION_STATUSES);
    const timestamp = now();
    this.db
      .prepare(`
        UPDATE conversation_links SET
          status = ?, provider_session_id = COALESCE(?, provider_session_id),
          last_active_at = ?, ended_at = ?
        WHERE id = ?
      `)
      .run(
        nextStatus,
        providerSessionId || null,
        timestamp,
        nextStatus === "active" ? null : timestamp,
        current.id,
      );
    return this.getConversationLink(current.id);
  }

  getConversationLink(id) {
    const row = this.db.prepare("SELECT * FROM conversation_links WHERE id = ?").get(id);
    return row ? { ...row } : null;
  }

  listConversationLinks(buddy) {
    const ownerBuddy = this.#requireBuddy(buddy);
    return rows(
      this.db.prepare(`
        SELECT * FROM conversation_links
        WHERE buddy_id = ?
        ORDER BY last_active_at DESC
      `),
      ownerBuddy.id,
    );
  }

  // ------------------------------------------------------------------
  // Direct reports (sub-buddies).
  // Design: unleashd agent_notes/2026-08-19_sub-buddies-design.md
  //         SS7.5, 8.1, 8.4, 8.5, 9.1-9.4.
  // ------------------------------------------------------------------

  /**
   * §7.5. UNION, never UNION ALL: `manager A->B` and `reports_to B->A` are two
   * distinct rows under UNIQUE(from_buddy_id, to_buddy_id, kind) that denote ONE
   * relationship, and overview() dedupes exactly this pair. UNION ALL double-counts.
   * Paused reports still belong to the current team; archived reports are history.
   */
  countHeldDirectReports(manager) {
    const managerId = this.#requireBuddy(manager).id;
    return this.db
      .prepare(`
        SELECT COUNT(*) AS held
        FROM (
          SELECT to_buddy_id   AS report_id FROM buddy_relationships
           WHERE kind = 'manager'    AND from_buddy_id = ?
          UNION
          SELECT from_buddy_id AS report_id FROM buddy_relationships
           WHERE kind = 'reports_to' AND to_buddy_id   = ?
        ) AS reports
        JOIN buddies ON buddies.id = reports.report_id
        WHERE buddies.status <> 'archived'
      `)
      .get(managerId, managerId).held;
  }

  /**
   * §9.1. The canonicalizer (kappa) for hire: the ONLY place that inspects buddy
   * rows. Every hire handler downstream is one clean path over the returned sum.
   *
   * §8.5 - the lookup MUST be `project_id = ? AND slug = ?`, the real
   * UNIQUE(project_id, slug) constraint. `getBuddy(slug, workspace)` joins
   * buddy_projects (assignment, not home) and is wrong in both directions:
   *   - false 409: a Buddy homed in W1 and also assigned to W2 makes hire(name, W2)
   *     report "name taken" although the INSERT would succeed;
   *   - missed collision: an archived `scout` homed in W1 is invisible to
   *     getBuddy('scout', W2), the create path runs, two rows share the slug, and
   *     every bare getBuddy('scout') throws "ambiguous across workspaces" forever.
   */
  resolveHireTarget(manager, slug, workspace) {
    const managerBuddy = this.#requireBuddy(manager);
    const homeWorkspace = this.#requireProject(workspace);
    const row = this.db
      .prepare("SELECT * FROM buddies WHERE project_id = ? AND slug = ?")
      .get(homeWorkspace.id, slug);
    if (!row) return { kind: "vacant" };
    const sub = { ...row };
    const employment = this.#employmentOf(sub.id);
    if (employment.kind === "top_level") {
      return { kind: "slug_owned_by_top_level", sub };
    }
    if (employment.managerId !== managerBuddy.id) {
      return { kind: "held_elsewhere", sub, managerId: employment.managerId };
    }
    return sub.status === "archived"
      ? { kind: "reactivatable", sub }
      : { kind: "held", sub };
  }

  /**
   * §5.2. Employment as a sum, not `managerId: string | null`. `null` was doing two
   * jobs (who manages this / does this show in the directory) and that is the origin
   * of the "archive the manager and the active report vanishes" bug.
   *
   * UNION ALL here is correct and deliberate - the opposite of
   * countHeldDirectReports. We want the EARLIEST edge overall, and both encodings of
   * one relationship yield the same manager_id, so duplicates cannot change a
   * LIMIT 1 answer. `ORDER BY created_at, id`: created_at is millisecond ISO, ties
   * have no stable order and can flip after `VACUUM INTO` (backupDatabase), which
   * would make the canonical manager nondeterministic (§8.3).
   */
  #employmentOf(buddyId) {
    const row = this.db
      .prepare(`
        SELECT manager_id FROM (
          SELECT from_buddy_id AS manager_id, created_at, id FROM buddy_relationships
           WHERE kind = 'manager'    AND to_buddy_id   = ?
          UNION ALL
          SELECT to_buddy_id   AS manager_id, created_at, id FROM buddy_relationships
           WHERE kind = 'reports_to' AND from_buddy_id = ?
        )
        ORDER BY created_at, id
        LIMIT 1
      `)
      .get(buddyId, buddyId);
    return row
      ? { kind: "direct_report", managerId: row.manager_id }
      : { kind: "top_level" };
  }

  /**
   * Thin dispatch over the canonical hire target. One manager and workspace
   * membership constrain a hire; the historical headcount quota is not consulted.
   */
  hireDirectReport({
    managerBuddy,
    name,
    role,
    soul,
    workspace,
    additionalWorkspaces = [],
    provider,
    model,
    reasoningEffort,
  }) {
    const manager = this.#requireBuddy(managerBuddy);
    if (manager.status !== "active") {
      throw new Error(
        `only an active Buddy can hire: ${manager.slug} is ${manager.status}`,
      );
    }
    const homeWorkspace = this.#requireProject(workspace);
    const extraWorkspaces = additionalWorkspaces
      .map((candidate) => this.#requireProject(candidate))
      .filter(
        (candidate, index, all) =>
          candidate.id !== homeWorkspace.id &&
          all.findIndex((other) => other.id === candidate.id) === index,
      );
    // A manager can only staff workspaces it is in: assignBuddyToProject is
    // unguarded, so without this a report lands where its manager cannot follow.
    const managerWorkspaceIds = new Set(
      this.listBuddyWorkspaces(manager.id).map((entry) => entry.id),
    );
    for (const candidate of [homeWorkspace, ...extraWorkspaces]) {
      if (!managerWorkspaceIds.has(candidate.id)) {
        throw new Error(
          `manager ${manager.slug} is not assigned to workspace ${candidate.slug}`,
        );
      }
    }
    const slug = slugify(name);
    // §8.4. slugify() returns "" for "...", "!!!", "---", "..", an emoji - required()
    // passes because the INPUT was non-empty. `profiles/${""}/BUDDY_SOUL.md` then
    // normalises to `<workspace>/profiles/BUDDY_SOUL.md` and the post-commit rename
    // targets the profiles/ DIRECTORY ITSELF. Assert before any filesystem work, and
    // name `name` (what the caller passed), not `slug` (what we derived).
    if (!DIRECT_REPORT_SLUG_RE.test(slug)) {
      throw new Error(
        `name must reduce to a slug matching ${DIRECT_REPORT_SLUG_RE}: ${JSON.stringify(name)}`,
      );
    }
    const soulBody = required("direct report soul", soul);
    if (Buffer.byteLength(soulBody, "utf8") > MAX_DIRECT_REPORT_SOUL_BYTES) {
      throw new Error(
        `direct report soul exceeds ${MAX_DIRECT_REPORT_SOUL_BYTES} bytes`,
      );
    }
    const roleValue = required("direct report role", role);
    // §4. A Buddy with no soul and no memory path is not a direct report: its
    // briefing renders "(No Buddy soul has been configured.)" and every
    // buddy.remember throws. hire OWNS profiles/<slug>/ and provisions both.
    const soulPath = `profiles/${slug}/BUDDY_SOUL.md`;
    const memoryPath = `profiles/${slug}/memory`;
    // §9.3. Stage first, rename after COMMIT. Writing the final path before BEGIN
    // with flag 'wx' wedges the slug on a crash with an EEXIST that names the
    // filesystem instead of the problem.
    const staging = this.#stageDirectReportProfile(homeWorkspace, {
      slug,
      soul: soulBody,
      manager,
    });

    let result;
    try {
      result = this.#tx(() => {
        const target = this.resolveHireTarget(manager, slug, homeWorkspace);
        const context = {
          manager,
          slug,
          name,
          role: roleValue,
          homeWorkspace,
          extraWorkspaces,
          soulPath,
          memoryPath,
          provider,
          model,
          reasoningEffort,
        };
        switch (target.kind) {
          case "vacant":
            return this.#hireVacant(context);
          case "reactivatable":
            return this.#hireReactivatable(context, target.sub);
          case "held":
            return this.#hireHeld(context, target.sub);
          case "held_elsewhere":
            return this.#hireHeldElsewhere(context, target);
          case "slug_owned_by_top_level":
            return this.#hireSlugOwnedByTopLevel(context, target.sub);
          default:
            throw new Error(`unhandled hire target: ${target.kind}`);
        }
      });
    } catch (error) {
      this.#discardStagedProfile(staging);
      throw error;
    }
    // §9.3. This rename does NOT close the COMMIT -> rename window; a crash here
    // still leaves "row, no profile", which is silent (getBuddyContext swallows
    // ENOENT on the soul read) and permanent (re-hire takes the `held` arm). The
    // window is closed by #repairProfile in the held / reactivatable handlers.
    switch (result.profile.kind) {
      case "promote":
        this.#promoteStagedProfile(staging, this.#profileDir(homeWorkspace, slug));
        break;
      case "discard":
        this.#discardStagedProfile(staging);
        break;
      default:
        throw new Error(`unhandled staged profile action: ${result.profile.kind}`);
    }
    return { buddy: this.getBuddy(result.buddy.id), outcome: result.outcome };
  }

  #hireVacant(context) {
    const sub = this.createBuddy({
      project: context.homeWorkspace,
      name: context.name,
      role: context.role,
      slug: context.slug,
      status: "active",
      soulPath: context.soulPath,
      memoryPath: context.memoryPath,
      provider: context.provider,
      model: context.model,
      reasoningEffort: context.reasoningEffort,
      hireQuota: 0,
    });
    for (const extra of context.extraWorkspaces) {
      this.assignBuddyToProject({
        buddy: sub.id,
        project: extra.id,
        role: context.role,
      });
    }
    this.setBuddyRelationship({
      fromBuddy: context.manager.id,
      toBuddy: sub.id,
      kind: "manager",
    });
    this.recordAuditEvent({
      buddy: sub.id,
      workspace: context.homeWorkspace.id,
      operation: "buddy.hire_direct_report",
      payload: {
        managerId: context.manager.id,
        slug: context.slug,
        role: context.role,
      },
    });
    return { buddy: sub, outcome: "hired", profile: { kind: "promote" } };
  }

  #hireReactivatable(context, sub) {
    // Deliberately asymmetric with retire (§9.4): retire disables automations,
    // reactivate does NOT re-enable them. A report returning after weeks must not
    // fire a schedule written against a world that has moved on.
    const reactivated = this.updateBuddy(sub.id, {
      status: "active",
      role: context.role,
    });
    for (const extra of context.extraWorkspaces) {
      this.assignBuddyToProject({
        buddy: sub.id,
        project: extra.id,
        role: context.role,
      });
    }
    this.recordAuditEvent({
      buddy: sub.id,
      workspace: context.homeWorkspace.id,
      operation: "buddy.reactivate_direct_report",
      payload: {
        managerId: context.manager.id,
        slug: context.slug,
        role: context.role,
      },
    });
    return {
      buddy: reactivated,
      outcome: "reactivated",
      profile: this.#repairProfile(context, sub),
    };
  }

  #hireHeld(context, sub) {
    // Repeating a valid hire preserves the existing identity and profile.
    return {
      buddy: sub,
      outcome: "unchanged",
      profile: this.#repairProfile(context, sub),
    };
  }

  #hireHeldElsewhere(context, target) {
    const other = this.#requireBuddy(target.managerId);
    throw new Error(
      `slug ${context.slug} in workspace ${context.homeWorkspace.slug} is already a direct report of ${other.slug}`,
    );
  }

  #hireSlugOwnedByTopLevel(context, sub) {
    throw new Error(
      `slug ${context.slug} in workspace ${context.homeWorkspace.slug} belongs to top-level Buddy ${sub.name} (${sub.id})`,
    );
  }

  /**
   * §9.3 repair path. The invariant is "hire owns profiles/<slug>/", so the row's
   * paths are restated unconditionally (one statement, no branch) and the soul is
   * re-materialized when it is missing or empty. This is the ONLY thing that ever
   * fixes a post-crash "row committed, profile never renamed" state: memory
   * self-heals (memory writes create their directory), the row is active so re-hire lands on `held`,
   * and the briefing just renders "(No Buddy soul has been configured.)" forever.
   */
  #repairProfile(context, sub) {
    const timestamp = now();
    this.db
      .prepare(
        "UPDATE buddies SET soul_path = ?, memory_path = ?, updated_at = ? WHERE id = ?",
      )
      .run(
        this.#projectPath(context.homeWorkspace, context.soulPath),
        this.#projectPath(context.homeWorkspace, context.memoryPath),
        timestamp,
        sub.id,
      );
    const soulState = this.#soulState(
      this.#projectPath(context.homeWorkspace, context.soulPath),
    );
    return PROFILE_ACTION_BY_SOUL_STATE[soulState.kind];
  }

  #soulState(absolutePath) {
    try {
      return readFileSync(absolutePath, "utf8").trim() === ""
        ? { kind: "absent" }
        : { kind: "materialized" };
    } catch (error) {
      if (error.code === "ENOENT" || error.code === "EISDIR") {
        return { kind: "absent" };
      }
      throw error;
    }
  }

  #profileDir(workspace, slug) {
    // #containedPath, not join(): staging and promotion run inside the store, so
    // they get the same containment check as every other Buddy-authored path.
    return this.#containedPath(workspace.root_path, "profiles", slug);
  }

  #stageDirectReportProfile(workspace, { slug, soul, manager }) {
    const dir = this.#containedPath(
      workspace.root_path,
      "profiles",
      ".staging",
      randomUUID(),
    );
    mkdirSync(join(dir, "memory"), { recursive: true });
    // §11: the soul is LLM-authored text spliced verbatim into a system prompt and
    // written to a git-tracked file. Stamp provenance so an Owner reading a diff can
    // tell it was not hand-written.
    const header = [
      "<!--",
      `  authored_by: ${manager.slug} (${manager.id})`,
      `  at: ${now()}`,
      `  hired_as: ${slug}`,
      "-->",
      "",
    ].join("\n");
    writeFileSync(join(dir, "BUDDY_SOUL.md"), `${header}${soul}\n`, "utf8");
    return dir;
  }

  /**
   * Promote by renaming the FILE, never the directory. `renameSync(staging, final)`
   * fails ENOTEMPTY when profiles/<slug>/ already exists, and clearing it first
   * would delete profiles/<slug>/memory - the one thing a retire/re-hire cycle must
   * preserve. Same filesystem, so the file rename is still atomic.
   */
  #promoteStagedProfile(staging, profileDir) {
    mkdirSync(profileDir, { recursive: true });
    renameSync(join(staging, "BUDDY_SOUL.md"), join(profileDir, "BUDDY_SOUL.md"));
    mkdirSync(join(profileDir, "memory"), { recursive: true });
    this.#discardStagedProfile(staging);
  }

  #discardStagedProfile(staging) {
    rmSync(staging, { recursive: true, force: true });
  }

  /**
   * §9.3(2). A crash before COMMIT orphans profiles/.staging/<uuid>/ forever.
   * Age-gated because a concurrent hire in another process owns a fresh staging dir
   * and this runs on every store open. Failures are kept as data rather than
   * swallowed (T4) and rather than bricking every store open.
   */
  #gcStagedProfiles() {
    const cutoff = Date.now() - STAGING_GC_MIN_AGE_MS;
    for (const workspace of this.listProjects()) {
      const root = join(workspace.root_path, "profiles", ".staging");
      try {
        if (!existsSync(root)) continue;
        for (const entry of readdirSync(root)) {
          const candidate = join(root, entry);
          if (statSync(candidate).mtimeMs > cutoff) continue;
          rmSync(candidate, { recursive: true, force: true });
        }
      } catch (error) {
        this.stagingGcErrors.push({ root, message: error.message });
      }
    }
  }

  /**
   * §9.4. Everything runs inside one BEGIN IMMEDIATE: the open-work listing and the
   * reassignment must not straddle the transaction or a project created between
   * them is left owned by an archived Buddy.
   *
   * Relationships are NEVER touched (§5). The directory rule promotes a managerless
   * Buddy to top level, so deleting the manager edge would UN-HIDE the retiree. An
   * archived report is still historically that manager's report.
   */
  retireDirectReport({ managerBuddy, subBuddy, reason, reassignOpenWorkTo }) {
    const manager = this.#requireBuddy(managerBuddy);
    const sub = this.#requireBuddy(subBuddy);
    return this.#tx(() => {
      // §8.3: canonical manager, one direction. "either direction" matching lets a
      // non-canonical manager retire someone else's report.
      const employment = this.#employmentOf(sub.id);
      if (
        employment.kind !== "direct_report" ||
        employment.managerId !== manager.id
      ) {
        throw new Error(`${sub.slug} is not a direct report of ${manager.slug}`);
      }

      // The scheduler alone owns run cancellation and provider drain. Retirement
      // cannot manufacture completion while an executor still holds authority.
      const activeRun = this.db.prepare(`
        SELECT r.id FROM buddy_automation_runs r
        JOIN buddy_automations a ON a.id = r.automation_id
        WHERE a.buddy_id = ? AND r.status IN ('claimed', 'running', 'cancel_requested')
        LIMIT 1
      `).get(sub.id);
      if (activeRun) {
        throw new Error(`Cancel and finish active automation run ${activeRun.id} before retiring ${sub.slug}`);
      }
      const work = this.#resolveRetirementWork(manager, sub, reassignOpenWorkTo);
      let reassigned;
      switch (work.kind) {
        case "no_open_work":
          reassigned = 0;
          break;
        case "reassign_to_manager":
          for (const project of work.projects) {
            this.reassignOwnedProject({ project: project.id, toBuddy: manager.id });
          }
          reassigned = work.projects.length;
          break;
        default:
          throw new Error(`unhandled retirement work plan: ${work.kind}`);
      }
      const timestamp = now();
      // Direct UPDATE, not updateAutomation(): that method opens its own #tx, and a
      // nested savepoint per automation buys nothing over one statement here.
      const automations = this.db
        .prepare(
          "UPDATE buddy_automations SET enabled = 0, next_run_at = NULL, updated_at = ? WHERE buddy_id = ?",
        )
        .run(timestamp, sub.id).changes;
      // BOTH delegation directions: buddy_delegations is one table for both, so
      // "cancel the report's delegations" is ambiguous. Work the retiree ISSUED
      // would strand its recipients; work ASSIGNED to it would sit pending forever.
      const issued = this.db
        .prepare(`
          UPDATE buddy_delegations SET status = 'cancelled',
            outcome = COALESCE(outcome, 'cancelled: the delegating Buddy was retired'),
            updated_at = ?, completed_at = COALESCE(completed_at, ?)
          WHERE from_buddy_id = ? AND status IN ('pending', 'active')
        `)
        .run(timestamp, timestamp, sub.id).changes;
      const received = this.db
        .prepare(`
          UPDATE buddy_delegations SET status = 'cancelled',
            outcome = COALESCE(outcome, 'cancelled: the assigned Buddy was retired'),
            updated_at = ?, completed_at = COALESCE(completed_at, ?)
          WHERE to_buddy_id = ? AND status IN ('pending', 'active')
        `)
        .run(timestamp, timestamp, sub.id).changes;
      const reviews = this.db
        .prepare(`
          UPDATE buddy_reviews SET status = 'cancelled', updated_at = ?,
            completed_at = COALESCE(completed_at, ?)
          WHERE reviewer_buddy_id = ? AND status = 'draft'
        `)
        .run(timestamp, timestamp, sub.id).changes;
      this.db
        .prepare("UPDATE buddies SET status = 'archived', updated_at = ? WHERE id = ?")
        .run(timestamp, sub.id);
      this.db.prepare(`UPDATE buddy_messages SET status = 'cancelled', outcome = 'Buddy retired', updated_at = ?,
        wait_status = CASE WHEN wait_status = 'waiting' THEN 'cancelled' ELSE wait_status END
        WHERE (from_buddy_id = ? OR to_buddy_id = ?) AND status IN ('pending','active')`)
        .run(now(), sub.id, sub.id);
      this.recordAuditEvent({
        buddy: sub.id,
        workspace: sub.project_id,
        operation: "buddy.retire_direct_report",
        payload: {
          managerId: manager.id,
          reason: reason ?? null,
          reassignedProjects: reassigned,
          cancelledDelegations: issued + received,
          cancelledReviews: reviews,
          disabledAutomations: automations,
        },
      });
      return {
        buddy: this.getBuddy(sub.id),
        reassignedProjects: reassigned,
        disabledAutomations: automations,
        cancelledDelegations: issued + received,
        cancelledReviews: reviews,
      };
    });
  }

  /**
   * §9.4 / §7.4. The workspace re-check is load-bearing: newProject guards owners
   * with #requireBuddy(buddy, ownerWorkspace), so handing the manager a project in a
   * workspace it is not in breaks that invariant silently and getBuddyContext then
   * throws "buddy does not belong to the workspace" every time it opens the project.
   * reassignOwnedProject re-checks it too; checking here as well is what turns a
   * mid-loop failure into an up-front refusal that names the workspace.
   * owned_projects has no slug column - name the project by title and id.
   */
  #resolveRetirementWork(manager, sub, reassignOpenWorkTo) {
    const open = this.listBuddyOwnedProjects({ buddy: sub.id });
    if (reassignOpenWorkTo === undefined || reassignOpenWorkTo === null) {
      if (open.length === 0) return { kind: "no_open_work" };
      throw new Error(
        `${sub.slug} still owns ${open.length} open project(s): ${open
          .map((project) => `${project.title} (${project.id})`)
          .join(", ")}; pass reassignOpenWorkTo to hand them to the manager`,
      );
    }
    const target = this.#requireBuddy(reassignOpenWorkTo);
    if (target.id !== manager.id) {
      throw new Error(
        `reassignOpenWorkTo must be the retiring manager ${manager.slug}, not ${target.slug}`,
      );
    }
    for (const project of open) {
      if (!this.#buddyHasProject(manager.id, project.workspace_id)) {
        throw new Error(
          `cannot reassign "${project.title}": ${manager.slug} is not a member of workspace ${project.workspace_slug}`,
        );
      }
    }
    return { kind: "reassign_to_manager", projects: open };
  }

  #projectPath(project, path) {
    return this.#containedPath(project.root_path, required("file path", path));
  }

  #containedPath(root, ...segments) {
    const target = resolve(root, ...segments);
    const fromRoot = relative(root, target);
    if (fromRoot === ".." || fromRoot.startsWith(`..${process.platform === "win32" ? "\\" : "/"}`) || isAbsolute(fromRoot)) {
      throw new Error("memory path escapes the Buddy memory root");
    }
    let probe = target;
    while (!existsSync(probe) && probe !== dirname(probe)) {
      probe = dirname(probe);
    }
    if (existsSync(root) && existsSync(probe)) {
      const realRoot = realpathSync(root);
      const realTarget = realpathSync(probe);
      const realRelative = relative(realRoot, realTarget);
      if (
        realRelative === ".." ||
        realRelative.startsWith(`..${process.platform === "win32" ? "\\" : "/"}`) ||
        isAbsolute(realRelative)
      ) {
        throw new Error("memory path escapes the Buddy memory root");
      }
    }
    return target;
  }

  #memoryRoot(buddy) {
    const homeWorkspace = this.#requireProject(buddy.project_id);
    return this.#projectPath(homeWorkspace, buddy.memory_path || `profiles/${buddy.slug}/memory`);
  }

  #insertTodo(projectId, input, timestamp = now()) {
    const status = input.status || "open";
    const completionEvidence = input.evidence ?? [];
    if (!Array.isArray(completionEvidence) || completionEvidence.length > 32 || completionEvidence.some(e => typeof e !== "string" || !e.trim() || e.length > 4000)) throw new Error("Invalid todo completion evidence");
    assertOneOf("todo status", status, BUDDY_TODO_STATUSES);
    if (status === "blocked" && !input.blockedReason?.trim()) {
      throw new Error("blocked reason is required when blocking a todo");
    }
    this.db
      .prepare(`
        INSERT INTO buddy_todos (
          id, buddy_project_id, title, status, position, definition_of_done,
          next_action, blocked_reason, created_at, updated_at, completed_at, completion_evidence
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `)
      .run(
        id("todo"),
        projectId,
        required("todo title", input.title),
        status,
        Number(input.position) || 0,
        input.definitionOfDone?.trim() || null,
        input.nextAction?.trim() || null,
        status === "blocked" ? input.blockedReason.trim() : null,
        timestamp,
        timestamp,
        ["done", "cancelled"].includes(status) ? timestamp : null,
        JSON.stringify(completionEvidence),
      );
  }

  #updateTodo(projectId, operation, timestamp) {
    const current = this.db
      .prepare("SELECT * FROM buddy_todos WHERE id = ? AND buddy_project_id = ?")
      .get(required("todo id", operation.todoId), projectId);
    if (!current) throw new Error("todo does not belong to the updated Buddy project");
    const criteriaChanged = operation.definitionOfDone !== undefined && (operation.definitionOfDone?.trim() || null) !== current.definition_of_done;
    const requestedStatus = operation.status ?? current.status;
    const status = criteriaChanged && requestedStatus === "done" && !operation.evidence?.length ? "open" : requestedStatus;
    const completionEvidence = operation.evidence ?? (criteriaChanged ? [] : JSON.parse(current.completion_evidence || "[]"));
    if (!Array.isArray(completionEvidence) || completionEvidence.length > 32 || completionEvidence.some(e => typeof e !== "string" || !e.trim() || e.length > 4000)) throw new Error("Invalid todo completion evidence");
    assertOneOf("todo status", status, BUDDY_TODO_STATUSES);
    const blocker =
      status === "blocked"
        ? operation.blockedReason?.trim() || current.blocked_reason
        : null;
    if (status === "blocked" && !blocker) {
      throw new Error("blocked reason is required when blocking a todo");
    }
    this.db
      .prepare(`
        UPDATE buddy_todos SET
          title = ?, status = ?, position = ?, definition_of_done = ?,
          next_action = ?, blocked_reason = ?, updated_at = ?, completed_at = ?, completion_evidence = ?
        WHERE id = ?
      `)
      .run(
        operation.title === undefined ? current.title : required("todo title", operation.title),
        status,
        operation.position === undefined
          ? current.position
          : Math.max(0, Number(operation.position) || 0),
        operation.definitionOfDone === undefined
          ? current.definition_of_done
          : operation.definitionOfDone?.trim() || null,
        operation.nextAction === undefined
          ? current.next_action
          : operation.nextAction?.trim() || null,
        blocker,
        timestamp,
        ["done", "cancelled"].includes(status)
          ? (criteriaChanged ? timestamp : current.completed_at || timestamp)
          : null,
        JSON.stringify(completionEvidence),
        current.id,
      );
  }

  #validateAutomationDefinition({
    scheduleKind,
    scheduleExpression,
    timezone,
    jobKind,
    jobPayload,
  }) {
    assertOneOf("schedule kind", scheduleKind, AUTOMATION_SCHEDULE_KINDS);
    assertOneOf("job kind", jobKind, AUTOMATION_JOB_KINDS);
    const expression = required("schedule expression", scheduleExpression);
    if (scheduleKind === "interval") {
      const interval = Number(expression);
      if (!Number.isFinite(interval) || interval <= 0) {
        throw new Error("interval schedule expression must be a positive number of seconds");
      }
    } else if (expression.trim().split(/\s+/).length !== 5) {
      throw new Error("cron schedule expression must contain five fields");
    }
    const zone = required("timezone", timezone);
    try {
      new Intl.DateTimeFormat("en", { timeZone: zone });
    } catch {
      throw new Error(`invalid timezone: ${zone}`);
    }
    if (!jobPayload || typeof jobPayload !== "object" || Array.isArray(jobPayload)) {
      throw new Error("job payload must be an object");
    }
    if (jobPayload.conversationId !== undefined && (jobKind!=="prompt" || typeof jobPayload.conversationId!=="string" || !jobPayload.conversationId.trim())) throw new Error("Thread schedules require a prompt job and conversationId");
    if (jobKind === "prompt") {
      required("job prompt", jobPayload.prompt);
    } else if (jobKind === "sequence") {
      if (!Array.isArray(jobPayload.prompts) || jobPayload.prompts.length === 0) {
        throw new Error("sequence job requires at least one prompt");
      }
      jobPayload.prompts.forEach((prompt) => required("sequence prompt", prompt));
    } else {
      required("loop prompt", jobPayload.prompt);
      required("loop termination condition", jobPayload.termination?.condition);
      const iterations = Number(jobPayload.termination?.max_iterations);
      const duration = Number(jobPayload.termination?.max_duration_seconds);
      if (!Number.isInteger(iterations) || iterations < 1) {
        throw new Error("loop max_iterations must be a positive integer");
      }
      if (!Number.isFinite(duration) || duration <= 0) {
        throw new Error("loop max_duration_seconds must be positive");
      }
    }
    return {
      scheduleKind,
      scheduleExpression: expression,
      timezone: zone,
      jobKind,
      jobPayload,
    };
  }

  #validateAutomationPolicy(policy, jobKind, jobPayload, current) {
    const plannedIterations =
      jobKind === "prompt"
        ? 1
        : jobKind === "sequence"
          ? jobPayload.prompts.length
          : jobPayload.termination.max_iterations;
    const source = policy || {};
    const fallback = current || {
      max_runtime_seconds: DEFAULT_AUTOMATION_MAX_RUNTIME_SECONDS,
      max_iterations: Math.min(DEFAULT_AUTOMATION_MAX_ITERATIONS, plannedIterations),
      max_tokens: DEFAULT_AUTOMATION_MAX_TOKENS,
      max_cost_usd: DEFAULT_AUTOMATION_MAX_COST_USD,
      allowed_operations: DEFAULT_AUTOMATION_ALLOWED_OPERATIONS,
    };
    const value = {
      max_runtime_seconds:
        source.maxRuntimeSeconds ?? source.max_runtime_seconds ?? fallback.max_runtime_seconds,
      max_iterations:
        source.maxIterations ?? source.max_iterations ?? fallback.max_iterations,
      max_tokens: source.maxTokens ?? source.max_tokens ?? fallback.max_tokens,
      max_cost_usd: source.maxCostUsd ?? source.max_cost_usd ?? fallback.max_cost_usd,
      allowed_operations:
        source.allowedOperations ?? source.allowed_operations ?? fallback.allowed_operations,
    };
    value.max_runtime_seconds = Number(value.max_runtime_seconds);
    value.max_iterations = Number(value.max_iterations);
    value.max_tokens = Number(value.max_tokens);
    value.max_cost_usd = Number(value.max_cost_usd);
    if (!Number.isInteger(value.max_runtime_seconds) || value.max_runtime_seconds < 1) {
      throw new Error("automation max runtime seconds must be a positive integer");
    }
    if (!Number.isInteger(value.max_iterations) || value.max_iterations < 1) {
      throw new Error("automation max iterations must be a positive integer");
    }
    if (!Number.isInteger(value.max_tokens) || value.max_tokens < 1) {
      throw new Error("automation max tokens must be a positive integer");
    }
    if (!Number.isFinite(value.max_cost_usd) || value.max_cost_usd <= 0) {
      throw new Error("automation max cost USD must be positive");
    }
    if (!Array.isArray(value.allowed_operations)) {
      throw new Error("automation allowed operations must be an array");
    }
    value.allowed_operations = [
      ...new Set(
        value.allowed_operations.map((operation) => {
          const name = required("automation allowed operation", operation);
          assertOneOf("automation allowed operation", name, AUTOMATION_ALLOWED_OPERATIONS);
          return name;
        }),
      ),
    ];
    return value;
  }

  #insertAutomationPolicy(automationId, policy, timestamp = now()) {
    this.db
      .prepare(`
        INSERT INTO buddy_automation_policies (
          automation_id, max_runtime_seconds, max_iterations, max_tokens,
          max_cost_usd, allowed_operations, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
      `)
      .run(
        automationId,
        policy.max_runtime_seconds,
        policy.max_iterations,
        policy.max_tokens,
        policy.max_cost_usd,
        JSON.stringify(policy.allowed_operations),
        timestamp,
        timestamp,
      );
  }

  #automationRow(row) {
    const policyRow = this.db
      .prepare("SELECT * FROM buddy_automation_policies WHERE automation_id = ?")
      .get(row.id);
    if (!policyRow) throw new Error(`automation policy not found: ${row.id}`);
    return {
      ...row,
      enabled: Boolean(row.enabled),
      job_payload:
        typeof row.job_payload === "string" ? JSON.parse(row.job_payload) : row.job_payload,
      policy: {
        max_runtime_seconds: policyRow.max_runtime_seconds,
        max_iterations: policyRow.max_iterations,
        max_tokens: policyRow.max_tokens,
        max_cost_usd: policyRow.max_cost_usd,
        allowed_operations: JSON.parse(policyRow.allowed_operations),
      },
    };
  }

  #automationRunRow(row) {
    const policyRow = this.db
      .prepare("SELECT * FROM buddy_automation_run_policies WHERE run_id = ?")
      .get(row.id);
    if (!policyRow) throw new Error(`automation run policy not found: ${row.id}`);
    return {
      ...row,
      tokens_used: policyRow.tokens_used,
      cost_usd: policyRow.cost_usd,
      policy: {
        max_runtime_seconds: policyRow.max_runtime_seconds,
        max_iterations: policyRow.max_iterations,
        max_tokens: policyRow.max_tokens,
        max_cost_usd: policyRow.max_cost_usd,
        allowed_operations: JSON.parse(policyRow.allowed_operations),
      },
    };
  }

  #requireProject(idOrSlug) {
    if (typeof idOrSlug === "object" && idOrSlug?.id) {
      return idOrSlug;
    }
    const project = this.getProject(required("project", idOrSlug));
    if (!project) throw new Error(`project not found: ${idOrSlug}`);
    return project;
  }

  #requireBuddy(idOrSlug, project) {
    if (typeof idOrSlug === "object" && idOrSlug?.id) {
      if (project && !this.#buddyHasProject(idOrSlug.id, project.id)) {
        throw new Error("buddy does not belong to the project");
      }
      return idOrSlug;
    }
    const lookup = required("buddy", idOrSlug);
    const buddy = this.getBuddy(lookup, project ? project.id : undefined);
    if (!buddy && project) {
      const buddyInAnotherProject = this.getBuddy(lookup);
      if (buddyInAnotherProject) {
        throw new Error("buddy does not belong to the project");
      }
    }
    if (!buddy) throw new Error(`buddy not found: ${idOrSlug}`);
    if (project && !this.#buddyHasProject(buddy.id, project.id)) {
      throw new Error("buddy does not belong to the project");
    }
    return buddy;
  }

  #buddyHasProject(buddyId, projectId) {
    return Boolean(
      this.db
        .prepare("SELECT 1 FROM buddy_projects WHERE buddy_id = ? AND project_id = ?")
        .get(buddyId, projectId),
    );
  }

  #requireSprint(id, project) {
    if (typeof id === "object" && id?.id) {
      if (project && id.project_id !== project.id) {
        throw new Error("sprint does not belong to the project");
      }
      return id;
    }
    const sprint = this.getSprint(required("sprint", id));
    if (!sprint) throw new Error(`sprint not found: ${id}`);
    if (project && sprint.project_id !== project.id) {
      throw new Error("sprint does not belong to the project");
    }
    return sprint;
  }

  #requireWorkItem(id, projectId) {
    const workItem =
      typeof id === "object" && id?.id
        ? id
        : this.getWorkItem(required("work item", id));
    if (!workItem) throw new Error(`work item not found: ${id}`);
    if (projectId && workItem.project_id !== projectId) {
      throw new Error("work item does not belong to the buddy's project");
    }
    return workItem;
  }

  #requireBuddyProject(project) {
    const ownedProject =
      typeof project === "object" && project?.id
        ? project
        : this.db
            .prepare("SELECT * FROM owned_projects WHERE id = ?")
            .get(required("Buddy project", project));
    if (!ownedProject) throw new Error(`Buddy project not found: ${project}`);
    return ownedProject;
  }

  #requireAutomation(automation) {
    const value = this.getAutomation(automation);
    if (!value) throw new Error(`automation not found: ${automation}`);
    return value;
  }

  #requireAutomationRun(run) {
    const value = this.getAutomationRun(run);
    if (!value) throw new Error(`automation run not found: ${run}`);
    return value;
  }
}
