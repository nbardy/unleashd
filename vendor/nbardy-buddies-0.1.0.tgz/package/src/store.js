import {
  appendFileSync,
  existsSync,
  mkdirSync,
  readFileSync,
  readdirSync,
  realpathSync,
  renameSync,
  rmSync,
  statSync,
  writeFileSync,
} from "node:fs";
import { homedir } from "node:os";
import { dirname, isAbsolute, join, relative, resolve } from "node:path";
import { createHash, randomUUID } from "node:crypto";
import { DatabaseSync } from "node:sqlite";

export const BUDDY_STATUSES = ["active", "paused", "archived"];
export const SPRINT_STATUSES = ["planned", "active", "completed", "cancelled"];
export const WORK_ITEM_STATUSES = [
  "backlog",
  "ready",
  "in_progress",
  "blocked",
  "review",
  "done",
  "cancelled",
];
export const CONVERSATION_STATUSES = ["active", "complete", "failed", "cancelled"];
export const BUDDY_PROJECT_STATUSES = [...WORK_ITEM_STATUSES];
export const BUDDY_TODO_STATUSES = [
  "open",
  "in_progress",
  "blocked",
  "done",
  "cancelled",
];
export const AUTOMATION_SCHEDULE_KINDS = ["cron", "interval"];
export const AUTOMATION_JOB_KINDS = ["prompt", "sequence", "loop"];
export const AUTOMATION_RUN_STATUSES = [
  "claimed",
  "running",
  "cancel_requested",
  "complete",
  "failed",
  "cancelled",
];
export const BUDDY_RELATIONSHIP_KINDS = [
  "manager",
  "reports_to",
  "consults",
  "reviews",
];
// design §8.3. `manager A->B` and `reports_to B->A` are inverse encodings of ONE
// edge. When both are stored, overview() derives the pairs {A:B} AND {B:A}, so
// BOTH buddies drop out of `topLevel` permanently with no UI signal. This table
// is the single normalization point: `reports_to` survives as input vocabulary
// only and no `reports_to` row is ever written again. Keys mirror
// BUDDY_RELATIONSHIP_KINDS; assertOneOf runs first, so a missing key is
// unreachable rather than a silent fallback.
const CANONICAL_RELATIONSHIP = {
  manager: (from, to) => ({ from, to, kind: "manager" }),
  reports_to: (from, to) => ({ from: to, to: from, kind: "manager" }),
  consults: (from, to) => ({ from, to, kind: "consults" }),
  reviews: (from, to) => ({ from, to, kind: "reviews" }),
};

// design §5.2. Directory membership is a SUM, not a null check. Frozen and
// shared: a consumer that tries to bolt `managerId` onto a top-level employee
// throws instead of silently inventing a manager.
const TOP_LEVEL_EMPLOYMENT = Object.freeze({ kind: "top_level" });

export const BUDDY_SKILL_MODES = ["always", "on_demand"];
export const DELEGATION_STATUSES = ["pending", "active", "complete", "failed", "cancelled"];
export const REVIEW_STATUSES = ["draft", "complete", "cancelled"];
export const REVIEW_VERDICTS = ["needs_work", "pass", "fail"];
export const APPROVAL_STATUSES = ["pending", "approved", "rejected"];
export const AUTOMATION_ALLOWED_OPERATIONS = [
  "buddy.get_current_work",
  "buddy.get_inbox",
  "buddy.get_automations",
  "buddy.set_automation",
  "buddy.new_project",
  "buddy.update_project",
  "buddy.remember",
  "buddy.compact_memory",
  "buddy.delegate",
  "buddy.request_review",
  "buddy.complete_delegation",
  "buddy.complete_assignment",
  "buddy.submit_review",
  "buddy.request_human_approval",
];

const CURRENT_SCHEMA_VERSION = 15;
const DEFAULT_AUTOMATION_MAX_RUNTIME_SECONDS = 600;
const DEFAULT_AUTOMATION_MAX_ITERATIONS = 10;
const DEFAULT_AUTOMATION_MAX_TOKENS = 50_000;
const DEFAULT_AUTOMATION_MAX_COST_USD = 2;
const DEFAULT_AUTOMATION_ALLOWED_OPERATIONS = ["buddy.get_current_work"];

// Direct reports (§8.4). slugify() can return "", and `profiles/${""}/BUDDY_SOUL.md`
// normalises to `<workspace>/profiles/BUDDY_SOUL.md`, so an unchecked slug turns the
// post-commit rename into a rename of the profiles/ directory itself.
const DIRECT_REPORT_SLUG_RE = /^[a-z0-9][a-z0-9-]{0,62}$/;
const MAX_DIRECT_REPORT_SOUL_BYTES = 32_000;
const STAGING_GC_MIN_AGE_MS = 60 * 60 * 1000;
// §9.3. The soul-file state sum maps to the staged-profile action sum through a
// table, so neither #repairProfile nor the promote/discard dispatch branches on
// "what did we find on disk?".
const PROFILE_ACTION_BY_SOUL_STATE = {
  absent: { kind: "promote" },
  materialized: { kind: "discard" },
};

export function defaultDatabasePath() {
  const buddiesHome =
    process.env.BUDDIES_HOME?.trim() || join(homedir(), ".buddies");
  return join(resolve(buddiesHome), "buddies.sqlite");
}

function now() {
  return new Date().toISOString();
}

function id(prefix) {
  return `${prefix}_${randomUUID()}`;
}

function assertOneOf(label, value, allowed) {
  if (!allowed.includes(value)) {
    throw new Error(`${label} must be one of: ${allowed.join(", ")}`);
  }
}

function required(label, value) {
  if (typeof value !== "string" || value.trim() === "") {
    throw new Error(`${label} is required`);
  }
  return value.trim();
}

function requireNonNegativeInteger(label, value) {
  if (!Number.isInteger(value) || value < 0) {
    throw new Error(`${label} must be a non-negative integer`);
  }
  return value;
}

function slugify(value) {
  return required("name", value)
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "");
}

function rows(statement, ...params) {
  return statement.all(...params).map((row) => ({ ...row }));
}

export class BuddiesStore {
  /** Depth for #tx: 0 opens a real transaction, deeper opens a SAVEPOINT. */
  #txDepth = 0;

  constructor(databasePath = defaultDatabasePath()) {
    this.databasePath = databasePath === ":memory:" ? databasePath : resolve(databasePath);
    if (this.databasePath !== ":memory:") {
      mkdirSync(dirname(this.databasePath), { recursive: true });
    }
    this.db = new DatabaseSync(this.databasePath);
    // B5: busy_timeout FIRST, and for every database. SQLite's default is 0, so
    // under WAL the second concurrent writer gets SQLITE_BUSY immediately - and
    // `PRAGMA journal_mode = WAL` itself takes an exclusive lock, so setting the
    // timeout after it means a concurrent open can throw "database is locked"
    // before the timeout it needs has been set.
    this.db.exec("PRAGMA busy_timeout = 5000");
    this.db.exec("PRAGMA foreign_keys = ON");
    if (this.databasePath !== ":memory:") {
      this.db.exec("PRAGMA journal_mode = WAL");
    }
    // §9.3(2): must exist before #gcStagedProfiles runs.
    this.stagingGcErrors = [];
    this.#migrate();
    this.#gcStagedProfiles();
  }

  close() {
    this.db.close();
  }

  backupDatabase(destination) {
    if (this.databasePath === ":memory:") {
      throw new Error("in-memory Buddy databases cannot be backed up");
    }
    const target = resolve(required("backup destination", destination));
    if (existsSync(target)) throw new Error(`backup destination already exists: ${target}`);
    mkdirSync(dirname(target), { recursive: true });
    this.db.prepare("VACUUM INTO ?").run(target);
    return {
      database: this.databasePath,
      backup: target,
      schemaVersion: this.db.prepare("PRAGMA user_version").get().user_version,
      createdAt: now(),
    };
  }

  #migrate() {
    let version = this.db.prepare("PRAGMA user_version").get().user_version;
    if (version > CURRENT_SCHEMA_VERSION) {
      throw new Error(
        `Database schema ${version} is newer than this Buddies version (${CURRENT_SCHEMA_VERSION})`,
      );
    }
    if (version === 0) {
      this.db.exec(`
        BEGIN;

        CREATE TABLE projects (
          id TEXT PRIMARY KEY,
          slug TEXT NOT NULL UNIQUE,
          name TEXT NOT NULL,
          root_path TEXT NOT NULL UNIQUE,
          created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL
        ) STRICT;

        CREATE TABLE buddies (
          id TEXT PRIMARY KEY,
          project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
          slug TEXT NOT NULL,
          name TEXT NOT NULL,
          role TEXT NOT NULL,
          status TEXT NOT NULL CHECK (status IN ('active', 'paused', 'archived')),
          soul_path TEXT,
          memory_path TEXT,
          provider TEXT,
          model TEXT,
          reasoning_effort TEXT,
          created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL,
          UNIQUE(project_id, slug)
        ) STRICT;

        CREATE TABLE buddy_projects (
          buddy_id TEXT NOT NULL REFERENCES buddies(id) ON DELETE CASCADE,
          project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
          assignment_role TEXT,
          created_at TEXT NOT NULL,
          PRIMARY KEY (buddy_id, project_id)
        ) STRICT;

        CREATE TABLE sprints (
          id TEXT PRIMARY KEY,
          project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
          name TEXT NOT NULL,
          goal TEXT,
          status TEXT NOT NULL CHECK (status IN ('planned', 'active', 'completed', 'cancelled')),
          starts_at TEXT,
          ends_at TEXT,
          created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL
        ) STRICT;

        CREATE UNIQUE INDEX one_active_sprint_per_project
          ON sprints(project_id) WHERE status = 'active';

        CREATE TABLE work_items (
          id TEXT PRIMARY KEY,
          project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
          sprint_id TEXT REFERENCES sprints(id) ON DELETE SET NULL,
          buddy_id TEXT REFERENCES buddies(id) ON DELETE SET NULL,
          title TEXT NOT NULL,
          kind TEXT NOT NULL DEFAULT 'task',
          external_key TEXT,
          source_path TEXT,
          objective TEXT,
          definition_of_done TEXT NOT NULL,
          status TEXT NOT NULL CHECK (
            status IN ('backlog', 'ready', 'in_progress', 'blocked', 'review', 'done', 'cancelled')
          ),
          priority INTEGER NOT NULL DEFAULT 0,
          next_action TEXT,
          blocked_reason TEXT,
          created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL,
          completed_at TEXT
        ) STRICT;

        CREATE UNIQUE INDEX work_items_by_external_key
          ON work_items(project_id, external_key)
          WHERE external_key IS NOT NULL;

        CREATE INDEX work_items_by_project_status
          ON work_items(project_id, status, priority DESC, created_at);
        CREATE INDEX work_items_by_buddy_status
          ON work_items(buddy_id, status, priority DESC, created_at);

        CREATE TABLE conversation_links (
          id TEXT PRIMARY KEY,
          buddy_id TEXT NOT NULL REFERENCES buddies(id) ON DELETE CASCADE,
          work_item_id TEXT REFERENCES work_items(id) ON DELETE SET NULL,
          provider TEXT NOT NULL,
          provider_session_id TEXT,
          unleashd_conversation_id TEXT,
          status TEXT NOT NULL CHECK (status IN ('active', 'complete', 'failed', 'cancelled')),
          started_at TEXT NOT NULL,
          last_active_at TEXT NOT NULL,
          ended_at TEXT,
          CHECK (provider_session_id IS NOT NULL OR unleashd_conversation_id IS NOT NULL)
        ) STRICT;

        CREATE UNIQUE INDEX conversation_links_by_unleashd_id
          ON conversation_links(unleashd_conversation_id)
          WHERE unleashd_conversation_id IS NOT NULL;

        PRAGMA user_version = 3;
        COMMIT;
      `);
      version = 3;
    }
    if (version === 1) {
      this.db.exec(`
        BEGIN;
        CREATE TABLE buddy_projects (
          buddy_id TEXT NOT NULL REFERENCES buddies(id) ON DELETE CASCADE,
          project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
          assignment_role TEXT,
          created_at TEXT NOT NULL,
          PRIMARY KEY (buddy_id, project_id)
        ) STRICT;
        INSERT INTO buddy_projects (buddy_id, project_id, assignment_role, created_at)
          SELECT id, project_id, role, created_at FROM buddies;
        PRAGMA user_version = 2;
        COMMIT;
      `);
      version = 2;
    }
    if (version === 2) {
      this.db.exec(`
        BEGIN;
        ALTER TABLE work_items ADD COLUMN kind TEXT NOT NULL DEFAULT 'task';
        ALTER TABLE work_items ADD COLUMN external_key TEXT;
        ALTER TABLE work_items ADD COLUMN source_path TEXT;
        CREATE UNIQUE INDEX work_items_by_external_key
          ON work_items(project_id, external_key)
          WHERE external_key IS NOT NULL;
        PRAGMA user_version = 3;
        COMMIT;
      `);
      version = 3;
    }
    if (version === 3) {
      this.db.exec(`
        BEGIN;

        CREATE TABLE owned_projects (
          id TEXT PRIMARY KEY,
          workspace_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
          buddy_id TEXT NOT NULL REFERENCES buddies(id) ON DELETE CASCADE,
          sprint_id TEXT REFERENCES sprints(id) ON DELETE SET NULL,
          title TEXT NOT NULL,
          objective TEXT,
          definition_of_done TEXT NOT NULL,
          status TEXT NOT NULL CHECK (
            status IN ('backlog', 'ready', 'in_progress', 'blocked', 'review', 'done', 'cancelled')
          ),
          priority INTEGER NOT NULL DEFAULT 0,
          next_action TEXT,
          blocked_reason TEXT,
          source_path TEXT,
          external_key TEXT,
          created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL,
          completed_at TEXT
        ) STRICT;

        CREATE UNIQUE INDEX owned_projects_by_external_key
          ON owned_projects(workspace_id, external_key)
          WHERE external_key IS NOT NULL;
        CREATE INDEX owned_projects_by_buddy_status
          ON owned_projects(buddy_id, status, priority DESC, created_at);

        CREATE TABLE buddy_todos (
          id TEXT PRIMARY KEY,
          buddy_project_id TEXT NOT NULL REFERENCES owned_projects(id) ON DELETE CASCADE,
          title TEXT NOT NULL,
          status TEXT NOT NULL CHECK (
            status IN ('open', 'in_progress', 'blocked', 'done', 'cancelled')
          ),
          position INTEGER NOT NULL,
          definition_of_done TEXT,
          next_action TEXT,
          blocked_reason TEXT,
          created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL,
          completed_at TEXT
        ) STRICT;
        CREATE INDEX buddy_todos_by_project_position
          ON buddy_todos(buddy_project_id, position, created_at);

        CREATE TABLE buddy_automations (
          id TEXT PRIMARY KEY,
          buddy_id TEXT NOT NULL REFERENCES buddies(id) ON DELETE CASCADE,
          workspace_id TEXT REFERENCES projects(id) ON DELETE CASCADE,
          buddy_project_id TEXT REFERENCES owned_projects(id) ON DELETE CASCADE,
          name TEXT NOT NULL,
          schedule_kind TEXT NOT NULL CHECK (schedule_kind IN ('cron', 'interval')),
          schedule_expression TEXT NOT NULL,
          timezone TEXT NOT NULL,
          job_kind TEXT NOT NULL CHECK (job_kind IN ('prompt', 'sequence', 'loop')),
          job_payload TEXT NOT NULL,
          enabled INTEGER NOT NULL DEFAULT 1 CHECK (enabled IN (0, 1)),
          next_run_at TEXT,
          last_run_at TEXT,
          created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL
        ) STRICT;
        CREATE INDEX buddy_automations_due
          ON buddy_automations(enabled, next_run_at);

        CREATE TABLE buddy_automation_runs (
          id TEXT PRIMARY KEY,
          automation_id TEXT NOT NULL REFERENCES buddy_automations(id) ON DELETE CASCADE,
          scheduled_for TEXT NOT NULL,
          idempotency_key TEXT NOT NULL UNIQUE,
          status TEXT NOT NULL CHECK (
            status IN ('claimed', 'running', 'complete', 'failed', 'cancelled')
          ),
          conversation_id TEXT,
          iteration INTEGER NOT NULL DEFAULT 0,
          outcome TEXT,
          error TEXT,
          claimed_at TEXT NOT NULL,
          started_at TEXT,
          ended_at TEXT
        ) STRICT;
        CREATE INDEX buddy_automation_runs_by_automation
          ON buddy_automation_runs(automation_id, claimed_at DESC);

        ALTER TABLE conversation_links
          ADD COLUMN buddy_project_id TEXT REFERENCES owned_projects(id) ON DELETE SET NULL;

        PRAGMA user_version = 4;
        COMMIT;
      `);
      version = 4;
    }
    if (version === 4) {
      this.db.exec(`
        BEGIN;

        ALTER TABLE conversation_links
          ADD COLUMN workspace_id TEXT REFERENCES projects(id) ON DELETE CASCADE;
        UPDATE conversation_links
        SET workspace_id = COALESCE(
          (SELECT workspace_id FROM owned_projects
            WHERE owned_projects.id = conversation_links.buddy_project_id),
          (SELECT project_id FROM work_items
            WHERE work_items.id = conversation_links.work_item_id),
          (SELECT project_id FROM buddies
            WHERE buddies.id = conversation_links.buddy_id)
        );

        CREATE TABLE buddy_relationships (
          id TEXT PRIMARY KEY,
          from_buddy_id TEXT NOT NULL REFERENCES buddies(id) ON DELETE CASCADE,
          to_buddy_id TEXT NOT NULL REFERENCES buddies(id) ON DELETE CASCADE,
          kind TEXT NOT NULL CHECK (
            kind IN ('manager', 'reports_to', 'consults', 'reviews')
          ),
          created_at TEXT NOT NULL,
          UNIQUE(from_buddy_id, to_buddy_id, kind),
          CHECK(from_buddy_id != to_buddy_id)
        ) STRICT;

        CREATE TABLE buddy_skills (
          id TEXT PRIMARY KEY,
          buddy_id TEXT NOT NULL REFERENCES buddies(id) ON DELETE CASCADE,
          name TEXT NOT NULL,
          instruction_path TEXT NOT NULL,
          mode TEXT NOT NULL CHECK (mode IN ('always', 'on_demand')),
          created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL,
          UNIQUE(buddy_id, name)
        ) STRICT;

        CREATE TABLE buddy_delegations (
          id TEXT PRIMARY KEY,
          from_buddy_id TEXT NOT NULL REFERENCES buddies(id) ON DELETE CASCADE,
          to_buddy_id TEXT NOT NULL REFERENCES buddies(id) ON DELETE CASCADE,
          workspace_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
          buddy_project_id TEXT REFERENCES owned_projects(id) ON DELETE SET NULL,
          purpose TEXT NOT NULL,
          parent_conversation_id TEXT,
          child_conversation_id TEXT,
          status TEXT NOT NULL CHECK (
            status IN ('pending', 'active', 'complete', 'failed', 'cancelled')
          ),
          outcome TEXT,
          created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL,
          completed_at TEXT,
          CHECK(from_buddy_id != to_buddy_id)
        ) STRICT;

        CREATE TABLE buddy_reviews (
          id TEXT PRIMARY KEY,
          reviewer_buddy_id TEXT NOT NULL REFERENCES buddies(id) ON DELETE CASCADE,
          subject_buddy_id TEXT NOT NULL REFERENCES buddies(id) ON DELETE CASCADE,
          workspace_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
          buddy_project_id TEXT REFERENCES owned_projects(id) ON DELETE SET NULL,
          conversation_id TEXT,
          status TEXT NOT NULL CHECK (status IN ('draft', 'complete', 'cancelled')),
          verdict TEXT CHECK (verdict IN ('needs_work', 'pass', 'fail')),
          score REAL,
          summary TEXT,
          evidence TEXT NOT NULL DEFAULT '[]',
          created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL,
          completed_at TEXT
        ) STRICT;

        PRAGMA user_version = 5;
        COMMIT;
      `);
      version = 5;
    }
    if (version === 5) {
      this.db.exec(`
        BEGIN;

        UPDATE conversation_links
        SET workspace_id = (
          SELECT project_id FROM buddies
          WHERE buddies.id = conversation_links.buddy_id
        )
        WHERE workspace_id IS NULL;

        UPDATE buddy_automations
        SET workspace_id = (
          SELECT project_id FROM buddies
          WHERE buddies.id = buddy_automations.buddy_id
        )
        WHERE workspace_id IS NULL;

        CREATE TRIGGER conversation_links_workspace_required_insert
        BEFORE INSERT ON conversation_links
        WHEN NEW.workspace_id IS NULL
        BEGIN
          SELECT RAISE(ABORT, 'conversation workspace is required');
        END;

        CREATE TRIGGER conversation_links_workspace_required_update
        BEFORE UPDATE OF workspace_id ON conversation_links
        WHEN NEW.workspace_id IS NULL
        BEGIN
          SELECT RAISE(ABORT, 'conversation workspace is required');
        END;

        CREATE TRIGGER buddy_automations_workspace_required_insert
        BEFORE INSERT ON buddy_automations
        WHEN NEW.workspace_id IS NULL
        BEGIN
          SELECT RAISE(ABORT, 'automation workspace is required');
        END;

        CREATE TRIGGER buddy_automations_workspace_required_update
        BEFORE UPDATE OF workspace_id ON buddy_automations
        WHEN NEW.workspace_id IS NULL
        BEGIN
          SELECT RAISE(ABORT, 'automation workspace is required');
        END;

        PRAGMA user_version = 6;
        COMMIT;
      `);
      version = 6;
    }
    if (version === 6) {
      this.db.exec(`
        BEGIN;

        CREATE TABLE buddy_audit_events (
          id TEXT PRIMARY KEY,
          buddy_id TEXT NOT NULL REFERENCES buddies(id) ON DELETE CASCADE,
          workspace_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
          buddy_project_id TEXT REFERENCES owned_projects(id) ON DELETE SET NULL,
          operation TEXT NOT NULL,
          payload TEXT NOT NULL,
          created_at TEXT NOT NULL
        ) STRICT;
        CREATE INDEX buddy_audit_events_by_buddy
          ON buddy_audit_events(buddy_id, created_at DESC);
        CREATE INDEX buddy_audit_events_by_project
          ON buddy_audit_events(buddy_project_id, created_at DESC);

        PRAGMA user_version = 7;
        COMMIT;
      `);
      version = 7;
    }
    if (version === 7) {
      this.db.exec(`
        BEGIN;

        CREATE TABLE buddy_automation_policies (
          automation_id TEXT PRIMARY KEY
            REFERENCES buddy_automations(id) ON DELETE CASCADE,
          max_runtime_seconds INTEGER NOT NULL CHECK (max_runtime_seconds > 0),
          max_iterations INTEGER NOT NULL CHECK (max_iterations > 0),
          max_tokens INTEGER NOT NULL CHECK (max_tokens > 0),
          max_cost_usd REAL NOT NULL CHECK (max_cost_usd > 0),
          allowed_operations TEXT NOT NULL CHECK (
            json_valid(allowed_operations) AND json_type(allowed_operations) = 'array'
          ),
          created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL
        ) STRICT;

        INSERT INTO buddy_automation_policies (
          automation_id, max_runtime_seconds, max_iterations, max_tokens,
          max_cost_usd, allowed_operations, created_at, updated_at
        )
        SELECT
          id,
          600,
          CASE job_kind
            WHEN 'prompt' THEN 1
            WHEN 'sequence' THEN
              MIN(10, MAX(1, json_array_length(json_extract(job_payload, '$.prompts'))))
            WHEN 'loop' THEN
              MIN(10, MAX(1, CAST(json_extract(job_payload, '$.termination.max_iterations') AS INTEGER)))
          END,
          50000,
          2.0,
          '["buddy.get_current_work"]',
          created_at,
          updated_at
        FROM buddy_automations;

        CREATE TABLE buddy_automation_run_policies (
          run_id TEXT PRIMARY KEY
            REFERENCES buddy_automation_runs(id) ON DELETE CASCADE,
          max_runtime_seconds INTEGER NOT NULL CHECK (max_runtime_seconds > 0),
          max_iterations INTEGER NOT NULL CHECK (max_iterations > 0),
          max_tokens INTEGER NOT NULL CHECK (max_tokens > 0),
          max_cost_usd REAL NOT NULL CHECK (max_cost_usd > 0),
          allowed_operations TEXT NOT NULL CHECK (
            json_valid(allowed_operations) AND json_type(allowed_operations) = 'array'
          ),
          tokens_used INTEGER NOT NULL DEFAULT 0 CHECK (tokens_used >= 0),
          cost_usd REAL NOT NULL DEFAULT 0 CHECK (cost_usd >= 0)
        ) STRICT;

        INSERT INTO buddy_automation_run_policies (
          run_id, max_runtime_seconds, max_iterations, max_tokens,
          max_cost_usd, allowed_operations, tokens_used, cost_usd
        )
        SELECT
          runs.id, policies.max_runtime_seconds, policies.max_iterations,
          policies.max_tokens, policies.max_cost_usd, policies.allowed_operations,
          0, 0
        FROM buddy_automation_runs AS runs
        JOIN buddy_automation_policies AS policies
          ON policies.automation_id = runs.automation_id;

        CREATE TABLE buddy_approval_requests (
          id TEXT PRIMARY KEY,
          buddy_id TEXT NOT NULL REFERENCES buddies(id) ON DELETE CASCADE,
          workspace_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
          buddy_project_id TEXT REFERENCES owned_projects(id) ON DELETE SET NULL,
          automation_run_id TEXT REFERENCES buddy_automation_runs(id) ON DELETE SET NULL,
          conversation_id TEXT,
          action TEXT NOT NULL,
          reason TEXT NOT NULL,
          risk TEXT NOT NULL,
          status TEXT NOT NULL CHECK (status IN ('pending', 'approved', 'rejected')),
          resolved_by TEXT,
          resolution_note TEXT,
          requested_at TEXT NOT NULL,
          resolved_at TEXT,
          CHECK (
            (status = 'pending' AND resolved_by IS NULL AND resolved_at IS NULL)
            OR
            (status IN ('approved', 'rejected') AND resolved_by IS NOT NULL AND resolved_at IS NOT NULL)
          )
        ) STRICT;
        CREATE INDEX buddy_approval_requests_by_buddy
          ON buddy_approval_requests(buddy_id, status, requested_at DESC);
        CREATE INDEX buddy_approval_requests_by_workspace
          ON buddy_approval_requests(workspace_id, status, requested_at DESC);

        PRAGMA user_version = 8;
        COMMIT;
      `);
      version = 8;
    }
    if (version === 8) {
      const runColumns = new Set(
        rows(this.db.prepare("PRAGMA table_info(buddy_automation_runs)")).map(
          (column) => column.name,
        ),
      );
      this.db.exec("BEGIN");
      try {
        if (!runColumns.has("claim_token")) {
          this.db.exec("ALTER TABLE buddy_automation_runs ADD COLUMN claim_token TEXT");
        }
        if (!runColumns.has("claim_expires_at")) {
          this.db.exec(
            "ALTER TABLE buddy_automation_runs ADD COLUMN claim_expires_at TEXT",
          );
        }
        this.db.exec(`
          CREATE INDEX IF NOT EXISTS buddy_automation_runs_by_claim_expiry
            ON buddy_automation_runs(status, claim_expires_at);
          PRAGMA user_version = 9;
          COMMIT;
        `);
      } catch (error) {
        this.db.exec("ROLLBACK");
        throw error;
      }
      version = 9;
    }
    if (version === 9) {
      const delegationColumns = new Set(
        rows(this.db.prepare("PRAGMA table_info(buddy_delegations)")).map(
          (column) => column.name,
        ),
      );
      this.db.exec("BEGIN");
      try {
        if (!delegationColumns.has("dispatch_token")) {
          this.db.exec("ALTER TABLE buddy_delegations ADD COLUMN dispatch_token TEXT");
        }
        if (!delegationColumns.has("dispatch_expires_at")) {
          this.db.exec(
            "ALTER TABLE buddy_delegations ADD COLUMN dispatch_expires_at TEXT",
          );
        }
        this.db.exec(`
          CREATE INDEX IF NOT EXISTS buddy_delegations_by_dispatch_expiry
            ON buddy_delegations(status, dispatch_expires_at);
          PRAGMA user_version = 10;
          COMMIT;
        `);
      } catch (error) {
        this.db.exec("ROLLBACK");
        throw error;
      }
      version = 10;
    }
    if (version === 10) {
      this.db.exec(`
        BEGIN;

        CREATE TABLE IF NOT EXISTS buddy_builder_creations (
          conversation_id TEXT PRIMARY KEY,
          buddy_id TEXT NOT NULL UNIQUE REFERENCES buddies(id) ON DELETE CASCADE,
          workspace_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
          request_fingerprint TEXT NOT NULL,
          created_at TEXT NOT NULL
        ) STRICT;

        PRAGMA user_version = 11;
        COMMIT;
      `);
      version = 11;
    }
    if (version === 11) {
      // Historical. v12 shipped `hire_quota` nullable and without the one-manager
      // indexes; it is kept verbatim so a database already at 12 and a database
      // replaying the ladder converge on the same physical schema. v13 below is
      // where the column is corrected. The PRAGMA table_info guard follows the
      // v9/v10 precedent and is load-bearing: test/v1.test.js resets user_version
      // to 5 on a physically newer database, so the ladder re-runs over a table
      // that already has the column.
      const buddyColumns = new Set(
        rows(this.db.prepare("PRAGMA table_info(buddies)")).map(
          (column) => column.name,
        ),
      );
      this.db.exec("BEGIN");
      try {
        if (!buddyColumns.has("hire_quota")) {
          this.db.exec(
            "ALTER TABLE buddies ADD COLUMN hire_quota INTEGER CHECK (hire_quota IS NULL OR hire_quota >= 0)",
          );
        }
        this.db.exec(`
          PRAGMA user_version = 12;
          COMMIT;
        `);
      } catch (error) {
        this.db.exec("ROLLBACK");
        throw error;
      }
      version = 12;
    }
    if (version === 12) {
      // §6, landed as v13 rather than v12 because commit fc7751a already consumed
      // 12 with the WRONG physical schema and shipped it (databases in the field,
      // including ~/.buddies/buddies.sqlite, sit at user_version 12 with a nullable
      // hire_quota and no indexes). A rewritten `version === 11` block would never
      // be re-entered on those, leaving a store that reports a schema it does not
      // have - exactly the silent fallback T4 forbids. One rung, one path, for
      // fresh and already-12 databases alike.
      //
      // SQLite cannot add NOT NULL to an existing column, hence RENAME/ADD/COPY/DROP.
      const buddyColumns = new Set(
        rows(this.db.prepare("PRAGMA table_info(buddies)")).map(
          (column) => column.name,
        ),
      );
      if (!buddyColumns.has("hire_quota")) {
        throw new Error(
          "schema 12 is missing buddies.hire_quota; refusing to migrate an inconsistent database",
        );
      }
      this.db.exec("BEGIN");
      try {
        this.db.exec("ALTER TABLE buddies RENAME COLUMN hire_quota TO hire_quota_v12");
        this.db.exec(
          "ALTER TABLE buddies ADD COLUMN hire_quota INTEGER NOT NULL DEFAULT 0 CHECK (hire_quota >= 0)",
        );
        this.db.exec("UPDATE buddies SET hire_quota = COALESCE(hire_quota_v12, 0)");
        this.db.exec("ALTER TABLE buddies DROP COLUMN hire_quota_v12");
        // Order matters: normalize the dual encoding first so the collapse sees
        // one edge per relationship, then collapse, then create the indexes -
        // they are a constraint and fail outright on data that violates them.
        this.#normalizeReportsToEdges();
        this.#collapseDuplicateManagerEdges();
        this.db.exec(`
          CREATE UNIQUE INDEX IF NOT EXISTS buddy_one_manager_fwd
            ON buddy_relationships(to_buddy_id) WHERE kind = 'manager';
          CREATE UNIQUE INDEX IF NOT EXISTS buddy_one_manager_rev
            ON buddy_relationships(from_buddy_id) WHERE kind = 'reports_to';
          PRAGMA user_version = 13;
          COMMIT;
        `);
      } catch (error) {
        this.db.exec("ROLLBACK");
        throw error;
      }
      version = 13;
    }
    if (version === 13) {
      // Explicit archival replaces the old enabled=0,next_run_at=NULL sentinel.
      // The backfill preserves the behavior of databases which already used
      // deleteAutomation as archive. See
      // agent_notes/2026-08-24_automation-execution-ownership-design.md I9 in
      // the Unleashd repository.
      const automationColumns = new Set(
        rows(this.db.prepare("PRAGMA table_info(buddy_automations)")).map(
          (column) => column.name,
        ),
      );
      this.db.exec("BEGIN");
      try {
        if (!automationColumns.has("archived_at")) {
          this.db.exec("ALTER TABLE buddy_automations ADD COLUMN archived_at TEXT");
        }
        this.db.exec(`
          UPDATE buddy_automations
          SET archived_at = COALESCE(archived_at, updated_at)
          WHERE enabled = 0 AND next_run_at IS NULL;
          PRAGMA user_version = 14;
          COMMIT;
        `);
      } catch (error) {
        this.db.exec("ROLLBACK");
        throw error;
      }
      version = 14;
    }
    if (version === 14) {
      // SQLite bakes the run-state vocabulary into the table CHECK, so adding
      // durable cancellation is a table migration rather than a TypeScript-only
      // enum edit. `cancel_requested` deliberately remains nonterminal: it keeps
      // the single-run lease occupied while immediately revoking operation
      // authority. See the Unleashd repository's
      // agent_notes/2026-08-24_automation-execution-ownership-design.md.
      this.db.exec("PRAGMA foreign_keys = OFF");
      this.db.exec("BEGIN");
      try {
        this.db.exec(`
          CREATE TABLE buddy_automation_runs_v15 (
            id TEXT PRIMARY KEY,
            automation_id TEXT NOT NULL REFERENCES buddy_automations(id) ON DELETE CASCADE,
            scheduled_for TEXT NOT NULL,
            idempotency_key TEXT NOT NULL UNIQUE,
            status TEXT NOT NULL CHECK (
              status IN (
                'claimed', 'running', 'cancel_requested',
                'complete', 'failed', 'cancelled'
              )
            ),
            conversation_id TEXT,
            iteration INTEGER NOT NULL DEFAULT 0,
            outcome TEXT,
            error TEXT,
            claimed_at TEXT NOT NULL,
            started_at TEXT,
            ended_at TEXT,
            claim_token TEXT,
            claim_expires_at TEXT
          ) STRICT;
          INSERT INTO buddy_automation_runs_v15 (
            id, automation_id, scheduled_for, idempotency_key, status,
            conversation_id, iteration, outcome, error, claimed_at,
            started_at, ended_at, claim_token, claim_expires_at
          )
          SELECT
            id, automation_id, scheduled_for, idempotency_key, status,
            conversation_id, iteration, outcome, error, claimed_at,
            started_at, ended_at, claim_token, claim_expires_at
          FROM buddy_automation_runs;
          DROP TABLE buddy_automation_runs;
          ALTER TABLE buddy_automation_runs_v15 RENAME TO buddy_automation_runs;
          CREATE INDEX buddy_automation_runs_by_automation
            ON buddy_automation_runs(automation_id, claimed_at DESC);
          CREATE INDEX buddy_automation_runs_by_claim_expiry
            ON buddy_automation_runs(status, claim_expires_at);
          PRAGMA user_version = 15;
          COMMIT;
        `);
      } catch (error) {
        this.db.exec("ROLLBACK");
        throw error;
      } finally {
        this.db.exec("PRAGMA foreign_keys = ON");
      }
      const foreignKeyViolation = this.db.prepare("PRAGMA foreign_key_check").get();
      if (foreignKeyViolation) {
        throw new Error(`automation run migration broke a foreign key: ${foreignKeyViolation.table}`);
      }
      version = 15;
    }
  }

  /**
   * §8.3 item 2, applied to rows written before setBuddyRelationship normalized.
   * `manager A->B` and `reports_to B->A` are inverse encodings of one edge; while
   * both exist, overview() derives pairs {A:B} and {B:A} and BOTH buddies vanish
   * from `topLevel` with no UI signal, and the partial unique indexes below
   * constrain each encoding separately so neither one catches it.
   *
   * Rewrite every `reports_to` row as the equivalent `manager` row, then drop the
   * encoding entirely. Raw SQL rather than setBuddyRelationship: a migration must
   * not depend on the public API surface it is migrating toward.
   */
  #normalizeReportsToEdges() {
    const converted = this.db
      .prepare(`
        INSERT INTO buddy_relationships (id, from_buddy_id, to_buddy_id, kind, created_at)
        SELECT 'relationship_norm_' || id, to_buddy_id, from_buddy_id, 'manager', created_at
        FROM buddy_relationships WHERE kind = 'reports_to'
        ON CONFLICT(from_buddy_id, to_buddy_id, kind) DO NOTHING
      `)
      .run().changes;
    this.db.prepare("DELETE FROM buddy_relationships WHERE kind = 'reports_to'").run();
    return converted;
  }

  /**
   * §6 backfill. v13's partial unique indexes are a constraint, not an assertion,
   * so CREATE INDEX fails outright on a database that already holds two manager
   * edges into one report. `UNIQUE(from_buddy_id, to_buddy_id, kind)` only ever
   * constrained the pair, never the report's in-degree, and the relationships
   * route writes edges directly, so duplicates are reachable today.
   *
   * Keep the earliest edge per report and delete the rest. `ORDER BY created_at,
   * id` (not `created_at` alone): created_at is millisecond ISO, so ties have no
   * stable order and can flip after `VACUUM INTO`, which would make the surviving
   * manager nondeterministic.
   *
   * Raw INSERT rather than recordAuditEvent, for the same reason as above.
   */
  #collapseDuplicateManagerEdges() {
    const losers = rows(
      this.db.prepare(`
        SELECT edge.id, edge.created_at,
               edge.to_buddy_id AS report_id, edge.from_buddy_id AS manager_id,
               report.project_id AS workspace_id
        FROM buddy_relationships AS edge
        JOIN buddies AS report ON report.id = edge.to_buddy_id
        WHERE edge.kind = 'manager'
          AND edge.id <> (
            SELECT winner.id FROM buddy_relationships AS winner
            WHERE winner.kind = 'manager' AND winner.to_buddy_id = edge.to_buddy_id
            ORDER BY winner.created_at, winner.id
            LIMIT 1
          )
        ORDER BY edge.created_at, edge.id
      `),
    );
    const deleteEdge = this.db.prepare("DELETE FROM buddy_relationships WHERE id = ?");
    const insertAudit = this.db.prepare(`
      INSERT INTO buddy_audit_events (
        id, buddy_id, workspace_id, buddy_project_id, operation, payload, created_at
      ) VALUES (?, ?, ?, NULL, 'buddy.migration_collapsed_manager_edge', ?, ?)
    `);
    const timestamp = now();
    for (const edge of losers) {
      deleteEdge.run(edge.id);
      insertAudit.run(
        id("audit"),
        edge.report_id,
        edge.workspace_id,
        JSON.stringify({
          relationshipId: edge.id,
          managerId: edge.manager_id,
          reportId: edge.report_id,
          createdAt: edge.created_at,
          reason: "schema v13 enforces one manager per report",
        }),
        timestamp,
      );
    }
    return losers.length;
  }

  /**
   * §7.1. Re-entrant transaction. `node:sqlite` has no `db.transaction()` (this
   * store is DatabaseSync, not better-sqlite3), so nesting was hand-rolled and
   * broken (B2): an inner `BEGIN` threw "cannot start a transaction within a
   * transaction", the inner catch's `ROLLBACK` destroyed the CALLER's transaction,
   * and the caller's own `ROLLBACK` then threw "no transaction is active",
   * masking the real error.
   *
   * Depth 0 opens BEGIN IMMEDIATE: the write lock is taken up front, so a decision
   * read inside the body cannot be invalidated by another connection before the
   * write lands (B4). Deeper calls open a depth-NAMED savepoint - a single shared
   * name would release the wrong one at depth 3.
   *
   * The catch arm is guarded on `this.db.isTransaction` because a statement that
   * aborts the transaction (or a failed COMMIT) leaves none active, and an
   * unguarded ROLLBACK would throw and replace the root cause. The inner catch
   * swallows only the rollback's own error, never the caller's.
   */
  #tx(fn) {
    const depth = this.#txDepth;
    const savepoint = `buddies_sp_${depth}`;
    this.db.exec(depth === 0 ? "BEGIN IMMEDIATE" : `SAVEPOINT ${savepoint}`);
    this.#txDepth = depth + 1;
    try {
      const result = fn();
      this.db.exec(depth === 0 ? "COMMIT" : `RELEASE ${savepoint}`);
      return result;
    } catch (error) {
      if (this.db.isTransaction) {
        try {
          this.db.exec(
            depth === 0
              ? "ROLLBACK"
              : `ROLLBACK TO ${savepoint}; RELEASE ${savepoint};`,
          );
        } catch {
          // The rollback failed; the caller's error is the one worth reporting.
        }
      }
      throw error;
    } finally {
      this.#txDepth = depth;
    }
  }

  createProject({ name, rootPath, slug = slugify(name) }) {
    const timestamp = now();
    const project = {
      id: id("project"),
      slug: required("project slug", slug),
      name: required("project name", name),
      rootPath: resolve(required("project root path", rootPath)),
      createdAt: timestamp,
      updatedAt: timestamp,
    };
    this.db
      .prepare(`
        INSERT INTO projects (id, slug, name, root_path, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?)
      `)
      .run(
        project.id,
        project.slug,
        project.name,
        project.rootPath,
        project.createdAt,
        project.updatedAt,
      );
    return this.getProject(project.id);
  }

  getProject(idOrSlug) {
    const row = this.db
      .prepare("SELECT * FROM projects WHERE id = ? OR slug = ?")
      .get(idOrSlug, idOrSlug);
    return row ? { ...row } : null;
  }

  listProjects() {
    return rows(this.db.prepare("SELECT * FROM projects ORDER BY name"));
  }

  createWorkspace(input) {
    return this.createProject(input);
  }

  getWorkspace(idOrSlug) {
    return this.getProject(idOrSlug);
  }

  listWorkspaces() {
    return this.listProjects();
  }

  createBuddy({
    project,
    name,
    role,
    slug = slugify(name),
    status = "active",
    soulPath,
    memoryPath,
    provider,
    model,
    reasoningEffort,
    hireQuota = 0,
  }) {
    assertOneOf("buddy status", status, BUDDY_STATUSES);
    const ownerProject = this.#requireProject(project);
    const timestamp = now();
    const buddy = {
      id: id("buddy"),
      projectId: ownerProject.id,
      slug: required("buddy slug", slug),
      name: required("buddy name", name),
      role: required("buddy role", role),
      status,
      soulPath: soulPath ? this.#projectPath(ownerProject, soulPath) : null,
      memoryPath: memoryPath ? this.#projectPath(ownerProject, memoryPath) : null,
      provider: provider || null,
      model: model || null,
      reasoningEffort: reasoningEffort || null,
      // B1: hire_quota is how many direct reports this Buddy may hold at once.
      // Non-negative integer, never null - the column is NOT NULL DEFAULT 0 and a
      // nullable quota reads as `0 < null === false`, i.e. hire refuses forever
      // with no diagnostic.
      hireQuota: requireNonNegativeInteger("hire quota", hireQuota),
      createdAt: timestamp,
      updatedAt: timestamp,
    };
    // #tx-routed because hire calls createBuddy from inside its own transaction.
    this.#tx(() => {
      this.db
        .prepare(`
          INSERT INTO buddies (
            id, project_id, slug, name, role, status, soul_path, memory_path,
            provider, model, reasoning_effort, hire_quota, created_at, updated_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `)
        .run(
          buddy.id,
          buddy.projectId,
          buddy.slug,
          buddy.name,
          buddy.role,
          buddy.status,
          buddy.soulPath,
          buddy.memoryPath,
          buddy.provider,
          buddy.model,
          buddy.reasoningEffort,
          buddy.hireQuota,
          buddy.createdAt,
          buddy.updatedAt,
        );
      this.db
        .prepare(`
          INSERT INTO buddy_projects (buddy_id, project_id, assignment_role, created_at)
          VALUES (?, ?, ?, ?)
        `)
        .run(buddy.id, buddy.projectId, buddy.role, timestamp);
    });
    return this.getBuddy(buddy.id);
  }

  /**
   * One transaction owns Builder idempotency, identity, and every workspace
   * assignment. Application code should not rebuild this with lookup/create
   * sequences: those can race across MCP processes.
   */
  createBuddyFromBuilder({
    conversationId,
    requestFingerprint,
    project,
    additionalWorkspaces = [],
    name,
    role,
    slug = slugify(name),
    status = "active",
    provider,
    model,
    reasoningEffort,
  }) {
    const builderConversationId = required("Builder conversation", conversationId);
    const fingerprint = required("Builder request fingerprint", requestFingerprint);
    const existing = this.db
      .prepare("SELECT * FROM buddy_builder_creations WHERE conversation_id = ?")
      .get(builderConversationId);
    if (existing) {
      if (existing.request_fingerprint !== fingerprint) {
        throw new Error("this Buddy Builder conversation already created a different Buddy");
      }
      const buddy = this.getBuddy(existing.buddy_id);
      if (!buddy) throw new Error("Buddy Builder result references a missing Buddy");
      return {
        buddy,
        homeWorkspace: this.getWorkspace(existing.workspace_id),
        workspaces: this.listBuddyWorkspaces(buddy.id),
        requestFingerprint: existing.request_fingerprint,
        replayed: true,
      };
    }

    assertOneOf("buddy status", status, BUDDY_STATUSES);
    const homeWorkspace = this.#requireProject(project);
    const assignedWorkspaces = [
      homeWorkspace,
      ...additionalWorkspaces.map((workspace) => this.#requireProject(workspace)),
    ].filter(
      (workspace, index, all) =>
        all.findIndex((candidate) => candidate.id === workspace.id) === index,
    );
    const timestamp = now();
    const buddy = {
      id: id("buddy"),
      projectId: homeWorkspace.id,
      slug: required("buddy slug", slug),
      name: required("buddy name", name),
      role: required("buddy role", role),
      status,
      soulPath: null,
      memoryPath: null,
      provider: provider || null,
      model: model || null,
      reasoningEffort: reasoningEffort || null,
      createdAt: timestamp,
      updatedAt: timestamp,
    };

    // §7.1. The replay result is returned OUT of the transaction body rather than
    // committed mid-flight, so #tx owns commit and rollback on one path.
    let replayedRecord = null;
    try {
      replayedRecord = this.#tx(() => {
        const existingInside = this.db
          .prepare("SELECT * FROM buddy_builder_creations WHERE conversation_id = ?")
          .get(builderConversationId);
        if (existingInside) {
          if (existingInside.request_fingerprint !== fingerprint) {
            throw new Error("this Buddy Builder conversation already created a different Buddy");
          }
          return existingInside;
        }
        this.db
          .prepare(`
            INSERT INTO buddies (
              id, project_id, slug, name, role, status, soul_path, memory_path,
              provider, model, reasoning_effort, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
          `)
          .run(
            buddy.id,
            buddy.projectId,
            buddy.slug,
            buddy.name,
            buddy.role,
            buddy.status,
            buddy.soulPath,
            buddy.memoryPath,
            buddy.provider,
            buddy.model,
            buddy.reasoningEffort,
            buddy.createdAt,
            buddy.updatedAt,
          );
        const assign = this.db.prepare(`
          INSERT INTO buddy_projects (buddy_id, project_id, assignment_role, created_at)
          VALUES (?, ?, ?, ?)
        `);
        for (const workspace of assignedWorkspaces) {
          assign.run(buddy.id, workspace.id, buddy.role, timestamp);
        }
        this.db
          .prepare(`
            INSERT INTO buddy_builder_creations (
              conversation_id, buddy_id, workspace_id, request_fingerprint, created_at
            ) VALUES (?, ?, ?, ?, ?)
          `)
          .run(builderConversationId, buddy.id, homeWorkspace.id, fingerprint, timestamp);
        return null;
      });
    } catch (error) {
      // Kept from the pre-#tx version: under WAL a concurrent Builder run can
      // surface as SQLITE_BUSY or a UNIQUE violation here. If that other run
      // committed the same fingerprint, replay its result instead of reporting a
      // lock error (B5).
      const raced = this.db
        .prepare("SELECT * FROM buddy_builder_creations WHERE conversation_id = ?")
        .get(builderConversationId);
      if (raced?.request_fingerprint === fingerprint) {
        const replayedBuddy = this.getBuddy(raced.buddy_id);
        if (!replayedBuddy) throw error;
        return {
          buddy: replayedBuddy,
          homeWorkspace: this.getWorkspace(raced.workspace_id),
          workspaces: this.listBuddyWorkspaces(replayedBuddy.id),
          requestFingerprint: raced.request_fingerprint,
          replayed: true,
        };
      }
      throw error;
    }
    if (replayedRecord) {
      const replayed = this.getBuddy(replayedRecord.buddy_id);
      if (!replayed) throw new Error("Buddy Builder result references a missing Buddy");
      return {
        buddy: replayed,
        homeWorkspace: this.getWorkspace(replayedRecord.workspace_id),
        workspaces: this.listBuddyWorkspaces(replayed.id),
        requestFingerprint: replayedRecord.request_fingerprint,
        replayed: true,
      };
    }
    return {
      buddy: this.getBuddy(buddy.id),
      homeWorkspace,
      workspaces: this.listBuddyWorkspaces(buddy.id),
      requestFingerprint: fingerprint,
      replayed: false,
    };
  }

  getBuddyBuilderResult(conversationId) {
    const creation = this.db
      .prepare("SELECT * FROM buddy_builder_creations WHERE conversation_id = ?")
      .get(required("Builder conversation", conversationId));
    if (!creation) return null;
    const buddy = this.getBuddy(creation.buddy_id);
    if (!buddy) return null;
    return {
      buddy,
      homeWorkspace: this.getWorkspace(creation.workspace_id),
      workspaces: this.listBuddyWorkspaces(buddy.id),
      requestFingerprint: creation.request_fingerprint,
      replayed: true,
    };
  }

  getBuddy(idOrSlug, project) {
    let row;
    if (project) {
      const ownerProject = this.#requireProject(project);
      row = this.db
        .prepare(`
          SELECT buddies.*
          FROM buddies
          JOIN buddy_projects ON buddy_projects.buddy_id = buddies.id
          WHERE buddy_projects.project_id = ? AND (buddies.id = ? OR buddies.slug = ?)
        `)
        .get(ownerProject.id, idOrSlug, idOrSlug);
    } else {
      row = this.db.prepare("SELECT * FROM buddies WHERE id = ?").get(idOrSlug);
      if (!row) {
        const matches = rows(
          this.db.prepare("SELECT * FROM buddies WHERE slug = ? ORDER BY project_id"),
          idOrSlug,
        );
        if (matches.length > 1) {
          throw new Error(
            `buddy slug is ambiguous across workspaces: ${idOrSlug}; use the Buddy id or provide a workspace`,
          );
        }
        row = matches[0];
      }
    }
    return row ? { ...row } : null;
  }

  updateBuddy(buddy, {
    name,
    role,
    status,
    homeWorkspace,
    soulPath,
    memoryPath,
    provider,
    model,
    reasoningEffort,
    hireQuota,
  } = {}) {
    const current = this.#requireBuddy(buddy);
    const workspace =
      homeWorkspace === undefined
        ? this.#requireProject(current.project_id)
        : this.#requireProject(homeWorkspace);
    const nextStatus = status ?? current.status;
    assertOneOf("buddy status", nextStatus, BUDDY_STATUSES);
    const nextSoulPath =
      soulPath === undefined
        ? homeWorkspace === undefined || !current.soul_path
          ? current.soul_path
          : this.#projectPath(workspace, current.soul_path)
        : soulPath
          ? this.#projectPath(workspace, soulPath)
          : null;
    const nextMemoryPath =
      memoryPath === undefined
        ? homeWorkspace === undefined || !current.memory_path
          ? current.memory_path
          : this.#projectPath(workspace, current.memory_path)
        : memoryPath
          ? this.#projectPath(workspace, memoryPath)
          : null;
    // B1: hire_quota was missing from both the destructured options and the UPDATE
    // column list, so `{hireQuota: 3}` was silently discarded - HTTP 200, quota
    // still 0, every hire refused forever, no diagnostic. Validate BEFORE the
    // transaction: canonicalization belongs outside the write, not inside it, and
    // a bad input must not open and roll back a write transaction.
    const nextHireQuota =
      hireQuota === undefined
        ? current.hire_quota
        : requireNonNegativeInteger("hire quota", hireQuota);
    const timestamp = now();
    // #tx-routed because hire's `reactivatable` arm calls updateBuddy from inside
    // hire's transaction.
    this.#tx(() => {
      this.db
        .prepare(`
          UPDATE buddies SET
            project_id = ?, name = ?, role = ?, status = ?, soul_path = ?, memory_path = ?,
            provider = ?, model = ?, reasoning_effort = ?, hire_quota = ?, updated_at = ?
          WHERE id = ?
        `)
        .run(
          workspace.id,
          name === undefined ? current.name : required("buddy name", name),
          role === undefined ? current.role : required("buddy role", role),
          nextStatus,
          nextSoulPath,
          nextMemoryPath,
          provider === undefined ? current.provider : provider || null,
          model === undefined ? current.model : model || null,
          reasoningEffort === undefined
            ? current.reasoning_effort
            : reasoningEffort || null,
          nextHireQuota,
          timestamp,
          current.id,
        );
      this.db
        .prepare(`
          INSERT INTO buddy_projects (buddy_id, project_id, assignment_role, created_at)
          VALUES (?, ?, ?, ?)
          ON CONFLICT(buddy_id, project_id) DO NOTHING
        `)
        .run(current.id, workspace.id, role ?? current.role, timestamp);
    });
    return this.getBuddy(current.id);
  }

  listBuddies(project) {
    if (!project) {
      return rows(
        this.db.prepare(`
          SELECT buddies.*, projects.slug AS project_slug
          FROM buddies
          JOIN projects ON projects.id = buddies.project_id
          ORDER BY projects.name, buddies.name
        `),
      );
    }
    const ownerProject = this.#requireProject(project);
    return rows(
      this.db.prepare(`
        SELECT buddies.*, buddy_projects.assignment_role
        FROM buddies
        JOIN buddy_projects ON buddy_projects.buddy_id = buddies.id
        WHERE buddy_projects.project_id = ?
        ORDER BY buddies.name
      `),
      ownerProject.id,
    );
  }

  assignBuddyToProject({ buddy, project, role }) {
    const ownerBuddy = this.#requireBuddy(buddy);
    const ownerProject = this.#requireProject(project);
    this.db
      .prepare(`
        INSERT INTO buddy_projects (buddy_id, project_id, assignment_role, created_at)
        VALUES (?, ?, ?, ?)
        ON CONFLICT(buddy_id, project_id) DO UPDATE SET
          assignment_role = excluded.assignment_role
      `)
      .run(ownerBuddy.id, ownerProject.id, role?.trim() || ownerBuddy.role, now());
    return this.listBuddyProjects(ownerBuddy.id);
  }

  listBuddyProjects(buddy) {
    const ownerBuddy = this.#requireBuddy(buddy);
    return rows(
      this.db.prepare(`
        SELECT projects.*, buddy_projects.assignment_role
        FROM buddy_projects
        JOIN projects ON projects.id = buddy_projects.project_id
        WHERE buddy_projects.buddy_id = ?
        ORDER BY projects.name
      `),
      ownerBuddy.id,
    );
  }

  assignBuddyToWorkspace({ buddy, workspace, role }) {
    return this.assignBuddyToProject({ buddy, project: workspace, role });
  }

  listBuddyWorkspaces(buddy) {
    return this.listBuddyProjects(buddy);
  }

  /**
   * §7.4. The only way to move `owned_projects.buddy_id` (B3). `updateProject` has
   * a fixed column list without it, `upsertBuddyProject` throws "external key
   * belongs to another Buddy", and `newProject` inserts once and never updates.
   *
   * Workspace membership is re-checked HERE rather than trusted from the caller:
   * `newProject` guards ownership with `#requireBuddy(buddy, ownerWorkspace)`, so a
   * raw UPDATE would silently produce an owner outside its project's workspace and
   * `getBuddyContext` would then throw "buddy does not belong to the workspace"
   * every time that project is opened. The error names the workspace so the caller
   * can act on it.
   *
   * One project per call, not a bulk move: the caller (retire) already has the list
   * from `listBuddyOwnedProjects` and needs a per-project audit trail.
   */
  reassignOwnedProject({ project, toBuddy }) {
    const ownerProject = this.#requireBuddyProject(project);
    const workspace = this.#requireProject(ownerProject.workspace_id);
    const nextOwner = this.#requireBuddy(toBuddy);
    if (nextOwner.id === ownerProject.buddy_id) {
      throw new Error("Buddy project is already owned by that Buddy");
    }
    if (nextOwner.status === "archived") {
      throw new Error(`cannot reassign work to an archived Buddy: ${nextOwner.slug}`);
    }
    if (!this.#buddyHasProject(nextOwner.id, workspace.id)) {
      throw new Error(
        `buddy ${nextOwner.slug} does not belong to workspace ${workspace.slug}; assign it there before reassigning work`,
      );
    }
    const timestamp = now();
    return this.#tx(() => {
      this.db
        .prepare("UPDATE owned_projects SET buddy_id = ?, updated_at = ? WHERE id = ?")
        .run(nextOwner.id, timestamp, ownerProject.id);
      this.recordAuditEvent({
        buddy: nextOwner.id,
        workspace: workspace.id,
        project: ownerProject.id,
        operation: "buddy.reassign_owned_project",
        payload: {
          projectId: ownerProject.id,
          fromBuddyId: ownerProject.buddy_id,
          toBuddyId: nextOwner.id,
        },
      });
      return this.getBuddyProject(ownerProject.id);
    });
  }

  /**
   * The single choke point for the hierarchy: the relationships route bypasses
   * hire entirely and lands here, so normalization and the cycle rule live here,
   * not in hire. Callers asking for `reports_to` get back a `manager` row with
   * from/to swapped - that is the point (§8.3), not a bug.
   */
  setBuddyRelationship({ fromBuddy, toBuddy, kind }) {
    assertOneOf("relationship kind", kind, BUDDY_RELATIONSHIP_KINDS);
    const from = this.#requireBuddy(fromBuddy);
    const to = this.#requireBuddy(toBuddy);
    if (from.id === to.id) throw new Error("a Buddy cannot relate to itself");
    // Canonicalize once, up front; nothing below asks "which direction was this
    // written in?".
    const edge = CANONICAL_RELATIONSHIP[kind](from.id, to.id);
    const relationshipId = id("relationship");
    // BEGIN IMMEDIATE via #tx: the cycle walk and the insert are one write. Two
    // concurrent "A manages B" / "B manages A" calls would otherwise both read a
    // cycle-free graph and both commit.
    this.#tx(() => {
      // Dispatch on the canonical kind: only hierarchy edges can form the cycle
      // that empties `topLevel`. `consults`/`reviews` cycles are legal.
      if (edge.kind === "manager") this.#assertNoManagementCycle(edge.from, edge.to);
      this.db
        .prepare(`
          INSERT INTO buddy_relationships (
            id, from_buddy_id, to_buddy_id, kind, created_at
          ) VALUES (?, ?, ?, ?, ?)
          ON CONFLICT(from_buddy_id, to_buddy_id, kind) DO NOTHING
        `)
        .run(relationshipId, edge.from, edge.to, edge.kind, now());
    });
    return this.db
      .prepare(`
        SELECT * FROM buddy_relationships
        WHERE from_buddy_id = ? AND to_buddy_id = ? AND kind = ?
      `)
      .get(edge.from, edge.to, edge.kind);
  }

  /**
   * §8.3. A management cycle has no top_level member, so every buddy in it vanishes
   * from the directory - the same invisible failure as the dual encoding. Walk UP
   * from the prospective manager; reaching the report means the new edge closes a
   * loop. Both encodings are read because a database can still hold `reports_to`
   * rows written before v13's normalization (a direct SQLite write, §10 path 2).
   * `seen` bounds the walk so a cycle already present in the data terminates
   * instead of hanging the process.
   */
  #assertNoManagementCycle(managerId, reportId) {
    const managersOf = this.db.prepare(`
      SELECT from_buddy_id AS manager_id FROM buddy_relationships
       WHERE kind = 'manager' AND to_buddy_id = ?
      UNION
      SELECT to_buddy_id AS manager_id FROM buddy_relationships
       WHERE kind = 'reports_to' AND from_buddy_id = ?
    `);
    const seen = new Set();
    const queue = [managerId];
    while (queue.length > 0) {
      const cursor = queue.shift();
      if (cursor === reportId) {
        throw new Error(
          `a Buddy cannot manage its own manager: ${reportId} already manages ${managerId} directly or transitively`,
        );
      }
      if (seen.has(cursor)) continue;
      seen.add(cursor);
      for (const row of rows(managersOf, cursor, cursor)) queue.push(row.manager_id);
    }
  }

  removeBuddyRelationship(relationship) {
    const result = this.db
      .prepare("DELETE FROM buddy_relationships WHERE id = ?")
      .run(required("relationship", relationship));
    return result.changes > 0;
  }

  listBuddyRelationships(buddy) {
    const ownerBuddy = this.#requireBuddy(buddy);
    return rows(
      this.db.prepare(`
        SELECT buddy_relationships.*,
          from_buddy.name AS from_buddy_name, to_buddy.name AS to_buddy_name
        FROM buddy_relationships
        JOIN buddies AS from_buddy ON from_buddy.id = from_buddy_id
        JOIN buddies AS to_buddy ON to_buddy.id = to_buddy_id
        WHERE from_buddy_id = ? OR to_buddy_id = ?
        ORDER BY created_at
      `),
      ownerBuddy.id,
      ownerBuddy.id,
    );
  }

  recordAuditEvent({ buddy, workspace, project, operation, payload = {} }) {
    const ownerWorkspace = this.#requireProject(workspace);
    const ownerBuddy = this.#requireBuddy(buddy, ownerWorkspace);
    const ownerProject = project ? this.#requireBuddyProject(project) : null;
    if (ownerProject && ownerProject.workspace_id !== ownerWorkspace.id) {
      throw new Error("audit project does not belong to the workspace");
    }
    const event = {
      id: id("audit"),
      buddyId: ownerBuddy.id,
      workspaceId: ownerWorkspace.id,
      buddyProjectId: ownerProject?.id || null,
      operation: required("audit operation", operation),
      payload: JSON.stringify(payload ?? {}),
      createdAt: now(),
    };
    this.db
      .prepare(`
        INSERT INTO buddy_audit_events (
          id, buddy_id, workspace_id, buddy_project_id,
          operation, payload, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?)
      `)
      .run(
        event.id,
        event.buddyId,
        event.workspaceId,
        event.buddyProjectId,
        event.operation,
        event.payload,
        event.createdAt,
      );
    return this.getAuditEvent(event.id);
  }

  getAuditEvent(event) {
    const row = this.db
      .prepare("SELECT * FROM buddy_audit_events WHERE id = ?")
      .get(required("audit event", event));
    return row
      ? {
          ...row,
          payload: JSON.parse(row.payload),
        }
      : null;
  }

  listAuditEvents({ buddy, workspace, project, limit = 100 } = {}) {
    const conditions = [];
    const params = [];
    if (buddy) {
      conditions.push("buddy_id = ?");
      params.push(this.#requireBuddy(buddy).id);
    }
    if (workspace) {
      conditions.push("workspace_id = ?");
      params.push(this.#requireProject(workspace).id);
    }
    if (project) {
      conditions.push("buddy_project_id = ?");
      params.push(this.#requireBuddyProject(project).id);
    }
    const where = conditions.length ? `WHERE ${conditions.join(" AND ")}` : "";
    const safeLimit = Math.max(1, Math.min(1000, Number(limit) || 100));
    return rows(
      this.db.prepare(`
        SELECT * FROM buddy_audit_events
        ${where}
        ORDER BY created_at DESC, id DESC
        LIMIT ?
      `),
      ...params,
      safeLimit,
    ).map((row) => ({
      ...row,
      payload: JSON.parse(row.payload),
    }));
  }

  createApprovalRequest({
    buddy,
    workspace,
    project,
    automationRun,
    conversationId,
    action,
    reason,
    risk,
  }) {
    const ownerWorkspace = this.#requireProject(workspace);
    const ownerBuddy = this.#requireBuddy(buddy, ownerWorkspace);
    const ownerRun = automationRun ? this.#requireAutomationRun(automationRun) : null;
    const runAutomation = ownerRun ? this.#requireAutomation(ownerRun.automation_id) : null;
    const ownerProject = project
      ? this.#requireBuddyProject(project)
      : runAutomation?.buddy_project_id
        ? this.#requireBuddyProject(runAutomation.buddy_project_id)
        : null;
    if (ownerProject && ownerProject.workspace_id !== ownerWorkspace.id) {
      throw new Error("approval project does not belong to the workspace");
    }
    if (ownerProject && ownerProject.buddy_id !== ownerBuddy.id) {
      throw new Error("approval project does not belong to the Buddy");
    }
    if (ownerRun) {
      if (
        runAutomation.buddy_id !== ownerBuddy.id ||
        runAutomation.workspace_id !== ownerWorkspace.id ||
        (ownerProject && runAutomation.buddy_project_id !== ownerProject.id)
      ) {
        throw new Error("automation run does not belong to the approval scope");
      }
    }
    const conversation = conversationId
      ? this.db
          .prepare(`
            SELECT * FROM conversation_links
            WHERE id = ? OR unleashd_conversation_id = ? OR provider_session_id = ?
          `)
          .get(conversationId, conversationId, conversationId)
      : null;
    if (conversationId && !conversation) {
      throw new Error("approval conversation is not linked to the Buddy");
    }
    if (
      conversation &&
      (conversation.buddy_id !== ownerBuddy.id ||
        conversation.workspace_id !== ownerWorkspace.id ||
        (ownerProject && conversation.buddy_project_id !== ownerProject.id))
    ) {
      throw new Error("conversation does not belong to the approval scope");
    }
    const approvalId = id("approval");
    const timestamp = now();
    const request = {
      id: approvalId,
      buddyId: ownerBuddy.id,
      workspaceId: ownerWorkspace.id,
      buddyProjectId: ownerProject?.id || null,
      automationRunId: ownerRun?.id || null,
      conversationId: conversationId?.trim() || null,
      action: required("approval action", action),
      reason: required("approval reason", reason),
      risk: required("approval risk", risk),
      requestedAt: timestamp,
    };
    this.#tx(() => {
      this.db
        .prepare(`
          INSERT INTO buddy_approval_requests (
            id, buddy_id, workspace_id, buddy_project_id, automation_run_id,
            conversation_id, action, reason, risk, status, resolved_by,
            resolution_note, requested_at, resolved_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending', NULL, NULL, ?, NULL)
        `)
        .run(
          request.id,
          request.buddyId,
          request.workspaceId,
          request.buddyProjectId,
          request.automationRunId,
          request.conversationId,
          request.action,
          request.reason,
          request.risk,
          request.requestedAt,
        );
      this.recordAuditEvent({
        buddy: ownerBuddy.id,
        workspace: ownerWorkspace.id,
        project: ownerProject?.id,
        operation: "buddy.request_human_approval",
        payload: {
          approvalId,
          automationRunId: request.automationRunId,
          conversationId: request.conversationId,
          action: request.action,
          reason: request.reason,
          risk: request.risk,
          status: "pending",
        },
      });
    });
    return this.getApprovalRequest(approvalId);
  }

  getApprovalRequest(approval) {
    const row = this.db
      .prepare("SELECT * FROM buddy_approval_requests WHERE id = ?")
      .get(required("approval request", approval));
    return row ? { ...row } : null;
  }

  listApprovalRequests({ buddy, workspace, project, status, limit = 100 } = {}) {
    const conditions = [];
    const params = [];
    if (buddy) {
      conditions.push("buddy_id = ?");
      params.push(this.#requireBuddy(buddy).id);
    }
    if (workspace) {
      conditions.push("workspace_id = ?");
      params.push(this.#requireProject(workspace).id);
    }
    if (project) {
      conditions.push("buddy_project_id = ?");
      params.push(this.#requireBuddyProject(project).id);
    }
    if (status) {
      assertOneOf("approval status", status, APPROVAL_STATUSES);
      conditions.push("status = ?");
      params.push(status);
    }
    return rows(
      this.db.prepare(`
        SELECT * FROM buddy_approval_requests
        ${conditions.length ? `WHERE ${conditions.join(" AND ")}` : ""}
        ORDER BY requested_at DESC, id DESC
        LIMIT ?
      `),
      ...params,
      Math.max(1, Math.min(1000, Number(limit) || 100)),
    );
  }

  resolveApprovalRequest(approval, { decision, resolvedBy, note } = {}) {
    assertOneOf("approval decision", decision, ["approved", "rejected"]);
    const current = this.getApprovalRequest(approval);
    if (!current) throw new Error(`approval request not found: ${approval}`);
    if (current.status !== "pending") {
      throw new Error(`approval request is already ${current.status}`);
    }
    const actor = required("approval resolver", resolvedBy);
    const timestamp = now();
    this.#tx(() => {
      const result = this.db
        .prepare(`
          UPDATE buddy_approval_requests
          SET status = ?, resolved_by = ?, resolution_note = ?, resolved_at = ?
          WHERE id = ? AND status = 'pending'
        `)
        .run(decision, actor, note?.trim() || null, timestamp, current.id);
      if (result.changes !== 1) {
        throw new Error("approval request was resolved concurrently");
      }
      this.recordAuditEvent({
        buddy: current.buddy_id,
        workspace: current.workspace_id,
        project: current.buddy_project_id || undefined,
        operation: "buddy.resolve_human_approval",
        payload: {
          approvalId: current.id,
          decision,
          resolvedBy: actor,
          note: note?.trim() || null,
        },
      });
    });
    return this.getApprovalRequest(current.id);
  }

  assignBuddySkill({ buddy, name, instructionPath, mode = "on_demand" }) {
    assertOneOf("skill mode", mode, BUDDY_SKILL_MODES);
    const ownerBuddy = this.#requireBuddy(buddy);
    const rootWorkspace = this.#requireProject(ownerBuddy.project_id);
    const path = this.#projectPath(rootWorkspace, instructionPath);
    const timestamp = now();
    this.db
      .prepare(`
        INSERT INTO buddy_skills (
          id, buddy_id, name, instruction_path, mode, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(buddy_id, name) DO UPDATE SET
          instruction_path = excluded.instruction_path,
          mode = excluded.mode,
          updated_at = excluded.updated_at
      `)
      .run(id("skill"), ownerBuddy.id, required("skill name", name), path, mode, timestamp, timestamp);
    return this.db
      .prepare("SELECT * FROM buddy_skills WHERE buddy_id = ? AND name = ?")
      .get(ownerBuddy.id, name.trim());
  }

  removeBuddySkill(buddy, name) {
    const ownerBuddy = this.#requireBuddy(buddy);
    return (
      this.db
        .prepare("DELETE FROM buddy_skills WHERE buddy_id = ? AND name = ?")
        .run(ownerBuddy.id, required("skill name", name)).changes > 0
    );
  }

  listBuddySkills(buddy) {
    const ownerBuddy = this.#requireBuddy(buddy);
    return rows(
      this.db.prepare("SELECT * FROM buddy_skills WHERE buddy_id = ? ORDER BY name"),
      ownerBuddy.id,
    );
  }

  createDelegation({
    fromBuddy,
    toBuddy,
    workspace,
    project,
    purpose,
    parentConversationId,
    childConversationId,
    status = "pending",
  }) {
    assertOneOf("delegation status", status, DELEGATION_STATUSES);
    const from = this.#requireBuddy(fromBuddy);
    const to = this.#requireBuddy(toBuddy);
    if (from.id === to.id) throw new Error("a Buddy cannot delegate to itself");
    const ownerWorkspace = this.#requireProject(workspace);
    this.#requireBuddy(from, ownerWorkspace);
    this.#requireBuddy(to, ownerWorkspace);
    const ownerProject = project ? this.#requireBuddyProject(project) : null;
    if (ownerProject && ownerProject.workspace_id !== ownerWorkspace.id) {
      throw new Error("Buddy project does not belong to the delegation workspace");
    }
    if (ownerProject && ownerProject.buddy_id !== from.id) {
      throw new Error("Buddy project does not belong to the delegating Buddy");
    }
    const timestamp = now();
    const delegationId = id("delegation");
    this.db
      .prepare(`
        INSERT INTO buddy_delegations (
          id, from_buddy_id, to_buddy_id, workspace_id, buddy_project_id,
          purpose, parent_conversation_id, child_conversation_id, status,
          outcome, created_at, updated_at, completed_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NULL, ?, ?, ?)
      `)
      .run(
        delegationId, from.id, to.id, ownerWorkspace.id, ownerProject?.id || null,
        required("delegation purpose", purpose), parentConversationId || null,
        childConversationId || null, status, timestamp, timestamp,
        ["complete", "failed", "cancelled"].includes(status) ? timestamp : null,
      );
    return this.getDelegation(delegationId);
  }

  getDelegation(delegation) {
    const row = this.db.prepare("SELECT * FROM buddy_delegations WHERE id = ?").get(delegation);
    return row ? { ...row } : null;
  }

  claimDelegationDispatch(delegation, { claimToken, leaseSeconds = 120 } = {}) {
    const current = this.getDelegation(delegation);
    if (!current) throw new Error(`delegation not found: ${delegation}`);
    const token = required("delegation dispatch claim token", claimToken);
    const claimedAt = now();
    const expiresAt = new Date(
      Date.parse(claimedAt) + Math.max(1, Number(leaseSeconds) || 120) * 1000,
    ).toISOString();
    const result = this.db
      .prepare(`
        UPDATE buddy_delegations
        SET dispatch_token = ?, dispatch_expires_at = ?, updated_at = ?
        WHERE id = ?
          AND status = 'pending'
          AND child_conversation_id IS NULL
          AND (
            dispatch_token IS NULL
            OR dispatch_expires_at IS NULL
            OR dispatch_expires_at <= ?
          )
      `)
      .run(token, expiresAt, claimedAt, current.id, claimedAt);
    return {
      ...this.getDelegation(current.id),
      dispatch_claim_acquired: result.changes === 1,
    };
  }

  bindDelegationConversation(delegation, { claimToken, childConversationId }) {
    const current = this.getDelegation(delegation);
    if (!current) throw new Error(`delegation not found: ${delegation}`);
    const token = required("delegation dispatch claim token", claimToken);
    const conversation = required("delegation child conversation", childConversationId);
    if (current.child_conversation_id === conversation && current.status === "active") {
      return current;
    }
    const timestamp = now();
    const result = this.db
      .prepare(`
        UPDATE buddy_delegations
        SET status = 'active', child_conversation_id = ?,
          dispatch_token = NULL, dispatch_expires_at = NULL, updated_at = ?
        WHERE id = ?
          AND status = 'pending'
          AND child_conversation_id IS NULL
          AND dispatch_token = ?
      `)
      .run(conversation, timestamp, current.id, token);
    if (result.changes !== 1) {
      throw new Error("delegation dispatch claim is not owned by this executor");
    }
    return this.getDelegation(current.id);
  }

  failDelegationDispatch(delegation, { claimToken, error }) {
    const current = this.getDelegation(delegation);
    if (!current) throw new Error(`delegation not found: ${delegation}`);
    const token = required("delegation dispatch claim token", claimToken);
    const timestamp = now();
    const result = this.db
      .prepare(`
        UPDATE buddy_delegations
        SET status = 'failed', outcome = ?, dispatch_token = NULL,
          dispatch_expires_at = NULL, updated_at = ?, completed_at = ?
        WHERE id = ?
          AND status = 'pending'
          AND child_conversation_id IS NULL
          AND dispatch_token = ?
      `)
      .run(String(error || "Delegation dispatch failed"), timestamp, timestamp, current.id, token);
    if (result.changes !== 1) {
      throw new Error("delegation dispatch claim is not owned by this executor");
    }
    return this.getDelegation(current.id);
  }

  updateDelegation(delegation, {
    status,
    childConversationId,
    outcome,
  }) {
    const current = this.getDelegation(delegation);
    if (!current) throw new Error(`delegation not found: ${delegation}`);
    const nextStatus = status ?? current.status;
    assertOneOf("delegation status", nextStatus, DELEGATION_STATUSES);
    const timestamp = now();
    this.db
      .prepare(`
        UPDATE buddy_delegations SET status = ?, child_conversation_id = ?,
          outcome = ?, updated_at = ?, completed_at = ? WHERE id = ?
      `)
      .run(
        nextStatus,
        childConversationId === undefined ? current.child_conversation_id : childConversationId || null,
        outcome === undefined ? current.outcome : outcome || null,
        timestamp,
        ["complete", "failed", "cancelled"].includes(nextStatus)
          ? current.completed_at || timestamp
          : null,
        current.id,
      );
    return this.getDelegation(current.id);
  }

  listDelegations({ buddy, workspace, status } = {}) {
    const conditions = [];
    const params = [];
    if (buddy) {
      const ownerBuddy = this.#requireBuddy(buddy);
      conditions.push("(from_buddy_id = ? OR to_buddy_id = ?)");
      params.push(ownerBuddy.id, ownerBuddy.id);
    }
    if (workspace) {
      conditions.push("workspace_id = ?");
      params.push(this.#requireProject(workspace).id);
    }
    if (status) {
      assertOneOf("delegation status", status, DELEGATION_STATUSES);
      conditions.push("status = ?");
      params.push(status);
    }
    return rows(
      this.db.prepare(`
        SELECT * FROM buddy_delegations
        ${conditions.length ? `WHERE ${conditions.join(" AND ")}` : ""}
        ORDER BY created_at DESC
      `),
      ...params,
    );
  }

  createReview({
    reviewer,
    subject,
    workspace,
    project,
    conversationId,
    status = "draft",
    verdict,
    score,
    summary,
    evidence = [],
  }) {
    assertOneOf("review status", status, REVIEW_STATUSES);
    if (verdict) assertOneOf("review verdict", verdict, REVIEW_VERDICTS);
    if (status === "complete" && (!verdict || !summary?.trim())) {
      throw new Error("a completed review requires verdict and summary");
    }
    if (!Array.isArray(evidence)) throw new Error("review evidence must be an array");
    if (status === "complete" && evidence.length === 0) {
      throw new Error("a completed review requires evidence");
    }
    const reviewerBuddy = this.#requireBuddy(reviewer);
    const subjectBuddy = this.#requireBuddy(subject);
    if (reviewerBuddy.id === subjectBuddy.id) {
      throw new Error("a Buddy cannot review itself");
    }
    const ownerWorkspace = this.#requireProject(workspace);
    this.#requireBuddy(reviewerBuddy, ownerWorkspace);
    this.#requireBuddy(subjectBuddy, ownerWorkspace);
    const ownerProject = project ? this.#requireBuddyProject(project) : null;
    if (ownerProject && ownerProject.workspace_id !== ownerWorkspace.id) {
      throw new Error("Buddy project does not belong to the review workspace");
    }
    if (ownerProject && ownerProject.buddy_id !== subjectBuddy.id) {
      throw new Error("Buddy project does not belong to the reviewed Buddy");
    }
    const timestamp = now();
    const reviewId = id("review");
    this.db
      .prepare(`
        INSERT INTO buddy_reviews (
          id, reviewer_buddy_id, subject_buddy_id, workspace_id,
          buddy_project_id, conversation_id, status, verdict, score, summary,
          evidence, created_at, updated_at, completed_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `)
      .run(
        reviewId, reviewerBuddy.id, subjectBuddy.id, ownerWorkspace.id,
        ownerProject?.id || null, conversationId || null, status, verdict || null,
        score === undefined ? null : Number(score), summary?.trim() || null,
        JSON.stringify(evidence), timestamp, timestamp,
        status === "complete" ? timestamp : null,
      );
    return this.getReview(reviewId);
  }

  getReview(review) {
    const row = this.db.prepare("SELECT * FROM buddy_reviews WHERE id = ?").get(review);
    return row ? { ...row, evidence: JSON.parse(row.evidence) } : null;
  }

  updateReview(review, changes = {}) {
    const current = this.getReview(review);
    if (!current) throw new Error(`review not found: ${review}`);
    const status = changes.status ?? current.status;
    const verdict = changes.verdict === undefined ? current.verdict : changes.verdict;
    const summary = changes.summary === undefined ? current.summary : changes.summary?.trim() || null;
    assertOneOf("review status", status, REVIEW_STATUSES);
    if (verdict) assertOneOf("review verdict", verdict, REVIEW_VERDICTS);
    if (status === "complete" && (!verdict || !summary)) {
      throw new Error("a completed review requires verdict and summary");
    }
    const evidence = changes.evidence === undefined ? current.evidence : changes.evidence;
    if (!Array.isArray(evidence)) throw new Error("review evidence must be an array");
    if (status === "complete" && evidence.length === 0) {
      throw new Error("a completed review requires evidence");
    }
    const timestamp = now();
    this.db
      .prepare(`
        UPDATE buddy_reviews SET status = ?, verdict = ?, score = ?, summary = ?,
          evidence = ?, updated_at = ?, completed_at = ? WHERE id = ?
      `)
      .run(
        status, verdict || null,
        changes.score === undefined ? current.score : Number(changes.score),
        summary, JSON.stringify(evidence), timestamp,
        status === "complete" ? current.completed_at || timestamp : null,
        current.id,
      );
    return this.getReview(current.id);
  }

  listReviews({ buddy, workspace, status } = {}) {
    const conditions = [];
    const params = [];
    if (buddy) {
      const ownerBuddy = this.#requireBuddy(buddy);
      conditions.push("(reviewer_buddy_id = ? OR subject_buddy_id = ?)");
      params.push(ownerBuddy.id, ownerBuddy.id);
    }
    if (workspace) {
      conditions.push("workspace_id = ?");
      params.push(this.#requireProject(workspace).id);
    }
    if (status) {
      assertOneOf("review status", status, REVIEW_STATUSES);
      conditions.push("status = ?");
      params.push(status);
    }
    return rows(
      this.db.prepare(`
        SELECT * FROM buddy_reviews
        ${conditions.length ? `WHERE ${conditions.join(" AND ")}` : ""}
        ORDER BY created_at DESC
      `),
      ...params,
    ).map((row) => ({ ...row, evidence: JSON.parse(row.evidence) }));
  }

  createSprint({ project, name, goal, status = "planned" }) {
    assertOneOf("sprint status", status, SPRINT_STATUSES);
    const ownerProject = this.#requireProject(project);
    const timestamp = now();
    const sprint = {
      id: id("sprint"),
      projectId: ownerProject.id,
      name: required("sprint name", name),
      goal: goal?.trim() || null,
      status,
      startsAt: status === "active" ? timestamp : null,
      createdAt: timestamp,
      updatedAt: timestamp,
    };
    this.db
      .prepare(`
        INSERT INTO sprints (
          id, project_id, name, goal, status, starts_at, ends_at, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, NULL, ?, ?)
      `)
      .run(
        sprint.id,
        sprint.projectId,
        sprint.name,
        sprint.goal,
        sprint.status,
        sprint.startsAt,
        sprint.createdAt,
        sprint.updatedAt,
      );
    return this.getSprint(sprint.id);
  }

  getSprint(id) {
    const row = this.db.prepare("SELECT * FROM sprints WHERE id = ?").get(id);
    return row ? { ...row } : null;
  }

  getActiveSprint(project) {
    const ownerProject = this.#requireProject(project);
    const row = this.db
      .prepare("SELECT * FROM sprints WHERE project_id = ? AND status = 'active'")
      .get(ownerProject.id);
    return row ? { ...row } : null;
  }

  completeSprint(sprintId) {
    const sprint = this.#requireSprint(sprintId);
    const timestamp = now();
    this.db
      .prepare(`
        UPDATE sprints
        SET status = 'completed', ends_at = ?, updated_at = ?
        WHERE id = ?
      `)
      .run(timestamp, timestamp, sprint.id);
    return this.getSprint(sprint.id);
  }

  newProject({
    buddy,
    workspace,
    title,
    objective,
    definitionOfDone,
    sprint,
    status = "backlog",
    priority = 0,
    nextAction,
    blockedReason,
    sourcePath,
    externalKey,
    todos = [],
  }) {
    assertOneOf("Buddy project status", status, BUDDY_PROJECT_STATUSES);
    if (status === "blocked" && !blockedReason?.trim()) {
      throw new Error("blocked reason is required when blocking a Buddy project");
    }
    const ownerWorkspace = this.#requireProject(workspace);
    const ownerBuddy = this.#requireBuddy(buddy, ownerWorkspace);
    const ownerSprint = sprint ? this.#requireSprint(sprint, ownerWorkspace) : null;
    if (!Array.isArray(todos)) throw new Error("todos must be an array");
    const timestamp = now();
    const projectId = id("buddy_project");
    this.#tx(() => {
      this.db
        .prepare(`
          INSERT INTO owned_projects (
            id, workspace_id, buddy_id, sprint_id, title, objective,
            definition_of_done, status, priority, next_action, blocked_reason,
            source_path, external_key, created_at, updated_at, completed_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `)
        .run(
          projectId,
          ownerWorkspace.id,
          ownerBuddy.id,
          ownerSprint?.id || null,
          required("Buddy project title", title),
          objective?.trim() || null,
          required("definition of done", definitionOfDone),
          status,
          Number(priority) || 0,
          nextAction?.trim() || null,
          status === "blocked" ? blockedReason.trim() : null,
          sourcePath ? this.#projectPath(ownerWorkspace, sourcePath) : null,
          externalKey?.trim() || null,
          timestamp,
          timestamp,
          ["done", "cancelled"].includes(status) ? timestamp : null,
        );
      for (let position = 0; position < todos.length; position += 1) {
        const todo = todos[position];
        this.#insertTodo(projectId, {
          ...todo,
          position,
        }, timestamp);
      }
    });
    return this.getBuddyProject(projectId);
  }

  upsertBuddyProject(input) {
    const externalKey = required("external key", input.externalKey);
    const ownerWorkspace = this.#requireProject(input.workspace);
    const ownerBuddy = this.#requireBuddy(input.buddy, ownerWorkspace);
    const existing = this.db
      .prepare(
        "SELECT * FROM owned_projects WHERE workspace_id = ? AND external_key = ?",
      )
      .get(ownerWorkspace.id, externalKey);

    if (!existing) {
      return this.newProject({
        ...input,
        buddy: ownerBuddy.id,
        workspace: ownerWorkspace.id,
        externalKey,
      });
    }
    if (existing.buddy_id !== ownerBuddy.id) {
      throw new Error("external key belongs to another Buddy");
    }

    const existingTodos = this.listTodos(existing.id, { includeClosed: true });
    const existingTodoTitles = new Set(existingTodos.map((todo) => todo.title));
    const todoOperations = (input.todos || [])
      .filter((todo) => !existingTodoTitles.has(required("todo title", todo.title)))
      .map((todo) => ({ operation: "add", ...todo }));

    return this.updateProject(existing.id, {
      title: input.title,
      objective: input.objective,
      definitionOfDone: input.definitionOfDone,
      sprint: input.sprint,
      status: input.status,
      priority: input.priority,
      nextAction: input.nextAction,
      blockedReason: input.blockedReason,
      sourcePath: input.sourcePath,
      todoOperations,
    });
  }

  getBuddyProject(project) {
    const row =
      typeof project === "object" && project?.id
        ? project
        : this.db.prepare("SELECT * FROM owned_projects WHERE id = ?").get(project);
    if (!row) return null;
    return {
      ...row,
      todos: this.listTodos(row.id, { includeClosed: true }),
    };
  }

  listBuddyOwnedProjects({ buddy, workspace, sprint, includeClosed = false } = {}) {
    const conditions = [];
    const params = [];
    if (buddy) {
      conditions.push("owned_projects.buddy_id = ?");
      params.push(this.#requireBuddy(buddy).id);
    }
    if (workspace) {
      conditions.push("owned_projects.workspace_id = ?");
      params.push(this.#requireProject(workspace).id);
    }
    if (sprint) {
      conditions.push("owned_projects.sprint_id = ?");
      params.push(this.#requireSprint(sprint).id);
    }
    if (!includeClosed) {
      conditions.push("owned_projects.status NOT IN ('done', 'cancelled')");
    }
    const where = conditions.length ? `WHERE ${conditions.join(" AND ")}` : "";
    return rows(
      this.db.prepare(`
        SELECT owned_projects.*, projects.name AS workspace_name,
          projects.slug AS workspace_slug, buddies.name AS buddy_name,
          sprints.name AS sprint_name
        FROM owned_projects
        JOIN projects ON projects.id = owned_projects.workspace_id
        JOIN buddies ON buddies.id = owned_projects.buddy_id
        LEFT JOIN sprints ON sprints.id = owned_projects.sprint_id
        ${where}
        ORDER BY owned_projects.priority DESC, owned_projects.created_at
      `),
      ...params,
    ).map((project) => ({
      ...project,
      todos: this.listTodos(project.id, { includeClosed: true }),
    }));
  }

  listTodos(project, { includeClosed = false } = {}) {
    const ownerProject = this.#requireBuddyProject(project);
    return rows(
      this.db.prepare(`
        SELECT * FROM buddy_todos
        WHERE buddy_project_id = ?
          ${includeClosed ? "" : "AND status NOT IN ('done', 'cancelled')"}
        ORDER BY position, created_at
      `),
      ownerProject.id,
    );
  }

  updateProject(project, changes = {}) {
    const ownerProject = this.#requireBuddyProject(project);
    const timestamp = now();
    const nextStatus = changes.status ?? ownerProject.status;
    assertOneOf("Buddy project status", nextStatus, BUDDY_PROJECT_STATUSES);
    const nextBlockedReason =
      nextStatus === "blocked"
        ? changes.blockedReason?.trim() || ownerProject.blocked_reason
        : null;
    if (nextStatus === "blocked" && !nextBlockedReason) {
      throw new Error("blocked reason is required when blocking a Buddy project");
    }
    const workspace = this.#requireProject(ownerProject.workspace_id);
    const sprint =
      changes.sprint === null
        ? null
        : changes.sprint
          ? this.#requireSprint(changes.sprint, workspace)
          : undefined;
    if (changes.todoOperations && !Array.isArray(changes.todoOperations)) {
      throw new Error("todoOperations must be an array");
    }
    this.#tx(() => {
      this.db
        .prepare(`
          UPDATE owned_projects SET
            title = ?, objective = ?, definition_of_done = ?, status = ?,
            priority = ?, next_action = ?, blocked_reason = ?, sprint_id = ?,
            source_path = ?, updated_at = ?, completed_at = ?
          WHERE id = ?
        `)
        .run(
          changes.title === undefined
            ? ownerProject.title
            : required("Buddy project title", changes.title),
          changes.objective === undefined
            ? ownerProject.objective
            : changes.objective?.trim() || null,
          changes.definitionOfDone === undefined
            ? ownerProject.definition_of_done
            : required("definition of done", changes.definitionOfDone),
          nextStatus,
          changes.priority === undefined
            ? ownerProject.priority
            : Number(changes.priority) || 0,
          changes.nextAction === undefined
            ? ownerProject.next_action
            : changes.nextAction?.trim() || null,
          nextBlockedReason,
          sprint === undefined ? ownerProject.sprint_id : sprint?.id || null,
          changes.sourcePath === undefined
            ? ownerProject.source_path
            : changes.sourcePath
              ? this.#projectPath(workspace, changes.sourcePath)
              : null,
          timestamp,
          ["done", "cancelled"].includes(nextStatus)
            ? ownerProject.completed_at || timestamp
            : null,
          ownerProject.id,
        );
      for (const operation of changes.todoOperations || []) {
        if (operation.operation === "add") {
          const nextPosition =
            this.db
              .prepare(
                "SELECT COALESCE(MAX(position), -1) + 1 AS position FROM buddy_todos WHERE buddy_project_id = ?",
              )
              .get(ownerProject.id).position;
          this.#insertTodo(ownerProject.id, { ...operation, position: nextPosition }, timestamp);
        } else if (operation.operation === "update") {
          this.#updateTodo(ownerProject.id, operation, timestamp);
        } else {
          throw new Error(`unknown todo operation: ${operation.operation}`);
        }
      }
    });
    return this.getBuddyProject(ownerProject.id);
  }

  readBuddyMemory(buddy, { recentJournalLimit = 7 } = {}) {
    const ownerBuddy = this.#requireBuddy(buddy);
    if (!ownerBuddy.memory_path) {
      return { summary: "", recentJournal: [] };
    }
    const root = this.#memoryRoot(ownerBuddy);
    const summaryPath = this.#containedPath(root, "MEMORY.md");
    let summary = "";
    try {
      summary = readFileSync(summaryPath, "utf8");
    } catch (error) {
      if (error.code !== "ENOENT") throw error;
    }
    const journal = [];
    const today = new Date();
    for (let offset = 0; offset < Math.max(0, Number(recentJournalLimit) || 0); offset += 1) {
      const date = new Date(today);
      date.setUTCDate(today.getUTCDate() - offset);
      const day = date.toISOString().slice(0, 10);
      const path = this.#containedPath(root, "journal", `${day}.md`);
      try {
        journal.push({ path, content: readFileSync(path, "utf8") });
      } catch (error) {
        if (error.code !== "ENOENT") throw error;
      }
    }
    return { summary, recentJournal: journal };
  }

  remember(buddy, { content, kind = "journal", date = new Date() }) {
    assertOneOf("memory kind", kind, ["journal", "curated"]);
    const ownerBuddy = this.#requireBuddy(buddy);
    const root = this.#memoryRoot(ownerBuddy);
    const timestamp = date instanceof Date ? date.toISOString() : new Date(date).toISOString();
    const body = required("memory content", content);
    const path =
      kind === "journal"
        ? this.#containedPath(root, "journal", `${timestamp.slice(0, 10)}.md`)
        : this.#containedPath(root, "MEMORY.md");
    mkdirSync(dirname(path), { recursive: true });
    this.#containedPath(root, relative(root, path));
    const entry =
      kind === "journal"
        ? `\n## ${timestamp}\n\n${body}\n`
        : `\n## ${timestamp.slice(0, 10)}\n\n${body}\n`;
    appendFileSync(path, entry, "utf8");
    return { buddy_id: ownerBuddy.id, kind, path, content: body, written_at: timestamp };
  }

  compactMemory(
    buddy,
    {
      summary,
      retainDays = 7,
      maxActiveCharacters = 50_000,
      dryRun = false,
      date = new Date(),
    } = {},
  ) {
    const ownerBuddy = this.#requireBuddy(buddy);
    const root = this.#memoryRoot(ownerBuddy);
    const journalRoot = this.#containedPath(root, "journal");
    const summaryPath = this.#containedPath(root, "MEMORY.md");
    const indexPath = this.#containedPath(root, "index.json");
    const files = existsSync(journalRoot)
      ? readdirSync(journalRoot)
          .filter((name) => /^\d{4}-\d{2}-\d{2}\.md$/.test(name))
          .sort()
          .map((name) => {
            const path = this.#containedPath(journalRoot, name);
            const content = readFileSync(path, "utf8");
            return { name, path, content, characters: content.length };
          })
      : [];
    const keepCount = Math.max(0, Number(retainDays) || 0);
    const candidates = files.slice(0, Math.max(0, files.length - keepCount));
    let activeCharacters = files.reduce((total, file) => total + file.characters, 0);
    for (const file of files) {
      if (activeCharacters <= Math.max(0, Number(maxActiveCharacters) || 0)) break;
      if (!candidates.includes(file)) candidates.push(file);
      activeCharacters -= file.characters;
    }
    candidates.sort((left, right) => left.name.localeCompare(right.name));
    const sources = candidates.map((file) => ({
      path: `journal/${file.name}`,
      sha256: createHash("sha256").update(file.content).digest("hex"),
      characters: file.characters,
    }));
    const plan = {
      buddyId: ownerBuddy.id,
      dryRun: Boolean(dryRun),
      compact: candidates.length > 0,
      retainedJournalFiles: files.length - candidates.length,
      archivedJournalFiles: sources,
    };
    if (dryRun || candidates.length === 0) return plan;
    const rollup = required("memory compaction summary", summary);
    const timestamp = date instanceof Date ? date.toISOString() : new Date(date).toISOString();
    const existingSummary = existsSync(summaryPath) ? readFileSync(summaryPath, "utf8") : "";
    const sourceList = sources.map((source) => `- ${source.path} (${source.sha256})`).join("\n");
    const nextSummary = `${existingSummary.trimEnd()}\n\n## Compaction ${timestamp}\n\n${rollup}\n\nSources:\n${sourceList}\n`;
    let index = { version: 1, compactions: [] };
    if (existsSync(indexPath)) {
      const parsed = JSON.parse(readFileSync(indexPath, "utf8"));
      if (parsed?.version !== 1 || !Array.isArray(parsed.compactions)) {
        throw new Error("unsupported Buddy memory index");
      }
      index = parsed;
    }
    const signature = createHash("sha256")
      .update(sources.map((source) => source.sha256).join(":"))
      .digest("hex");
    if (index.compactions.some((entry) => entry.signature === signature)) {
      return { ...plan, compact: false, alreadyCompacted: true };
    }
    const nextIndex = {
      version: 1,
      compactions: [
        ...index.compactions,
        {
          id: id("compaction"),
          signature,
          createdAt: timestamp,
          summary: rollup,
          sources,
        },
      ],
    };
    mkdirSync(root, { recursive: true });
    const tempSummary = this.#containedPath(root, `.MEMORY.${randomUUID()}.tmp`);
    const tempIndex = this.#containedPath(root, `.index.${randomUUID()}.tmp`);
    const backupSummary = this.#containedPath(root, `.MEMORY.${randomUUID()}.bak`);
    const backupIndex = this.#containedPath(root, `.index.${randomUUID()}.bak`);
    const moved = [];
    let summaryBackedUp = false;
    let indexBackedUp = false;
    try {
      writeFileSync(tempSummary, nextSummary, "utf8");
      writeFileSync(tempIndex, `${JSON.stringify(nextIndex, null, 2)}\n`, "utf8");
      for (const file of candidates) {
        const archiveDirectory = this.#containedPath(
          root,
          "archive",
          file.name.slice(0, 7),
        );
        mkdirSync(archiveDirectory, { recursive: true });
        const archivePath = this.#containedPath(archiveDirectory, file.name);
        if (existsSync(archivePath)) {
          const archivedHash = createHash("sha256")
            .update(readFileSync(archivePath))
            .digest("hex");
          const source = sources.find((item) => item.path.endsWith(file.name));
          if (archivedHash !== source.sha256) {
            throw new Error(`memory archive collision: ${file.name}`);
          }
          rmSync(file.path);
        } else {
          renameSync(file.path, archivePath);
          moved.push({ from: file.path, to: archivePath });
        }
      }
      if (existsSync(summaryPath)) {
        renameSync(summaryPath, backupSummary);
        summaryBackedUp = true;
      }
      if (existsSync(indexPath)) {
        renameSync(indexPath, backupIndex);
        indexBackedUp = true;
      }
      renameSync(tempSummary, summaryPath);
      renameSync(tempIndex, indexPath);
      rmSync(backupSummary, { force: true });
      rmSync(backupIndex, { force: true });
    } catch (error) {
      rmSync(tempSummary, { force: true });
      rmSync(tempIndex, { force: true });
      if (summaryBackedUp) {
        rmSync(summaryPath, { force: true });
        renameSync(backupSummary, summaryPath);
      }
      if (indexBackedUp) {
        rmSync(indexPath, { force: true });
        renameSync(backupIndex, indexPath);
      }
      for (const file of moved.reverse()) {
        if (existsSync(file.to) && !existsSync(file.from)) renameSync(file.to, file.from);
      }
      throw error;
    }
    return {
      ...plan,
      compactedAt: timestamp,
      indexPath,
      summaryPath,
      signature,
    };
  }

  createWorkItem({
    project,
    title,
    definitionOfDone,
    objective,
    buddy,
    sprint,
    status = "backlog",
    priority = 0,
    nextAction,
    kind = "task",
    externalKey,
    sourcePath,
    blockedReason,
  }) {
    assertOneOf("work item status", status, WORK_ITEM_STATUSES);
    if (status === "blocked" && !blockedReason?.trim()) {
      throw new Error("blocked reason is required when creating blocked work");
    }
    const ownerProject = this.#requireProject(project);
    const ownerBuddy = buddy ? this.#requireBuddy(buddy, ownerProject) : null;
    const ownerSprint = sprint ? this.#requireSprint(sprint, ownerProject) : null;
    const timestamp = now();
    const workItem = {
      id: id("work"),
      projectId: ownerProject.id,
      sprintId: ownerSprint?.id || null,
      buddyId: ownerBuddy?.id || null,
      title: required("work item title", title),
      kind: required("work item kind", kind),
      externalKey: externalKey?.trim() || null,
      sourcePath: sourcePath ? this.#projectPath(ownerProject, sourcePath) : null,
      objective: objective?.trim() || null,
      definitionOfDone: required("definition of done", definitionOfDone),
      status,
      priority: Number(priority) || 0,
      nextAction: nextAction?.trim() || null,
      blockedReason: status === "blocked" ? blockedReason.trim() : null,
      createdAt: timestamp,
      updatedAt: timestamp,
      completedAt: status === "done" ? timestamp : null,
    };
    this.db
      .prepare(`
        INSERT INTO work_items (
          id, project_id, sprint_id, buddy_id, title, kind, external_key, source_path, objective,
          definition_of_done, status, priority, next_action, blocked_reason,
          created_at, updated_at, completed_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `)
      .run(
        workItem.id,
        workItem.projectId,
        workItem.sprintId,
        workItem.buddyId,
        workItem.title,
        workItem.kind,
        workItem.externalKey,
        workItem.sourcePath,
        workItem.objective,
        workItem.definitionOfDone,
        workItem.status,
        workItem.priority,
        workItem.nextAction,
        workItem.blockedReason,
        workItem.createdAt,
        workItem.updatedAt,
        workItem.completedAt,
      );
    return this.getWorkItem(workItem.id);
  }

  upsertWorkItem(input) {
    if (!input.externalKey?.trim()) {
      return this.createWorkItem(input);
    }
    const ownerProject = this.#requireProject(input.project);
    const existing = this.db
      .prepare("SELECT * FROM work_items WHERE project_id = ? AND external_key = ?")
      .get(ownerProject.id, input.externalKey.trim());
    if (!existing) return this.createWorkItem(input);

    const ownerBuddy = input.buddy ? this.#requireBuddy(input.buddy, ownerProject) : null;
    const ownerSprint = input.sprint ? this.#requireSprint(input.sprint, ownerProject) : null;
    assertOneOf("work item status", input.status, WORK_ITEM_STATUSES);
    if (input.status === "blocked" && !input.blockedReason?.trim()) {
      throw new Error("blocked reason is required when blocking a work item");
    }
    const timestamp = now();
    this.db
      .prepare(`
        UPDATE work_items SET
          sprint_id = ?, buddy_id = ?, title = ?, kind = ?, source_path = ?,
          objective = ?, definition_of_done = ?, status = ?, priority = ?,
          next_action = ?, blocked_reason = ?, updated_at = ?, completed_at = ?
        WHERE id = ?
      `)
      .run(
        ownerSprint?.id || null,
        ownerBuddy?.id || null,
        required("work item title", input.title),
        required("work item kind", input.kind || "task"),
        input.sourcePath ? this.#projectPath(ownerProject, input.sourcePath) : null,
        input.objective?.trim() || null,
        required("definition of done", input.definitionOfDone),
        input.status,
        Number(input.priority) || 0,
        input.nextAction?.trim() || null,
        input.status === "blocked" ? input.blockedReason.trim() : null,
        timestamp,
        input.status === "done" ? timestamp : null,
        existing.id,
      );
    return this.getWorkItem(existing.id);
  }

  getWorkItem(id) {
    const row = this.db.prepare("SELECT * FROM work_items WHERE id = ?").get(id);
    return row ? { ...row } : null;
  }

  updateWorkItemStatus(id, status, { blockedReason, nextAction } = {}) {
    assertOneOf("work item status", status, WORK_ITEM_STATUSES);
    this.#requireWorkItem(id);
    if (status === "blocked" && !blockedReason?.trim()) {
      throw new Error("blocked reason is required when blocking a work item");
    }
    const timestamp = now();
    this.db
      .prepare(`
        UPDATE work_items
        SET status = ?,
            blocked_reason = ?,
            next_action = COALESCE(?, next_action),
            completed_at = ?,
            updated_at = ?
        WHERE id = ?
      `)
      .run(
        status,
        status === "blocked" ? blockedReason.trim() : null,
        nextAction?.trim() || null,
        status === "done" ? timestamp : null,
        timestamp,
        id,
      );
    return this.getWorkItem(id);
  }

  listWorkItems({ project, buddy, sprint, includeClosed = false } = {}) {
    const conditions = [];
    const params = [];
    if (project) {
      conditions.push("work_items.project_id = ?");
      params.push(this.#requireProject(project).id);
    }
    if (buddy) {
      conditions.push("work_items.buddy_id = ?");
      params.push(this.#requireBuddy(buddy).id);
    }
    if (sprint) {
      conditions.push("work_items.sprint_id = ?");
      params.push(this.#requireSprint(sprint).id);
    }
    if (!includeClosed) {
      conditions.push("work_items.status NOT IN ('done', 'cancelled')");
    }
    const where = conditions.length ? `WHERE ${conditions.join(" AND ")}` : "";
    return rows(
      this.db.prepare(`
        SELECT work_items.*, buddies.name AS buddy_name, sprints.name AS sprint_name
        FROM work_items
        LEFT JOIN buddies ON buddies.id = work_items.buddy_id
        LEFT JOIN sprints ON sprints.id = work_items.sprint_id
        ${where}
        ORDER BY work_items.priority DESC, work_items.created_at
      `),
      ...params,
    );
  }

  currentWork(project) {
    const ownerProject = this.#requireProject(project);
    const activeSprint = this.getActiveSprint(ownerProject.id);
    const workItems = activeSprint
      ? this.listWorkItems({ project: ownerProject.id, sprint: activeSprint.id })
      : this.listWorkItems({ project: ownerProject.id });
    return {
      project: ownerProject,
      sprint: activeSprint,
      workItems,
    };
  }

  auditWorkMigration() {
    const summary = this.db
      .prepare(`
        SELECT
          COUNT(*) AS open_legacy,
          SUM(CASE WHEN owned_projects.id IS NOT NULL THEN 1 ELSE 0 END) AS migrated,
          SUM(CASE WHEN owned_projects.id IS NULL THEN 1 ELSE 0 END) AS unmigrated
        FROM work_items
        LEFT JOIN owned_projects
          ON owned_projects.workspace_id = work_items.project_id
          AND owned_projects.external_key = work_items.external_key
        WHERE work_items.status NOT IN ('done', 'cancelled')
      `)
      .get();
    const unmigratedItems = rows(
      this.db.prepare(`
        SELECT work_items.id, work_items.project_id, work_items.buddy_id,
          work_items.external_key, work_items.title, work_items.status
        FROM work_items
        LEFT JOIN owned_projects
          ON owned_projects.workspace_id = work_items.project_id
          AND owned_projects.external_key = work_items.external_key
        WHERE work_items.status NOT IN ('done', 'cancelled')
          AND owned_projects.id IS NULL
        ORDER BY work_items.priority DESC, work_items.created_at
      `),
    );
    return {
      openLegacy: Number(summary.open_legacy) || 0,
      migrated: Number(summary.migrated) || 0,
      unmigrated: Number(summary.unmigrated) || 0,
      unmigratedItems,
    };
  }

  dashboard() {
    const projects = this.listProjects();
    const buddies = this.listBuddies().map((buddy) => ({
      ...buddy,
      projects: this.listBuddyProjects(buddy.id),
      conversations: this.listConversationLinks(buddy.id),
    }));
    const sprints = rows(
      this.db.prepare(`
        SELECT sprints.*, projects.slug AS project_slug
        FROM sprints
        JOIN projects ON projects.id = sprints.project_id
        ORDER BY
          CASE sprints.status WHEN 'active' THEN 0 WHEN 'planned' THEN 1 ELSE 2 END,
          sprints.created_at DESC
      `),
    );
    return {
      projects,
      buddies,
      sprints,
      workItems: this.listWorkItems({ includeClosed: true }),
      buddyOwnedProjects: this.listBuddyOwnedProjects({ includeClosed: true }),
    };
  }

  overview({ recentSince } = {}) {
    const buddies = this.listBuddies();
    const workspaces = this.listProjects();
    const workspaceById = new Map(workspaces.map((workspace) => [workspace.id, workspace]));
    const relationships = rows(
      this.db.prepare(`
        SELECT * FROM buddy_relationships
        WHERE kind IN ('manager', 'reports_to')
        ORDER BY created_at, id
      `),
    );
    const managementPairs = new Map();
    for (const relationship of relationships) {
      const managerId =
        relationship.kind === "manager"
          ? relationship.from_buddy_id
          : relationship.to_buddy_id;
      const reportId =
        relationship.kind === "manager"
          ? relationship.to_buddy_id
          : relationship.from_buddy_id;
      managementPairs.set(`${managerId}:${reportId}`, { managerId, reportId });
    }
    // §5.1. Visibility is a property of the PAIR, not the row, and the gate is on
    // the MANAGER side only. Dropping an edge whose manager is archived lets the
    // report fall back to top_level; without that, archiving a manager leaves its
    // still-active reports in `employees` but out of `topLevel` - invisible in the
    // whole overview and unreachable in the UI, while their automations keep
    // firing. Gating the REPORT side too would be wrong: archived members must stay
    // in `team[]` (they carry `status`, and the client counts with buddyCardMetrics).
    const visibleBuddies = buddies.filter((buddy) => buddy.status !== "archived");
    const visibleIds = new Set(visibleBuddies.map((buddy) => buddy.id));
    // §5.2. Seeded top_level for EVERY buddy so the read in employee() is total: no
    // `?? {kind:"top_level"}`, no nullable local to re-derive.
    const employmentByBuddy = new Map(
      buddies.map((buddy) => [buddy.id, TOP_LEVEL_EMPLOYMENT]),
    );
    const reportsByManager = new Map();
    for (const { managerId, reportId } of managementPairs.values()) {
      if (!visibleIds.has(managerId)) continue;
      const reports = reportsByManager.get(managerId) || new Set();
      reports.add(reportId);
      reportsByManager.set(managerId, reports);
      // First surviving edge wins - the same canonical-manager rule the old
      // managerByReport had. v13's partial unique indexes make in-degree > 1
      // impossible for rows written through the store.
      if (employmentByBuddy.get(reportId).kind === "direct_report") continue;
      employmentByBuddy.set(reportId, { kind: "direct_report", managerId });
    }

    // Deliberately over ALL buddies, not visibleBuddies: `team[]` keeps archived
    // members so the client can count and label them (§12).
    const buddyById = new Map(buddies.map((buddy) => [buddy.id, buddy]));
    const openProjects = this.listBuddyOwnedProjects();
    const workByBuddy = new Map();
    for (const project of openProjects) {
      const work = workByBuddy.get(project.buddy_id) || [];
      work.push(project);
      workByBuddy.set(project.buddy_id, work);
    }
    const employee = (buddy) => {
      const work = workByBuddy.get(buddy.id) || [];
      const reportIds = reportsByManager.get(buddy.id) || new Set();
      return {
        buddy,
        employment: employmentByBuddy.get(buddy.id),
        workspaces: this.listBuddyWorkspaces(buddy.id),
        team: [...reportIds]
          .map((reportId) => buddyById.get(reportId))
          .filter(Boolean)
          .map(({ id: reportId, name, role, status }) => ({
            id: reportId,
            name,
            role,
            status,
          })),
        currentWork: {
          open: work.length,
          active: work.filter((project) => project.status === "in_progress").length,
          blocked: work.filter((project) => project.status === "blocked").length,
          review: work.filter((project) => project.status === "review").length,
          nextActionMissing: work.filter((project) => !project.next_action).length,
        },
      };
    };
    const employees = visibleBuddies.map(employee);
    const cutoff =
      recentSince === undefined
        ? Date.now() - 7 * 24 * 60 * 60 * 1000
        : new Date(recentSince).getTime();
    if (!Number.isFinite(cutoff)) throw new Error("recentSince must be a valid date");
    const recentRuns = [];
    // §5.1. This loop iterates buddies, not employees, so it needs its own filter -
    // otherwise a retired report keeps surfacing in the feed.
    for (const buddy of visibleBuddies) {
      for (const conversation of this.listConversationLinks(buddy.id)) {
        if (new Date(conversation.last_active_at).getTime() < cutoff) continue;
        const workspace = workspaceById.get(conversation.workspace_id);
        recentRuns.push({
          conversationId:
            conversation.unleashd_conversation_id ||
            conversation.provider_session_id ||
            conversation.id,
          buddyId: buddy.id,
          buddyName: buddy.name,
          workspaceId: conversation.workspace_id,
          workspaceName: workspace?.name || "General",
          status: conversation.status,
          lastActiveAt: conversation.last_active_at,
        });
      }
    }
    recentRuns.sort(
      (left, right) =>
        new Date(right.lastActiveAt).getTime() - new Date(left.lastActiveAt).getTime(),
    );
    return {
      generatedAt: now(),
      employees,
      topLevel: employees.filter((item) => item.employment.kind === "top_level"),
      recentRuns,
    };
  }

  getBuddyContext(buddy, { workspace, project } = {}) {
    const ownerBuddy = this.#requireBuddy(buddy);
    const homeWorkspace = this.#requireProject(ownerBuddy.project_id);
    const workspaces = this.listBuddyWorkspaces(ownerBuddy.id);
    const selectedWorkspace = workspace
      ? this.#requireProject(workspace)
      : workspaces.find((item) => item.id === ownerBuddy.project_id) || workspaces[0];
    if (selectedWorkspace && !this.#buddyHasProject(ownerBuddy.id, selectedWorkspace.id)) {
      throw new Error("buddy does not belong to the workspace");
    }
    const selectedProject = project ? this.#requireBuddyProject(project) : null;
    if (selectedProject && selectedProject.buddy_id !== ownerBuddy.id) {
      throw new Error("Buddy project does not belong to the buddy");
    }
    if (selectedProject && selectedWorkspace?.id !== selectedProject.workspace_id) {
      throw new Error("Buddy project does not belong to the workspace");
    }
    let soul = "";
    if (ownerBuddy.soul_path) {
      try {
        soul = readFileSync(
          this.#projectPath(homeWorkspace, ownerBuddy.soul_path),
          "utf8",
        );
      } catch (error) {
        if (error.code !== "ENOENT") throw error;
      }
    }
    const skills = this.listBuddySkills(ownerBuddy.id).map((skill) => ({
      ...skill,
      instruction_path: this.#projectPath(homeWorkspace, skill.instruction_path),
    }));
    return {
      buddy: ownerBuddy,
      relationships: this.listBuddyRelationships(ownerBuddy.id),
      skills,
      workspaces,
      workspace: selectedWorkspace || null,
      sprint: selectedWorkspace ? this.getActiveSprint(selectedWorkspace.id) : null,
      project: selectedProject ? this.getBuddyProject(selectedProject.id) : null,
      projects: selectedWorkspace
        ? this.listBuddyOwnedProjects({
            buddy: ownerBuddy.id,
            workspace: selectedWorkspace.id,
          })
        : [],
      legacyWorkItems: selectedWorkspace
        ? this.listWorkItems({ buddy: ownerBuddy.id, project: selectedWorkspace.id })
        : [],
      soul,
      memory: this.readBuddyMemory(ownerBuddy),
    };
  }

  createAutomation({
    buddy,
    workspace,
    project,
    name,
    scheduleKind,
    scheduleExpression,
    timezone = "UTC",
    jobKind,
    jobPayload,
    policy,
    enabled = true,
    nextRunAt,
  }) {
    const ownerBuddy = this.#requireBuddy(buddy);
    const ownerWorkspace = this.#requireProject(workspace || ownerBuddy.project_id);
    if (!this.#buddyHasProject(ownerBuddy.id, ownerWorkspace.id)) {
      throw new Error("buddy does not belong to the workspace");
    }
    const ownerProject = project ? this.#requireBuddyProject(project) : null;
    if (ownerProject && ownerProject.buddy_id !== ownerBuddy.id) {
      throw new Error("Buddy project does not belong to the buddy");
    }
    if (ownerProject && ownerWorkspace && ownerProject.workspace_id !== ownerWorkspace.id) {
      throw new Error("Buddy project does not belong to the workspace");
    }
    const definition = this.#validateAutomationDefinition({
      scheduleKind,
      scheduleExpression,
      timezone,
      jobKind,
      jobPayload,
    });
    const automationPolicy = this.#validateAutomationPolicy(
      policy,
      definition.jobKind,
      definition.jobPayload,
    );
    const timestamp = now();
    const automationId = id("automation");
    this.#tx(() => {
      this.db
        .prepare(`
          INSERT INTO buddy_automations (
            id, buddy_id, workspace_id, buddy_project_id, name, schedule_kind,
            schedule_expression, timezone, job_kind, job_payload, enabled,
            next_run_at, last_run_at, created_at, updated_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NULL, ?, ?)
        `)
        .run(
          automationId,
          ownerBuddy.id,
          ownerWorkspace.id,
          ownerProject?.id || null,
          required("automation name", name),
          definition.scheduleKind,
          definition.scheduleExpression,
          definition.timezone,
          definition.jobKind,
          JSON.stringify(definition.jobPayload),
          enabled ? 1 : 0,
          nextRunAt ? new Date(nextRunAt).toISOString() : null,
          timestamp,
          timestamp,
        );
      this.#insertAutomationPolicy(automationId, automationPolicy, timestamp);
    });
    return this.getAutomation(automationId);
  }

  getAutomation(automation) {
    const row =
      typeof automation === "object" && automation?.id
        ? automation
        : this.db.prepare("SELECT * FROM buddy_automations WHERE id = ?").get(automation);
    return row ? this.#automationRow(row) : null;
  }

  listAutomations({ buddy, enabled, includeArchived = false } = {}) {
    const conditions = [];
    const params = [];
    if (buddy) {
      conditions.push("buddy_id = ?");
      params.push(this.#requireBuddy(buddy).id);
    }
    if (enabled !== undefined) {
      conditions.push("enabled = ?");
      params.push(enabled ? 1 : 0);
    }
    if (!includeArchived) {
      conditions.push("archived_at IS NULL");
    }
    return rows(
      this.db.prepare(`
        SELECT * FROM buddy_automations
        ${conditions.length ? `WHERE ${conditions.join(" AND ")}` : ""}
        ORDER BY created_at
      `),
      ...params,
    ).map((row) => this.#automationRow(row));
  }

  updateAutomation(automation, changes = {}) {
    const current = this.#requireAutomation(automation);
    if (current.archived_at) {
      throw new Error("archived automation definitions are immutable");
    }
    const definition = this.#validateAutomationDefinition({
      scheduleKind: changes.scheduleKind ?? current.schedule_kind,
      scheduleExpression: changes.scheduleExpression ?? current.schedule_expression,
      timezone: changes.timezone ?? current.timezone,
      jobKind: changes.jobKind ?? current.job_kind,
      jobPayload: changes.jobPayload ?? current.job_payload,
    });
    const automationPolicy = this.#validateAutomationPolicy(
      changes.policy,
      definition.jobKind,
      definition.jobPayload,
      current.policy,
    );
    const nextRunAt =
      changes.nextRunAt === undefined
        ? current.next_run_at
        : changes.nextRunAt
          ? new Date(changes.nextRunAt).toISOString()
          : null;
    const timestamp = now();
    this.#tx(() => {
      this.db
        .prepare(`
          UPDATE buddy_automations SET
            name = ?, schedule_kind = ?, schedule_expression = ?, timezone = ?,
            job_kind = ?, job_payload = ?, enabled = ?, next_run_at = ?, updated_at = ?
          WHERE id = ?
        `)
        .run(
          changes.name === undefined ? current.name : required("automation name", changes.name),
          definition.scheduleKind,
          definition.scheduleExpression,
          definition.timezone,
          definition.jobKind,
          JSON.stringify(definition.jobPayload),
          changes.enabled === undefined ? (current.enabled ? 1 : 0) : changes.enabled ? 1 : 0,
          nextRunAt,
          timestamp,
          current.id,
        );
      this.db
        .prepare(`
          UPDATE buddy_automation_policies SET
            max_runtime_seconds = ?, max_iterations = ?, max_tokens = ?,
            max_cost_usd = ?, allowed_operations = ?, updated_at = ?
          WHERE automation_id = ?
        `)
        .run(
          automationPolicy.max_runtime_seconds,
          automationPolicy.max_iterations,
          automationPolicy.max_tokens,
          automationPolicy.max_cost_usd,
          JSON.stringify(automationPolicy.allowed_operations),
          timestamp,
          current.id,
        );
    });
    return this.getAutomation(current.id);
  }

  deleteAutomation(automation) {
    return this.archiveAutomation(automation);
  }

  archiveAutomation(automation) {
    const current = this.#requireAutomation(automation);
    if (current.archived_at) return current;
    const timestamp = now();
    // "Delete" is deliberately an archive operation. The definition owns the
    // immutable execution ledger through a foreign key, so physical deletion
    // would erase the evidence needed to explain prior Buddy actions. See
    // agent_notes/2026-08-24_automation-execution-ownership-design.md.
    this.db
      .prepare(`
        UPDATE buddy_automations
        SET enabled = 0, next_run_at = NULL, archived_at = ?, updated_at = ?
        WHERE id = ?
      `)
      .run(timestamp, timestamp, current.id);
    return this.getAutomation(current.id);
  }

  /**
   * §10.1. `enabled = 0` (set by retire) was the ONLY thing keeping a retired
   * Buddy's schedule quiet - zero defence in depth. updateBuddy never touches
   * automations, so a *paused* Buddy kept firing, and re-enabling an archived
   * identity resurrected its schedule.
   *
   * `buddy_automations.*` rather than `*` is load-bearing: across this join a bare
   * `*` returns buddies.id LAST, so the row's `id` becomes the buddy id and
   * #automationRow then throws "automation policy not found". `created_at` would be
   * clobbered too. `buddy_automations.buddy_id` is NOT NULL REFERENCES buddies(id),
   * so the INNER JOIN cannot lose a legitimate row.
   */
  listDueAutomations(at = new Date()) {
    const due = at instanceof Date ? at.toISOString() : new Date(at).toISOString();
    return rows(
      this.db.prepare(`
        SELECT buddy_automations.*
        FROM buddy_automations
        JOIN buddies ON buddies.id = buddy_automations.buddy_id
        WHERE buddies.status = 'active'
          AND buddy_automations.enabled = 1
          AND buddy_automations.next_run_at IS NOT NULL
          AND buddy_automations.next_run_at <= ?
        ORDER BY buddy_automations.next_run_at, buddy_automations.created_at
      `),
      due,
    ).map((row) => this.#automationRow(row));
  }

  claimAutomationRun(
    automation,
    { scheduledFor, idempotencyKey, claimToken, leaseSeconds } = {},
  ) {
    const ownerAutomation = this.#requireAutomation(automation);
    const occurrence = scheduledFor || ownerAutomation.next_run_at || now();
    const scheduled = new Date(occurrence).toISOString();
    const key = idempotencyKey?.trim() || `${ownerAutomation.id}:${scheduled}`;
    const timestamp = now();
    const runId = id("automation_run");
    const token = claimToken?.trim() || id("automation_claim");
    const requestedLeaseSeconds =
      leaseSeconds === undefined
        ? ownerAutomation.policy.max_runtime_seconds + 60
        : Number(leaseSeconds);
    if (!Number.isInteger(requestedLeaseSeconds) || requestedLeaseSeconds < 1) {
      throw new Error("automation claim lease seconds must be a positive integer");
    }
    const claimExpiresAt = new Date(
      Date.parse(timestamp) + requestedLeaseSeconds * 1000,
    ).toISOString();
    let blockedBy = null;
    this.#tx(() => {
      const active = this.db
        .prepare(`
          SELECT * FROM buddy_automation_runs
          WHERE automation_id = ? AND status IN ('claimed', 'running', 'cancel_requested')
          ORDER BY claimed_at
          LIMIT 1
        `)
        .get(ownerAutomation.id);
      if (active) {
        // We intentionally do not transfer an expired lease. Without a durable
        // worker/adoption protocol the old process may still be alive, and a
        // takeover would create two writers with plausible authority. Recovery
        // closes the old occurrence; it never replays it. See
        // agent_notes/2026-08-24_automation-execution-ownership-design.md.
        if (
          !active.claim_token ||
          !active.claim_expires_at ||
          active.claim_expires_at <= timestamp
        ) {
          this.db
            .prepare(`
              UPDATE buddy_automation_runs
              SET status = 'failed', error = ?, ended_at = ?
              WHERE id = ? AND status IN ('claimed', 'running', 'cancel_requested')
            `)
            .run("Automation interrupted after its executor lease expired", timestamp, active.id);
          this.db
            .prepare(`
              UPDATE buddy_automations
              SET last_run_at = ?, updated_at = ?
              WHERE id = ?
            `)
            .run(timestamp, timestamp, ownerAutomation.id);
          blockedBy = active.id;
          return;
        }
        blockedBy = active.id;
        return;
      }
      const inserted = this.db
        .prepare(`
          INSERT INTO buddy_automation_runs (
            id, automation_id, scheduled_for, idempotency_key, status,
            conversation_id, iteration, outcome, error, claimed_at, started_at, ended_at,
            claim_token, claim_expires_at
          ) VALUES (?, ?, ?, ?, 'claimed', NULL, 0, NULL, NULL, ?, NULL, NULL, ?, ?)
          ON CONFLICT(idempotency_key) DO NOTHING
        `)
        .run(runId, ownerAutomation.id, scheduled, key, timestamp, token, claimExpiresAt);
      if (inserted.changes === 1) {
        this.db
          .prepare(`
            INSERT INTO buddy_automation_run_policies (
              run_id, max_runtime_seconds, max_iterations, max_tokens,
              max_cost_usd, allowed_operations, tokens_used, cost_usd
            ) VALUES (?, ?, ?, ?, ?, ?, 0, 0)
          `)
          .run(
            runId,
            ownerAutomation.policy.max_runtime_seconds,
            ownerAutomation.policy.max_iterations,
            ownerAutomation.policy.max_tokens,
            ownerAutomation.policy.max_cost_usd,
            JSON.stringify(ownerAutomation.policy.allowed_operations),
          );
      }
    });
    if (blockedBy) {
      return { ...this.getAutomationRun(blockedBy), claim_acquired: false };
    }
    const claimed = this.getAutomationRunByIdempotencyKey(key);
    if (claimed?.automation_id !== ownerAutomation.id) {
      throw new Error("idempotency key is already claimed by another automation");
    }
    return {
      ...claimed,
      claim_acquired: claimed.claim_token === token,
    };
  }

  getAutomationRun(run) {
    const row =
      typeof run === "object" && run?.id
        ? run
        : this.db.prepare("SELECT * FROM buddy_automation_runs WHERE id = ?").get(run);
    return row ? this.#automationRunRow(row) : null;
  }

  getAutomationRunByIdempotencyKey(key) {
    const row = this.db
      .prepare("SELECT * FROM buddy_automation_runs WHERE idempotency_key = ?")
      .get(required("idempotency key", key));
    return row ? this.#automationRunRow(row) : null;
  }

  updateAutomationRun(run, {
    status,
    conversationId,
    iteration,
    outcome,
    error,
    nextRunAt,
    tokensUsed,
    costUsd,
    claimToken,
  }) {
    const current = this.#requireAutomationRun(run);
    assertOneOf("automation run status", status, AUTOMATION_RUN_STATUSES);
    if (current.claim_token && claimToken !== current.claim_token) {
      throw new Error("automation run claim is not owned by this executor");
    }
    const terminalStatuses = ["complete", "failed", "cancelled"];
    if (terminalStatuses.includes(current.status)) {
      if (status !== current.status) {
        throw new Error(
          `terminal automation run cannot transition from ${current.status} to ${status}`,
        );
      }
      // Recovery terminalizes an expired occurrence inside claimAutomationRun,
      // then the scheduler computes the schedule-kind-specific next occurrence.
      // Permit that one idempotent terminal write; never reopen the run itself.
      if (nextRunAt === undefined) return current;
    }
    if (
      current.status === "cancel_requested" &&
      !["cancelled", "failed"].includes(status)
    ) {
      throw new Error(
        `cancel-requested automation run cannot transition to ${status}`,
      );
    }
    const timestamp = now();
    const startedAt =
      status === "running" ? current.started_at || timestamp : current.started_at;
    const endedAt = terminalStatuses.includes(status)
      ? current.ended_at || timestamp
      : null;
    const nextIteration =
      iteration === undefined ? current.iteration : Math.max(0, Number(iteration) || 0);
    const nextTokensUsed =
      tokensUsed === undefined ? current.tokens_used : Number(tokensUsed);
    const nextCostUsd = costUsd === undefined ? current.cost_usd : Number(costUsd);
    if (!Number.isInteger(nextTokensUsed) || nextTokensUsed < 0) {
      throw new Error("automation tokens used must be a non-negative integer");
    }
    if (!Number.isFinite(nextCostUsd) || nextCostUsd < 0) {
      throw new Error("automation cost used must be non-negative");
    }
    if (nextIteration < current.iteration) {
      throw new Error("automation iteration cannot decrease");
    }
    if (nextTokensUsed < current.tokens_used) {
      throw new Error("automation tokens used cannot decrease");
    }
    if (nextCostUsd < current.cost_usd) {
      throw new Error("automation cost used cannot decrease");
    }
    if (nextIteration > current.policy.max_iterations) {
      throw new Error("automation iteration budget exceeded");
    }
    if (nextTokensUsed > current.policy.max_tokens) {
      throw new Error("automation token budget exceeded");
    }
    if (nextCostUsd > current.policy.max_cost_usd) {
      throw new Error("automation cost budget exceeded");
    }
    if (
      status === "running" &&
      startedAt &&
      Date.parse(timestamp) - Date.parse(startedAt) >
        current.policy.max_runtime_seconds * 1000
    ) {
      throw new Error("automation runtime budget exceeded");
    }
    this.#tx(() => {
      this.db
        .prepare(`
          UPDATE buddy_automation_runs SET
            status = ?, conversation_id = ?, iteration = ?, outcome = ?,
            error = ?, started_at = ?, ended_at = ?
          WHERE id = ?
        `)
        .run(
          status,
          conversationId === undefined ? current.conversation_id : conversationId || null,
          nextIteration,
          outcome === undefined ? current.outcome : outcome || null,
          error === undefined ? current.error : error || null,
          startedAt,
          endedAt,
          current.id,
        );
      this.db
        .prepare(`
          UPDATE buddy_automation_run_policies
          SET tokens_used = ?, cost_usd = ?
          WHERE run_id = ?
        `)
        .run(nextTokensUsed, nextCostUsd, current.id);
      if (terminalStatuses.includes(status)) {
        const automation = this.#requireAutomation(current.automation_id);
        const scheduledNextRun =
          nextRunAt === undefined
            ? automation.next_run_at
            : nextRunAt
              ? new Date(nextRunAt).toISOString()
              : null;
        this.db
          .prepare(`
            UPDATE buddy_automations
            SET last_run_at = ?, next_run_at = ?, updated_at = ?
            WHERE id = ?
          `)
          .run(
            timestamp,
            scheduledNextRun,
            timestamp,
            current.automation_id,
          );
      }
    });
    return this.getAutomationRun(current.id);
  }

  listAutomationRuns(automation, { limit = 50 } = {}) {
    const ownerAutomation = this.#requireAutomation(automation);
    return rows(
      this.db.prepare(`
        SELECT * FROM buddy_automation_runs
        WHERE automation_id = ?
        ORDER BY claimed_at DESC
        LIMIT ?
      `),
      ownerAutomation.id,
      Math.max(1, Number(limit) || 50),
    ).map((row) => this.#automationRunRow(row));
  }

  getAutomationRunByConversationId(conversationId) {
    const value = required("conversation id", conversationId);
    const row = this.db
      .prepare("SELECT * FROM buddy_automation_runs WHERE conversation_id = ? LIMIT 1")
      .get(value);
    return row ? this.#automationRunRow(row) : null;
  }

  listNonterminalAutomationRuns() {
    return rows(
      this.db.prepare(`
        SELECT * FROM buddy_automation_runs
        WHERE status IN ('claimed', 'running', 'cancel_requested')
        ORDER BY claimed_at, id
      `),
    ).map((row) => this.#automationRunRow(row));
  }

  assertAutomationOperationAllowed(run, operation, claimToken) {
    const ownerRun = this.#requireAutomationRun(run);
    const name = required("automation operation", operation);
    // The operation allowlist is only half the authority decision. A saved
    // conversation is durable, but execution authority is not: terminal,
    // cancelled and expired runs must never regain mutation rights on resume.
    // See agent_notes/2026-08-24_automation-execution-ownership-design.md.
    if (ownerRun.status !== "running") {
      throw new Error(`automation run is not active: ${ownerRun.status}`);
    }
    if (!ownerRun.claim_token || ownerRun.claim_token !== claimToken) {
      throw new Error("automation run claim is not owned by this executor");
    }
    if (
      !ownerRun.claim_expires_at ||
      Date.parse(ownerRun.claim_expires_at) <= Date.now()
    ) {
      throw new Error("automation run authority has expired");
    }
    if (!ownerRun.policy.allowed_operations.includes(name)) {
      throw new Error(`automation operation is not allowed: ${name}`);
    }
    return true;
  }

  withAutomationRunAuthority(run, operation, claimToken, callback) {
    if (typeof callback !== "function") throw new Error("automation callback is required");
    // The authority read and every synchronous store mutation in callback share
    // one BEGIN IMMEDIATE transaction. The second assertion prevents callback
    // code from terminalising its own run and then committing a mutation. Never
    // accept a Promise here: a database write lock is not an async mutex.
    // See agent_notes/2026-08-24_automation-execution-ownership-design.md I2.
    return this.#tx(() => {
      this.assertAutomationOperationAllowed(run, operation, claimToken);
      const result = callback();
      if (result && typeof result.then === "function") {
        throw new Error("automation authority callbacks must be synchronous");
      }
      this.assertAutomationOperationAllowed(run, operation, claimToken);
      return result;
    });
  }

  linkConversation({
    buddy,
    workspace,
    project,
    workItem,
    provider,
    providerSessionId,
    unleashdConversationId,
    status = "active",
  }) {
    assertOneOf("conversation status", status, CONVERSATION_STATUSES);
    if (!providerSessionId && !unleashdConversationId) {
      throw new Error("provider session id or Unleashd conversation id is required");
    }
    const ownerBuddy = this.#requireBuddy(buddy);
    const item = workItem ? this.#requireWorkItem(workItem) : null;
    const ownerProject = project ? this.#requireBuddyProject(project) : null;
    if (ownerProject && ownerProject.buddy_id !== ownerBuddy.id) {
      throw new Error("Buddy project does not belong to the buddy");
    }
    const ownerWorkspace = this.#requireProject(
      workspace || ownerProject?.workspace_id || item?.project_id || ownerBuddy.project_id,
    );
    this.#requireBuddy(ownerBuddy, ownerWorkspace);
    if (item && item.project_id !== ownerWorkspace.id) {
      throw new Error("legacy work item does not belong to the conversation workspace");
    }
    if (ownerProject && ownerProject.workspace_id !== ownerWorkspace.id) {
      throw new Error("Buddy project does not belong to the conversation workspace");
    }
    const timestamp = now();
    const link = {
      id: id("conversation"),
      buddyId: ownerBuddy.id,
      workspaceId: ownerWorkspace.id,
      buddyProjectId: ownerProject?.id || null,
      workItemId: item?.id || null,
      provider: required("provider", provider),
      providerSessionId: providerSessionId || null,
      unleashdConversationId: unleashdConversationId || null,
      status,
      startedAt: timestamp,
      lastActiveAt: timestamp,
      endedAt: status === "active" ? null : timestamp,
    };
    this.db
      .prepare(`
        INSERT INTO conversation_links (
          id, buddy_id, workspace_id, buddy_project_id, work_item_id, provider, provider_session_id,
          unleashd_conversation_id, status, started_at, last_active_at, ended_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `)
      .run(
        link.id,
        link.buddyId,
        link.workspaceId,
        link.buddyProjectId,
        link.workItemId,
        link.provider,
        link.providerSessionId,
        link.unleashdConversationId,
        link.status,
        link.startedAt,
        link.lastActiveAt,
        link.endedAt,
      );
    return this.getConversationLink(link.id);
  }

  updateConversationLink(idOrConversationId, {
    status,
    providerSessionId,
  } = {}) {
    const current = this.db
      .prepare(`
        SELECT * FROM conversation_links
        WHERE id = ? OR unleashd_conversation_id = ? OR provider_session_id = ?
      `)
      .get(idOrConversationId, idOrConversationId, idOrConversationId);
    if (!current) throw new Error(`conversation link not found: ${idOrConversationId}`);
    const nextStatus = status || current.status;
    assertOneOf("conversation status", nextStatus, CONVERSATION_STATUSES);
    const timestamp = now();
    this.db
      .prepare(`
        UPDATE conversation_links SET
          status = ?, provider_session_id = COALESCE(?, provider_session_id),
          last_active_at = ?, ended_at = ?
        WHERE id = ?
      `)
      .run(
        nextStatus,
        providerSessionId || null,
        timestamp,
        nextStatus === "active" ? null : timestamp,
        current.id,
      );
    return this.getConversationLink(current.id);
  }

  getConversationLink(id) {
    const row = this.db.prepare("SELECT * FROM conversation_links WHERE id = ?").get(id);
    return row ? { ...row } : null;
  }

  listConversationLinks(buddy) {
    const ownerBuddy = this.#requireBuddy(buddy);
    return rows(
      this.db.prepare(`
        SELECT * FROM conversation_links
        WHERE buddy_id = ?
        ORDER BY last_active_at DESC
      `),
      ownerBuddy.id,
    );
  }

  // ------------------------------------------------------------------
  // Direct reports (sub-buddies).
  // Design: unleashd agent_notes/2026-08-19_sub-buddies-design.md
  //         SS7.5, 8.1, 8.4, 8.5, 9.1-9.4.
  // ------------------------------------------------------------------

  /**
   * §7.5. UNION, never UNION ALL: `manager A->B` and `reports_to B->A` are two
   * distinct rows under UNIQUE(from_buddy_id, to_buddy_id, kind) that denote ONE
   * relationship, and overview() dedupes exactly this pair. UNION ALL double-counts,
   * and then the directory badge and the quota disagree.
   *
   * `status <> 'archived'` (not `= 'active'`): §8.2, a paused report holds a seat,
   * otherwise a manager pauses two, hires two more, and unpauses.
   */
  countHeldDirectReports(manager) {
    const managerId = this.#requireBuddy(manager).id;
    return this.db
      .prepare(`
        SELECT COUNT(*) AS held
        FROM (
          SELECT to_buddy_id   AS report_id FROM buddy_relationships
           WHERE kind = 'manager'    AND from_buddy_id = ?
          UNION
          SELECT from_buddy_id AS report_id FROM buddy_relationships
           WHERE kind = 'reports_to' AND to_buddy_id   = ?
        ) AS reports
        JOIN buddies ON buddies.id = reports.report_id
        WHERE buddies.status <> 'archived'
      `)
      .get(managerId, managerId).held;
  }

  /**
   * §9.1. The canonicalizer (kappa) for hire: the ONLY place that inspects buddy
   * rows. Every hire handler downstream is one clean path over the returned sum.
   *
   * §8.5 - the lookup MUST be `project_id = ? AND slug = ?`, the real
   * UNIQUE(project_id, slug) constraint. `getBuddy(slug, workspace)` joins
   * buddy_projects (assignment, not home) and is wrong in both directions:
   *   - false 409: a Buddy homed in W1 and also assigned to W2 makes hire(name, W2)
   *     report "name taken" although the INSERT would succeed;
   *   - missed collision: an archived `scout` homed in W1 is invisible to
   *     getBuddy('scout', W2), the create path runs, two rows share the slug, and
   *     every bare getBuddy('scout') throws "ambiguous across workspaces" forever.
   */
  resolveHireTarget(manager, slug, workspace) {
    const managerBuddy = this.#requireBuddy(manager);
    const homeWorkspace = this.#requireProject(workspace);
    const row = this.db
      .prepare("SELECT * FROM buddies WHERE project_id = ? AND slug = ?")
      .get(homeWorkspace.id, slug);
    if (!row) return { kind: "vacant" };
    const sub = { ...row };
    const employment = this.#employmentOf(sub.id);
    if (employment.kind === "top_level") {
      return { kind: "slug_owned_by_top_level", sub };
    }
    if (employment.managerId !== managerBuddy.id) {
      return { kind: "held_elsewhere", sub, managerId: employment.managerId };
    }
    return sub.status === "archived"
      ? { kind: "reactivatable", sub }
      : { kind: "held", sub };
  }

  /**
   * §5.2. Employment as a sum, not `managerId: string | null`. `null` was doing two
   * jobs (who manages this / does this show in the directory) and that is the origin
   * of the "archive the manager and the active report vanishes" bug.
   *
   * UNION ALL here is correct and deliberate - the opposite of
   * countHeldDirectReports. We want the EARLIEST edge overall, and both encodings of
   * one relationship yield the same manager_id, so duplicates cannot change a
   * LIMIT 1 answer. `ORDER BY created_at, id`: created_at is millisecond ISO, ties
   * have no stable order and can flip after `VACUUM INTO` (backupDatabase), which
   * would make the canonical manager nondeterministic (§8.3).
   */
  #employmentOf(buddyId) {
    const row = this.db
      .prepare(`
        SELECT manager_id FROM (
          SELECT from_buddy_id AS manager_id, created_at, id FROM buddy_relationships
           WHERE kind = 'manager'    AND to_buddy_id   = ?
          UNION ALL
          SELECT to_buddy_id   AS manager_id, created_at, id FROM buddy_relationships
           WHERE kind = 'reports_to' AND from_buddy_id = ?
        )
        ORDER BY created_at, id
        LIMIT 1
      `)
      .get(buddyId, buddyId);
    return row
      ? { kind: "direct_report", managerId: row.manager_id }
      : { kind: "top_level" };
  }

  /**
   * §9.2. Thin dispatch over HireTarget; five handlers, one semantic path each.
   * Seats are consumed by TRANSITIONS, not by calls (§8.1): only `vacant` and
   * `reactivatable` assert the quota. `held` must not, or an idempotent replay
   * breaks the moment the Owner lowers hire_quota below current headcount (B6).
   */
  hireDirectReport({
    managerBuddy,
    name,
    role,
    soul,
    workspace,
    additionalWorkspaces = [],
    provider,
    model,
    reasoningEffort,
  }) {
    const manager = this.#requireBuddy(managerBuddy);
    if (manager.status !== "active") {
      throw new Error(
        `only an active Buddy can hire: ${manager.slug} is ${manager.status}`,
      );
    }
    const homeWorkspace = this.#requireProject(workspace);
    const extraWorkspaces = additionalWorkspaces
      .map((candidate) => this.#requireProject(candidate))
      .filter(
        (candidate, index, all) =>
          candidate.id !== homeWorkspace.id &&
          all.findIndex((other) => other.id === candidate.id) === index,
      );
    // A manager can only staff workspaces it is in: assignBuddyToProject is
    // unguarded, so without this a report lands where its manager cannot follow.
    const managerWorkspaceIds = new Set(
      this.listBuddyWorkspaces(manager.id).map((entry) => entry.id),
    );
    for (const candidate of [homeWorkspace, ...extraWorkspaces]) {
      if (!managerWorkspaceIds.has(candidate.id)) {
        throw new Error(
          `manager ${manager.slug} is not assigned to workspace ${candidate.slug}`,
        );
      }
    }
    const slug = slugify(name);
    // §8.4. slugify() returns "" for "...", "!!!", "---", "..", an emoji - required()
    // passes because the INPUT was non-empty. `profiles/${""}/BUDDY_SOUL.md` then
    // normalises to `<workspace>/profiles/BUDDY_SOUL.md` and the post-commit rename
    // targets the profiles/ DIRECTORY ITSELF. Assert before any filesystem work, and
    // name `name` (what the caller passed), not `slug` (what we derived).
    if (!DIRECT_REPORT_SLUG_RE.test(slug)) {
      throw new Error(
        `name must reduce to a slug matching ${DIRECT_REPORT_SLUG_RE}: ${JSON.stringify(name)}`,
      );
    }
    const soulBody = required("direct report soul", soul);
    if (Buffer.byteLength(soulBody, "utf8") > MAX_DIRECT_REPORT_SOUL_BYTES) {
      throw new Error(
        `direct report soul exceeds ${MAX_DIRECT_REPORT_SOUL_BYTES} bytes`,
      );
    }
    const roleValue = required("direct report role", role);
    // §4. A Buddy with no soul and no memory path is not a direct report: its
    // briefing renders "(No Buddy soul has been configured.)" and every
    // buddy.remember throws. hire OWNS profiles/<slug>/ and provisions both.
    const soulPath = `profiles/${slug}/BUDDY_SOUL.md`;
    const memoryPath = `profiles/${slug}/memory`;
    // §9.3. Stage first, rename after COMMIT. Writing the final path before BEGIN
    // with flag 'wx' wedges the slug on a crash with an EEXIST that names the
    // filesystem instead of the problem.
    const staging = this.#stageDirectReportProfile(homeWorkspace, {
      slug,
      soul: soulBody,
      manager,
    });

    let result;
    try {
      result = this.#tx(() => {
        const target = this.resolveHireTarget(manager, slug, homeWorkspace);
        // B4. The quota read is INSIDE the transaction. BEGIN IMMEDIATE serialises
        // writes, not a decision taken on a read from before the transaction
        // opened; two MCP processes would otherwise both see 0 < 1 and both insert.
        const held = this.countHeldDirectReports(manager.id);
        const context = {
          manager,
          held,
          slug,
          name,
          role: roleValue,
          homeWorkspace,
          extraWorkspaces,
          soulPath,
          memoryPath,
          provider,
          model,
          reasoningEffort,
        };
        switch (target.kind) {
          case "vacant":
            return this.#hireVacant(context);
          case "reactivatable":
            return this.#hireReactivatable(context, target.sub);
          case "held":
            return this.#hireHeld(context, target.sub);
          case "held_elsewhere":
            return this.#hireHeldElsewhere(context, target);
          case "slug_owned_by_top_level":
            return this.#hireSlugOwnedByTopLevel(context, target.sub);
          default:
            throw new Error(`unhandled hire target: ${target.kind}`);
        }
      });
    } catch (error) {
      this.#discardStagedProfile(staging);
      throw error;
    }
    // §9.3. This rename does NOT close the COMMIT -> rename window; a crash here
    // still leaves "row, no profile", which is silent (getBuddyContext swallows
    // ENOENT on the soul read) and permanent (re-hire takes the `held` arm). The
    // window is closed by #repairProfile in the held / reactivatable handlers.
    switch (result.profile.kind) {
      case "promote":
        this.#promoteStagedProfile(staging, this.#profileDir(homeWorkspace, slug));
        break;
      case "discard":
        this.#discardStagedProfile(staging);
        break;
      default:
        throw new Error(`unhandled staged profile action: ${result.profile.kind}`);
    }
    return { buddy: this.getBuddy(result.buddy.id), outcome: result.outcome };
  }

  /**
   * §8.1/§8.2. hire_quota is a CONCURRENT HEADCOUNT ceiling, not a lifetime budget
   * and not a depth rule: retiring frees the seat, and the Owner may fund a report.
   *
   * The integer guard is not reachable through the store after v13 (the column is
   * NOT NULL DEFAULT 0 CHECK >= 0) but §10 path 2 - a direct SQLite write by any
   * process running as the agent's uid - is real, and `held >= null` is `false`,
   * i.e. an unfunded manager would hire without limit. Refuse loudly instead.
   */
  #assertSeatAvailable(manager, held) {
    const quota = manager.hire_quota;
    if (!Number.isInteger(quota)) {
      throw new Error(
        `${manager.slug} has no hire quota; the Owner must set hire_quota before it can hire`,
      );
    }
    if (held >= quota) {
      throw new Error(
        `hire quota exceeded: ${manager.slug} already holds ${held} of ${quota} direct reports`,
      );
    }
  }

  #hireVacant(context) {
    this.#assertSeatAvailable(context.manager, context.held);
    const sub = this.createBuddy({
      project: context.homeWorkspace,
      name: context.name,
      role: context.role,
      slug: context.slug,
      status: "active",
      soulPath: context.soulPath,
      memoryPath: context.memoryPath,
      provider: context.provider,
      model: context.model,
      reasoningEffort: context.reasoningEffort,
      hireQuota: 0,
    });
    for (const extra of context.extraWorkspaces) {
      this.assignBuddyToProject({
        buddy: sub.id,
        project: extra.id,
        role: context.role,
      });
    }
    this.setBuddyRelationship({
      fromBuddy: context.manager.id,
      toBuddy: sub.id,
      kind: "manager",
    });
    this.recordAuditEvent({
      buddy: sub.id,
      workspace: context.homeWorkspace.id,
      operation: "buddy.hire_direct_report",
      payload: {
        managerId: context.manager.id,
        slug: context.slug,
        role: context.role,
      },
    });
    return { buddy: sub, outcome: "hired", profile: { kind: "promote" } };
  }

  #hireReactivatable(context, sub) {
    this.#assertSeatAvailable(context.manager, context.held);
    // Deliberately asymmetric with retire (§9.4): retire disables automations,
    // reactivate does NOT re-enable them. A report returning after weeks must not
    // fire a schedule written against a world that has moved on.
    const reactivated = this.updateBuddy(sub.id, {
      status: "active",
      role: context.role,
    });
    for (const extra of context.extraWorkspaces) {
      this.assignBuddyToProject({
        buddy: sub.id,
        project: extra.id,
        role: context.role,
      });
    }
    this.recordAuditEvent({
      buddy: sub.id,
      workspace: context.homeWorkspace.id,
      operation: "buddy.reactivate_direct_report",
      payload: {
        managerId: context.manager.id,
        slug: context.slug,
        role: context.role,
      },
    });
    return {
      buddy: reactivated,
      outcome: "reactivated",
      profile: this.#repairProfile(context, sub),
    };
  }

  #hireHeld(context, sub) {
    // §8.1: no quota assert here. The seat is already held, so a replay must still
    // succeed after the Owner lowers hire_quota (B6).
    return {
      buddy: sub,
      outcome: "unchanged",
      profile: this.#repairProfile(context, sub),
    };
  }

  #hireHeldElsewhere(context, target) {
    const other = this.#requireBuddy(target.managerId);
    throw new Error(
      `slug ${context.slug} in workspace ${context.homeWorkspace.slug} is already a direct report of ${other.slug}`,
    );
  }

  #hireSlugOwnedByTopLevel(context, sub) {
    throw new Error(
      `slug ${context.slug} in workspace ${context.homeWorkspace.slug} belongs to top-level Buddy ${sub.name} (${sub.id})`,
    );
  }

  /**
   * §9.3 repair path. The invariant is "hire owns profiles/<slug>/", so the row's
   * paths are restated unconditionally (one statement, no branch) and the soul is
   * re-materialized when it is missing or empty. This is the ONLY thing that ever
   * fixes a post-crash "row committed, profile never renamed" state: memory
   * self-heals (remember() mkdirs), the row is active so re-hire lands on `held`,
   * and the briefing just renders "(No Buddy soul has been configured.)" forever.
   */
  #repairProfile(context, sub) {
    const timestamp = now();
    this.db
      .prepare(
        "UPDATE buddies SET soul_path = ?, memory_path = ?, updated_at = ? WHERE id = ?",
      )
      .run(
        this.#projectPath(context.homeWorkspace, context.soulPath),
        this.#projectPath(context.homeWorkspace, context.memoryPath),
        timestamp,
        sub.id,
      );
    const soulState = this.#soulState(
      this.#projectPath(context.homeWorkspace, context.soulPath),
    );
    return PROFILE_ACTION_BY_SOUL_STATE[soulState.kind];
  }

  #soulState(absolutePath) {
    try {
      return readFileSync(absolutePath, "utf8").trim() === ""
        ? { kind: "absent" }
        : { kind: "materialized" };
    } catch (error) {
      if (error.code === "ENOENT" || error.code === "EISDIR") {
        return { kind: "absent" };
      }
      throw error;
    }
  }

  #profileDir(workspace, slug) {
    // #containedPath, not join(): staging and promotion run inside the store, so
    // they get the same containment check as every other Buddy-authored path.
    return this.#containedPath(workspace.root_path, "profiles", slug);
  }

  #stageDirectReportProfile(workspace, { slug, soul, manager }) {
    const dir = this.#containedPath(
      workspace.root_path,
      "profiles",
      ".staging",
      randomUUID(),
    );
    mkdirSync(join(dir, "memory"), { recursive: true });
    // §11: the soul is LLM-authored text spliced verbatim into a system prompt and
    // written to a git-tracked file. Stamp provenance so an Owner reading a diff can
    // tell it was not hand-written.
    const header = [
      "<!--",
      `  authored_by: ${manager.slug} (${manager.id})`,
      `  at: ${now()}`,
      `  hired_as: ${slug}`,
      "-->",
      "",
    ].join("\n");
    writeFileSync(join(dir, "BUDDY_SOUL.md"), `${header}${soul}\n`, "utf8");
    return dir;
  }

  /**
   * Promote by renaming the FILE, never the directory. `renameSync(staging, final)`
   * fails ENOTEMPTY when profiles/<slug>/ already exists, and clearing it first
   * would delete profiles/<slug>/memory - the one thing a retire/re-hire cycle must
   * preserve. Same filesystem, so the file rename is still atomic.
   */
  #promoteStagedProfile(staging, profileDir) {
    mkdirSync(profileDir, { recursive: true });
    renameSync(join(staging, "BUDDY_SOUL.md"), join(profileDir, "BUDDY_SOUL.md"));
    mkdirSync(join(profileDir, "memory"), { recursive: true });
    this.#discardStagedProfile(staging);
  }

  #discardStagedProfile(staging) {
    rmSync(staging, { recursive: true, force: true });
  }

  /**
   * §9.3(2). A crash before COMMIT orphans profiles/.staging/<uuid>/ forever.
   * Age-gated because a concurrent hire in another process owns a fresh staging dir
   * and this runs on every store open. Failures are kept as data rather than
   * swallowed (T4) and rather than bricking every store open.
   */
  #gcStagedProfiles() {
    const cutoff = Date.now() - STAGING_GC_MIN_AGE_MS;
    for (const workspace of this.listProjects()) {
      const root = join(workspace.root_path, "profiles", ".staging");
      try {
        if (!existsSync(root)) continue;
        for (const entry of readdirSync(root)) {
          const candidate = join(root, entry);
          if (statSync(candidate).mtimeMs > cutoff) continue;
          rmSync(candidate, { recursive: true, force: true });
        }
      } catch (error) {
        this.stagingGcErrors.push({ root, message: error.message });
      }
    }
  }

  /**
   * §9.4. Everything runs inside one BEGIN IMMEDIATE: the open-work listing and the
   * reassignment must not straddle the transaction or a project created between
   * them is left owned by an archived Buddy.
   *
   * Relationships are NEVER touched (§5). The directory rule promotes a managerless
   * Buddy to top level, so deleting the manager edge would UN-HIDE the retiree. An
   * archived report is still historically that manager's report.
   */
  retireDirectReport({ managerBuddy, subBuddy, reason, reassignOpenWorkTo }) {
    const manager = this.#requireBuddy(managerBuddy);
    const sub = this.#requireBuddy(subBuddy);
    return this.#tx(() => {
      // §8.3: canonical manager, one direction. "either direction" matching lets a
      // non-canonical manager retire someone else's report.
      const employment = this.#employmentOf(sub.id);
      if (
        employment.kind !== "direct_report" ||
        employment.managerId !== manager.id
      ) {
        throw new Error(`${sub.slug} is not a direct report of ${manager.slug}`);
      }
      const work = this.#resolveRetirementWork(manager, sub, reassignOpenWorkTo);
      let reassigned;
      switch (work.kind) {
        case "no_open_work":
          reassigned = 0;
          break;
        case "reassign_to_manager":
          for (const project of work.projects) {
            this.reassignOwnedProject({ project: project.id, toBuddy: manager.id });
          }
          reassigned = work.projects.length;
          break;
        default:
          throw new Error(`unhandled retirement work plan: ${work.kind}`);
      }
      const timestamp = now();
      // Direct UPDATE, not updateAutomation(): that method opens its own #tx, and a
      // nested savepoint per automation buys nothing over one statement here.
      const automations = this.db
        .prepare(
          "UPDATE buddy_automations SET enabled = 0, next_run_at = NULL, updated_at = ? WHERE buddy_id = ?",
        )
        .run(timestamp, sub.id).changes;
      // BOTH delegation directions: buddy_delegations is one table for both, so
      // "cancel the report's delegations" is ambiguous. Work the retiree ISSUED
      // would strand its recipients; work ASSIGNED to it would sit pending forever.
      const issued = this.db
        .prepare(`
          UPDATE buddy_delegations SET status = 'cancelled',
            outcome = COALESCE(outcome, 'cancelled: the delegating Buddy was retired'),
            updated_at = ?, completed_at = COALESCE(completed_at, ?)
          WHERE from_buddy_id = ? AND status IN ('pending', 'active')
        `)
        .run(timestamp, timestamp, sub.id).changes;
      const received = this.db
        .prepare(`
          UPDATE buddy_delegations SET status = 'cancelled',
            outcome = COALESCE(outcome, 'cancelled: the assigned Buddy was retired'),
            updated_at = ?, completed_at = COALESCE(completed_at, ?)
          WHERE to_buddy_id = ? AND status IN ('pending', 'active')
        `)
        .run(timestamp, timestamp, sub.id).changes;
      const reviews = this.db
        .prepare(`
          UPDATE buddy_reviews SET status = 'cancelled', updated_at = ?,
            completed_at = COALESCE(completed_at, ?)
          WHERE reviewer_buddy_id = ? AND status = 'draft'
        `)
        .run(timestamp, timestamp, sub.id).changes;
      this.db
        .prepare("UPDATE buddies SET status = 'archived', updated_at = ? WHERE id = ?")
        .run(timestamp, sub.id);
      this.recordAuditEvent({
        buddy: sub.id,
        workspace: sub.project_id,
        operation: "buddy.retire_direct_report",
        payload: {
          managerId: manager.id,
          reason: reason ?? null,
          reassignedProjects: reassigned,
          cancelledDelegations: issued + received,
          cancelledReviews: reviews,
          disabledAutomations: automations,
        },
      });
      return {
        buddy: this.getBuddy(sub.id),
        reassignedProjects: reassigned,
        disabledAutomations: automations,
        cancelledDelegations: issued + received,
        cancelledReviews: reviews,
      };
    });
  }

  /**
   * §9.4 / §7.4. The workspace re-check is load-bearing: newProject guards owners
   * with #requireBuddy(buddy, ownerWorkspace), so handing the manager a project in a
   * workspace it is not in breaks that invariant silently and getBuddyContext then
   * throws "buddy does not belong to the workspace" every time it opens the project.
   * reassignOwnedProject re-checks it too; checking here as well is what turns a
   * mid-loop failure into an up-front refusal that names the workspace.
   * owned_projects has no slug column - name the project by title and id.
   */
  #resolveRetirementWork(manager, sub, reassignOpenWorkTo) {
    const open = this.listBuddyOwnedProjects({ buddy: sub.id });
    if (reassignOpenWorkTo === undefined || reassignOpenWorkTo === null) {
      if (open.length === 0) return { kind: "no_open_work" };
      throw new Error(
        `${sub.slug} still owns ${open.length} open project(s): ${open
          .map((project) => `${project.title} (${project.id})`)
          .join(", ")}; pass reassignOpenWorkTo to hand them to the manager`,
      );
    }
    const target = this.#requireBuddy(reassignOpenWorkTo);
    if (target.id !== manager.id) {
      throw new Error(
        `reassignOpenWorkTo must be the retiring manager ${manager.slug}, not ${target.slug}`,
      );
    }
    for (const project of open) {
      if (!this.#buddyHasProject(manager.id, project.workspace_id)) {
        throw new Error(
          `cannot reassign "${project.title}": ${manager.slug} is not a member of workspace ${project.workspace_slug}`,
        );
      }
    }
    return { kind: "reassign_to_manager", projects: open };
  }

  #projectPath(project, path) {
    return this.#containedPath(project.root_path, required("file path", path));
  }

  #containedPath(root, ...segments) {
    const target = resolve(root, ...segments);
    const fromRoot = relative(root, target);
    if (fromRoot === ".." || fromRoot.startsWith(`..${process.platform === "win32" ? "\\" : "/"}`) || isAbsolute(fromRoot)) {
      throw new Error("memory path escapes the Buddy memory root");
    }
    let probe = target;
    while (!existsSync(probe) && probe !== dirname(probe)) {
      probe = dirname(probe);
    }
    if (existsSync(root) && existsSync(probe)) {
      const realRoot = realpathSync(root);
      const realTarget = realpathSync(probe);
      const realRelative = relative(realRoot, realTarget);
      if (
        realRelative === ".." ||
        realRelative.startsWith(`..${process.platform === "win32" ? "\\" : "/"}`) ||
        isAbsolute(realRelative)
      ) {
        throw new Error("memory path escapes the Buddy memory root");
      }
    }
    return target;
  }

  #memoryRoot(buddy) {
    if (!buddy.memory_path) throw new Error("Buddy has no configured memory path");
    const homeWorkspace = this.#requireProject(buddy.project_id);
    return this.#projectPath(homeWorkspace, buddy.memory_path);
  }

  #insertTodo(projectId, input, timestamp = now()) {
    const status = input.status || "open";
    assertOneOf("todo status", status, BUDDY_TODO_STATUSES);
    if (status === "blocked" && !input.blockedReason?.trim()) {
      throw new Error("blocked reason is required when blocking a todo");
    }
    this.db
      .prepare(`
        INSERT INTO buddy_todos (
          id, buddy_project_id, title, status, position, definition_of_done,
          next_action, blocked_reason, created_at, updated_at, completed_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `)
      .run(
        id("todo"),
        projectId,
        required("todo title", input.title),
        status,
        Number(input.position) || 0,
        input.definitionOfDone?.trim() || null,
        input.nextAction?.trim() || null,
        status === "blocked" ? input.blockedReason.trim() : null,
        timestamp,
        timestamp,
        ["done", "cancelled"].includes(status) ? timestamp : null,
      );
  }

  #updateTodo(projectId, operation, timestamp) {
    const current = this.db
      .prepare("SELECT * FROM buddy_todos WHERE id = ? AND buddy_project_id = ?")
      .get(required("todo id", operation.todoId), projectId);
    if (!current) throw new Error("todo does not belong to the updated Buddy project");
    const status = operation.status ?? current.status;
    assertOneOf("todo status", status, BUDDY_TODO_STATUSES);
    const blocker =
      status === "blocked"
        ? operation.blockedReason?.trim() || current.blocked_reason
        : null;
    if (status === "blocked" && !blocker) {
      throw new Error("blocked reason is required when blocking a todo");
    }
    this.db
      .prepare(`
        UPDATE buddy_todos SET
          title = ?, status = ?, position = ?, definition_of_done = ?,
          next_action = ?, blocked_reason = ?, updated_at = ?, completed_at = ?
        WHERE id = ?
      `)
      .run(
        operation.title === undefined ? current.title : required("todo title", operation.title),
        status,
        operation.position === undefined
          ? current.position
          : Math.max(0, Number(operation.position) || 0),
        operation.definitionOfDone === undefined
          ? current.definition_of_done
          : operation.definitionOfDone?.trim() || null,
        operation.nextAction === undefined
          ? current.next_action
          : operation.nextAction?.trim() || null,
        blocker,
        timestamp,
        ["done", "cancelled"].includes(status)
          ? current.completed_at || timestamp
          : null,
        current.id,
      );
  }

  #validateAutomationDefinition({
    scheduleKind,
    scheduleExpression,
    timezone,
    jobKind,
    jobPayload,
  }) {
    assertOneOf("schedule kind", scheduleKind, AUTOMATION_SCHEDULE_KINDS);
    assertOneOf("job kind", jobKind, AUTOMATION_JOB_KINDS);
    const expression = required("schedule expression", scheduleExpression);
    if (scheduleKind === "interval") {
      const interval = Number(expression);
      if (!Number.isFinite(interval) || interval <= 0) {
        throw new Error("interval schedule expression must be a positive number of seconds");
      }
    } else if (expression.trim().split(/\s+/).length !== 5) {
      throw new Error("cron schedule expression must contain five fields");
    }
    const zone = required("timezone", timezone);
    try {
      new Intl.DateTimeFormat("en", { timeZone: zone });
    } catch {
      throw new Error(`invalid timezone: ${zone}`);
    }
    if (!jobPayload || typeof jobPayload !== "object" || Array.isArray(jobPayload)) {
      throw new Error("job payload must be an object");
    }
    if (jobKind === "prompt") {
      required("job prompt", jobPayload.prompt);
    } else if (jobKind === "sequence") {
      if (!Array.isArray(jobPayload.prompts) || jobPayload.prompts.length === 0) {
        throw new Error("sequence job requires at least one prompt");
      }
      jobPayload.prompts.forEach((prompt) => required("sequence prompt", prompt));
    } else {
      required("loop prompt", jobPayload.prompt);
      required("loop termination condition", jobPayload.termination?.condition);
      const iterations = Number(jobPayload.termination?.max_iterations);
      const duration = Number(jobPayload.termination?.max_duration_seconds);
      if (!Number.isInteger(iterations) || iterations < 1) {
        throw new Error("loop max_iterations must be a positive integer");
      }
      if (!Number.isFinite(duration) || duration <= 0) {
        throw new Error("loop max_duration_seconds must be positive");
      }
    }
    return {
      scheduleKind,
      scheduleExpression: expression,
      timezone: zone,
      jobKind,
      jobPayload,
    };
  }

  #validateAutomationPolicy(policy, jobKind, jobPayload, current) {
    const plannedIterations =
      jobKind === "prompt"
        ? 1
        : jobKind === "sequence"
          ? jobPayload.prompts.length
          : jobPayload.termination.max_iterations;
    const source = policy || {};
    const fallback = current || {
      max_runtime_seconds: DEFAULT_AUTOMATION_MAX_RUNTIME_SECONDS,
      max_iterations: Math.min(DEFAULT_AUTOMATION_MAX_ITERATIONS, plannedIterations),
      max_tokens: DEFAULT_AUTOMATION_MAX_TOKENS,
      max_cost_usd: DEFAULT_AUTOMATION_MAX_COST_USD,
      allowed_operations: DEFAULT_AUTOMATION_ALLOWED_OPERATIONS,
    };
    const value = {
      max_runtime_seconds:
        source.maxRuntimeSeconds ?? source.max_runtime_seconds ?? fallback.max_runtime_seconds,
      max_iterations:
        source.maxIterations ?? source.max_iterations ?? fallback.max_iterations,
      max_tokens: source.maxTokens ?? source.max_tokens ?? fallback.max_tokens,
      max_cost_usd: source.maxCostUsd ?? source.max_cost_usd ?? fallback.max_cost_usd,
      allowed_operations:
        source.allowedOperations ?? source.allowed_operations ?? fallback.allowed_operations,
    };
    value.max_runtime_seconds = Number(value.max_runtime_seconds);
    value.max_iterations = Number(value.max_iterations);
    value.max_tokens = Number(value.max_tokens);
    value.max_cost_usd = Number(value.max_cost_usd);
    if (!Number.isInteger(value.max_runtime_seconds) || value.max_runtime_seconds < 1) {
      throw new Error("automation max runtime seconds must be a positive integer");
    }
    if (!Number.isInteger(value.max_iterations) || value.max_iterations < 1) {
      throw new Error("automation max iterations must be a positive integer");
    }
    if (!Number.isInteger(value.max_tokens) || value.max_tokens < 1) {
      throw new Error("automation max tokens must be a positive integer");
    }
    if (!Number.isFinite(value.max_cost_usd) || value.max_cost_usd <= 0) {
      throw new Error("automation max cost USD must be positive");
    }
    if (!Array.isArray(value.allowed_operations)) {
      throw new Error("automation allowed operations must be an array");
    }
    value.allowed_operations = [
      ...new Set(
        value.allowed_operations.map((operation) => {
          const name = required("automation allowed operation", operation);
          assertOneOf("automation allowed operation", name, AUTOMATION_ALLOWED_OPERATIONS);
          return name;
        }),
      ),
    ];
    return value;
  }

  #insertAutomationPolicy(automationId, policy, timestamp = now()) {
    this.db
      .prepare(`
        INSERT INTO buddy_automation_policies (
          automation_id, max_runtime_seconds, max_iterations, max_tokens,
          max_cost_usd, allowed_operations, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
      `)
      .run(
        automationId,
        policy.max_runtime_seconds,
        policy.max_iterations,
        policy.max_tokens,
        policy.max_cost_usd,
        JSON.stringify(policy.allowed_operations),
        timestamp,
        timestamp,
      );
  }

  #automationRow(row) {
    const policyRow = this.db
      .prepare("SELECT * FROM buddy_automation_policies WHERE automation_id = ?")
      .get(row.id);
    if (!policyRow) throw new Error(`automation policy not found: ${row.id}`);
    return {
      ...row,
      enabled: Boolean(row.enabled),
      job_payload:
        typeof row.job_payload === "string" ? JSON.parse(row.job_payload) : row.job_payload,
      policy: {
        max_runtime_seconds: policyRow.max_runtime_seconds,
        max_iterations: policyRow.max_iterations,
        max_tokens: policyRow.max_tokens,
        max_cost_usd: policyRow.max_cost_usd,
        allowed_operations: JSON.parse(policyRow.allowed_operations),
      },
    };
  }

  #automationRunRow(row) {
    const policyRow = this.db
      .prepare("SELECT * FROM buddy_automation_run_policies WHERE run_id = ?")
      .get(row.id);
    if (!policyRow) throw new Error(`automation run policy not found: ${row.id}`);
    return {
      ...row,
      tokens_used: policyRow.tokens_used,
      cost_usd: policyRow.cost_usd,
      policy: {
        max_runtime_seconds: policyRow.max_runtime_seconds,
        max_iterations: policyRow.max_iterations,
        max_tokens: policyRow.max_tokens,
        max_cost_usd: policyRow.max_cost_usd,
        allowed_operations: JSON.parse(policyRow.allowed_operations),
      },
    };
  }

  #requireProject(idOrSlug) {
    if (typeof idOrSlug === "object" && idOrSlug?.id) {
      return idOrSlug;
    }
    const project = this.getProject(required("project", idOrSlug));
    if (!project) throw new Error(`project not found: ${idOrSlug}`);
    return project;
  }

  #requireBuddy(idOrSlug, project) {
    if (typeof idOrSlug === "object" && idOrSlug?.id) {
      if (project && !this.#buddyHasProject(idOrSlug.id, project.id)) {
        throw new Error("buddy does not belong to the project");
      }
      return idOrSlug;
    }
    const lookup = required("buddy", idOrSlug);
    const buddy = this.getBuddy(lookup, project ? project.id : undefined);
    if (!buddy && project) {
      const buddyInAnotherProject = this.getBuddy(lookup);
      if (buddyInAnotherProject) {
        throw new Error("buddy does not belong to the project");
      }
    }
    if (!buddy) throw new Error(`buddy not found: ${idOrSlug}`);
    if (project && !this.#buddyHasProject(buddy.id, project.id)) {
      throw new Error("buddy does not belong to the project");
    }
    return buddy;
  }

  #buddyHasProject(buddyId, projectId) {
    return Boolean(
      this.db
        .prepare("SELECT 1 FROM buddy_projects WHERE buddy_id = ? AND project_id = ?")
        .get(buddyId, projectId),
    );
  }

  #requireSprint(id, project) {
    if (typeof id === "object" && id?.id) {
      if (project && id.project_id !== project.id) {
        throw new Error("sprint does not belong to the project");
      }
      return id;
    }
    const sprint = this.getSprint(required("sprint", id));
    if (!sprint) throw new Error(`sprint not found: ${id}`);
    if (project && sprint.project_id !== project.id) {
      throw new Error("sprint does not belong to the project");
    }
    return sprint;
  }

  #requireWorkItem(id, projectId) {
    const workItem =
      typeof id === "object" && id?.id
        ? id
        : this.getWorkItem(required("work item", id));
    if (!workItem) throw new Error(`work item not found: ${id}`);
    if (projectId && workItem.project_id !== projectId) {
      throw new Error("work item does not belong to the buddy's project");
    }
    return workItem;
  }

  #requireBuddyProject(project) {
    const ownedProject =
      typeof project === "object" && project?.id
        ? project
        : this.db
            .prepare("SELECT * FROM owned_projects WHERE id = ?")
            .get(required("Buddy project", project));
    if (!ownedProject) throw new Error(`Buddy project not found: ${project}`);
    return ownedProject;
  }

  #requireAutomation(automation) {
    const value = this.getAutomation(automation);
    if (!value) throw new Error(`automation not found: ${automation}`);
    return value;
  }

  #requireAutomationRun(run) {
    const value = this.getAutomationRun(run);
    if (!value) throw new Error(`automation run not found: ${run}`);
    return value;
  }
}
