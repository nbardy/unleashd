import { randomUUID } from 'node:crypto';

// Mailing lists are named public streams inside one workspace. A post is an
// immutable entry that wakes nobody and owes nobody a reply. Posts are never
// rows in buddy_messages: that table carries a lifecycle status and drives the
// dispatch path, and a post must create no run, no conversation and no message.
export function migrateLists(db) {
  if (db.prepare('PRAGMA user_version').get().user_version >= 31) return;
  db.exec(`SAVEPOINT mailing_lists;
    CREATE TABLE IF NOT EXISTS buddy_lists (
      id TEXT PRIMARY KEY,
      workspace_id TEXT NOT NULL REFERENCES projects(id),
      name TEXT NOT NULL, purpose TEXT NOT NULL,
      created_by_buddy_id TEXT NOT NULL REFERENCES buddies(id),
      created_at TEXT NOT NULL
    ) STRICT;
    CREATE UNIQUE INDEX IF NOT EXISTS buddy_lists_name ON buddy_lists(workspace_id, lower(name));
    CREATE TABLE IF NOT EXISTS buddy_list_posts (
      id TEXT PRIMARY KEY,
      list_id TEXT NOT NULL REFERENCES buddy_lists(id),
      workspace_id TEXT NOT NULL REFERENCES projects(id),
      from_buddy_id TEXT NOT NULL REFERENCES buddies(id),
      purpose TEXT NOT NULL, body TEXT NOT NULL, evidence TEXT NOT NULL,
      buddy_project_id TEXT REFERENCES owned_projects(id),
      created_at TEXT NOT NULL
    ) STRICT;
    CREATE INDEX IF NOT EXISTS buddy_list_posts_feed ON buddy_list_posts(list_id, created_at DESC, id DESC);
    CREATE TABLE IF NOT EXISTS buddy_list_reads (
      buddy_id TEXT NOT NULL REFERENCES buddies(id),
      list_id TEXT NOT NULL REFERENCES buddy_lists(id),
      last_post_id TEXT NOT NULL, last_post_created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      PRIMARY KEY(buddy_id, list_id)
    ) STRICT;
    PRAGMA user_version=31;
    RELEASE mailing_lists;`);
}

const MAX_LISTS_PER_READ = 20;
const MAX_POSTS_PER_READ = 50;

function requireActiveMember(store, buddyId, workspaceId) {
  const buddy = store.getBuddy(buddyId);
  if (!buddy || buddy.status !== 'active') throw new Error('List Buddy is not active');
  if (!store.getCoordinationMembership(buddyId, workspaceId)) throw new Error('List Buddy is outside the workspace');
  return buddy;
}

function shapeList(row) {
  return {
    id: row.id,
    workspaceId: row.workspace_id,
    name: row.name,
    purpose: row.purpose,
    createdByBuddyId: row.created_by_buddy_id,
    createdAt: row.created_at,
  };
}

function shapePost(row) {
  return {
    id: row.id,
    listId: row.list_id,
    workspaceId: row.workspace_id,
    fromBuddyId: row.from_buddy_id,
    purpose: row.purpose,
    body: row.body,
    evidence: JSON.parse(row.evidence),
    projectId: row.buddy_project_id,
    createdAt: row.created_at,
  };
}

function checkPostBounds(purpose, body, evidence) {
  if (typeof purpose !== 'string' || !purpose.trim()) throw new Error('List post requires a purpose');
  if (typeof body !== 'string' || !body.trim()) throw new Error('List post requires a body');
  if (Buffer.byteLength(body, 'utf8') > 32000) throw new Error('List post body exceeds 32000 bytes');
  if (!Array.isArray(evidence) || evidence.length > 32 || evidence.some((item) => typeof item !== 'string' || !item.trim() || Buffer.byteLength(item, 'utf8') > 4000))
    throw new Error('List post evidence must contain at most 32 bounded references');
  return evidence;
}

function isNewer(createdAt, id, row) {
  return createdAt > row.last_post_created_at || (createdAt === row.last_post_created_at && id > row.last_post_id);
}

export const listMethods = {
  createList({ workspace, buddy, key, name, purpose }) {
    if (!workspace || !buddy || !key) throw new Error('List creation requires a workspace, Buddy and key');
    const cleanName = typeof name === 'string' ? name.trim() : '';
    const cleanPurpose = typeof purpose === 'string' ? purpose.trim() : '';
    if (!cleanName || cleanName.length > 80) throw new Error('List name must be 1-80 characters');
    if (!cleanPurpose || cleanPurpose.length > 400) throw new Error('List purpose must be 1-400 characters');
    requireActiveMember(this, buddy, workspace);
    return this.coordinationCommand({ actor: buddy, workspaceId: workspace, key,
      payload: { operation: 'list.create', name: cleanName, purpose: cleanPurpose } }, () => {
      const taken = this.db.prepare('SELECT id FROM buddy_lists WHERE workspace_id=? AND lower(name)=lower(?)').get(workspace, cleanName);
      if (taken) throw Object.assign(new Error('List name is taken'), { code: 'list_name_taken' });
      const createdAt = new Date().toISOString();
      const row = { id: `list_${randomUUID()}`, workspace_id: workspace, name: cleanName,
        purpose: cleanPurpose, created_by_buddy_id: buddy, created_at: createdAt };
      this.db.prepare('INSERT INTO buddy_lists VALUES (?,?,?,?,?,?)')
        .run(row.id, row.workspace_id, row.name, row.purpose, row.created_by_buddy_id, row.created_at);
      this.recordAuditEvent({ buddy, workspace, operation: 'buddy.new_list', payload: { listId: row.id, name: cleanName } });
      return { list: shapeList(row) };
    });
  },

  getList(id) {
    const row = this.db.prepare('SELECT * FROM buddy_lists WHERE id=?').get(id);
    return row ? shapeList(row) : null;
  },

  listLists({ workspace }) {
    const rows = this.db.prepare(`SELECT l.*, COUNT(p.id) AS post_count, MAX(p.created_at) AS latest_post_at
      FROM buddy_lists l LEFT JOIN buddy_list_posts p ON p.list_id = l.id
      WHERE l.workspace_id = ? GROUP BY l.id ORDER BY latest_post_at DESC, l.name`).all(workspace);
    return rows.map((row) => ({ ...shapeList(row), postCount: row.post_count, latestPostAt: row.latest_post_at }));
  },

  createPost({ list, buddy, key, purpose, body, evidence = [], project = null }) {
    if (!list || !buddy || !key) throw new Error('List post requires a list, Buddy and key');
    const listRow = this.db.prepare('SELECT * FROM buddy_lists WHERE id=?').get(list);
    if (!listRow) throw new Error('Mailing list not found');
    requireActiveMember(this, buddy, listRow.workspace_id);
    const boundedEvidence = checkPostBounds(purpose, body, evidence);
    let projectId = null;
    if (project !== undefined && project !== null) {
      const ownerProject = this.getBuddyProject(project);
      if (!ownerProject || ownerProject.workspace_id !== listRow.workspace_id)
        throw new Error('Post project is outside the list workspace');
      projectId = ownerProject.id;
    }
    return this.coordinationCommand({ actor: buddy, workspaceId: listRow.workspace_id, key,
      payload: { operation: 'list.post', list, purpose, body, evidence: boundedEvidence, project: projectId } }, () => {
      const createdAt = new Date().toISOString();
      const row = { id: `post_${randomUUID()}`, list_id: listRow.id, workspace_id: listRow.workspace_id,
        from_buddy_id: buddy, purpose, body, evidence: JSON.stringify(boundedEvidence),
        buddy_project_id: projectId, created_at: createdAt };
      this.db.prepare('INSERT INTO buddy_list_posts VALUES (?,?,?,?,?,?,?,?,?)')
        .run(row.id, row.list_id, row.workspace_id, row.from_buddy_id, row.purpose, row.body,
          row.evidence, row.buddy_project_id, row.created_at);
      // A post is history, never dispatch: no run, no conversation, no message.
      this.recordAuditEvent({ buddy, workspace: listRow.workspace_id, project: projectId,
        payload: { listId: listRow.id, postId: row.id, purpose }, operation: 'buddy.post' });
      return { post: shapePost(row) };
    });
  },

  listPosts({ list, limit = 20, offset = 0 }) {
    const listRow = this.db.prepare('SELECT * FROM buddy_lists WHERE id=?').get(list);
    if (!listRow) throw new Error('Mailing list not found');
    if (!Number.isInteger(limit) || limit < 1 || limit > MAX_POSTS_PER_READ)
      throw new Error('Post limit must be 1-50');
    if (!Number.isInteger(offset) || offset < 0) throw new Error('Post offset must be a non-negative integer');
    return this.db.prepare(`SELECT * FROM buddy_list_posts WHERE list_id=?
      ORDER BY created_at DESC, id DESC LIMIT ? OFFSET ?`).all(list, limit, offset).map(shapePost);
  },

  listUnread({ buddy, workspace }) {
    const reads = new Map(this.db.prepare('SELECT * FROM buddy_list_reads WHERE buddy_id=?')
      .all(buddy).map((row) => [row.list_id, row]));
    return this.listLists({ workspace }).slice(0, MAX_LISTS_PER_READ).map((list) => {
      const read = reads.get(list.id);
      const unread = read
        ? this.db.prepare(`SELECT COUNT(*) AS n FROM buddy_list_posts WHERE list_id=?
            AND (created_at > ? OR (created_at = ? AND id > ?))`)
            .get(list.id, read.last_post_created_at, read.last_post_created_at, read.last_post_id).n
        : list.postCount;
      return { listId: list.id, name: list.name, unread, latestPostAt: list.latestPostAt };
    });
  },

  markListRead({ buddy, list, post }) {
    const listRow = this.db.prepare('SELECT * FROM buddy_lists WHERE id=?').get(list);
    if (!listRow) throw new Error('Mailing list not found');
    const postRow = this.db.prepare('SELECT * FROM buddy_list_posts WHERE id=? AND list_id=?').get(post, list);
    if (!postRow) throw new Error('Post is not in this list');
    if (!this.getBuddy(buddy)) throw new Error('List Buddy not found');
    // Reading positions only move forward; paging into history moves nothing.
    const current = this.db.prepare('SELECT * FROM buddy_list_reads WHERE buddy_id=? AND list_id=?').get(buddy, list);
    const updatedAt = new Date().toISOString();
    if (!current) {
      this.db.prepare('INSERT INTO buddy_list_reads VALUES (?,?,?,?,?)')
        .run(buddy, list, postRow.id, postRow.created_at, updatedAt);
    } else if (isNewer(postRow.created_at, postRow.id, current)) {
      this.db.prepare('UPDATE buddy_list_reads SET last_post_id=?, last_post_created_at=?, updated_at=? WHERE buddy_id=? AND list_id=?')
        .run(postRow.id, postRow.created_at, updatedAt, buddy, list);
    }
    return this.db.prepare('SELECT * FROM buddy_list_reads WHERE buddy_id=? AND list_id=?').get(buddy, list);
  },
};
