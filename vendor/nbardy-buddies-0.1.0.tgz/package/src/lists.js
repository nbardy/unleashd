import { randomUUID } from 'node:crypto';

// Mailing lists are named public streams inside one workspace. A post is an
// immutable entry that wakes nobody and owes nobody a reply. Posts are never
// rows in buddy_messages: that table carries a lifecycle status and drives the
// dispatch path, and a post must create no run, no conversation and no message.
// (The host may choose to start a turn in response to an owner post, e.g. an
// @mention in the app; that is host policy layered on top, never store behaviour.)
export function migrateLists(db) {
  let version = db.prepare('PRAGMA user_version').get().user_version;
  if (version >= 33) return;
  db.exec(`SAVEPOINT mailing_lists;
    CREATE TABLE IF NOT EXISTS buddy_lists (
      id TEXT PRIMARY KEY,
      workspace_id TEXT NOT NULL REFERENCES projects(id),
      name TEXT NOT NULL, purpose TEXT NOT NULL,
      created_by_buddy_id TEXT NOT NULL REFERENCES buddies(id),
      created_at TEXT NOT NULL
    ) STRICT;
    CREATE UNIQUE INDEX IF NOT EXISTS buddy_lists_name ON buddy_lists(workspace_id, lower(name));
    CREATE TABLE IF NOT EXISTS buddy_list_posts (
      id TEXT PRIMARY KEY,
      list_id TEXT NOT NULL REFERENCES buddy_lists(id),
      workspace_id TEXT NOT NULL REFERENCES projects(id),
      from_buddy_id TEXT NOT NULL REFERENCES buddies(id),
      purpose TEXT NOT NULL, body TEXT NOT NULL, evidence TEXT NOT NULL,
      buddy_project_id TEXT REFERENCES owned_projects(id),
      sender_conversation_id TEXT,
      sender_run_id TEXT,
      created_at TEXT NOT NULL
    ) STRICT;
    CREATE INDEX IF NOT EXISTS buddy_list_posts_feed ON buddy_list_posts(list_id, created_at DESC, id DESC);
    CREATE TABLE IF NOT EXISTS buddy_list_reads (
      buddy_id TEXT NOT NULL REFERENCES buddies(id),
      list_id TEXT NOT NULL REFERENCES buddy_lists(id),
      last_post_id TEXT NOT NULL, last_post_created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      PRIMARY KEY(buddy_id, list_id)
    ) STRICT;
    RELEASE mailing_lists;`);
  if (version < 31) {
    db.exec('PRAGMA user_version=31;');
    version = 31;
  }
  // v32 adds nullable server-stamped instance provenance plus a project feed
  // index. Rows written before this migration read back as null.
  if (version < 32) {
    const columns = new Set(db.prepare('PRAGMA table_info(buddy_list_posts)').all().map((column) => column.name));
    if (!columns.has('sender_conversation_id')) db.exec('ALTER TABLE buddy_list_posts ADD COLUMN sender_conversation_id TEXT');
    if (!columns.has('sender_run_id')) db.exec('ALTER TABLE buddy_list_posts ADD COLUMN sender_run_id TEXT');
    db.exec(`CREATE INDEX IF NOT EXISTS buddy_list_posts_project_feed
      ON buddy_list_posts(workspace_id, buddy_project_id, created_at DESC, id DESC);
      PRAGMA user_version=32;`);
    version = 32;
  }
  // v33: the owner authors lists and posts directly, and a post may reply in a
  // one-level thread. SQLite cannot relax NOT NULL in place, so both tables are
  // rebuilt. The author is a sum, Buddy(from_buddy_id) | Owner, enforced by a
  // CHECK so a row can never claim to be both or neither. buddy_list_reads
  // references buddy_lists by name, so the rename keeps it pointed correctly.
  if (version < 33) {
    db.exec('PRAGMA foreign_keys = OFF');
    try {
      db.exec(`SAVEPOINT list_authors;
        CREATE TABLE buddy_lists_v33 (
          id TEXT PRIMARY KEY,
          workspace_id TEXT NOT NULL REFERENCES projects(id),
          name TEXT NOT NULL, purpose TEXT NOT NULL,
          created_by_kind TEXT NOT NULL CHECK(created_by_kind IN ('buddy','owner')),
          created_by_buddy_id TEXT REFERENCES buddies(id),
          created_at TEXT NOT NULL,
          CHECK((created_by_kind = 'buddy') = (created_by_buddy_id IS NOT NULL))
        ) STRICT;
        INSERT INTO buddy_lists_v33 (id, workspace_id, name, purpose, created_by_kind, created_by_buddy_id, created_at)
          SELECT id, workspace_id, name, purpose, 'buddy', created_by_buddy_id, created_at FROM buddy_lists;
        DROP TABLE buddy_lists;
        ALTER TABLE buddy_lists_v33 RENAME TO buddy_lists;
        CREATE UNIQUE INDEX buddy_lists_name ON buddy_lists(workspace_id, lower(name));
        CREATE TABLE buddy_list_posts_v33 (
          id TEXT PRIMARY KEY,
          list_id TEXT NOT NULL REFERENCES buddy_lists(id),
          workspace_id TEXT NOT NULL REFERENCES projects(id),
          author_kind TEXT NOT NULL CHECK(author_kind IN ('buddy','owner')),
          from_buddy_id TEXT REFERENCES buddies(id),
          thread_root_id TEXT REFERENCES buddy_list_posts(id),
          purpose TEXT NOT NULL, body TEXT NOT NULL, evidence TEXT NOT NULL,
          buddy_project_id TEXT REFERENCES owned_projects(id),
          sender_conversation_id TEXT,
          sender_run_id TEXT,
          created_at TEXT NOT NULL,
          CHECK((author_kind = 'buddy') = (from_buddy_id IS NOT NULL))
        ) STRICT;
        INSERT INTO buddy_list_posts_v33 (id, list_id, workspace_id, author_kind, from_buddy_id, thread_root_id,
            purpose, body, evidence, buddy_project_id, sender_conversation_id, sender_run_id, created_at)
          SELECT id, list_id, workspace_id, 'buddy', from_buddy_id, NULL,
            purpose, body, evidence, buddy_project_id, sender_conversation_id, sender_run_id, created_at
          FROM buddy_list_posts;
        DROP TABLE buddy_list_posts;
        ALTER TABLE buddy_list_posts_v33 RENAME TO buddy_list_posts;
        CREATE INDEX buddy_list_posts_feed ON buddy_list_posts(list_id, created_at DESC, id DESC);
        CREATE INDEX buddy_list_posts_project_feed
          ON buddy_list_posts(workspace_id, buddy_project_id, created_at DESC, id DESC);
        CREATE INDEX buddy_list_posts_thread ON buddy_list_posts(thread_root_id, created_at, id)
          WHERE thread_root_id IS NOT NULL;
        PRAGMA user_version=33;
        RELEASE list_authors;`);
    } catch (error) {
      db.exec('ROLLBACK TO list_authors; RELEASE list_authors;');
      throw error;
    } finally {
      db.exec('PRAGMA foreign_keys = ON');
    }
    const violation = db.prepare('PRAGMA foreign_key_check').get();
    if (violation) throw new Error(`mailing list migration broke a foreign key: ${violation.table}`);
  }
}

const MAX_LISTS_PER_READ = 20;
const MAX_POSTS_PER_READ = 50;
const MAX_THREAD_REPLIES_PER_READ = 200;

// Every post read carries its thread summary so a channel feed can show
// "N replies" without a second query. Replies themselves report 0.
const POST_COLUMNS = `p.*,
  (SELECT COUNT(*) FROM buddy_list_posts r WHERE r.thread_root_id = p.id) AS reply_count,
  (SELECT MAX(r.created_at) FROM buddy_list_posts r WHERE r.thread_root_id = p.id) AS latest_reply_at`;

function requireActiveMember(store, buddyId, workspaceId) {
  const buddy = store.getBuddy(buddyId);
  if (!buddy || buddy.status !== 'active') throw new Error('List Buddy is not active');
  if (!store.getCoordinationMembership(buddyId, workspaceId)) throw new Error('List Buddy is outside the workspace');
  return buddy;
}

// Author = Buddy(buddyId) | Owner. The owner is the host's authenticated human
// and implicitly belongs to every workspace; a Buddy author must be an active
// member. Returns the receipt actor used for idempotency. Employee MCP must
// never construct an owner author: only host (owner HTTP) code does.
function requireAuthor(store, author, workspaceId) {
  switch (author?.kind) {
    case 'buddy':
      requireActiveMember(store, author.buddyId, workspaceId);
      return author.buddyId;
    case 'owner':
      if (!store.getWorkspace(workspaceId)) throw new Error('List workspace not found');
      return 'owner';
    default:
      throw new Error('List author must be {kind:"buddy",buddyId} or {kind:"owner"}');
  }
}

function authorColumns(author) {
  return author.kind === 'buddy' ? ['buddy', author.buddyId] : ['owner', null];
}

function authorFromRow(kind, buddyId) {
  return kind === 'owner' ? { kind: 'owner' } : { kind: 'buddy', buddyId };
}

function shapeList(row) {
  return {
    id: row.id,
    workspaceId: row.workspace_id,
    name: row.name,
    purpose: row.purpose,
    createdBy: authorFromRow(row.created_by_kind, row.created_by_buddy_id),
    createdAt: row.created_at,
  };
}

function shapePost(row) {
  return {
    id: row.id,
    listId: row.list_id,
    workspaceId: row.workspace_id,
    author: authorFromRow(row.author_kind, row.from_buddy_id),
    threadRootId: row.thread_root_id,
    replyCount: row.reply_count ?? 0,
    latestReplyAt: row.latest_reply_at ?? null,
    purpose: row.purpose,
    body: row.body,
    evidence: JSON.parse(row.evidence),
    projectId: row.buddy_project_id,
    senderConversationId: row.sender_conversation_id ?? null,
    senderRunId: row.sender_run_id ?? null,
    createdAt: row.created_at,
  };
}

function checkPostBounds(purpose, body, evidence) {
  if (typeof purpose !== 'string' || !purpose.trim()) throw new Error('List post requires a purpose');
  if (typeof body !== 'string' || !body.trim()) throw new Error('List post requires a body');
  if (Buffer.byteLength(body, 'utf8') > 32000) throw new Error('List post body exceeds 32000 bytes');
  if (!Array.isArray(evidence) || evidence.length > 32 || evidence.some((item) => typeof item !== 'string' || !item.trim() || Buffer.byteLength(item, 'utf8') > 4000))
    throw new Error('List post evidence must contain at most 32 bounded references');
  return evidence;
}

function isNewer(createdAt, id, row) {
  return createdAt > row.last_post_created_at || (createdAt === row.last_post_created_at && id > row.last_post_id);
}

export const listMethods = {
  createList({ workspace, author, key, name, purpose }) {
    if (!workspace || !key) throw new Error('List creation requires a workspace, author and key');
    const cleanName = typeof name === 'string' ? name.trim() : '';
    const cleanPurpose = typeof purpose === 'string' ? purpose.trim() : '';
    if (!cleanName || cleanName.length > 80) throw new Error('List name must be 1-80 characters');
    if (!cleanPurpose || cleanPurpose.length > 400) throw new Error('List purpose must be 1-400 characters');
    const actor = requireAuthor(this, author, workspace);
    const [kind, buddyId] = authorColumns(author);
    return this.coordinationCommand({ actor, workspaceId: workspace, key,
      payload: { operation: 'list.create', name: cleanName, purpose: cleanPurpose } }, () => {
      const taken = this.db.prepare('SELECT id FROM buddy_lists WHERE workspace_id=? AND lower(name)=lower(?)').get(workspace, cleanName);
      if (taken) throw Object.assign(new Error('List name is taken'), { code: 'list_name_taken' });
      const row = { id: `list_${randomUUID()}`, workspace_id: workspace, name: cleanName,
        purpose: cleanPurpose, created_by_kind: kind, created_by_buddy_id: buddyId,
        created_at: new Date().toISOString() };
      this.db.prepare(`INSERT INTO buddy_lists (id, workspace_id, name, purpose, created_by_kind, created_by_buddy_id, created_at)
        VALUES (?,?,?,?,?,?,?)`)
        .run(row.id, row.workspace_id, row.name, row.purpose, row.created_by_kind, row.created_by_buddy_id, row.created_at);
      // Audit rows are attributed to a Buddy; an owner-created list is its own record.
      if (buddyId) this.recordAuditEvent({ buddy: buddyId, workspace, operation: 'buddy.new_list', payload: { listId: row.id, name: cleanName } });
      return { list: shapeList(row) };
    });
  },

  getList(id) {
    const row = this.db.prepare('SELECT * FROM buddy_lists WHERE id=?').get(id);
    return row ? shapeList(row) : null;
  },

  listLists({ workspace }) {
    const rows = this.db.prepare(`SELECT l.*, COUNT(p.id) AS post_count, MAX(p.created_at) AS latest_post_at
      FROM buddy_lists l LEFT JOIN buddy_list_posts p ON p.list_id = l.id
      WHERE l.workspace_id = ? GROUP BY l.id ORDER BY latest_post_at DESC, l.name`).all(workspace);
    return rows.map((row) => ({ ...shapeList(row), postCount: row.post_count, latestPostAt: row.latest_post_at }));
  },

  // threadRoot null means a top-level channel post; that absence is the meaning.
  // Threads are one level: a reply's root must itself be top-level in the same list.
  createPost({ list, author, key, purpose, body, evidence = [], project = null, threadRoot = null,
    conversationId = null, runId = null }) {
    if (!list || !key) throw new Error('List post requires a list, author and key');
    const listRow = this.db.prepare('SELECT * FROM buddy_lists WHERE id=?').get(list);
    if (!listRow) throw new Error('Mailing list not found');
    const actor = requireAuthor(this, author, listRow.workspace_id);
    const [kind, buddyId] = authorColumns(author);
    const boundedEvidence = checkPostBounds(purpose, body, evidence);
    let projectId = null;
    if (project !== undefined && project !== null) {
      const ownerProject = this.getBuddyProject(project);
      if (!ownerProject || ownerProject.workspace_id !== listRow.workspace_id)
        throw new Error('Post project is outside the list workspace');
      projectId = ownerProject.id;
    }
    let threadRootId = null;
    if (threadRoot !== undefined && threadRoot !== null) {
      const root = this.db.prepare('SELECT id, list_id, thread_root_id FROM buddy_list_posts WHERE id=?').get(threadRoot);
      if (!root || root.list_id !== listRow.id) throw new Error('Thread root is not a post in this list');
      if (root.thread_root_id !== null) throw new Error('Threads are one level: reply to the thread root');
      threadRootId = root.id;
    }
    // Instance provenance is server-stamped context, never caller identity:
    // only a string handle is kept, everything else reads back as null.
    if (conversationId !== undefined && conversationId !== null && typeof conversationId !== 'string')
      throw new Error('Post conversation id must be a string or null');
    if (runId !== undefined && runId !== null && typeof runId !== 'string')
      throw new Error('Post run id must be a string or null');
    const senderConversationId = typeof conversationId === 'string' && conversationId ? conversationId : null;
    const senderRunId = typeof runId === 'string' && runId ? runId : null;
    return this.coordinationCommand({ actor, workspaceId: listRow.workspace_id, key,
      payload: { operation: 'list.post', list, purpose, body, evidence: boundedEvidence, project: projectId,
        threadRoot: threadRootId, conversationId: senderConversationId, runId: senderRunId } }, () => {
      const row = { id: `post_${randomUUID()}`, list_id: listRow.id, workspace_id: listRow.workspace_id,
        author_kind: kind, from_buddy_id: buddyId, thread_root_id: threadRootId,
        purpose, body, evidence: JSON.stringify(boundedEvidence),
        buddy_project_id: projectId, sender_conversation_id: senderConversationId,
        sender_run_id: senderRunId, created_at: new Date().toISOString() };
      this.db.prepare(`INSERT INTO buddy_list_posts
        (id, list_id, workspace_id, author_kind, from_buddy_id, thread_root_id, purpose, body, evidence,
          buddy_project_id, sender_conversation_id, sender_run_id, created_at)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)`)
        .run(row.id, row.list_id, row.workspace_id, row.author_kind, row.from_buddy_id, row.thread_root_id,
          row.purpose, row.body, row.evidence, row.buddy_project_id, row.sender_conversation_id,
          row.sender_run_id, row.created_at);
      // A post is history, never dispatch: no run, no conversation, no message.
      if (buddyId) this.recordAuditEvent({ buddy: buddyId, workspace: listRow.workspace_id, project: projectId,
        payload: { listId: listRow.id, postId: row.id, threadRootId, purpose }, operation: 'buddy.post' });
      return { post: shapePost(row) };
    });
  },

  getPost(id) {
    const row = this.db.prepare(`SELECT ${POST_COLUMNS} FROM buddy_list_posts p WHERE p.id=?`).get(id);
    return row ? shapePost(row) : null;
  },

  // A channel feed ({list} alone) is top-level posts only, each carrying its
  // reply summary; thread replies are read with listThread. Task feeds
  // ({list|workspace, project}) and the workspace feed include replies, since
  // a reply about a Task is still about that Task.
  listPosts({ list = null, workspace = null, project = null, limit = 20, offset = 0 }) {
    if (!Number.isInteger(limit) || limit < 1 || limit > MAX_POSTS_PER_READ)
      throw new Error('Post limit must be 1-50');
    if (!Number.isInteger(offset) || offset < 0) throw new Error('Post offset must be a non-negative integer');
    if (project !== undefined && project !== null && typeof project !== 'string')
      throw new Error('Post project filter must be a string or null');
    const projectFilter = typeof project === 'string' && project ? project : null;
    const page = 'ORDER BY p.created_at DESC, p.id DESC LIMIT ? OFFSET ?';
    const select = (where, ...args) =>
      this.db.prepare(`SELECT ${POST_COLUMNS} FROM buddy_list_posts p WHERE ${where} ${page}`)
        .all(...args, limit, offset).map(shapePost);
    if (list) {
      const listRow = this.db.prepare('SELECT * FROM buddy_lists WHERE id=?').get(list);
      if (!listRow) throw new Error('Mailing list not found');
      if (projectFilter) return select('p.list_id=? AND p.buddy_project_id=?', list, projectFilter);
      return select('p.list_id=? AND p.thread_root_id IS NULL', list);
    }
    // Cross-list feed: one workspace, optionally narrowed to one Task.
    if (!workspace) throw new Error('Post listing requires a list or workspace');
    if (projectFilter) return select('p.workspace_id=? AND p.buddy_project_id=?', workspace, projectFilter);
    return select('p.workspace_id=?', workspace);
  },

  // One thread: the root plus its replies oldest-first, the order a thread reads.
  listThread({ root, limit = MAX_THREAD_REPLIES_PER_READ }) {
    if (!Number.isInteger(limit) || limit < 1 || limit > MAX_THREAD_REPLIES_PER_READ)
      throw new Error(`Thread reply limit must be 1-${MAX_THREAD_REPLIES_PER_READ}`);
    const rootPost = this.getPost(root);
    if (!rootPost) throw new Error('Thread root not found');
    if (rootPost.threadRootId !== null) throw new Error('Post is a reply; read its thread root');
    const replies = this.db.prepare(`SELECT ${POST_COLUMNS} FROM buddy_list_posts p
      WHERE p.thread_root_id=? ORDER BY p.created_at, p.id LIMIT ?`).all(root, limit).map(shapePost);
    return { root: rootPost, replies };
  },

  // Newest post anywhere in the list, replies included: the read mark a fresh
  // get_list should advance to, so thread activity stops counting as unread.
  newestListPost({ list }) {
    const row = this.db.prepare(`SELECT ${POST_COLUMNS} FROM buddy_list_posts p WHERE p.list_id=?
      ORDER BY p.created_at DESC, p.id DESC LIMIT 1`).get(list);
    return row ? shapePost(row) : null;
  },

  listUnread({ buddy, workspace }) {
    const reads = new Map(this.db.prepare('SELECT * FROM buddy_list_reads WHERE buddy_id=?')
      .all(buddy).map((row) => [row.list_id, row]));
    return this.listLists({ workspace }).slice(0, MAX_LISTS_PER_READ).map((list) => {
      const read = reads.get(list.id);
      const unread = read
        ? this.db.prepare(`SELECT COUNT(*) AS n FROM buddy_list_posts WHERE list_id=?
            AND (created_at > ? OR (created_at = ? AND id > ?))`)
            .get(list.id, read.last_post_created_at, read.last_post_created_at, read.last_post_id).n
        : list.postCount;
      return { listId: list.id, name: list.name, unread, latestPostAt: list.latestPostAt };
    });
  },

  markListRead({ buddy, list, post }) {
    const listRow = this.db.prepare('SELECT * FROM buddy_lists WHERE id=?').get(list);
    if (!listRow) throw new Error('Mailing list not found');
    const postRow = this.db.prepare('SELECT * FROM buddy_list_posts WHERE id=? AND list_id=?').get(post, list);
    if (!postRow) throw new Error('Post is not in this list');
    if (!this.getBuddy(buddy)) throw new Error('List Buddy not found');
    // Reading positions only move forward; paging into history moves nothing.
    const current = this.db.prepare('SELECT * FROM buddy_list_reads WHERE buddy_id=? AND list_id=?').get(buddy, list);
    const updatedAt = new Date().toISOString();
    if (!current) {
      this.db.prepare('INSERT INTO buddy_list_reads VALUES (?,?,?,?,?)')
        .run(buddy, list, postRow.id, postRow.created_at, updatedAt);
    } else if (isNewer(postRow.created_at, postRow.id, current)) {
      this.db.prepare('UPDATE buddy_list_reads SET last_post_id=?, last_post_created_at=?, updated_at=? WHERE buddy_id=? AND list_id=?')
        .run(postRow.id, postRow.created_at, updatedAt, buddy, list);
    }
    return this.db.prepare('SELECT * FROM buddy_list_reads WHERE buddy_id=? AND list_id=?').get(buddy, list);
  },
};
