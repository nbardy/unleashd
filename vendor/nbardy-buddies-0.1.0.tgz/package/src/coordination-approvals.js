import { createHash } from 'node:crypto';
function canonical(value) {
  if(Array.isArray(value)) return value.map(canonical);
  if(value && typeof value==='object') return Object.fromEntries(Object.keys(value).sort().filter(k=>value[k]!==undefined).map(k=>[k,canonical(value[k])]));
  return value;
}
const digest=value=>createHash('sha256').update(JSON.stringify(canonical(value))).digest('hex');
export function migrateCoordinationApprovals(db) {
  if(db.prepare('PRAGMA user_version').get().user_version>=22) return;
  db.exec('SAVEPOINT coordination_approvals');
  try {
    if(!db.prepare('PRAGMA table_info(buddy_messages)').all().some(c=>c.name==='return_policy')) db.exec("ALTER TABLE buddy_messages ADD COLUMN return_policy TEXT NOT NULL DEFAULT '{}'");
    for(const [name,type] of Object.entries({message_id:'TEXT REFERENCES buddy_messages(id)',operation:'TEXT',arguments_json:'TEXT',arguments_hash:'TEXT',project_revision:'INTEGER',expires_at:'TEXT',consumed_by_run_id:'TEXT REFERENCES buddy_runs(id)'})) {
      if(!db.prepare('PRAGMA table_info(buddy_approval_requests)').all().some(c=>c.name===name)) db.exec(`ALTER TABLE buddy_approval_requests ADD COLUMN ${name} ${type}`);
    }
    db.exec('CREATE UNIQUE INDEX IF NOT EXISTS buddy_approval_message ON buddy_approval_requests(message_id) WHERE message_id IS NOT NULL; PRAGMA user_version=22; RELEASE coordination_approvals');
  } catch(error) {db.exec('ROLLBACK TO coordination_approvals; RELEASE coordination_approvals');throw error;}
}
export const coordinationApprovalMethods={
  attachMessageApproval(messageId,grant) {
    const message=this.getMessage(messageId);
    if(!message || message.to_buddy_id || !message.expects_reply) throw new Error('Executable approval requires a reply-bearing owner message');
    if(grant.operation!=='buddy.update_project') throw new Error('Only registered project mutations support executable approval');
    const args=grant.arguments;
    if(!args || typeof args!=='object' || Array.isArray(args) || !args.projectId || !Number.isInteger(args.baseRevision)) throw new Error('Approval requires exact project arguments and revision');
    const allowed=['projectId','baseRevision','ownerId','executionState'];
    if(Object.keys(args).some(k=>!allowed.includes(k)) || (!args.ownerId && !args.executionState)) throw new Error('Unsupported executable approval arguments');
    if(args.executionState && !['enabled','paused','cancelled'].includes(args.executionState)) throw new Error('Invalid approved project state');
    const project=this.getBuddyProject(args.projectId);
    if(!project || project.buddy_id!==message.from_buddy_id || project.workspace_id!==message.workspace_id || project.revision!==args.baseRevision) throw new Error('Approval project scope or revision does not match');
    const expiry=new Date(grant.expiresAt).toISOString();
    if(Date.parse(expiry)<=Date.now() || Date.parse(expiry)>Date.now()+86400000) throw new Error('Approval expiry must be within 24 hours');
    const approval=this.createApprovalRequest({buddy:message.from_buddy_id,workspace:message.workspace_id,project:project.id,conversationId:message.parent_conversation_id,action:grant.operation,reason:message.body,risk:'Exact project control mutation; inspect arguments before approving'});
    this.db.prepare('UPDATE buddy_approval_requests SET message_id=?,operation=?,arguments_json=?,arguments_hash=?,project_revision=?,expires_at=? WHERE id=?').run(message.id,grant.operation,JSON.stringify(canonical(args)),digest(args),project.revision,expiry,approval.id);
    return this.getApprovalRequest(approval.id);
  },
  resolveMessageApproval(message) {
    const approval=this.db.prepare('SELECT * FROM buddy_approval_requests WHERE message_id=?').get(message.id);
    if(!approval) return;
    if(!['approved','rejected'].includes(message.outcome)) throw new Error('Executable approval must be approved or rejected explicitly');
    if(approval.status!=='pending') {if(approval.status!==message.outcome) throw new Error('Approval already resolved');return;}
    this.resolveApprovalRequest(approval.id,{decision:message.outcome,resolvedBy:'owner',note:message.reply_body});
  },
  consumeProjectApproval(id,args,{actor,runId},callback) {
    return this.coordinationTransaction(()=>{
      const grant=this.db.prepare('SELECT * FROM buddy_approval_requests WHERE id=?').get(id);
      const run=this.getBuddyRun(runId);
      if(!grant || grant.buddy_id!==actor || grant.status!=='approved' || grant.consumed_by_run_id || grant.expires_at<=new Date().toISOString()) throw new Error('Approval is unavailable, expired or consumed');
      if(!run || run.buddy_id!==actor || !['claimed','running'].includes(run.status) || run.deadline<=new Date().toISOString()) throw new Error('Approval requires a fresh valid run');
      if(grant.operation!=='buddy.update_project' || digest(args)!==grant.arguments_hash || this.getBuddyProject(args.projectId)?.revision!==grant.project_revision) throw new Error('Approval arguments or project revision changed');
      const result=callback();
      this.db.prepare('UPDATE buddy_approval_requests SET consumed_by_run_id=? WHERE id=?').run(runId,id);
      return result;
    });
  },
};
