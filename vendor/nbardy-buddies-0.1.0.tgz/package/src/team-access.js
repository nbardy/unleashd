import { createHash } from 'node:crypto';
import { MEMORY_DOCUMENT_CAPS } from './store.js';

export const TEAM_CAPABILITIES = [
  'staff.create', 'relationship.write', 'profile.read', 'profile.write',
  'soul.read', 'soul.write', 'memory.read', 'memory.write', 'schedule.manage', 'execution.manage',
];
const now = () => new Date().toISOString();
const hash = (value) => createHash('sha256').update(JSON.stringify(value)).digest('hex');

export function migrateTeamAccess(db) {
  if (db.prepare('PRAGMA user_version').get().user_version >= 23) return;
  db.exec('SAVEPOINT team_access');
  try {
    db.exec(`CREATE TABLE IF NOT EXISTS buddy_access_grants (
      grantee_id TEXT NOT NULL REFERENCES buddies(id), workspace_id TEXT NOT NULL REFERENCES projects(id),
      target_id TEXT NOT NULL, capabilities TEXT NOT NULL, revision INTEGER NOT NULL,
      expires_at TEXT, reason TEXT NOT NULL, updated_at TEXT NOT NULL,
      PRIMARY KEY(grantee_id,workspace_id,target_id)
    ) STRICT`);
    const add = (table, column, definition) => {
      if (!db.prepare(`PRAGMA table_info(${table})`).all().some(c=>c.name===column))
        db.exec(`ALTER TABLE ${table} ADD COLUMN ${column} ${definition}`);
    };
    add('buddies','profile_revision','INTEGER NOT NULL DEFAULT 1');
    add('owned_projects','accepted_by','TEXT REFERENCES buddies(id)');
    add('owned_projects','accepted_at','TEXT');
    add('buddy_messages','visibility',"TEXT NOT NULL DEFAULT 'participants' CHECK(visibility IN ('participants','project'))");
    db.exec('PRAGMA user_version=23; RELEASE team_access');
  } catch (error) { db.exec('ROLLBACK TO team_access; RELEASE team_access'); throw error; }
}

// Worker mode adds policy to ordinary identities; relationships remain parent authority.
export function migrateWorkerMode(db) {
  if (!db.prepare('PRAGMA table_info(buddies)').all().some(c => c.name === 'employment_mode'))
    db.exec("ALTER TABLE buddies ADD COLUMN employment_mode TEXT NOT NULL DEFAULT 'standing' CHECK(employment_mode IN ('standing','worker'))");
  db.exec(`
    CREATE TRIGGER IF NOT EXISTS worker_mode_parent_delete BEFORE DELETE ON buddy_relationships
    WHEN OLD.kind='manager' AND EXISTS(SELECT 1 FROM buddies WHERE id=OLD.to_buddy_id AND employment_mode='worker')
    BEGIN SELECT RAISE(ABORT,'Worker parent is fixed for its lifetime'); END;
    CREATE TRIGGER IF NOT EXISTS worker_mode_parent_update BEFORE UPDATE ON buddy_relationships
    WHEN OLD.kind='manager' AND EXISTS(SELECT 1 FROM buddies WHERE id=OLD.to_buddy_id AND employment_mode='worker')
    BEGIN SELECT RAISE(ABORT,'Worker parent is fixed for its lifetime'); END;
    CREATE TRIGGER IF NOT EXISTS worker_mode_parent_insert BEFORE INSERT ON buddy_relationships
    WHEN NEW.kind='manager' AND EXISTS(SELECT 1 FROM buddies WHERE id=NEW.to_buddy_id AND employment_mode='worker')
      AND NOT EXISTS(SELECT 1 FROM buddy_relationships WHERE kind='manager' AND to_buddy_id=NEW.to_buddy_id AND from_buddy_id=NEW.from_buddy_id)
    BEGIN SELECT RAISE(ABORT,'Worker parent is fixed for its lifetime'); END;
  `);
  if (db.prepare('PRAGMA user_version').get().user_version < 29) db.exec('PRAGMA user_version=29');
}

export const teamAccessMethods = {
  getTeamContractVersion() { return '2026-09-12.2'; },
  // Host-only. Employee MCP never exposes grant mutation or accepts an owner actor.
  setBuddyAccess({ granteeId, workspaceId, targetBuddyId, capabilities, baseRevision, key, reason, expiresAt, createdBuddyIncoming }) {
    return this.coordinationCommand({ actor: 'owner', workspaceId, key,
      payload: { granteeId, targetBuddyId, capabilities, baseRevision, reason, expiresAt, createdBuddyIncoming } }, () => {
      const targetId = targetBuddyId ?? workspaceId;
      if (!Array.isArray(capabilities) || capabilities.some((c) => !TEAM_CAPABILITIES.includes(c)))
        throw new Error('Unknown team capability');
      const previous = this.getBuddyAccess(granteeId, workspaceId, targetId);
      const revoking = !!previous && capabilities.length === 0 && createdBuddyIncoming !== true;
      if (!revoking && (!this.getCoordinationMembership(granteeId, workspaceId) ||
          (targetBuddyId && !this.getCoordinationMembership(targetBuddyId, workspaceId))))
        throw new Error('Grant participants must belong to the workspace');
      if (!targetBuddyId && capabilities.some((c) => c !== 'staff.create'))
        throw new Error('This capability requires an explicit target Buddy');
      if (targetBuddyId && capabilities.includes('staff.create'))
        throw new Error('Staff creation is granted on the workspace');
      if (!reason?.trim()) throw new Error('An owner reason is required');
      const expiry = expiresAt ? new Date(expiresAt).toISOString() : null;
      if (expiry && expiry <= now()) throw new Error('Grant expiry must be in the future');
      if (baseRevision !== (previous?.revision ?? 0)) throw new Error(`Grant revision conflict: current ${previous?.revision ?? 0}`);
      if (createdBuddyIncoming !== undefined && typeof createdBuddyIncoming !== 'boolean') throw new Error('createdBuddyIncoming must be boolean');
      if ((createdBuddyIncoming !== undefined && targetBuddyId) || (createdBuddyIncoming === true && !capabilities.includes('staff.create'))) throw new Error('createdBuddyIncoming requires workspace staff.create');
      const createdIncoming = !targetBuddyId && capabilities.includes('staff.create') ? (createdBuddyIncoming ?? !!previous?.created_buddy_incoming) : false;
      this.db.prepare(`INSERT INTO buddy_access_grants (grantee_id,workspace_id,target_id,capabilities,revision,expires_at,reason,updated_at,created_buddy_incoming) VALUES (?,?,?,?,?,?,?,?,?)
        ON CONFLICT(grantee_id,workspace_id,target_id) DO UPDATE SET capabilities=excluded.capabilities,
        revision=excluded.revision,expires_at=excluded.expires_at,reason=excluded.reason,updated_at=excluded.updated_at,created_buddy_incoming=excluded.created_buddy_incoming`)
        .run(granteeId, workspaceId, targetId, JSON.stringify([...new Set(capabilities)].sort()), baseRevision + 1, expiry, reason, now(), Number(createdIncoming));
      const grant = this.getBuddyAccess(granteeId, workspaceId, targetId);
      this.recordAuditEvent({ buddy: granteeId, workspace: workspaceId, operation: 'owner.set_buddy_access',
        payload: { targetId, capabilities: grant.capabilities, revision: grant.revision, reason, expiresAt: expiry, createdBuddyIncoming: createdIncoming } });
      return grant;
    });
  },

  getBuddyAccess(granteeId, workspaceId, targetId) {
    const row = this.db.prepare('SELECT * FROM buddy_access_grants WHERE grantee_id=? AND workspace_id=? AND target_id=?')
      .get(granteeId, workspaceId, targetId);
    return row ? { ...row, capabilities: JSON.parse(row.capabilities), created_buddy_incoming: !!row.created_buddy_incoming } : null;
  },

  listBuddyAccess(granteeId, workspaceId) {
    return this.db.prepare('SELECT target_id FROM buddy_access_grants WHERE grantee_id=? AND workspace_id=? ORDER BY target_id')
      .all(granteeId, workspaceId)
      .map(({ target_id }) => this.getBuddyAccess(granteeId, workspaceId, target_id));
  },

  buddyCapability({ actor, workspaceId, targetBuddyId, capability }) {
    const targetId = targetBuddyId ?? workspaceId;
    const unavailable = (code, reason, remedy) => ({ allowed: false, code, reason, remedy });
    if (!this.getCoordinationMembership(actor, workspaceId) ||
        (targetBuddyId && !this.getCoordinationMembership(targetBuddyId, workspaceId)))
      return unavailable('workspace_scope', 'The actor or target is outside this workspace.', 'Owner must admit the intended identity to the workspace.');
    if (this.getBuddy(actor)?.status !== 'active' || (targetBuddyId && this.getBuddy(targetBuddyId)?.status !== 'active'))
      return unavailable('inactive_buddy', 'The actor or target is not active.', 'Owner must inspect the archived or paused identity.');
    const grant = this.getBuddyAccess(actor, workspaceId, targetId);
    if (!grant || !grant.capabilities.includes(capability))
      return unavailable('owner_grant_required', `No owner grant for ${capability} on this target.`, 'Owner can grant this capability for the exact target in Team access.');
    if (grant.expires_at && grant.expires_at <= now())
      return unavailable('grant_expired', 'The owner grant has expired.', 'Owner can renew the bounded grant.');
    return { allowed: true, code: 'owner_grant', reason: grant.reason, remedy: null, grantRevision: grant.revision, expiresAt: grant.expires_at, createdBuddyIncoming: !!grant.created_buddy_incoming };
  },

  requireBuddyCapability(input) {
    const result = this.buddyCapability(input);
    if (!result.allowed) {
      const error = new Error(result.reason);
      error.code = result.code;
      error.details = result;
      throw error;
    }
    return result;
  },

  createTeamBuddy(input, { actor, workspaceId, key }) {
    return this.coordinationTransaction(() => {
      this.requireBuddyCapability({ actor, workspaceId, capability: 'staff.create' });
      if (Object.keys(input).some(k => !['name','role','soul','provider','model','reasoningEffort','backgroundEnabled','employmentMode'].includes(k))) throw new Error('Creation contains protected fields');
      const staffGrant = this.getBuddyAccess(actor,workspaceId,workspaceId);
      if (input.backgroundEnabled !== undefined && (typeof input.backgroundEnabled !== 'boolean' || !staffGrant.created_buddy_incoming)) throw new Error('Initial incoming work is protected by the createdBuddyIncoming staffing grant');
      if (input.employmentMode !== undefined && !['standing','worker'].includes(input.employmentMode)) throw new Error('Invalid employment mode');
      const worker = input.employmentMode === 'worker';
      if (worker && this.getBuddy(actor)?.status !== 'active') throw new Error('Worker parent must be active');
      const scope = `team:${actor}:${workspaceId}`;
      const result = this.createBuddyFromBuilder({ ...input, project: workspaceId,
        conversationId: scope, creationKey: key, requestFingerprint: hash(input) });
      if (worker) {
        this.setBuddyRelationship({fromBuddy:actor, toBuddy:result.buddy.id, kind:'manager'});
        this.db.prepare("UPDATE buddies SET employment_mode='worker' WHERE id=?").run(result.buddy.id);
        result.buddy = this.getBuddy(result.buddy.id);
      }
      // The creation mandate admits only this new identity to routine configuration.
      // It cannot confer hiring, schedule activation or onward grant authority.
      if (!this.getBuddyAccess(actor, workspaceId, result.buddy.id)) {
        this.setBuddyAccess({ granteeId: actor, workspaceId, targetBuddyId: result.buddy.id,
          capabilities: ['relationship.write','profile.read','profile.write','soul.read','soul.write','memory.read','memory.write',...(staffGrant.created_buddy_incoming ? ['execution.manage'] : [])],
          baseRevision: 0, key: `created:${result.buddy.id}`, reason: 'Target admitted by owner-authorized staff creation.' });
      }
      return result;
    });
  },

  setTeamRelationship({ fromBuddyId, toBuddyId, kind, key, present = true }, { actor, workspaceId }) {
    return this.coordinationTransaction(() => {
      if (typeof present !== 'boolean') throw new Error('Relationship present must be boolean');
      if (!['manager','consults'].includes(kind)) throw new Error('Unsupported relationship kind');
      for (const targetBuddyId of new Set([fromBuddyId, toBuddyId])) {
        if (targetBuddyId !== actor || toBuddyId === actor) this.requireBuddyCapability({ actor, workspaceId, targetBuddyId, capability: 'relationship.write' });
        if (!this.getCoordinationMembership(targetBuddyId, workspaceId)) throw new Error('Relationship participant is outside workspace');
      }
      if (kind === 'manager') {
        for (const workspace of this.listBuddyWorkspaces(toBuddyId)) {
          if (!this.getCoordinationMembership(fromBuddyId, workspace.id)) throw new Error('Manager must belong to every report workspace');
          if (workspace.id !== workspaceId)
            this.requireBuddyCapability({ actor, workspaceId: workspace.id, targetBuddyId: toBuddyId, capability: 'relationship.write' });
        }
      }
      return this.coordinationCommand({ actor, workspaceId, key, payload: { fromBuddyId, toBuddyId, kind, present } }, () => {
        if (!present) {
          this.db.prepare('DELETE FROM buddy_relationships WHERE from_buddy_id=? AND to_buddy_id=? AND kind=?').run(fromBuddyId,toBuddyId,kind);
          if (kind === 'manager') this.db.prepare("DELETE FROM buddy_relationships WHERE from_buddy_id=? AND to_buddy_id=? AND kind='reports_to'").run(toBuddyId,fromBuddyId);
          this.recordAuditEvent({buddy:actor,workspace:workspaceId,operation:'buddy.set_relationship',payload:{fromBuddyId,toBuddyId,kind,present}});
          return {fromBuddyId,toBuddyId,kind,present};
        }
        if (kind === 'manager') this.db.prepare("DELETE FROM buddy_relationships WHERE (kind='manager' AND to_buddy_id=?) OR (kind='reports_to' AND from_buddy_id=?)")
          .run(toBuddyId, toBuddyId);
        const result = this.setBuddyRelationship({ fromBuddy: fromBuddyId, toBuddy: toBuddyId, kind });
        this.recordAuditEvent({ buddy: actor, workspace: workspaceId, operation: 'buddy.set_relationship', payload: { fromBuddyId, toBuddyId, kind } });
        return result;
      });
    });
  },

  getTeamProfile(targetBuddyId) {
    const buddy = this.getBuddy(targetBuddyId);
    if (!buddy) throw new Error('Buddy not found');
    return { buddyId: buddy.id, name: buddy.name, role: buddy.role, provider: buddy.provider,
      model: buddy.model, reasoningEffort: buddy.reasoning_effort, revision: buddy.profile_revision };
  },

  updateTeamProfile({ targetBuddyId, key, baseRevision, reason, changes }, { actor, workspaceId }) {
    return this.coordinationTransaction(() => {
      if (actor !== 'owner' && Object.keys(changes ?? {}).some(k => k !== 'backgroundEnabled')) this.requireBuddyCapability({ actor, workspaceId, targetBuddyId, capability: 'profile.write' });
      if (actor !== 'owner' && changes?.backgroundEnabled !== undefined) this.requireBuddyCapability({ actor, workspaceId, targetBuddyId, capability: 'execution.manage' });
      if (actor !== 'owner') this.requireBuddyCapability({ actor, workspaceId, targetBuddyId, capability: 'profile.read' });
      if (!this.getCoordinationMembership(targetBuddyId, workspaceId)) throw new Error('Profile is outside workspace');
      if (!reason?.trim() || !changes || !Object.keys(changes).length) throw new Error('Profile changes and reason are required');
      if (Object.keys(changes).some((k) => !['name','role','provider','model','reasoningEffort','backgroundEnabled','employmentMode'].includes(k)))
        throw new Error('Profile contains protected fields');
      return this.coordinationCommand({ actor, workspaceId, key, payload: { targetBuddyId, baseRevision, reason, changes } }, () => {
        const before = this.getTeamProfile(targetBuddyId);
        if (before.revision !== baseRevision) throw new Error(`Profile revision conflict: current ${before.revision}`);
        const { backgroundEnabled, ...profile } = changes;
        if (Object.keys(profile).length) this.updateBuddy(targetBuddyId, profile);
        if (backgroundEnabled !== undefined) {
          if (typeof backgroundEnabled !== 'boolean') throw new Error('backgroundEnabled must be boolean');
          this.setCoordinationMembership(targetBuddyId, workspaceId, {background_enabled:backgroundEnabled});
        }
        const after = this.getTeamProfile(targetBuddyId);
        this.recordAuditEvent({ buddy: actor === 'owner' ? targetBuddyId : actor, workspace: workspaceId, operation: actor === 'owner' ? 'owner.update_profile' : 'buddy.update_profile',
          payload: { targetBuddyId, before, after, reason } });
        return { before, after, execution: {backgroundEnabled:!!this.getCoordinationMembership(targetBuddyId, workspaceId)?.background_enabled} };
      });
    });
  },

  readTeamDocument({ targetBuddyId, doc }, { actor, workspaceId }) {
    this.requireBuddyCapability({ actor, workspaceId, targetBuddyId, capability: `${doc === 'soul' ? 'soul' : 'memory'}.read` });
    if (doc === 'soul') {
      const head = this.readBuddySoul(targetBuddyId);
      return { buddyId: targetBuddyId, doc, content: head.body, revision: head.revision };
    }
    if (!['working','long_term'].includes(doc)) throw new Error('Unknown document');
    const memory = this.readBuddyMemory(targetBuddyId);
    return { buddyId: targetBuddyId, doc, content: doc === 'working' ? memory.working : memory.longTerm,
      revision: doc === 'working' ? memory.workingRevision : memory.longTermRevision };
  },

  updateTeamDocument({ targetBuddyId, doc, content, baseVersion, reasoning, key, preview = false }, { actor, workspaceId, conversationId }) {
    return this.coordinationTransaction(() => {
      this.requireBuddyCapability({ actor, workspaceId, targetBuddyId, capability: `${doc === 'soul' ? 'soul' : 'memory'}.write` });
      // A diff is a read: write-only grants must not reveal the prior private document.
      const before = this.readTeamDocument({ targetBuddyId, doc }, { actor, workspaceId });
      const apply = () => {
        if (before.revision !== baseVersion) {
          const error = new Error(`Document revision conflict: current ${before.revision}`);
          error.code = 'MEMORY_STALE'; error.details = { currentRevision: before.revision }; throw error;
        }
        if (typeof content !== 'string' || !reasoning?.trim()) throw new Error('Complete document and reason are required');
        const cap = MEMORY_DOCUMENT_CAPS[doc];
        if (content.length > cap) throw new Error(`${doc} memory exceeds ${cap} characters`);
        const oldLines = before.content.split('\n'), newLines = content.split('\n');
        let start = 0, end = 0;
        while (start < oldLines.length && start < newLines.length && oldLines[start] === newLines[start]) start++;
        while (end < oldLines.length - start && end < newLines.length - start && oldLines[oldLines.length-1-end] === newLines[newLines.length-1-end]) end++;
        const diff = { startLine: start + 1, removed: oldLines.slice(start,oldLines.length-end), added: newLines.slice(start,newLines.length-end) };
        if (preview) return { preview: true, targetBuddyId, doc, baseVersion, diff };
        const provenance = { source: 'owner-granted-team-edit', actor, workspace_id: workspaceId, conversation_id: conversationId ?? null };
        const input = { content, reasoning, baseVersion, requestedBy: actor, authorKind: 'buddy', provenance };
        if (doc === 'soul') {
          const buddy = this.getBuddy(targetBuddyId);
          if (!buddy.soul_path) {
            if (!/^[A-Za-z0-9_-]+$/.test(buddy.slug)) throw new Error('Invalid Buddy profile slug');
            // Provision only the canonical pointer, after authority, validation and CAS.
            // The existing document ledger owns the body and its file projection.
            this.updateBuddy(targetBuddyId, { soulPath: `profiles/${buddy.slug}/BUDDY_SOUL.md` });
          }
          this.updateSoul(targetBuddyId, input);
        }
        else this.updateMemory(targetBuddyId, { ...input, doc });
        const after = this.readTeamDocument({ targetBuddyId, doc }, { actor, workspaceId });
        this.recordAuditEvent({ buddy: actor, workspace: workspaceId, operation: doc === 'soul' ? 'buddy.update_soul' : 'buddy.update_memory',
          payload: { targetBuddyId, doc, baseVersion, revision: after.revision, reasoning,
            beforeHash: hash(before.content), afterHash: hash(content) } });
        return { ...after, diff, baseVersion };
      };
      return preview ? apply() : this.coordinationCommand({ actor, workspaceId, key,
        payload: { operation: 'update_document', targetBuddyId, doc, content, baseVersion, reasoning } }, apply);
    });
  },

  getMessageExecution(messageId) {
    const message = this.getMessage(messageId);
    if (!message) throw new Error('Message not found');
    const row = this.db.prepare("SELECT id FROM buddy_runs WHERE input_id=? AND input_kind='message_request' ORDER BY rowid DESC LIMIT 1").get(messageId);
    const run = row ? this.getBuddyRun(row.id) : null;
    const project = message.buddy_project_id ? this.getBuddyProject(message.buddy_project_id) : null;
    // A message can reference the sender's work. Its acceptance is not the recipient's acknowledgement.
    const acceptedProject = project?.buddy_id === message.to_buddy_id && project?.accepted_by === message.to_buddy_id ? project : null;
    const admitted = this.db.prepare("SELECT id, acknowledged_at FROM buddy_runs WHERE input_id=? AND input_kind='message_request' AND acknowledged_at IS NOT NULL ORDER BY acknowledged_at LIMIT 1").get(messageId);
    const acknowledgedAt = admitted?.acknowledged_at ?? message.replied_at ?? null;
    const membership = message.to_buddy_id ? this.getCoordinationMembership(message.to_buddy_id, message.workspace_id) : null;
    let code = null, reason = null, remedy = null;
    const held = (c, r, a) => { code = c; reason = r; remedy = a; };
    if (!message.to_buddy_id) held('owner_reply', 'Waiting for the owner response.', 'Owner can reply in the inbox.');
    else if (!run && !message.child_conversation_id) held('legacy_dispatch', 'No durable recipient run is bound to this legacy message.', 'Inspect the legacy dispatch receipt before retrying.');
    else if (run?.status === 'queued') {
      const gates = project ? this.projectAncestors(project.id) : [];
      const active = this.coordinationActiveCounts();
      if (!membership?.background_enabled) held('background_disabled', 'Recipient background execution is disabled.', 'Owner can enable incoming work in recipient execution settings.');
      else if (membership.background_paused_reason) held('background_paused', membership.background_paused_reason, 'Owner can inspect the cause and resume incoming work.');
      else if (this.getBuddy(message.to_buddy_id)?.status !== 'active') held('inactive_buddy', 'Recipient is not active.', 'Owner can inspect the paused or archived recipient.');
      else if (gates.some(p => p.execution_state !== 'enabled')) held('project_gate', 'The project or an ancestor is paused, cancelled or transferring ownership.', 'Inspect the project controls; an owner or authorized supervisor must resolve the gate.');
      else if (active.length >= 8 || active.filter(r => r.buddy_id === message.to_buddy_id).length >= membership.max_active_runs) held('active_run_limit', 'Available execution slots are occupied.', 'Wait for active work to drain or ask the owner to review execution limits.');
      else if (run.ready_at > now()) held('not_due', `Scheduled for ${run.ready_at}.`, 'Wait until the scheduled time.');
      else if (run.after_run_id && this.getBuddyRun(run.after_run_id)?.status !== 'complete') held('predecessor', 'Waiting for the source run to complete successfully.', 'Inspect the source run; explicitly retry an interrupted attempt.');
      else if (run.error) held(run.error_code ?? 'admission_held', run.error, 'Resolve the reported admission condition, then let the scheduler retry.');
      else held('awaiting_admission', 'Accepted; waiting for an available executor and conversation slot.', 'Wait for the active turn to drain; inspect scheduler health if this persists.');
    }
    if (run?.status === 'failed') held(run.error_code ?? 'execution_failed', run.error ?? 'Execution failed.', 'Inspect the attempt and recovery receipt before retrying.');
    const background = this.getBackgroundWork(messageId);
    if (background && !['queued','running'].includes(background.disposition)) held(background.disposition, background.reason, background.disposition === 'waiting' ? 'Wait for delegated replies; completion wakes this work.' : 'Inspect canonical work and the latest attempt.');
    if (run?.error_code === 'return_held') held('return_held', run.error, 'Restore the requester workspace membership or runtime admission condition; the original result will be delivered without repeating work.');
    return { background: background ? {mode:'until_done',disposition:background.disposition,maxRuns:background.execution.maxRuns,maxDurationSeconds:background.execution.maxDurationSeconds,runsUsed:background.runsUsed,startedAt:background.startedAt,deadline:background.deadline,waitingMessageIds:background.waitingMessageIds} : null, messageId, runId: run?.id ?? null, projectId: project?.id ?? null,
      state: background && !['queued','running'].includes(background.disposition) ? background.disposition : run?.status === 'queued' && code && code !== 'awaiting_admission' ? 'held' : run?.status ?? message.status,
      code, reason, remedy, conversationId: run?.conversation_id ?? message.child_conversation_id,
      acknowledgedAt, acknowledgedRunId: admitted?.id ?? null,
      acceptedBy: message.replied_by ?? null, acceptedAt: message.replied_at ?? null,
      completionEvidence: message.reply_evidence ?? [],
      projectSnapshot: project ? {id:project.id, revision:project.revision, status:project.status, updatedAt:project.updated_at, acceptedBy:acceptedProject?.accepted_by ?? null, acceptedAt:acceptedProject?.accepted_at ?? null, evidenceCount:(typeof project.completion_evidence === 'string' ? JSON.parse(project.completion_evidence) : project.completion_evidence ?? []).length} : null,
      delivery: this.getMessageDeliveries(messageId),
      outcome: message.outcome, error: run?.error ?? null };
  },
};
