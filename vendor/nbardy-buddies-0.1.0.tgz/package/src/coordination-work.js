import { randomUUID } from 'node:crypto';
const now = () => new Date().toISOString();

export function migrateCoordinationWork(db) {
  const add = (table, name, definition) => {
    if (
      !db
        .prepare(`PRAGMA table_info(${table})`)
        .all()
        .some((row) => row.name === name)
    )
      db.exec(`ALTER TABLE ${table} ADD COLUMN ${name} ${definition}`);
  };
  add('owned_projects', 'parent_project_id', 'TEXT REFERENCES owned_projects(id)');
  add('owned_projects', 'revision', 'INTEGER NOT NULL DEFAULT 1');
  add(
    'owned_projects',
    'execution_state',
    "TEXT NOT NULL DEFAULT 'enabled' CHECK(execution_state IN ('enabled','paused','draining','cancelled'))"
  );
  add('owned_projects', 'execution_epoch', 'INTEGER NOT NULL DEFAULT 1');
  add('owned_projects', 'pending_owner_id', 'TEXT REFERENCES buddies(id)');
  add('owned_projects', 'completion_evidence', "TEXT NOT NULL DEFAULT '[]'");
  add('buddy_runs', 'project_epochs', "TEXT NOT NULL DEFAULT '[]'");
  for (const [name, type] of Object.entries({
    read_all_work: 'INTEGER NOT NULL DEFAULT 0',
    dispatch: 'INTEGER NOT NULL DEFAULT 1',
    background_enabled: 'INTEGER NOT NULL DEFAULT 0',
    max_active_runs: 'INTEGER NOT NULL DEFAULT 2',
    max_background_runs_per_hour: 'INTEGER NOT NULL DEFAULT 30',
    max_sends_per_hour: 'INTEGER NOT NULL DEFAULT 100',
    max_pending_runs: 'INTEGER NOT NULL DEFAULT 100',
    background_paused_reason: 'TEXT',
  }))
    add('buddy_projects', name, type);
}

export function migrateTaskComments(db) {
  if (db.prepare('PRAGMA user_version').get().user_version >= 30) return;
  db.exec(`SAVEPOINT task_comments;
    CREATE TABLE IF NOT EXISTS buddy_task_comments (
      id TEXT PRIMARY KEY,
      project_id TEXT NOT NULL REFERENCES owned_projects(id) ON DELETE CASCADE,
      author TEXT NOT NULL,
      body TEXT NOT NULL,
      evidence TEXT NOT NULL DEFAULT '[]',
      created_at TEXT NOT NULL
    ) STRICT;
    CREATE INDEX IF NOT EXISTS buddy_task_comments_project_order
      ON buddy_task_comments(project_id, created_at DESC, id DESC);
    PRAGMA user_version=30;
    RELEASE task_comments;`);
}

function validateCommentEvidence(value = []) {
  if (
    !Array.isArray(value) ||
    value.length > 32 ||
    value.some((entry) => typeof entry !== 'string' || !entry.trim() || entry.length > 4000)
  )
    throw new Error('Task comment evidence must contain at most 32 non-empty 4000-byte references');
  return value.map((entry) => entry.trim());
}

function encodeCommentCursor(comment) {
  return Buffer.from(JSON.stringify([comment.created_at, comment.id]), 'utf8').toString('base64url');
}

function decodeCommentCursor(cursor) {
  if (cursor === undefined) return null;
  try {
    const value = JSON.parse(Buffer.from(cursor, 'base64url').toString('utf8'));
    if (!Array.isArray(value) || value.length !== 2 || value.some((entry) => typeof entry !== 'string' || !entry))
      throw new Error();
    return value;
  } catch {
    throw new Error('Invalid Task comment cursor');
  }
}

export const coordinationWorkMethods = {
  appendTaskComment({ projectId, key, body, evidence = [] }, { actor, workspaceId, runId } = {}) {
    const project = this.getBuddyProject(projectId);
    if (!project || project.workspace_id !== workspaceId) throw new Error('Task is outside workspace scope');
    if (actor !== 'owner' && (!this.getCoordinationMembership(actor, workspaceId) || !this.canReadCoordinationProject(actor, projectId)))
      throw new Error('Task comment is outside participant scope');
    if (typeof body !== 'string' || !body.trim()) throw new Error('Task comment body is required');
    if (body.trim().length > 32_000) throw new Error('Task comment body exceeds 32000 characters');
    const references = validateCommentEvidence(evidence);
    const write = () => this.coordinationCommand(
      { actor, workspaceId, key, payload: { projectId, body: body.trim(), evidence: references } },
      () => {
        const comment = {
          id: `task_comment_${randomUUID()}`,
          project_id: projectId,
          author: actor,
          body: body.trim(),
          evidence: references,
          created_at: now(),
        };
        this.db.prepare('INSERT INTO buddy_task_comments VALUES (?,?,?,?,?,?)').run(
          comment.id,
          comment.project_id,
          comment.author,
          comment.body,
          JSON.stringify(comment.evidence),
          comment.created_at
        );
        this.recordAuditEvent({
          buddy: actor === 'owner' ? project.buddy_id : actor,
          workspace: workspaceId,
          project: projectId,
          operation: 'buddy.append_task_comment',
          payload: { commentId: comment.id },
        });
        return comment;
      }
    );
    if (!runId) return write();
    const run = this.getBuddyRun(runId);
    if (!run || run.buddy_id !== actor || run.workspace_id !== workspaceId)
      throw new Error('Task comment run authority is outside scope');
    return this.withBuddyRunAuthority(runId, run.claim_token, 'buddy.append_task_comment', write);
  },

  listTaskComments({ projectId, limit = 50, cursor } = {}, { actor, workspaceId } = {}) {
    const project = this.getBuddyProject(projectId);
    if (!project || project.workspace_id !== workspaceId) throw new Error('Task is outside workspace scope');
    if (actor !== 'owner' && (!this.getCoordinationMembership(actor, workspaceId) || !this.canReadCoordinationProject(actor, projectId)))
      throw new Error('Task comments are outside participant scope');
    if (!Number.isSafeInteger(limit) || limit < 1 || limit > 100) throw new Error('Task comment limit must be between 1 and 100');
    const after = decodeCommentCursor(cursor);
    const rows = this.db.prepare(`SELECT * FROM buddy_task_comments
      WHERE project_id=? ${after ? 'AND (created_at < ? OR (created_at = ? AND id < ?))' : ''}
      ORDER BY created_at DESC,id DESC LIMIT ?`).all(
      projectId,
      ...(after ? [after[0], after[0], after[1]] : []),
      limit + 1
    );
    const page = rows.slice(0, limit).map((row) => ({ ...row, evidence: JSON.parse(row.evidence) }));
    return {
      items: page,
      nextCursor: rows.length > limit ? encodeCommentCursor(page.at(-1)) : null,
    };
  },

  reparentBuddy(buddyId, { managerId, key }) {
    const buddy = this.getBuddy(buddyId),
      manager = this.getBuddy(managerId);
    if (!buddy || !manager || buddy.status === 'archived' || manager.status !== 'active')
      throw new Error('Both staff identities must be available');
    return this.coordinationCommand(
      { actor: 'owner', workspaceId: buddy.project_id, key, payload: { buddyId, managerId } },
      () => {
        if (!this.getCoordinationMembership(managerId, buddy.project_id))
          throw new Error('Manager must belong to the report home workspace');
        this.db
          .prepare(
            "DELETE FROM buddy_relationships WHERE (kind='manager' AND to_buddy_id=?) OR (kind='reports_to' AND from_buddy_id=?)"
          )
          .run(buddyId, buddyId);
        const edge = this.setBuddyRelationship({
          fromBuddy: managerId,
          toBuddy: buddyId,
          kind: 'manager',
        });
        this.recordAuditEvent({
          buddy: buddyId,
          workspace: buddy.project_id,
          operation: 'buddy.reparent',
          payload: { managerId },
        });
        return edge;
      }
    );
  },

  getCoordinationMembership(buddyId, workspaceId) {
    return (
      this.db
        .prepare('SELECT * FROM buddy_projects WHERE buddy_id=? AND project_id=?')
        .get(buddyId, workspaceId) ?? null
    );
  },

  // Host-only: scoped agent tools never expose this mutation.
  setCoordinationMembership(buddyId, workspaceId, patch) {
    return this.coordinationTransaction(() => {
      if (!this.getCoordinationMembership(buddyId, workspaceId))
        throw new Error('Membership not found');
      const allowed = [
        'read_all_work',
        'dispatch',
        'background_enabled',
        'max_active_runs',
        'max_background_runs_per_hour',
        'max_sends_per_hour',
        'max_pending_runs',
        'background_paused_reason',
      ];
      for (const [key, value] of Object.entries(patch)) {
        if (!allowed.includes(key)) throw new Error('Unknown membership setting');
        if (key.startsWith('max_') && (!Number.isSafeInteger(value) || value < 1 || value > 10000))
          throw new Error('Invalid execution limit');
        if (
          ['read_all_work', 'dispatch', 'background_enabled'].includes(key) &&
          ![true, false, 0, 1].includes(value)
        )
          throw new Error('Invalid membership flag');
        if (key === 'background_paused_reason' && value !== null && typeof value !== 'string')
          throw new Error('Invalid pause reason');
        this.db
          .prepare(`UPDATE buddy_projects SET ${key}=? WHERE buddy_id=? AND project_id=?`)
          .run(typeof value === 'boolean' ? Number(value) : value, buddyId, workspaceId);
      }
      if (Object.keys(patch).length) this.db.prepare('UPDATE buddies SET profile_revision=profile_revision+1 WHERE id=?').run(buddyId);
      return this.getCoordinationMembership(buddyId, workspaceId);
    });
  },

  isCoordinationManager(managerId, reportId) {
    return this.listBuddyRelationships(managerId).some(
      (r) =>
        (r.kind === 'manager' && r.from_buddy_id === managerId && r.to_buddy_id === reportId) ||
        (r.kind === 'reports_to' && r.to_buddy_id === managerId && r.from_buddy_id === reportId)
    );
  },

  projectAncestors(projectId) {
    const result = [],
      seen = new Set();
    while (projectId) {
      if (seen.has(projectId)) throw new Error('Project hierarchy cycle');
      seen.add(projectId);
      const project = this.getBuddyProject(projectId);
      if (!project) throw new Error('Project not found');
      result.push(project);
      projectId = project.parent_project_id;
    }
    return result;
  },

  canReadCoordinationProject(buddyId, projectId) {
    const project = this.getBuddyProject(projectId);
    if (!project) return false;
    const membership = this.getCoordinationMembership(buddyId, project.workspace_id);
    if (!membership) return false;
    return (
      !!membership.read_all_work ||
      !!this.db
        .prepare(
          "SELECT 1 FROM buddy_messages WHERE buddy_project_id=? AND to_buddy_id=? AND status IN ('pending','active','replied')"
        )
        .get(projectId, buddyId) ||
      project.buddy_id === buddyId ||
      this.isCoordinationManager(buddyId, project.buddy_id) ||
      this.projectAncestors(projectId).some((p) => p.buddy_id === buddyId)
    );
  },

  canManageCoordinationProject(buddyId, projectId) {
    const project = this.getBuddyProject(projectId);
    return (
      !!project &&
      !!this.getCoordinationMembership(buddyId, project.workspace_id) &&
      (project.buddy_id === buddyId ||
        this.isCoordinationManager(buddyId, project.buddy_id) ||
        this.projectAncestors(projectId).some((p) => p.buddy_id === buddyId))
    );
  },

  assertProjectExecution(projectId, epochs, { admission = false, operation } = {}) {
    if (!projectId) return;
    const ancestors = this.projectAncestors(projectId);
    for (const p of ancestors) {
      if (p.execution_state !== 'enabled' || p.status === 'cancelled')
        throw new Error('Project execution is paused or cancelled');
      if (epochs && !epochs.some((e) => e.id === p.id && e.epoch === p.execution_epoch))
        throw new Error('Project execution epoch is stale');
    }
    // A finished project remains discussable; every work mutation checks this gate.
    if (
      ancestors.some((p) => p.status === 'done') && !admission &&
      ![
        'buddy.reply', 'buddy.send', 'buddy.get_inbox', 'buddy.get_current_work',
        'buddy.get_message', 'buddy.get_team_state', 'buddy.get_runs', 'buddy.list_buddies', 'buddy.get_automations',
        'buddy.append_task_comment', 'buddy.list_task_comments',
        'buddy.get_soul', 'buddy.get_memory', 'buddy.get_capabilities', 'buddy.get_profile', 'buddy.recall', 'buddy.remember_note',
        'buddy.update_memory', 'buddy.get_document', 'buddy.list_documents',
      ].includes(operation)
    )
      throw new Error('Completed project must be reopened');
  },

  createCoordinatedProject(input, { actor, key }) {
    const ownerId = input.ownerId ?? actor;
    return this.coordinationCommand(
      { actor, workspaceId: input.workspaceId, key, payload: input },
      () => {
        if (
          (actor !== 'owner' && !this.getCoordinationMembership(actor, input.workspaceId)) ||
          !this.getCoordinationMembership(ownerId, input.workspaceId)
        )
          throw new Error('Project assignment is outside membership');
        if (actor !== 'owner' && actor !== ownerId && !this.isCoordinationManager(actor, ownerId))
          throw new Error('Project assignee is not a direct report');
        if (input.parentProjectId) {
          const parent = this.getBuddyProject(input.parentProjectId);
          if (
            !parent ||
            (actor !== 'owner' && !this.canManageCoordinationProject(actor, parent.id)) ||
            !this.getCoordinationMembership(parent.buddy_id, input.workspaceId)
          )
            throw new Error('Parent project is outside supervisor scope');
          this.assertProjectExecution(parent.id, null, { operation: 'buddy.new_project' });
        }
        if (input.status === 'done')
          throw new Error('Complete newly created work through an evidence-bearing update');
        const project = this.newProject({ ...input, buddy: ownerId, workspace: input.workspaceId });
        this.db
          .prepare('UPDATE owned_projects SET parent_project_id=? WHERE id=?')
          .run(input.parentProjectId ?? null, project.id);
        return this.getBuddyProject(project.id);
      }
    );
  },

  finishProjectHandoffs() {
    const completed = [];
    for (const pending of this.db
      .prepare('SELECT id FROM owned_projects WHERE pending_owner_id IS NOT NULL')
      .all()) {
      this.coordinationTransaction(() => {
        const project = this.getBuddyProject(pending.id);
        const descendants = this.db
          .prepare(
            'WITH RECURSIVE tree(id) AS (SELECT ? UNION ALL SELECT p.id FROM owned_projects p JOIN tree t ON p.parent_project_id=t.id) SELECT id FROM tree'
          )
          .all(project.id)
          .map((p) => p.id);
        if (
          this.db
            .prepare(
              "SELECT project_id FROM buddy_runs WHERE status IN ('claimed','running','cancel_requested') UNION ALL SELECT a.buddy_project_id AS project_id FROM buddy_automation_runs r JOIN buddy_automations a ON a.id=r.automation_id WHERE r.status IN ('claimed','running','cancel_requested')"
            )
            .all()
            .some((r) => descendants.includes(r.project_id))
        )
          return;
        if (
          this.getBuddy(project.pending_owner_id)?.status !== 'active' ||
          !this.getCoordinationMembership(project.pending_owner_id, project.workspace_id)
        )
          return;
        // Ownership changes only after all affected providers have drained.
        this.db
          .prepare(
            "UPDATE owned_projects SET buddy_id=pending_owner_id,pending_owner_id=NULL,accepted_by=NULL,accepted_at=NULL,execution_state='enabled',revision=revision+1 WHERE id=?"
          )
          .run(project.id);
        for (const message of this.db
          .prepare(
            "SELECT id FROM buddy_messages WHERE buddy_project_id=? AND to_buddy_id=? AND status IN ('pending','active')"
          )
          .all(project.id, project.buddy_id)) {
          const old = this.getMessage(message.id);
          this.db
            .prepare(
              "UPDATE buddy_messages SET status='cancelled',outcome='superseded by ownership handoff',updated_at=? WHERE id=?"
            )
            .run(now(), old.id);
          for (const r of this.db
            .prepare("SELECT id FROM buddy_runs WHERE input_id=? AND status='queued'")
            .all(old.id))
            this.cancelBuddyRun(r.id);
          // Replacement is an explicit new obligation. Preserve immutable sender, return route and root.
          const replacement = { id: `message_${randomUUID()}` };
          this.db
            .prepare(
              `INSERT INTO buddy_messages (id,from_buddy_id,to_buddy_id,workspace_id,purpose,body,evidence,parent_conversation_id,status,wait_status,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,'pending','none',?,?)`
            )
            .run(
              replacement.id,
              old.from_buddy_id,
              project.pending_owner_id,
              old.workspace_id,
              old.purpose,
              `${old.body}\n\nSystem handoff: reassigned from ${project.buddy_id} to ${project.pending_owner_id}.`,
              JSON.stringify(old.evidence),
              old.parent_conversation_id,
              now(),
              now()
            );
          this.db.prepare('UPDATE buddy_messages SET visibility=? WHERE id=?').run(old.visibility ?? 'participants', replacement.id);
          this.recordAuditEvent({
            buddy: project.pending_owner_id,
            workspace: project.workspace_id,
            project: project.id,
            operation: 'buddy.project_handoff',
            payload: {
              from: project.buddy_id,
              to: project.pending_owner_id,
              supersededMessageId: old.id,
              replacementMessageId: replacement.id,
            },
          });
          this.db
            .prepare(
              'UPDATE buddy_messages SET buddy_project_id=?,source_project_id=?,source_workspace_id=?,root_message_id=?,expects_reply=?,command_key=? WHERE id=?'
            )
            .run(
              project.id,
              old.source_project_id,
              old.source_workspace_id,
              old.root_message_id,
              old.expects_reply,
              `handoff:${old.id}:${project.revision}`,
              replacement.id
            );
          this.db
            .prepare('UPDATE buddy_messages SET superseded_by_message_id=? WHERE id=?')
            .run(replacement.id, old.id);
          const original = this.db
            .prepare(
              "SELECT policy FROM buddy_runs WHERE input_id=? AND input_kind='message_request' ORDER BY attempt LIMIT 1"
            )
            .get(old.id);
          this.enqueueBuddyRun({
            inputKey: `message:${replacement.id}:request`,
            inputKind: 'message_request',
            inputId: replacement.id,
            buddyId: project.pending_owner_id,
            workspaceId: old.workspace_id,
            projectId: project.id,
            rootMessageId: old.root_message_id,
            policy: original
              ? JSON.parse(original.policy)
              : { allowed_operations: ['buddy.get_current_work', 'buddy.reply'] },
          });
        }
        this.db
          .prepare('UPDATE buddy_automations SET enabled=0 WHERE buddy_project_id=?')
          .run(project.id);
        for (const id of descendants) {
          const epochs = JSON.stringify(
            this.projectAncestors(id).map((p) => ({ id: p.id, epoch: p.execution_epoch }))
          );
          this.db
            .prepare(
              "UPDATE buddy_runs SET project_epochs=?,error=NULL,error_code=NULL WHERE project_id=? AND status='queued'"
            )
            .run(epochs, id);
        }
        completed.push(project.id);
      });
    }
    return completed;
  },

  updateCoordinatedProject(projectId, changes, { actor, key, runId }) {
    const project = this.getBuddyProject(projectId);
    if (!project) throw new Error('Project not found');
    return this.coordinationCommand(
      { actor, workspaceId: project.workspace_id, key, payload: { projectId, ...changes } },
      () => {
        if (changes.approvalId) {
          const { approvalId, key: ignoredKey, projectId: ignoredProject, ...args } = changes;
          return this.consumeProjectApproval(
            approvalId,
            { ...args, projectId },
            { actor, runId },
            () =>
              this.updateCoordinatedProject(projectId, args, {
                actor: 'owner',
                key: `approved:${approvalId}`,
              })
          );
        }
        const current = this.getBuddyProject(projectId);
        if (actor !== 'owner' && !this.canManageCoordinationProject(actor, projectId))
          throw new Error('Project mutation is outside supervisor scope');
        if (changes.baseRevision !== current.revision)
          throw new Error(`Project revision conflict: current ${current.revision}`);
        if (changes.ownerId && changes.ownerId !== current.buddy_id) {
          if (
            !this.getCoordinationMembership(changes.ownerId, current.workspace_id) ||
            this.getBuddy(changes.ownerId)?.status !== 'active'
          )
            throw new Error('New owner must be active in the workspace');
          if (actor !== 'owner' && !this.isCoordinationManager(actor, changes.ownerId))
            throw new Error('New owner must be a direct report');
          if (current.pending_owner_id) throw new Error('Handoff already pending');
          this.db
            .prepare(
              "UPDATE owned_projects SET pending_owner_id=?,execution_state='draining',execution_epoch=execution_epoch+1,revision=revision+1 WHERE id=?"
            )
            .run(changes.ownerId, projectId);
          for (const r of this.db
            .prepare(
              "WITH RECURSIVE tree(id) AS (SELECT ? UNION ALL SELECT p.id FROM owned_projects p JOIN tree t ON p.parent_project_id=t.id) SELECT r.id FROM buddy_runs r JOIN tree t ON r.project_id=t.id WHERE r.status IN ('claimed','running')"
            )
            .all(projectId))
            this.cancelBuddyRun(r.id);
          this.db
            .prepare(
              "WITH RECURSIVE tree(id) AS (SELECT ? UNION ALL SELECT p.id FROM owned_projects p JOIN tree t ON p.parent_project_id=t.id) UPDATE buddy_automation_runs SET status='cancel_requested' WHERE status IN ('claimed','running') AND automation_id IN (SELECT a.id FROM buddy_automations a JOIN tree t ON a.buddy_project_id=t.id)"
            )
            .run(projectId);
          return this.getBuddyProject(projectId);
        }
        if (
          changes.status === 'done' &&
          (!Array.isArray(changes.evidence) ||
            !changes.evidence.length ||
            changes.evidence.some((e) => typeof e !== 'string' || !e.trim()))
        )
          throw new Error('Completion requires evidence');
        const next = changes.status === 'cancelled' ? 'cancelled' : changes.executionState;
        if (current.execution_state === 'cancelled' && next === 'enabled')
          throw new Error('Cancelled projects cannot resume');
        if (next && !['enabled', 'paused', 'cancelled'].includes(next))
          throw new Error('Invalid project execution state');
        if (
          next === 'enabled' &&
          this.projectAncestors(projectId)
            .slice(1)
            .some((p) => p.execution_state !== 'enabled')
        )
          throw new Error('Ancestor project is paused');
        if (next && next !== current.execution_state) {
          const projects = this.db
            .prepare(
              `WITH RECURSIVE tree(id) AS (SELECT ? UNION ALL SELECT p.id FROM owned_projects p JOIN tree t ON p.parent_project_id=t.id) SELECT id FROM tree`
            )
            .all(projectId);
          if (next === 'enabled') {
            const ids = projects.map((p) => p.id);
            if (
              this.db
                .prepare(
                  "SELECT project_id FROM buddy_runs WHERE status IN ('claimed','running','cancel_requested') UNION ALL SELECT a.buddy_project_id AS project_id FROM buddy_automation_runs r JOIN buddy_automations a ON a.id=r.automation_id WHERE r.status IN ('claimed','running','cancel_requested')"
                )
                .all()
                .some((r) => ids.includes(r.project_id))
            )
              throw new Error('Project execution has not drained');
          }
          this.db
            .prepare(
              'UPDATE owned_projects SET execution_state=?,execution_epoch=execution_epoch+1 WHERE id=?'
            )
            .run(next, projectId);
          if (next === 'enabled')
            for (const p of projects) {
              const epochs = JSON.stringify(
                this.projectAncestors(p.id).map((a) => ({ id: a.id, epoch: a.execution_epoch }))
              );
              this.db
                .prepare(
                  "UPDATE buddy_runs SET project_epochs=?,error=NULL,error_code=NULL WHERE project_id=? AND status='queued'"
                )
                .run(epochs, p.id);
            }
          if (next !== 'enabled')
            for (const p of projects) {
              this.db
                .prepare(
                  "UPDATE buddy_automation_runs SET status='cancel_requested' WHERE status IN ('claimed','running') AND automation_id IN (SELECT id FROM buddy_automations WHERE buddy_project_id=?)"
                )
                .run(p.id);
              for (const r of this.db
                .prepare(
                  "SELECT id FROM buddy_runs WHERE project_id=? AND status IN ('claimed','running')"
                )
                .all(p.id))
                this.cancelBuddyRun(r.id);
              if (next === 'cancelled') {
                this.db
                  .prepare(
                    "UPDATE buddy_runs SET status='cancelled',ended_at=? WHERE project_id=? AND status='queued'"
                  )
                  .run(now(), p.id);
                this.db
                  .prepare(
                    "UPDATE buddy_messages SET status='cancelled' WHERE buddy_project_id=? AND status IN ('pending','active')"
                  )
                  .run(p.id);
                this.db
                  .prepare('UPDATE buddy_automations SET enabled=0 WHERE buddy_project_id=?')
                  .run(p.id);
              }
            }
        }
        this.updateProject(projectId, changes);
        const updated = this.getBuddyProject(projectId);
        const background = this.getProjectBackgroundExecution(projectId);
        if (background && ['pending','active'].includes(background.message.status)) {
          for (const todo of updated.todos) if (todo.status === 'done' && (!todo.definition_of_done?.trim() || !todo.completion_evidence.length)) throw new Error('Background task completion requires its criteria and evidence');
          if (updated.status === 'done' && updated.todos.some(t => !['done','cancelled'].includes(t.status))) throw new Error('Background project completion requires all tasks to be done or cancelled');
        }
        if (changes.status === 'in_progress' && actor === current.buddy_id)
          this.db.prepare('UPDATE owned_projects SET accepted_by=?,accepted_at=COALESCE(accepted_at,?) WHERE id=?').run(actor,now(),projectId);
        this.db
          .prepare('UPDATE owned_projects SET revision=revision+1,completion_evidence=? WHERE id=?')
          .run(
            JSON.stringify(changes.evidence ?? JSON.parse(updated.completion_evidence)),
            projectId
          );
        return this.getBuddyProject(projectId);
      }
    );
  },
};
