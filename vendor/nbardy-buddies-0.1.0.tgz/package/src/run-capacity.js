// Per-Buddy run capacity (owner decision 2026-09-25). Every run kind counts the
// same way: background work, workers, automations and foreground chat/channel
// turns. A run over the limit waits in arrival order instead of failing. The
// machine-wide cap still applies to background runs only. The rule itself is
// activeRunLimitReason in coordination.js.
export const DEFAULT_MAX_ACTIVE_RUNS = 5;
export const MACHINE_BACKGROUND_RUN_LIMIT = 8;

// SQLite cannot change a column default in place, so databases created before
// 2026-09-25 keep DEFAULT 2 on buddy_projects.max_active_runs; every membership
// insert therefore sets DEFAULT_MAX_ACTIVE_RUNS explicitly. Existing rows are
// NOT migrated: a schema bump would lock out every older host sharing
// ~/.buddies/buddies.sqlite (store.js refuses newer schemas). Raise existing
// memberships through setCoordinationMembership instead.
