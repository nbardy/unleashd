import { BuddiesStore, defaultDatabasePath } from "./store.js";

const HELP = `Buddies — persistent employees and their work

Usage:
  buddies init
  buddies backup <destination.sqlite>
  buddies workspace add <name> <root-path> [--slug <slug>]
  buddies workspace list
  buddies buddy add <workspace> <name> --role <role> [--soul <path>] [--memory <path>]
  buddies buddy update <buddy> [--name <name>] [--role <role>] [--status <status>]
    [--home-workspace <workspace>] [--soul <path>] [--memory <path>]
    [--provider <provider>] [--model <model>] [--effort <effort>]
    [--hire-quota <count>]
  buddies buddy list [workspace]
  buddies relationship set <from-buddy> <to-buddy> <kind>
  buddies relationship list <buddy>
  buddies context <buddy> [--workspace <id>] [--project <id>]
  buddies project new <buddy> <workspace> <title> --done <definition> [--todos-json <json>]
  buddies project update <project-id> [--status <status>] [--todo-operations-json <json>]
  buddies project list <buddy> [--workspace <id>] [--all]
  buddies remember-note <buddy> --topic <topic> --body <text> [--kind <kind>]
    [--workspace <id>] [--scope current|home] [--evidence-json <json>]
  buddies recall <buddy> --pattern <regex> [--workspace <id>] [--scope current|home|all]
    [--since <timestamp>] [--limit <count>]
  buddies memory read <buddy>
  buddies memory update <buddy> --doc working|long_term --content <text>
    --reasoning <text> --base-version <number>
  buddies export <buddy> [--fix]
  buddies delegation create <from-buddy> <to-buddy> <workspace> --purpose <text>
    [--project <id>] [--parent-conversation <id>]
  buddies delegation update <id> --status <status> [--outcome <text>]
    [--child-conversation <id>]
  buddies delegation list <buddy> [--workspace <id>] [--status <status>]
  buddies review create <reviewer> <subject> <workspace>
    [--project <id>] [--conversation <id>]
  buddies review submit <id> --verdict <verdict> --summary <text> --evidence-json <json>
    [--score <number>]
  buddies review list <buddy> [--workspace <id>] [--status <status>]
  buddies automation add <buddy> <name> --schedule-kind <kind> --schedule <expression>
    --job-kind prompt|sequence|loop --job-json <json> [--policy-json <json>]
    [--timezone <iana>] [--next-run <iso>]
  buddies automation list <buddy> [--all]
  buddies automation update <id> [fields] [--policy-json <json>]
  buddies automation delete <id>
  buddies automation runs <id>
  buddies automation claim <id> [--scheduled-for <iso>] [--key <idempotency-key>]
  buddies automation run-status <run-id> <status> [--conversation <id>] [--iteration <n>]
    [--tokens <n>] [--cost <usd>]
  buddies approval request <buddy> <workspace> <action> --reason <reason> --risk <risk>
  buddies approval list [--buddy <id>] [--workspace <id>] [--status <status>]
  buddies approval resolve <id> approved|rejected --by <human> [--note <text>]
  buddies sprint start <workspace> <name> [--goal <goal>]
  buddies sprint complete <sprint-id>
  buddies task add <workspace> <title> --done <definition> [--buddy <id-or-slug>] [--sprint <id>]
  buddies task list <workspace> [--all]
  buddies task status <work-id> <status> [--reason <blocked-reason>] [--next <next-action>]
  buddies current <workspace>
  buddies audit work

The legacy "project add" command retains its v3 workspace meaning.

Environment:
  BUDDIES_HOME   Directory containing buddies.sqlite (default: ~/.buddies)
`;

function parseArgs(argv) {
  const positionals = [];
  const flags = {};
  for (let index = 0; index < argv.length; index += 1) {
    const value = argv[index];
    if (!value.startsWith("--")) {
      positionals.push(value);
      continue;
    }
    const key = value.slice(2);
    const next = argv[index + 1];
    if (!next || next.startsWith("--")) {
      flags[key] = true;
    } else {
      flags[key] = next;
      index += 1;
    }
  }
  return { positionals, flags };
}

function print(value) {
  console.log(JSON.stringify(value, null, 2));
}

function need(value, usage) {
  if (!value) throw new Error(`Missing argument.\nUsage: ${usage}`);
  return value;
}

function json(value, usage) {
  try {
    return JSON.parse(need(value, usage));
  } catch (error) {
    throw new Error(`Invalid JSON for ${usage}: ${error.message}`);
  }
}

export async function runCli(argv, { Store = BuddiesStore } = {}) {
  const { positionals: args, flags } = parseArgs(argv);
  if (args.length === 0 || args[0] === "help" || flags.help) {
    console.log(HELP);
    return;
  }

  const store = new Store();
  try {
    const [resource, action, ...rest] = args;
    if (resource === "init") {
      print({ database: defaultDatabasePath(), initialized: true });
      return;
    }
    if (resource === "backup") {
      print(store.backupDatabase(need(action, "buddies backup <destination.sqlite>")));
      return;
    }

    if ((resource === "workspace" || resource === "project") && action === "add") {
      print(
        store.createWorkspace({
          name: need(rest[0], "buddies workspace add <name> <root-path>"),
          rootPath: need(rest[1], "buddies workspace add <name> <root-path>"),
          slug: flags.slug,
        }),
      );
      return;
    }
    if (resource === "workspace" && action === "list") {
      print(store.listWorkspaces());
      return;
    }

    if (resource === "buddy" && action === "add") {
      print(
        store.createBuddy({
          project: need(rest[0], "buddies buddy add <project> <name> --role <role>"),
          name: need(rest[1], "buddies buddy add <project> <name> --role <role>"),
          role: need(flags.role, "buddies buddy add <project> <name> --role <role>"),
          soulPath: flags.soul,
          memoryPath: flags.memory,
          provider: flags.provider,
          model: flags.model,
          reasoningEffort: flags.effort,
        }),
      );
      return;
    }
    if (resource === "buddy" && action === "list") {
      print(store.listBuddies(rest[0]));
      return;
    }
    if (resource === "buddy" && action === "update") {
      const changes = {};
      if (flags.name !== undefined) changes.name = flags.name;
      if (flags.role !== undefined) changes.role = flags.role;
      if (flags.status !== undefined) changes.status = flags.status;
      if (flags["home-workspace"] !== undefined) {
        changes.homeWorkspace = flags["home-workspace"];
      }
      if (flags.soul !== undefined) changes.soulPath = flags.soul;
      if (flags.memory !== undefined) changes.memoryPath = flags.memory;
      if (flags.provider !== undefined) changes.provider = flags.provider;
      if (flags.model !== undefined) changes.model = flags.model;
      if (flags.effort !== undefined) changes.reasoningEffort = flags.effort;
      if (flags["hire-quota"] !== undefined) {
        changes.hireQuota = Number(flags["hire-quota"]);
      }
      print(store.updateBuddy(need(rest[0], "buddies buddy update <buddy>"), changes));
      return;
    }

    if (resource === "relationship" && action === "set") {
      print(
        store.setBuddyRelationship({
          fromBuddy: need(rest[0], "buddies relationship set <from> <to> <kind>"),
          toBuddy: need(rest[1], "buddies relationship set <from> <to> <kind>"),
          kind: need(rest[2], "buddies relationship set <from> <to> <kind>"),
        }),
      );
      return;
    }
    if (resource === "relationship" && action === "list") {
      print(store.listBuddyRelationships(need(rest[0], "buddies relationship list <buddy>")));
      return;
    }

    if (resource === "context") {
      print(
        store.getBuddyContext(need(action, "buddies context <buddy>"), {
          workspace: flags.workspace,
          project: flags.project,
        }),
      );
      return;
    }

    if (resource === "audit" && action === "work") {
      print(store.auditWorkMigration());
      return;
    }

    if (resource === "project" && action === "new") {
      print(
        store.newProject({
          buddy: need(rest[0], "buddies project new <buddy> <workspace> <title> --done <definition>"),
          workspace: need(rest[1], "buddies project new <buddy> <workspace> <title> --done <definition>"),
          title: need(rest[2], "buddies project new <buddy> <workspace> <title> --done <definition>"),
          definitionOfDone: need(flags.done, "buddies project new ... --done <definition>"),
          objective: flags.objective,
          sprint: flags.sprint,
          status: flags.status || "backlog",
          priority: flags.priority,
          nextAction: flags.next,
          blockedReason: flags.reason,
          sourcePath: flags.source,
          externalKey: flags.external,
          todos: flags["todos-json"]
            ? json(flags["todos-json"], "--todos-json")
            : [],
        }),
      );
      return;
    }
    if (resource === "project" && action === "update") {
      const changes = {};
      if (flags.title !== undefined) changes.title = flags.title;
      if (flags.objective !== undefined) changes.objective = flags.objective;
      if (flags.done !== undefined) changes.definitionOfDone = flags.done;
      if (flags.status !== undefined) changes.status = flags.status;
      if (flags.priority !== undefined) changes.priority = flags.priority;
      if (flags.next !== undefined) changes.nextAction = flags.next;
      if (flags.reason !== undefined) changes.blockedReason = flags.reason;
      if (flags.sprint !== undefined) changes.sprint = flags.sprint;
      if (flags.source !== undefined) changes.sourcePath = flags.source;
      if (flags["todo-operations-json"]) {
        changes.todoOperations = json(
          flags["todo-operations-json"],
          "--todo-operations-json",
        );
      }
      print(store.updateProject(need(rest[0], "buddies project update <project-id>"), changes));
      return;
    }
    if (resource === "project" && action === "list") {
      print(
        store.listBuddyOwnedProjects({
          buddy: need(rest[0], "buddies project list <buddy>"),
          workspace: flags.workspace,
          includeClosed: Boolean(flags.all),
        }),
      );
      return;
    }

    if (resource === "remember-note") {
      print(store.rememberNote(need(action, "buddies remember-note <buddy>"), {
        topic: flags.topic,
        kind: flags.kind,
        body: need(flags.body, "buddies remember-note <buddy> --body <text>"),
        workspace: flags.workspace,
        scope: flags.scope,
        evidence: flags["evidence-json"] ? json(flags["evidence-json"], "--evidence-json") : [],
      }));
      return;
    }
    if (resource === "recall") {
      print(store.recall(need(action, "buddies recall <buddy>"), {
        pattern: need(flags.pattern, "buddies recall <buddy> --pattern <regex>"),
        workspace: flags.workspace,
        scope: flags.scope,
        since: flags.since,
        limit: flags.limit === undefined ? undefined : Number(flags.limit),
      }));
      return;
    }
    if (resource === "memory" && action === "read") {
      print(store.readBuddyMemory(need(rest[0], "buddies memory read <buddy>")));
      return;
    }
    if (resource === "memory" && action === "update") {
      print(store.updateMemory(need(rest[0], "buddies memory update <buddy>"), {
        documentKind: need(flags.doc, "buddies memory update <buddy> --doc working|long_term"),
        content: flags.content ?? "",
        reasoning: need(flags.reasoning, "buddies memory update <buddy> --reasoning <text>"),
        baseVersion: Number(need(flags["base-version"], "buddies memory update <buddy> --base-version <number>")),
      }));
      return;
    }

    if (resource === "export") {
      const target = need(action, "buddies export <buddy> [--fix]");
      const report = flags.fix ? store.fixExport(target) : store.exportCheck(target);
      print(report);
      if (!report.clean) process.exitCode = 1;
      return;
    }

    if (resource === "delegation" && action === "create") {
      print(
        store.createDelegation({
          fromBuddy: need(rest[0], "buddies delegation create <from> <to> <workspace>"),
          toBuddy: need(rest[1], "buddies delegation create <from> <to> <workspace>"),
          workspace: need(rest[2], "buddies delegation create <from> <to> <workspace>"),
          project: flags.project,
          purpose: need(flags.purpose, "buddies delegation create ... --purpose <text>"),
          parentConversationId: flags["parent-conversation"],
        }),
      );
      return;
    }
    if (resource === "delegation" && action === "update") {
      print(
        store.updateDelegation(need(rest[0], "buddies delegation update <id>"), {
          status: flags.status,
          outcome: flags.outcome,
          childConversationId: flags["child-conversation"],
        }),
      );
      return;
    }
    if (resource === "delegation" && action === "list") {
      print(
        store.listDelegations({
          buddy: need(rest[0], "buddies delegation list <buddy>"),
          workspace: flags.workspace,
          status: flags.status,
        }),
      );
      return;
    }
    if (resource === "review" && action === "create") {
      print(
        store.createReview({
          reviewer: need(rest[0], "buddies review create <reviewer> <subject> <workspace>"),
          subject: need(rest[1], "buddies review create <reviewer> <subject> <workspace>"),
          workspace: need(rest[2], "buddies review create <reviewer> <subject> <workspace>"),
          project: flags.project,
          conversationId: flags.conversation,
        }),
      );
      return;
    }
    if (resource === "review" && action === "submit") {
      print(
        store.updateReview(need(rest[0], "buddies review submit <id>"), {
          status: "complete",
          verdict: need(flags.verdict, "buddies review submit ... --verdict <verdict>"),
          score: flags.score === undefined ? undefined : Number(flags.score),
          summary: need(flags.summary, "buddies review submit ... --summary <text>"),
          evidence: json(flags["evidence-json"], "--evidence-json"),
        }),
      );
      return;
    }
    if (resource === "review" && action === "list") {
      print(
        store.listReviews({
          buddy: need(rest[0], "buddies review list <buddy>"),
          workspace: flags.workspace,
          status: flags.status,
        }),
      );
      return;
    }

    if (resource === "automation" && action === "add") {
      print(
        store.createAutomation({
          buddy: need(rest[0], "buddies automation add <buddy> <name> ..."),
          name: need(rest[1], "buddies automation add <buddy> <name> ..."),
          workspace: flags.workspace,
          project: flags.project,
          scheduleKind: need(flags["schedule-kind"], "--schedule-kind"),
          scheduleExpression: need(flags.schedule, "--schedule"),
          timezone: flags.timezone || "UTC",
          jobKind: need(flags["job-kind"], "--job-kind"),
          jobPayload: json(flags["job-json"], "--job-json"),
          policy: flags["policy-json"]
            ? json(flags["policy-json"], "--policy-json")
            : undefined,
          enabled: !flags.disabled,
          nextRunAt: flags["next-run"],
        }),
      );
      return;
    }
    if (resource === "automation" && action === "list") {
      print(
        store.listAutomations({
          buddy: need(rest[0], "buddies automation list <buddy>"),
          enabled: flags.all ? undefined : true,
        }),
      );
      return;
    }
    if (resource === "automation" && action === "update") {
      const changes = {};
      if (flags.name !== undefined) changes.name = flags.name;
      if (flags["schedule-kind"] !== undefined) changes.scheduleKind = flags["schedule-kind"];
      if (flags.schedule !== undefined) changes.scheduleExpression = flags.schedule;
      if (flags.timezone !== undefined) changes.timezone = flags.timezone;
      if (flags["job-kind"] !== undefined) changes.jobKind = flags["job-kind"];
      if (flags["job-json"]) changes.jobPayload = json(flags["job-json"], "--job-json");
      if (flags["policy-json"]) {
        changes.policy = json(flags["policy-json"], "--policy-json");
      }
      if (flags.enabled) changes.enabled = true;
      if (flags.disabled) changes.enabled = false;
      if (flags["next-run"] !== undefined) changes.nextRunAt = flags["next-run"];
      print(store.updateAutomation(need(rest[0], "buddies automation update <id>"), changes));
      return;
    }
    if (resource === "automation" && action === "delete") {
      print(store.deleteAutomation(need(rest[0], "buddies automation delete <id>")));
      return;
    }
    if (resource === "automation" && action === "runs") {
      print(store.listAutomationRuns(need(rest[0], "buddies automation runs <id>")));
      return;
    }
    if (resource === "automation" && action === "claim") {
      print(
        store.claimAutomationRun(need(rest[0], "buddies automation claim <id>"), {
          scheduledFor: flags["scheduled-for"],
          idempotencyKey: flags.key,
        }),
      );
      return;
    }
    if (resource === "automation" && action === "run-status") {
      print(
        store.updateAutomationRun(
          need(rest[0], "buddies automation run-status <run-id> <status>"),
          {
            status: need(rest[1], "buddies automation run-status <run-id> <status>"),
            conversationId: flags.conversation,
            iteration: flags.iteration,
            tokensUsed: flags.tokens,
            costUsd: flags.cost,
            outcome: flags.outcome,
            error: flags.error,
            nextRunAt: flags["next-run"],
            claimToken: flags["claim-token"],
          },
        ),
      );
      return;
    }

    if (resource === "approval" && action === "request") {
      print(
        store.createApprovalRequest({
          buddy: need(rest[0], "buddies approval request <buddy> <workspace> <action>"),
          workspace: need(rest[1], "buddies approval request <buddy> <workspace> <action>"),
          action: need(rest[2], "buddies approval request <buddy> <workspace> <action>"),
          project: flags.project,
          automationRun: flags.run,
          conversationId: flags.conversation,
          reason: need(flags.reason, "--reason"),
          risk: need(flags.risk, "--risk"),
        }),
      );
      return;
    }
    if (resource === "approval" && action === "list") {
      print(
        store.listApprovalRequests({
          buddy: flags.buddy,
          workspace: flags.workspace,
          project: flags.project,
          status: flags.status,
          limit: flags.limit,
        }),
      );
      return;
    }
    if (resource === "approval" && action === "resolve") {
      print(
        store.resolveApprovalRequest(
          need(rest[0], "buddies approval resolve <id> approved|rejected --by <human>"),
          {
            decision: need(
              rest[1],
              "buddies approval resolve <id> approved|rejected --by <human>",
            ),
            resolvedBy: need(flags.by, "--by"),
            note: flags.note,
          },
        ),
      );
      return;
    }

    if (resource === "sprint" && action === "start") {
      print(
        store.createSprint({
          project: need(rest[0], "buddies sprint start <project> <name>"),
          name: need(rest[1], "buddies sprint start <project> <name>"),
          goal: flags.goal,
          status: "active",
        }),
      );
      return;
    }
    if (resource === "sprint" && action === "complete") {
      print(store.completeSprint(need(rest[0], "buddies sprint complete <sprint-id>")));
      return;
    }

    if (resource === "task" && action === "add") {
      const project = need(rest[0], "buddies task add <project> <title> --done <definition>");
      const activeSprint = flags.sprint || store.getActiveSprint(project)?.id;
      print(
        store.createWorkItem({
          project,
          title: need(rest[1], "buddies task add <project> <title> --done <definition>"),
          definitionOfDone: need(
            flags.done,
            "buddies task add <project> <title> --done <definition>",
          ),
          objective: flags.objective,
          buddy: flags.buddy,
          sprint: activeSprint,
          status: flags.status || "ready",
          priority: flags.priority,
          nextAction: flags.next,
        }),
      );
      return;
    }
    if (resource === "task" && action === "list") {
      print(
        store.listWorkItems({
          project: need(rest[0], "buddies task list <project>"),
          includeClosed: Boolean(flags.all),
        }),
      );
      return;
    }
    if (resource === "task" && action === "status") {
      print(
        store.updateWorkItemStatus(
          need(rest[0], "buddies task status <work-id> <status>"),
          need(rest[1], "buddies task status <work-id> <status>"),
          { blockedReason: flags.reason, nextAction: flags.next },
        ),
      );
      return;
    }

    if (resource === "current") {
      print(store.currentWork(need(action, "buddies current <project>")));
      return;
    }

    throw new Error(`Unknown command: ${args.join(" ")}\n\n${HELP}`);
  } finally {
    store.close();
  }
}
