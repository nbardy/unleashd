import { normalizeBackgroundExecution } from './background-work.js';
import { migrateCoordinationApprovals } from './coordination-approvals.js';
import { migrateCoordinationWork } from './coordination-work.js';
import { randomUUID, createHash } from 'node:crypto';

const terminal = new Set(['complete', 'failed', 'cancelled']);
const timestamp = () => new Date().toISOString();
function transaction(db, fn) {
  const name = `coord_${randomUUID().replaceAll('-', '')}`;
  db.exec(`SAVEPOINT ${name}`);
  try {
    const result = fn();
    db.exec(`RELEASE ${name}`);
    return result;
  } catch (error) {
    db.exec(`ROLLBACK TO ${name}; RELEASE ${name}`);
    throw error;
  }
}

function canonical(value) {
  if (Array.isArray(value)) return value.map(canonical);
  if (value && typeof value === 'object')
    return Object.fromEntries(
      Object.keys(value)
        .sort()
        .filter((key) => value[key] !== undefined)
        .map((key) => [key, canonical(value[key])])
    );
  return value;
}

function required(value, name) {
  if (typeof value !== 'string' || !value.trim()) throw new Error(`${name} is required`);
  return value.trim();
}

function normalizeLaunchReference(value) {
  if (value === undefined) return undefined;
  if (!value || typeof value !== 'object' || Array.isArray(value))
    throw new Error('Invalid launch reference');
  const keys = Object.keys(value);
  if (keys.some((key) => !['through_message_id', 'tool_call_id'].includes(key)))
    throw new Error('Invalid launch reference');
  const throughMessageId = required(value.through_message_id, 'Launch through message');
  const toolCallId = value.tool_call_id === undefined
    ? undefined
    : required(value.tool_call_id, 'Launch tool call');
  return {
    through_message_id: throughMessageId,
    ...(toolCallId ? { tool_call_id: toolCallId } : {}),
  };
}

export function migrateCoordination(db) {
  if (db.prepare('PRAGMA user_version').get().user_version >= 21) {
    migrateCoordinationApprovals(db);
    return;
  }
  transaction(db, () => {
    // v20 existed in a separate notification build. Preserve all of its columns
    // while removing the v19 unique conversation constraint for follow-up turns.
    const columns = db
      .prepare('PRAGMA table_info(buddy_messages)')
      .all()
      .map((row) => row.name);
    db.exec(`CREATE TABLE buddy_messages_v21 (
      id TEXT PRIMARY KEY, from_buddy_id TEXT NOT NULL REFERENCES buddies(id),
      to_buddy_id TEXT REFERENCES buddies(id), workspace_id TEXT NOT NULL REFERENCES projects(id),
      buddy_project_id TEXT REFERENCES owned_projects(id), purpose TEXT NOT NULL,
      body TEXT NOT NULL, evidence TEXT NOT NULL, parent_conversation_id TEXT,
      child_conversation_id TEXT,
      status TEXT NOT NULL CHECK(status IN ('pending','active','replied','failed','cancelled')),
      outcome TEXT, reply_body TEXT, reply_evidence TEXT NOT NULL DEFAULT '[]', replied_by TEXT,
      wait_until TEXT, wait_status TEXT NOT NULL,
      created_at TEXT NOT NULL, updated_at TEXT NOT NULL, replied_at TEXT,
      notification_pending INTEGER NOT NULL DEFAULT 0,
      expects_reply INTEGER NOT NULL DEFAULT 1 CHECK(expects_reply IN (0,1)),
      source_project_id TEXT REFERENCES owned_projects(id), source_workspace_id TEXT REFERENCES projects(id),
      root_message_id TEXT, caused_by_run_id TEXT, not_before TEXT, after_run_id TEXT,
      continue_from_message_id TEXT, in_reply_to_id TEXT, superseded_by_message_id TEXT,
      root_stopped_at TEXT, command_key TEXT, payload_hash TEXT
    );`);
    const preserved = columns.filter((column) =>
      db
        .prepare('PRAGMA table_info(buddy_messages_v21)')
        .all()
        .some((row) => row.name === column)
    );
    db.exec(`INSERT INTO buddy_messages_v21 (${preserved.join(',')}) SELECT ${preserved.join(',')} FROM buddy_messages;
      DROP TABLE buddy_messages; ALTER TABLE buddy_messages_v21 RENAME TO buddy_messages;
      CREATE INDEX buddy_messages_sender ON buddy_messages(from_buddy_id, workspace_id, created_at DESC);
      CREATE INDEX buddy_messages_recipient ON buddy_messages(to_buddy_id, workspace_id, created_at DESC);
      CREATE INDEX buddy_messages_waits ON buddy_messages(wait_status, wait_until);
      CREATE UNIQUE INDEX buddy_message_command ON buddy_messages(from_buddy_id,workspace_id,command_key) WHERE command_key IS NOT NULL;
      UPDATE buddy_messages SET root_message_id=COALESCE(root_message_id,id), source_workspace_id=COALESCE(source_workspace_id,workspace_id);
      CREATE TABLE IF NOT EXISTS buddy_runs (
        id TEXT PRIMARY KEY, input_key TEXT NOT NULL, input_kind TEXT NOT NULL,
        input_id TEXT NOT NULL, attempt INTEGER NOT NULL DEFAULT 1,
        buddy_id TEXT NOT NULL REFERENCES buddies(id), workspace_id TEXT NOT NULL REFERENCES projects(id),
        conversation_id TEXT, project_id TEXT REFERENCES owned_projects(id), root_message_id TEXT,
        ready_at TEXT NOT NULL, after_run_id TEXT REFERENCES buddy_runs(id),
        status TEXT NOT NULL CHECK(status IN ('queued','claimed','running','cancel_requested','complete','failed','cancelled')),
        claim_token TEXT, claim_expires_at TEXT, deadline TEXT, policy TEXT NOT NULL DEFAULT '{}',
        created_at TEXT NOT NULL, started_at TEXT, ended_at TEXT, outcome TEXT, error TEXT,
        error_code TEXT, retry_of_run_id TEXT REFERENCES buddy_runs(id),
        UNIQUE(input_key,attempt)
      ) STRICT;
      CREATE UNIQUE INDEX IF NOT EXISTS buddy_run_live_input ON buddy_runs(input_key)
        WHERE status IN ('queued','claimed','running','cancel_requested');
      CREATE UNIQUE INDEX IF NOT EXISTS buddy_run_conversation_slot ON buddy_runs(conversation_id)
        WHERE conversation_id IS NOT NULL AND status IN ('claimed','running','cancel_requested');
      CREATE INDEX IF NOT EXISTS buddy_runs_ready ON buddy_runs(status,ready_at);
      CREATE TABLE IF NOT EXISTS buddy_command_receipts (
        actor TEXT NOT NULL, workspace_id TEXT NOT NULL, command_key TEXT NOT NULL,
        payload_hash TEXT NOT NULL, result TEXT NOT NULL, created_at TEXT NOT NULL,
        PRIMARY KEY(actor,workspace_id,command_key)
      ) STRICT;
      PRAGMA user_version=21;`);
    migrateCoordinationWork(db);
  });
  migrateCoordinationApprovals(db);
}

export const coordinationMethods = {
  getCoordinatedMessageByKey(actor, workspaceId, key) {
    const row = this.db.prepare(
      'SELECT id FROM buddy_messages WHERE from_buddy_id=? AND workspace_id=? AND command_key=?',
    ).get(required(actor, 'Message actor'), required(workspaceId, 'Message workspace'), required(key, 'Message key'));
    return row ? this.getMessage(row.id) : null;
  },

  assertWorkerParent(buddyId) {
    if (this.getBuddy(buddyId)?.employment_mode === 'worker' && this.getBuddyTeamState(buddyId).manager?.status !== 'active')
      throw new Error('Worker parent is not active');
  },
  coordinationActiveCounts() {
    return this.db
      .prepare(
        "SELECT buddy_id FROM buddy_runs WHERE status IN ('claimed','running','cancel_requested') UNION ALL SELECT a.buddy_id FROM buddy_automation_runs r JOIN buddy_automations a ON r.automation_id=a.id WHERE r.status IN ('claimed','running','cancel_requested')"
      )
      .all();
  },
  coordinationBackgroundActiveCounts() {
    return this.db
      .prepare(
        "SELECT buddy_id FROM buddy_runs WHERE status IN ('claimed','running','cancel_requested') AND COALESCE(json_extract(policy,'$.foreground'),0)=0 UNION ALL SELECT a.buddy_id FROM buddy_automation_runs r JOIN buddy_automations a ON r.automation_id=a.id WHERE r.status IN ('claimed','running','cancel_requested')"
      )
      .all();
  },
  beginBuddyChatRun({ buddyId, workspaceId, conversationId, projectId, allowedOperations, maxRuntimeSeconds = 24 * 60 * 60 }) {
    return this.coordinationTransaction(() => {
      const key = `chat:${randomUUID()}`;
      const run = this.enqueueBuddyRun({
        inputKey: key,
        inputKind: 'chat',
        inputId: key,
        buddyId,
        workspaceId,
        conversationId,
        projectId,
        policy: { allowed_operations: allowedOperations, foreground: true },
      });
      const claimed = this.claimBuddyRun(run.id, { claimToken: randomUUID(), conversationId, maxRuntimeSeconds });
      if (!claimed) throw new Error('Conversation execution slot is unavailable');
      return this.startBuddyRun(run.id, claimed.claim_token);
    });
  },
  sendCoordinatedMessage(input, { policy, runId, sourceProjectId, sourceWorkspaceId, returnConversationId, launch, assignmentConfig } = {}) {
    const {
      fromBuddy,
      workspace,
      key,
      continueFrom,
      inReplyTo,
      expectsReply = true,
      notBefore,
      execution: executionInput,
      config,
      ...request
    } = input;
    const execution = normalizeBackgroundExecution(executionInput);
    const launchReference = normalizeLaunchReference(launch);
    if (execution && (inReplyTo || input.waitUntil || !expectsReply || !input.project)) throw new Error('Background work requires an explicit project, expectsReply and non-waiting routing');
    if (continueFrom && inReplyTo) throw new Error('Choose either continueFrom or inReplyTo');
    if (input.waitUntil && (!expectsReply || input.to === fromBuddy))
      throw new Error('Cannot wait on an informational or self message');
    if (!policy || !Array.isArray(policy.allowed_operations))
      throw new Error('Message execution policy is required');
    return this.coordinationCommand(
      { actor: fromBuddy, workspaceId: workspace, key, payload: input },
      () => {
        const referenced =
          continueFrom || inReplyTo ? this.getMessage(continueFrom || inReplyTo) : null;
        if ((continueFrom || inReplyTo) && !referenced)
          throw new Error('Referenced message not found');
        if (
          continueFrom &&
          (referenced.from_buddy_id !== fromBuddy ||
            referenced.to_buddy_id !== input.to ||
            referenced.workspace_id !== workspace)
        )
          throw new Error('Follow-up is outside sender scope');
        if (continueFrom && this.getBuddy(input.to)?.employment_mode === 'worker' && referenced.parent_conversation_id !== (input.parentConversationId ?? null))
          throw new Error('Worker continuation must retain its original parent conversation audience');
        if (execution && continueFrom && (referenced.status !== 'replied' || referenced.outcome !== 'done'))
          throw new Error('Continue managed work only after its previous project is done; inspect failures through recovery');
        if (referenced?.superseded_by_message_id)
          throw new Error(`Message superseded by ${referenced.superseded_by_message_id}`);
        if (inReplyTo && referenced.source_workspace_id !== workspace)
          throw new Error('Informational returns must use the original source workspace');
        if (
          inReplyTo &&
          (referenced.to_buddy_id !== fromBuddy ||
            referenced.from_buddy_id !== input.to ||
            expectsReply)
        )
          throw new Error('Informational return is outside recipient scope');
        const parent = runId ? this.getBuddyRun(runId) : null;
        if (
          runId &&
          (!parent ||
            parent.buddy_id !== fromBuddy ||
            !['claimed', 'running'].includes(parent.status))
        )
          throw new Error('Source run is not active');
        const rootId = referenced?.root_message_id || referenced?.id || parent?.root_message_id;
        if (rootId && this.getMessage(rootId)?.root_stopped_at)
          throw new Error('Message root is stopped');
        const self = fromBuddy === input.to;
        if (self && parent?.policy.execution?.mode === 'until_done' && !execution) throw new Error('Background work continues automatically; separate self successors are not permitted');
        if (self && expectsReply && !execution) throw new Error('Self continuation must be informational');
        if (self && !runId && !execution) throw new Error('Self continuation requires a bounded source run');
        if (
          self && !execution &&
          this.db
            .prepare("SELECT 1 FROM buddy_runs WHERE after_run_id=? AND status='queued'")
            .get(runId)
        )
          throw new Error('Only one pending self successor is permitted');
        const membership = this.getCoordinationMembership(fromBuddy, workspace);
        if (!membership?.dispatch) throw new Error('Dispatch grant is required');
        const sent = this.db
          .prepare(
            'SELECT count(*) AS n FROM buddy_messages WHERE from_buddy_id=? AND workspace_id=? AND created_at>=?'
          )
          .get(fromBuddy, workspace, new Date(Date.now() - 3600000).toISOString()).n;
        if (sent >= membership.max_sends_per_hour) throw new Error('Hourly send limit reached');
        const projectId =
          request.project !== undefined ? request.project :
          (continueFrom
            ? referenced.buddy_project_id
            : inReplyTo
              ? referenced.source_project_id
              : expectsReply ? parent?.project_id : null);
        if (projectId) {
          const project = this.getBuddyProject(projectId);
          if (
            !project ||
            project.workspace_id !== workspace ||
            (expectsReply ? !this.canManageCoordinationProject(fromBuddy, projectId) :
              !this.canReadCoordinationProject(fromBuddy, projectId) ||
              (input.to !== 'owner' && !this.canReadCoordinationProject(input.to, projectId)))
          )
            throw new Error('Message project is outside supervisor or shared context scope');
          this.assertProjectExecution(projectId, null, { admission: true });
        }
        if (execution) {
          const project = this.getBuddyProject(projectId);
          if (!project || project.buddy_id !== input.to || !project.definition_of_done?.trim()) throw new Error('Background work requires a recipient-owned project with completion criteria');
          if (['done','cancelled'].includes(project.status)) throw new Error('Background project must be open');
          const existing = this.db.prepare(`SELECT m.id FROM buddy_messages m JOIN buddy_runs r ON r.input_id=m.id WHERE m.buddy_project_id=? AND (m.status IN ('pending','active') OR r.status IN ('claimed','running','cancel_requested')) AND r.input_kind='message_request' AND json_extract(r.policy,'$.execution.mode')='until_done' LIMIT 1`).get(projectId);
          if (existing) throw new Error(`Project already has background work: ${existing.id}`);
        }
        // Intent is in the replay payload; resolution is supplied by the host once.
        // It belongs to recipient attempts only, never the parent return policy.
        if (config && (!assignmentConfig || JSON.stringify(config) !== JSON.stringify(assignmentConfig.requested)))
          throw new Error('Assignment configuration requires a matching host resolution');
        // Informs start a recipient attempt too, so they may pin a harness; owner
        // messages have no attempt and replies run on the pinned return thread.
        if (config && (input.to === 'owner' || inReplyTo))
          throw new Error('Assignment configuration requires a recipient attempt: not an owner message or a reply');
        const message = this.sendMessage({ ...request, project: undefined, fromBuddy, workspace });
        this.db
          .prepare('UPDATE buddy_messages SET buddy_project_id=? WHERE id=?')
          .run(projectId ?? null, message.id);
        message.buddy_project_id = projectId ?? null;
      this.db.prepare('UPDATE buddy_messages SET visibility=? WHERE id=?').run(input.visibility ?? 'participants', message.id);
        const target = self && !execution
          ? input.parentConversationId
          : continueFrom
            ? referenced.child_conversation_id
            : inReplyTo
              ? JSON.parse(referenced.return_policy || '{}').return_conversation_id || referenced.parent_conversation_id
              : null;
        if ((continueFrom || inReplyTo || (self && !execution)) && !target)
          throw new Error('Destination conversation is unavailable');
        const ready = notBefore ? new Date(notBefore).toISOString() : timestamp();
        this.db
          .prepare(`UPDATE buddy_messages SET expects_reply=?,source_project_id=?,source_workspace_id=?,
        root_message_id=?,caused_by_run_id=?,not_before=?,after_run_id=?,continue_from_message_id=?,in_reply_to_id=?,
        command_key=?,child_conversation_id=?,status=CASE WHEN ? IS NULL THEN status ELSE 'active' END WHERE id=?`)
          .run(
            expectsReply ? 1 : 0,
            sourceProjectId ?? null,
            sourceWorkspaceId ?? workspace,
            rootId ?? message.id,
            runId ?? null,
            ready,
            self && !execution ? runId : null,
            continueFrom ?? null,
            inReplyTo ?? null,
            key,
            target,
            target,
            message.id
          );
        // Plain informs are Mail, not work: the durable message row is the
        // delivery, so no recipient attempt is enqueued and background
        // admission never gates them. Requests, work, continuations, returns,
        // self successors, deferred sends and config-carrying informs (which
        // pin the recipient harness since 21810ca) keep their attempt and the
        // existing execution gates.
        const informDelivered =
          !expectsReply &&
          !execution &&
          !config &&
          !continueFrom &&
          !inReplyTo &&
          !self &&
          !notBefore;
        if (message.to_buddy_id && !informDelivered)
          this.enqueueBuddyRun({
            inputKey: `message:${message.id}:request`,
            inputKind: 'message_request',
            inputId: message.id,
            buddyId: message.to_buddy_id,
            workspaceId: workspace,
            conversationId: target,
            projectId: message.buddy_project_id,
            rootMessageId: rootId ?? message.id,
            readyAt: ready,
            afterRunId: self && !execution ? runId : undefined,
            policy: { ...(execution ? {...policy, execution, max_runtime_seconds: Math.min(3600, Number(policy.max_runtime_seconds) || execution.maxDurationSeconds)} : {...policy, execution: undefined}), ...(config ? { assignment_config: assignmentConfig } : {}) },
          });
        this.db
          .prepare('UPDATE buddy_messages SET return_policy=? WHERE id=?')
          .run(JSON.stringify({
            ...policy,
            ...(returnConversationId ? { return_conversation_id: returnConversationId } : {}),
            ...(launchReference ? { launch: launchReference } : {}),
          }), message.id);
        if (parent && !parent.root_message_id)
          this.db
            .prepare('UPDATE buddy_runs SET root_message_id=? WHERE id=?')
            .run(rootId ?? message.id, parent.id);
        if (sent + 1 >= membership.max_sends_per_hour)
          this.setCoordinationMembership(fromBuddy, workspace, {
            background_paused_reason: 'Hourly send limit reached',
          });
        if (input.approval) this.attachMessageApproval(message.id, input.approval);
        return this.getMessage(message.id);
      }
    );
  },

  enqueueMessageReply(message) {
    const backgroundParent = this.backgroundParentMessage(message);
    if (backgroundParent) { this.reconcileBackgroundWork(backgroundParent); return null; }
    if (!message.command_key || !message.parent_conversation_id) return null;
    const original = this.db
      .prepare('SELECT policy FROM buddy_runs WHERE input_key=? ORDER BY attempt LIMIT 1')
      .get(`message:${message.id}:request`);
    const returnPolicy = message.return_policy && message.return_policy !== '{}' ? JSON.parse(message.return_policy) : original ? JSON.parse(original.policy) : {allowed_operations:['buddy.get_inbox','buddy.get_current_work','buddy.send','buddy.reply']};
    delete returnPolicy.execution;
    delete returnPolicy.assignment_config;
    return this.enqueueBuddyRun({
      inputKey: `message:${message.id}:reply`,
      inputKind: 'message_reply',
      inputId: message.id,
      buddyId: message.from_buddy_id,
      workspaceId: message.source_workspace_id || message.workspace_id,
      conversationId: returnPolicy.return_conversation_id || message.parent_conversation_id,
      projectId: message.source_project_id,
      rootMessageId: message.root_message_id || message.id,
      policy: returnPolicy,
    });
  },

  coordinationCommand({ actor, workspaceId, key, payload }, callback) {
    required(actor, 'Command actor');
    required(workspaceId, 'Command workspace');
    required(key, 'Command key');
    if (key.length > 200) throw new Error('Command key exceeds 200 characters');
    const hash = createHash('sha256')
      .update(JSON.stringify(canonical(payload)))
      .digest('hex');
    return this.coordinationTransaction(() => {
      const previous = this.db
        .prepare(
          'SELECT * FROM buddy_command_receipts WHERE actor=? AND workspace_id=? AND command_key=?'
        )
        .get(actor, workspaceId, key);
      if (previous) {
        if (previous.payload_hash !== hash)
          throw new Error('Command key conflicts with a different payload');
        return JSON.parse(previous.result);
      }
      const result = callback();
      if (result && typeof result.then === 'function')
        throw new Error('Coordination commands must be synchronous');
      this.db
        .prepare('INSERT INTO buddy_command_receipts VALUES (?,?,?,?,?,?)')
        .run(actor, workspaceId, key, hash, JSON.stringify(result), timestamp());
      return result;
    });
  },

  enqueueBuddyRun({
    inputKey,
    inputKind,
    inputId,
    buddyId,
    workspaceId,
    conversationId,
    projectId,
    rootMessageId,
    readyAt,
    afterRunId,
    policy = {},
  }) {
    return this.coordinationTransaction(() => {
      const existing = this.db
        .prepare('SELECT id FROM buddy_runs WHERE input_key=? ORDER BY attempt DESC LIMIT 1')
        .get(inputKey);
      if (existing) return this.getBuddyRun(existing.id);
      const buddy = this.getBuddy(buddyId);
      if (!buddy || !this.listBuddyWorkspaces(buddy.id).some((w) => w.id === workspaceId))
        throw new Error('Run Buddy is outside the workspace');
      if (afterRunId && !this.getBuddyRun(afterRunId)) throw new Error('Predecessor run not found');
      const membership = this.getCoordinationMembership(buddy.id, workspaceId);
      const pending = this.db
        .prepare(
          "SELECT count(*) AS n FROM buddy_runs WHERE buddy_id=? AND workspace_id=? AND status='queued'"
        )
        .get(buddy.id, workspaceId).n;
      if (inputKind === 'message_request' && pending >= membership.max_pending_runs)
        throw new Error('Pending run limit reached');
      const id = `buddy_run_${randomUUID()}`;
      const at = readyAt ? new Date(readyAt).toISOString() : timestamp();
      this.db
        .prepare(`INSERT INTO buddy_runs
        (id,input_key,input_kind,input_id,buddy_id,workspace_id,conversation_id,project_id,root_message_id,
        ready_at,after_run_id,status,policy,created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,'queued',?,?)`)
        .run(
          id,
          required(inputKey, 'Input key'),
          required(inputKind, 'Input kind'),
          required(inputId, 'Input ID'),
          buddy.id,
          workspaceId,
          conversationId ?? null,
          projectId ?? null,
          rootMessageId ?? null,
          at,
          afterRunId ?? null,
          JSON.stringify(policy),
          timestamp()
        );
      const epochs = projectId
        ? this.projectAncestors(projectId).map((p) => ({ id: p.id, epoch: p.execution_epoch }))
        : [];
      this.db
        .prepare('UPDATE buddy_runs SET project_epochs=? WHERE id=?')
        .run(JSON.stringify(epochs), id);
      return this.getBuddyRun(id);
    });
  },

  getBuddyRun(id) {
    const run = this.db.prepare('SELECT * FROM buddy_runs WHERE id=?').get(id);
    return run
      ? { ...run, execution_snapshot: run.execution_snapshot ? JSON.parse(run.execution_snapshot) : null, policy: JSON.parse(run.policy), project_epochs: JSON.parse(run.project_epochs) }
      : null;
  },

  listBuddyRuns({
    order = 'oldest',
    buddyId,
    workspaceId,
    conversationId,
    rootMessageId,
    projectId,
    status,
    limit = 20,
    offset = 0,
    accept = () => true,
  } = {}) {
    const clauses = [],
      values = [];
    for (const [column, value] of Object.entries({
      buddy_id: buddyId,
      workspace_id: workspaceId,
      conversation_id: conversationId,
      root_message_id: rootMessageId,
      project_id: projectId,
      status,
    })) {
      if (value !== undefined) {
        clauses.push(`${column}=?`);
        values.push(value);
      }
    }
    const page = [];
    let skipped = 0;
    const count = Math.max(1, Math.min(100, Math.floor(Number(limit) || 20)));
    const start = Math.max(0, Math.floor(Number(offset) || 0));
    for (const row of this.db.prepare(`SELECT id FROM buddy_runs ${clauses.length ? `WHERE ${clauses.join(' AND ')}` : ''}
      ORDER BY created_at ${order === 'newest' ? 'DESC' : 'ASC'},rowid ${order === 'newest' ? 'DESC' : 'ASC'}`).iterate(...values)) {
      const run = this.getBuddyRun(row.id);
      if (!accept(run)) continue;
      if (skipped++ < start) continue;
      page.push(run);
      if (page.length === count) break;
    }
    return page;
  },

  inspectBuddyAdmission({ buddyId, workspaceId, runId, conversationId, at = timestamp() }) {
    const run = runId ? this.getBuddyRun(runId) : null;
    const blockers = [];
    const add = (code, reason, remedy, resolvableBy = 'runtime') => blockers.push({ code, path: runId ?? buddyId, reason, remedy, resolvableBy });
    if (runId && (!run || run.buddy_id !== buddyId || run.workspace_id !== workspaceId)) {
      add('run_scope', 'The run does not belong to this Buddy and workspace.', 'Select the original scoped receipt.', 'owner');
      return { allowed: false, blockers };
    }
    if (run && run.status !== 'queued') add('run_not_queued', `Run is ${run.status}.`, 'Inspect the existing attempt; configuration never retries a terminal run.');
    if (run?.ready_at > at) add('not_due', `Scheduled for ${run.ready_at}.`, 'Wait until the scheduled time.');
    if (
      run?.policy.interruption_report_of_run_id &&
      typeof run.policy.interruption_report_deadline === 'string' &&
      run.policy.interruption_report_deadline <= at
    )
      add('report_deadline', 'Interruption reporting allowance expired.', 'Return the unavailable-report fallback.');
    const buddy = this.getBuddy(buddyId), membership = this.getCoordinationMembership(buddyId, workspaceId);
    if (buddy?.status !== 'active') add('inactive_buddy', 'Recipient is not active.', 'Inspect identity lifecycle.', 'owner');
    if (buddy?.employment_mode === 'worker' && this.getBuddyTeamState(buddyId).manager?.status !== 'active')
      add('inactive_parent', 'Worker parent is not active.', 'Inspect the parent lifecycle.', 'owner');
    if (!membership) add('workspace_membership_required', 'Recipient has no workspace membership.', 'Explicitly admit the identity to this workspace.', 'owner');
    if (!run?.policy.foreground && !membership?.background_enabled) add('background_disabled', 'Background execution is disabled.', 'Enable incoming work for this participant.', 'owner');
    if (!run?.policy.foreground && membership?.background_paused_reason) add('background_paused', membership.background_paused_reason, 'Inspect and resume the recorded execution pause.', 'owner');
    if (!run?.policy.foreground) {
      const active = this.coordinationBackgroundActiveCounts();
      if (active.length >= 8 || (membership && active.filter(r => r.buddy_id === buddyId).length >= (buddy.employment_mode === 'worker' ? 1 : membership.max_active_runs)))
        add('active_run_limit', 'Active run limit reached.', 'Wait for active work to drain.');
    }
    const recent = this.db.prepare("SELECT count(*) AS n FROM buddy_runs WHERE buddy_id=? AND workspace_id=? AND started_at>=? AND COALESCE(json_extract(policy,'$.foreground'),0)=0").get(buddyId, workspaceId, new Date(Date.parse(at)-3600000).toISOString()).n;
    if (!run?.policy.foreground && membership && recent >= membership.max_background_runs_per_hour) add('hourly_run_limit', 'Hourly run limit reached.', 'Review the hourly budget and resume after its window.', 'owner');
    if (run && !run.policy.foreground) {
      try { this.assertProjectExecution(run.project_id, run.project_epochs, { admission: true }); }
      catch (error) { add('project_gate', error.message, 'Inspect canonical project state and the original execution epoch.', 'lead'); }
    }
    if (run?.after_run_id && this.getBuddyRun(run.after_run_id)?.status !== 'complete') add('predecessor', 'Waiting for the source run to complete successfully.', 'Inspect the original predecessor run.');
    if (run?.root_message_id && this.getMessage(run.root_message_id)?.root_stopped_at) add('root_stopped', 'The message root was stopped.', 'Inspect the stop receipt; do not restart by reconfiguring staff.', 'owner');
    if (run?.input_kind === 'schedule' && this.db.prepare("SELECT 1 FROM buddy_runs WHERE input_kind='schedule' AND input_id=? AND status IN ('claimed','running','cancel_requested')").get(run.input_id)) add('schedule_running', 'This schedule already has an active run.', 'Wait for its current run to drain.');
    const target = run?.conversation_id ?? conversationId;
    if (target && this.db.prepare("SELECT 1 FROM buddy_runs WHERE conversation_id=? AND status IN ('claimed','running','cancel_requested')").get(target)) add('conversation_busy', 'The destination conversation has an active turn.', 'Wait for that turn to drain.');
    return { allowed: !blockers.length, blockers };
  },

  claimBuddyRun(id, { claimToken, conversationId, maxRuntimeSeconds = 600, now = timestamp() }) {
    return this.coordinationTransaction(() => {
      const run = this.getBuddyRun(id);
      if (!run || run.status !== 'queued' || run.ready_at > now) return null;
      const admission = this.inspectBuddyAdmission({buddyId:run.buddy_id,workspaceId:run.workspace_id,runId:id,conversationId,at:now});
      if (!admission.allowed) {
        const blocker = admission.blockers[0];
        if (blocker.code === 'hourly_run_limit') this.setCoordinationMembership(run.buddy_id,run.workspace_id,{background_paused_reason:'Hourly run limit reached'});
        if (blocker.code === 'project_gate') this.assertProjectExecution(run.project_id,run.project_epochs,{admission:true});
        this.holdBuddyRun(id,blocker.reason);
        return null;
      }
      const target = run.conversation_id ?? required(conversationId, 'Conversation ID');
      if (conversationId && run.conversation_id && run.conversation_id !== conversationId)
        throw new Error('Run destination cannot be changed during claim');
      // Foreground chats share the application turn budget; background limits remain separate.
      const maxAllowedSeconds = run.input_kind === 'chat' && run.policy.foreground ? 24 * 60 * 60 : 3600;
      if (!Number.isFinite(maxRuntimeSeconds) || maxRuntimeSeconds < 1 || maxRuntimeSeconds > maxAllowedSeconds)
        throw new Error('Invalid runtime limit');
      const background = run.input_kind === 'message_request' && !run.policy.interruption_report_of_run_id
        ? this.getBackgroundWork(run.input_id)
        : null;
      if (background && (background.message.status === 'replied' || (background.deadline && background.deadline <= now) || background.runsUsed >= background.execution.maxRuns)) { this.reconcileBackgroundWork(run.input_id); return null; }
      const reportDeadline = typeof run.policy.interruption_report_deadline === 'string'
        ? Date.parse(run.policy.interruption_report_deadline)
        : Infinity;
      const deadline = new Date(Math.min(
        Date.parse(now) + maxRuntimeSeconds * 1000,
        background?.deadline ? Date.parse(background.deadline) : background ? Date.parse(now) + background.execution.maxDurationSeconds * 1000 : Infinity,
        reportDeadline,
      )).toISOString();
      this.db
        .prepare(
          "UPDATE buddy_runs SET status='claimed',error=NULL,error_code=NULL, conversation_id=?, claim_token=?, claim_expires_at=?, deadline=?, started_at=? WHERE id=? AND status='queued'"
        )
        .run(target, required(claimToken, 'Claim token'), deadline, deadline, now, id);
      return this.getBuddyRun(id);
    });
  },

  withBuddyRunAuthority(id, claimToken, operation, callback) {
    return this.coordinationTransaction(() => {
      const run = this.getBuddyRun(id);
      if (
        !run ||
        !['claimed', 'running'].includes(run.status) ||
        !claimToken ||
        run.claim_token !== claimToken ||
        run.deadline <= timestamp()
      )
        throw new Error('Buddy run authority expired or revoked');
      if (
        !run.policy.foreground &&
        (!this.getCoordinationMembership(run.buddy_id, run.workspace_id)?.background_enabled ||
          this.getCoordinationMembership(run.buddy_id, run.workspace_id)?.background_paused_reason)
      )
        throw new Error('Background execution is disabled');
      if (this.getBuddy(run.buddy_id)?.status !== 'active') throw new Error('Buddy is not active');
      this.assertWorkerParent(run.buddy_id);
      if (run.root_message_id && this.getMessage(run.root_message_id)?.root_stopped_at)
        throw new Error('Message root is stopped');
      if (!run.policy.foreground)
        this.assertProjectExecution(run.project_id, run.project_epochs, { operation });
      if (
        !Array.isArray(run.policy.allowed_operations) ||
        !run.policy.allowed_operations.includes(operation)
      )
        throw new Error('Operation is outside the run policy');
      return callback(run);
    });
  },

  startBuddyRun(id, claimToken) {
    return this.coordinationTransaction(() => {
      const run = this.getBuddyRun(id);
      if (
        !run ||
        run.status !== 'claimed' ||
        run.claim_token !== claimToken ||
        run.deadline <= timestamp()
      )
        throw new Error('Run is not claimable');
      if (
        (!run.policy.foreground &&
          !this.getCoordinationMembership(run.buddy_id, run.workspace_id)?.background_enabled) ||
        this.getBuddy(run.buddy_id)?.status !== 'active'
      )
        throw new Error('Run permission revoked');
      this.assertWorkerParent(run.buddy_id);
      if (run.root_message_id && this.getMessage(run.root_message_id)?.root_stopped_at)
        throw new Error('Message root is stopped');
      if (!run.policy.foreground)
        this.assertProjectExecution(run.project_id, run.project_epochs, {
          admission: true,
        });
      if (
        run.input_kind === 'message_request' &&
        !this.getMessage(run.input_id)?.child_conversation_id
      )
        this.bindMessageConversation(run.input_id, run.conversation_id);
      this.db.prepare("UPDATE buddy_runs SET status='running',acknowledged_at=? WHERE id=?").run(timestamp(),id);
      return this.getBuddyRun(id);
    });
  },

  finishBuddyRun(id, { claimToken, status, outcome, error, errorCode }) {
    return this.coordinationTransaction(() => {
      const run = this.getBuddyRun(id);
      if (!run || !terminal.has(status) || run.claim_token !== claimToken || !claimToken)
        throw new Error('Invalid run settlement');
      if (terminal.has(run.status)) {
        if (run.status !== status) throw new Error('Terminal run cannot change status');
        return run;
      }
      if (run.status === 'cancel_requested' && status !== 'cancelled')
        throw new Error('Cancelled run cannot complete');
      if (status === 'complete' && run.deadline <= timestamp())
        throw new Error('Expired run cannot complete');
      this.db
        .prepare(
          'UPDATE buddy_runs SET status=?,outcome=?,error=?,error_code=?,ended_at=? WHERE id=?'
        )
        .run(status, outcome ?? null, error ?? null, errorCode ?? null, timestamp(), id);
      if (run.policy.interruption_report_of_run_id) {
        this.enqueueInterruptionReportReturn(this.getBuddyRun(id));
        return this.getBuddyRun(id);
      }
      if (run.policy.execution?.mode === 'until_done') {
        this.reconcileBackgroundWork(run.input_id);
        if (status === 'failed' && this.getBackgroundWork(run.input_id)?.disposition === 'recoverable')
          this.enqueueBuddyFailureNotice(this.getBuddyRun(id));
      }
      else if (status === 'failed') this.enqueueBuddyFailureNotice(this.getBuddyRun(id));
      return this.getBuddyRun(id);
    });
  },

  enqueueBuddyFailureNotice(run) {
    if (['max_runtime_timeout', 'interrupted'].includes(run.error_code))
      return this.ensureInterruptionReport(run.id);
    if (run.policy.execution?.mode === 'until_done' && this.getBackgroundWork(run.input_id)?.disposition !== 'recoverable') { this.reconcileBackgroundWork(run.input_id); return null; }
    const child = this.getMessage(run.input_id);
    const backgroundParent = child ? this.backgroundParentMessage(child) : null;
    if (backgroundParent) { this.reconcileBackgroundWork(backgroundParent); return null; }
    if (run.input_kind !== 'message_request') return null;
    const message = this.getMessage(run.input_id);
    if (
      !message?.parent_conversation_id ||
      message.root_stopped_at ||
      this.getMessage(message.root_message_id)?.root_stopped_at
    )
      return null;
    const returnPolicy = { ...run.policy, ...JSON.parse(message.return_policy || '{}') };
    delete returnPolicy.execution;
    delete returnPolicy.assignment_config;
    return this.enqueueBuddyRun({
      inputKey: `failure:${run.id}`,
      inputKind: 'failure_notice',
      inputId: run.id,
      buddyId: message.from_buddy_id,
      workspaceId: message.source_workspace_id || message.workspace_id,
      conversationId: returnPolicy.return_conversation_id || message.parent_conversation_id,
      projectId: message.source_project_id,
      rootMessageId: message.root_message_id,
      policy: returnPolicy,
    });
  },

  ensureInterruptionReport(sourceRunId) {
    const source = this.getBuddyRun(sourceRunId);
    if (
      !source ||
      source.input_kind !== 'message_request' ||
      source.policy.interruption_report_of_run_id ||
      source.status !== 'failed' ||
      !['max_runtime_timeout', 'interrupted'].includes(source.error_code)
    )
      return null;
    const message = this.getMessage(source.input_id);
    if (
      !message?.parent_conversation_id ||
      message.root_stopped_at ||
      this.getMessage(message.root_message_id)?.root_stopped_at
    )
      return null;
    const reportOperations = new Set([
      'buddy.get_current_work',
      'buddy.get_inbox',
      'buddy.get_message',
      'buddy.list_task_comments',
      'buddy.recall',
    ]);
    try {
      const report = this.enqueueBuddyRun({
        inputKey: `interruption-report:${source.id}`,
        inputKind: 'message_request',
        inputId: message.id,
        buddyId: source.buddy_id,
        workspaceId: source.workspace_id,
        projectId: source.project_id,
        rootMessageId: source.root_message_id,
        policy: {
          allowed_operations: source.policy.allowed_operations.filter((operation) => reportOperations.has(operation)),
          max_runtime_seconds: 120,
          interruption_report_deadline: new Date(Date.now() + 120_000).toISOString(),
          interruption_report_of_run_id: source.id,
          ...(source.policy.assignment_config ? { assignment_config: source.policy.assignment_config } : {}),
          source_run_id: source.id,
        },
      });
      const admission = this.inspectBuddyAdmission({
        buddyId: report.buddy_id,
        workspaceId: report.workspace_id,
        runId: report.id,
      });
      if (admission.allowed) return report;
      const reason = admission.blockers.map((blocker) => blocker.reason).join(' ');
      this.holdBuddyRun(report.id, `Interruption report unavailable: ${reason}`);
      this.cancelBuddyRun(report.id);
      return this.enqueueInterruptionReportReturn(
        this.getBuddyRun(report.id),
        undefined,
        new Error(reason),
      );
    } catch (error) {
      return this.enqueueInterruptionReportReturn(null, source, error);
    }
  },

  reconcileInterruptionReports(at = timestamp()) {
    const settled = [];
    for (const row of this.db.prepare(`SELECT id FROM buddy_runs
      WHERE status='queued' AND json_extract(policy,'$.interruption_report_of_run_id') IS NOT NULL`).all()) {
      const report = this.getBuddyRun(row.id);
      const admission = this.inspectBuddyAdmission({
        buddyId: report.buddy_id,
        workspaceId: report.workspace_id,
        runId: report.id,
        at,
      });
      if (admission.allowed) continue;
      const reason = admission.blockers.map((blocker) => blocker.reason).join(' ');
      this.holdBuddyRun(report.id, `Interruption report unavailable: ${reason}`);
      this.cancelBuddyRun(report.id);
      settled.push(this.enqueueInterruptionReportReturn(
        this.getBuddyRun(report.id),
        undefined,
        new Error(reason),
      ));
    }
    return settled.filter(Boolean);
  },

  enqueueInterruptionReportReturn(reportRun, sourceOverride, unavailableError) {
    const sourceId = reportRun?.policy.interruption_report_of_run_id ?? sourceOverride?.id;
    const source = sourceId ? this.getBuddyRun(sourceId) : null;
    if (!source || source.input_kind !== 'message_request') return null;
    const message = this.getMessage(source.input_id);
    if (
      !message?.parent_conversation_id ||
      message.root_stopped_at ||
      this.getMessage(message.root_message_id)?.root_stopped_at
    )
      return null;
    const returnPolicy = { ...source.policy, ...JSON.parse(message.return_policy || '{}') };
    delete returnPolicy.execution;
    delete returnPolicy.assignment_config;
    returnPolicy.source_run_id = source.id;
    if (reportRun) returnPolicy.interruption_report_run_id = reportRun.id;
    if (unavailableError) returnPolicy.interruption_report_unavailable = unavailableError instanceof Error
      ? unavailableError.message
      : String(unavailableError);
    return this.enqueueBuddyRun({
      inputKey: `interruption-return:${source.id}`,
      inputKind: 'failure_notice',
      inputId: reportRun?.id ?? source.id,
      buddyId: message.from_buddy_id,
      workspaceId: message.source_workspace_id || message.workspace_id,
      conversationId: returnPolicy.return_conversation_id || message.parent_conversation_id,
      projectId: message.source_project_id,
      rootMessageId: message.root_message_id,
      policy: returnPolicy,
    });
  },

  holdBuddyRun(id, reason) {
    this.db
      .prepare("UPDATE buddy_runs SET error=?,error_code='held' WHERE id=? AND status='queued'")
      .run(reason, id);
  },

  recoverBuddyRuns({ now = timestamp(), confirmedDrainedIds = [] } = {}) {
    return this.coordinationTransaction(() =>
      this.db
        .prepare(
          "SELECT id FROM buddy_runs WHERE status IN ('claimed','running','cancel_requested') AND (COALESCE(json_extract(policy,'$.foreground'),0)=1 OR deadline<=?)"
        )
        .all(now)
        .filter((r) => confirmedDrainedIds.includes(r.id))
        .map(({ id }) => {
          this.db
            .prepare(
              "UPDATE buddy_runs SET status=CASE WHEN status='cancel_requested' THEN 'cancelled' ELSE 'failed' END,error='Executor interrupted; inspect side effects before retry',error_code='interrupted',ended_at=?,claim_token=NULL WHERE id=?"
            )
            .run(now, id);
          const recovered = this.getBuddyRun(id);
          if (recovered.policy.interruption_report_of_run_id)
            this.enqueueInterruptionReportReturn(recovered);
          else
            this.enqueueBuddyFailureNotice(recovered);
          return recovered;
        })
    );
  },

  repairBuddyRun(id, { key, conversationId }) {
    const run = this.getBuddyRun(id);
    if (!run) throw new Error('Run not found');
    return this.coordinationCommand(
      { actor: 'owner', workspaceId: run.workspace_id, key, payload: { id, conversationId } },
      () => {
        if (this.getBuddyRun(id).status !== 'queued')
          throw new Error('Only queued inputs can be repaired');
        const target = this.db
          .prepare('SELECT * FROM conversation_links WHERE unleashd_conversation_id=?')
          .get(conversationId);
        if (!target || target.buddy_id !== run.buddy_id || target.workspace_id !== run.workspace_id)
          throw new Error('Repair destination must match Buddy and workspace');
        this.db
          .prepare('UPDATE buddy_runs SET conversation_id=?,error=NULL,error_code=NULL WHERE id=?')
          .run(conversationId, id);
        if (run.input_kind === 'message_request')
          this.db
            .prepare('UPDATE buddy_messages SET child_conversation_id=? WHERE id=?')
            .run(conversationId, run.input_id);
        return this.getBuddyRun(id);
      }
    );
  },

  retryBuddyRun(id, { key, conversationId, actor = 'owner', reason, checkpointId } = {}) {
    const original = this.getBuddyRun(id);
    if (!original) throw new Error('Run not found');
    return this.coordinationCommand(
      { actor, workspaceId: original.workspace_id, key, payload: { id, conversationId, reason, checkpointId } },
      () => {
        const run = this.getBuddyRun(id);
        const recovery = this.getBuddyRunRecovery(id, actor);
        if (!recovery.canRetry) throw new Error(recovery.reason);
        if (checkpointId && !this.listRunCheckpoints(id).some(c => c.id === checkpointId))
          throw new Error('Checkpoint does not belong to this attempt');
        if (recovery.mode === 'successor_request')
          return this.recoverClosedBackgroundMessage(run,{key,reason,checkpointId,conversationId});
        if (run.input_kind === 'chat')
          throw new Error('Retry owner messages from their conversation');
        if (!['failed', 'cancelled'].includes(run.status))
          throw new Error('Only failed or cancelled runs can be retried');
        if (
          this.db
            .prepare(
              "SELECT 1 FROM buddy_runs WHERE input_key=? AND status IN ('queued','claimed','running','cancel_requested')"
            )
            .get(run.input_key)
        )
          throw new Error('Input already has a live attempt');
        if (run.root_message_id && this.getMessage(run.root_message_id)?.root_stopped_at)
          throw new Error('Stopped roots cannot be retried');
        this.assertProjectExecution(run.project_id, null, { admission: true });
        const message = run.input_kind === 'message_request' ? this.getMessage(run.input_id) : null;
        if (
          message &&
          (message.superseded_by_message_id || ['replied', 'cancelled'].includes(message.status))
        )
          throw new Error('Request is no longer open');
        const next = `buddy_run_${randomUUID()}`;
        const attempt =
          this.db
            .prepare('SELECT max(attempt) AS n FROM buddy_runs WHERE input_key=?')
            .get(run.input_key).n + 1;
        this.db
          .prepare(
            `INSERT INTO buddy_runs (id,input_key,input_kind,input_id,attempt,buddy_id,workspace_id,conversation_id,project_id,root_message_id,ready_at,after_run_id,status,policy,created_at,retry_of_run_id,project_epochs) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,'queued',?,?,?,?)`
          )
          .run(
            next,
            run.input_key,
            run.input_kind,
            run.input_id,
            attempt,
            run.buddy_id,
            run.workspace_id,
            conversationId ?? run.conversation_id,
            run.project_id,
            run.root_message_id,
            timestamp(),
            run.after_run_id,
            JSON.stringify({...run.policy, ...(checkpointId ? {recovery_checkpoint_id:checkpointId} : {})}),
            timestamp(),
            id,
            JSON.stringify(
              run.project_id
                ? this.projectAncestors(run.project_id).map((p) => ({
                    id: p.id,
                    epoch: p.execution_epoch,
                  }))
                : []
            )
          );
        return this.getBuddyRun(next);
      }
    );
  },

  cancelBuddyRun(id) {
    this.db
      .prepare(`UPDATE buddy_runs SET status=CASE WHEN status='queued' THEN 'cancelled' ELSE 'cancel_requested' END,
      ended_at=CASE WHEN status='queued' THEN ? ELSE ended_at END WHERE id=? AND status IN ('queued','claimed','running')`)
      .run(timestamp(), id);
    return this.getBuddyRun(id);
  },

  stopBuddyMessageRoot(rootId) {
    return this.coordinationTransaction(() => {
      const root = this.getMessage(rootId);
      if (!root || (root.root_message_id && root.root_message_id !== root.id))
        throw new Error('Message is not a root');
      this.db
        .prepare('UPDATE buddy_messages SET root_stopped_at=COALESCE(root_stopped_at,?) WHERE id=?')
        .run(timestamp(), rootId);
      this.db
        .prepare(
          "UPDATE buddy_messages SET status='cancelled' WHERE root_message_id=? AND status IN ('pending','active')"
        )
        .run(rootId);
      const runs = this.db
        .prepare(
          "SELECT id FROM buddy_runs WHERE root_message_id=? AND status IN ('queued','claimed','running')"
        )
        .all(rootId);
      return runs.map((run) => this.cancelBuddyRun(run.id));
    });
  },
};
