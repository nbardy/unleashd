import { createHash } from "node:crypto";
import { existsSync } from "node:fs";

const OWNER = "owner:configure_team";
const now = () => new Date().toISOString();
const canonical = (value) =>
	Array.isArray(value)
		? value.map(canonical)
		: value && typeof value === "object"
			? Object.fromEntries(
					Object.keys(value)
						.sort()
						.filter((k) => value[k] !== undefined)
						.map((k) => [k, canonical(value[k])]),
				)
			: value;
const hash = (value) =>
	createHash("sha256")
		.update(JSON.stringify(canonical(value)))
		.digest("hex");
const token = (ref) =>
	ref?.id ?? (ref?.creationKey ? `creation:${ref.creationKey}` : null);
const creationScope = (workspaceId) => `owner:${workspaceId}`;
const creationInput = ({ creationKey, ...input }) => input;
const fail = (code, path, reason, remedy, resolvableBy = "owner") => ({
	code,
	path,
	reason,
	remedy,
	resolvableBy,
});
const strict = (value, fields, path) => {
	if (
		!value ||
		Array.isArray(value) ||
		typeof value !== "object" ||
		Object.keys(value).some((k) => !fields.includes(k))
	)
		throw new Error(`Invalid or unknown fields at ${path}`);
};
const string = (value, path, max = 200) => {
	if (typeof value !== "string" || !value.trim() || value.length > max)
		throw new Error(`Invalid ${path}`);
};
const bool = (value, path) => {
	if (value !== undefined && typeof value !== "boolean")
		throw new Error(`Invalid ${path}`);
};
const refCheck = (ref, path) => {
	strict(ref, ["id", "creationKey"], path);
	if (Object.keys(ref).length !== 1)
		throw new Error(`Exactly one identity reference required at ${path}`);
	string(ref.id ?? ref.creationKey, path);
};

// Package-side validation protects the host API even when called without the app's
// canonical Zod schema. No owner principal is accepted in this model-facing value.
export function validateTeamConfiguration(configuration) {
	strict(
		configuration,
		[
			"workspaceId",
			"reason",
			"create",
			"memberships",
			"relationships",
			"access",
			"staffing",
		],
		"configuration",
	);
	string(configuration.workspaceId, "workspaceId");
	string(configuration.reason, "reason", 4000);
	if (Buffer.byteLength(JSON.stringify(configuration)) > 256 * 1024)
		throw new Error("Team configuration exceeds 256 KiB");
	for (const [field, limit] of [
		["create", 32],
		["memberships", 32],
		["relationships", 64],
		["access", 128],
		["staffing", 32],
	]) {
		if (
			configuration[field] !== undefined &&
			(!Array.isArray(configuration[field]) ||
				configuration[field].length > limit)
		)
			throw new Error(`Invalid ${field} bound`);
		for (const [i, row] of (configuration[field] ?? []).entries()) {
			const path = `${field}.${i}`;
			if (
				(field === "access" || field === "staffing") &&
				row.expiresAt !== undefined &&
				row.expiresAt !== null &&
				(typeof row.expiresAt !== "string" ||
					!/^\d{4}-\d{2}-\d{2}T.*Z$/.test(row.expiresAt) ||
					!Number.isFinite(Date.parse(row.expiresAt)))
			)
				throw new Error(`Invalid ${path}.expiresAt`);
			if (
				(field === "access" || field === "staffing") &&
				row.baseRevision !== undefined &&
				(!Number.isInteger(row.baseRevision) || row.baseRevision < 0)
			)
				throw new Error(`Invalid ${path}.baseRevision`);
			if (field === "create") {
				strict(
					row,
					[
						"creationKey",
						"name",
						"role",
						"soul",
						"provider",
						"model",
						"reasoningEffort",
					],
					path,
				);
				string(row.creationKey, `${path}.creationKey`);
				string(row.name, `${path}.name`);
				string(row.role, `${path}.role`, 4000);
				string(row.soul, `${path}.soul`, 10000);
				if (Buffer.byteLength(row.soul, "utf8") > 10000)
					throw new Error(`Initial soul exceeds 10000 bytes at ${path}.soul`);
				for (const key of ["provider", "model", "reasoningEffort"])
					if (
						row[key] !== undefined &&
						(typeof row[key] !== "string" || row[key].length > 200)
					)
						throw new Error(`Invalid ${path}.${key}`);
			} else if (field === "memberships") {
				strict(
					row,
					["buddy", "present", "incoming", "dispatch", "readAllWork"],
					path,
				);
				refCheck(row.buddy, `${path}.buddy`);
				if (row.present !== true)
					throw new Error("Membership removal uses lifecycle controls");
				for (const key of ["incoming", "dispatch", "readAllWork"])
					bool(row[key], `${path}.${key}`);
			} else if (field === "relationships") {
				strict(row, ["from", "to", "kind", "present"], path);
				refCheck(row.from, `${path}.from`);
				refCheck(row.to, `${path}.to`);
				if (
					!["manager", "consults"].includes(row.kind) ||
					typeof row.present !== "boolean"
				)
					throw new Error(`Invalid ${path}`);
			} else if (field === "access") {
				strict(
					row,
					[
						"grantee",
						"target",
						"relationships",
						"profile",
						"soul",
						"memory",
						"incoming",
						"schedules",
						"baseRevision",
						"expiresAt",
					],
					path,
				);
				refCheck(row.grantee, `${path}.grantee`);
				refCheck(row.target, `${path}.target`);
				for (const key of ["relationships", "incoming", "schedules"])
					bool(row[key], `${path}.${key}`);
				for (const key of ["profile", "soul", "memory"])
					if (
						row[key] !== undefined &&
						!["none", "read", "write", "write_only"].includes(row[key])
					)
						throw new Error(`Invalid ${path}.${key}`);
			} else {
				strict(
					row,
					["grantee", "enabled", "createdBuddyIncoming", "baseRevision", "expiresAt"],
					path,
				);
				refCheck(row.grantee, `${path}.grantee`);
				if (typeof row.enabled !== "boolean")
					throw new Error(`Invalid ${path}.enabled`);
				bool(row.createdBuddyIncoming, `${path}.createdBuddyIncoming`);
			}
		}
	}
	return canonical(configuration);
}

export function migrateTeamConfiguration(db) {
	if (db.prepare("PRAGMA user_version").get().user_version >= 25) return;
	db.exec("SAVEPOINT team_configuration");
	try {
		if (
			!db
				.prepare("PRAGMA table_info(buddy_access_grants)")
				.all()
				.some((c) => c.name === "created_buddy_incoming")
		)
			db.exec(
				"ALTER TABLE buddy_access_grants ADD COLUMN created_buddy_incoming INTEGER NOT NULL DEFAULT 0 CHECK(created_buddy_incoming IN (0,1))",
			);
		db.exec("PRAGMA user_version=25; RELEASE team_configuration");
	} catch (error) {
		db.exec("ROLLBACK TO team_configuration; RELEASE team_configuration");
		throw error;
	}
}

const memberView = (member) =>
	member
		? {
				present: true,
				incoming: !!member.background_enabled,
				dispatch: !!member.dispatch,
				readAllWork: !!member.read_all_work,
				pausedReason: member.background_paused_reason ?? null,
				maxActiveRuns: member.max_active_runs,
			}
		: null;
const defaultMember = () => ({
	present: true,
	incoming: false,
	dispatch: true,
	readAllWork: false,
	pausedReason: null,
	maxActiveRuns: 2,
});
const buddyView = (buddy) => ({
	name: buddy.name,
	role: buddy.role,
	status: buddy.status,
	provider: buddy.provider ?? null,
	model: buddy.model ?? null,
	reasoningEffort: buddy.reasoning_effort ?? buddy.reasoningEffort ?? null,
	revision: buddy.profile_revision ?? 0,
});
const grantView = (row, targetWorkspaces) =>
	row
		? {
				granteeId: row.grantee_id,
				targetId: row.target_id,
				capabilities: [...row.capabilities].sort(),
				revision: row.revision,
				expiresAt: row.expires_at,
				reason: row.reason,
				createdBuddyIncoming: !!row.created_buddy_incoming,
				affectedWorkspaceIds: targetWorkspaces,
			}
		: null;

// Receipt baseline covers every requested record, including operations that
// were already satisfied. It never reconciles desired state back into storage.
function configurationState(store, configuration) {
	const workspaceId = configuration.workspaceId;
	const resolve = (ref) =>
		ref.id ??
		store.getBuddyBuilderResult(creationScope(workspaceId), ref.creationKey)
			?.buddy.id ??
		null;
	const ids = new Set();
	for (const input of configuration.create ?? [])
		ids.add(resolve({ creationKey: input.creationKey }));
	for (const [section, fields] of [
		["memberships", ["buddy"]],
		["relationships", ["from", "to"]],
		["access", ["grantee", "target"]],
		["staffing", ["grantee"]],
	])
		for (const row of configuration[section] ?? [])
			for (const field of fields) ids.add(resolve(row[field]));
	const memberIds = new Set(
		(configuration.memberships ?? []).map((row) => resolve(row.buddy)),
	);
	for (const input of configuration.create ?? [])
		memberIds.add(resolve({ creationKey: input.creationKey }));
	const grant = (granteeId, targetId) => {
		const row = store.getBuddyAccess(granteeId, workspaceId, targetId);
		return {
			granteeId,
			targetId,
			capabilities: row?.capabilities ?? [],
			createdBuddyIncoming: !!row?.created_buddy_incoming,
			expiresAt: row?.expires_at ?? null,
		};
	};
	return {
		buddies: [...ids]
			.sort()
			.map((id) => ({ id, status: store.getBuddy(id)?.status ?? null })),
		memberships: [...memberIds].sort().map((id) => ({
			id,
			value: memberView(store.getCoordinationMembership(id, workspaceId)),
		})),
		relationships: (configuration.relationships ?? []).map((row) => {
			const from = resolve(row.from),
				to = resolve(row.to);
			return {
				from,
				to,
				kind: row.kind,
				present: !!store.db
					.prepare(
						"SELECT id FROM buddy_relationships WHERE from_buddy_id=? AND to_buddy_id=? AND kind=?",
					)
					.get(from, to, row.kind),
				manager:
					row.kind === "manager"
						? (store.db
								.prepare(
									"SELECT from_buddy_id FROM buddy_relationships WHERE kind='manager' AND to_buddy_id=?",
								)
								.get(to)?.from_buddy_id ?? null)
						: null,
			};
		}),
		access: (configuration.access ?? []).map((row) =>
			grant(resolve(row.grantee), resolve(row.target)),
		),
		staffing: (configuration.staffing ?? []).map((row) =>
			grant(resolve(row.grantee), workspaceId),
		),
	};
}

export const teamConfigurationMethods = {
	prepareTeamConfiguration({ key, configuration }) {
		string(key, "key");
		const config = validateTeamConfiguration(configuration),
			workspaceId = config.workspaceId;
		const blockers = [],
			effects = [],
			resolved = new Map(),
			refs = new Map(),
			creations = new Map(),
			members = new Map(),
			grants = new Map();
		const snapshot = { buddies: [], grants: [], relationships: [], queue: [] };
		const add = (...args) => blockers.push(fail(...args));
		if (!this.getWorkspace(workspaceId))
			add(
				"workspace_not_found",
				"workspaceId",
				"Workspace does not exist.",
				"Select an existing owner-admitted workspace.",
			);
		const create = config.create ?? [];
		create.forEach((input, i) => {
			if (creations.has(input.creationKey))
				add(
					"duplicate_creation",
					`create.${i}`,
					"Creation key is declared more than once.",
					"Use one declaration per creation key.",
				);
			creations.set(input.creationKey, input);
		});
		const resolve = (ref, path) => {
			const refToken = token(ref);
			refs.set(refToken, ref);
			if (resolved.has(refToken)) return resolved.get(refToken);
			let buddy = null;
			if (ref.id) {
				buddy = this.getBuddy(ref.id);
				if (!buddy || buddy.id !== ref.id) {
					add(
						"buddy_not_found",
						path,
						"Exact Buddy ID was not found.",
						"Resolve an existing ID from the owner directory.",
					);
					resolved.set(refToken, null);
					return null;
				}
			} else {
				const input = creations.get(ref.creationKey);
				if (!input) {
					add(
						"undeclared_creation",
						path,
						"Creation reference is not declared in this command.",
						"Declare it in create or use an existing exact ID.",
					);
					resolved.set(refToken, null);
					return null;
				}
				const receipt = this.getBuddyBuilderResult(
					creationScope(workspaceId),
					ref.creationKey,
				);
				if (receipt) {
					if (receipt.requestFingerprint !== hash(creationInput(input)))
						add(
							"creation_key_conflict",
							path,
							"Creation key already identifies a different creation request.",
							"Use the original creation arguments or an explicitly new key.",
						);
					buddy = receipt.buddy;
				} else
					buddy = {
						id: refToken,
						name: input.name,
						role: input.role,
						status: "active",
						provider: input.provider ?? null,
						model: input.model ?? null,
						reasoningEffort: input.reasoningEffort ?? null,
						fresh: true,
					};
			}
			resolved.set(refToken, buddy);
			return buddy;
		};
		const requireActive = (buddy, path) => {
			if (buddy && buddy.status !== "active")
				add(
					"inactive_buddy",
					path,
					`${buddy.name} is ${buddy.status}.`,
					"Inspect lifecycle controls; setup never reactivates an identity.",
				);
		};
		create.forEach((row, i) =>
			requireActive(resolve({ creationKey: row.creationKey }, `create.${i}`), `create.${i}`),
		);
		for (const [section, fields] of [
			["memberships", ["buddy"]],
			["relationships", ["from", "to"]],
			["access", ["grantee", "target"]],
			["staffing", ["grantee"]],
		])
			(config[section] ?? []).forEach((row, i) =>
				fields.forEach((field) =>
					resolve(row[field], `${section}.${i}.${field}`),
				),
			);
		const buddies = [...resolved.values()].filter(Boolean);
		if (!buddies.length)
			add(
				"empty_configuration",
				"configuration",
				"Team configuration requires at least one identity.",
				"Select the requested exact identities.",
			);
		if (new Set(buddies.map((b) => b.id)).size > 32)
			add(
				"identity_limit",
				"configuration",
				"Configuration references more than 32 identities.",
				"Split independent workspace batches.",
			);
		if (
			buddies.some(
				(buddy, i) => buddies.findIndex((b) => b.id === buddy.id) !== i,
			)
		)
			add(
				"duplicate_identity",
				"configuration",
				"The same identity is referenced by ID and creation key.",
				"Use one reference spelling for each identity throughout the command.",
			);
		for (const buddy of buddies) {
			const current = buddy.fresh
				? null
				: this.getCoordinationMembership(buddy.id, workspaceId);
			const workspaces = buddy.fresh
				? [workspaceId]
				: this.listBuddyWorkspaces(buddy.id)
						.map((w) => w.id)
						.sort();
			snapshot.buddies.push({
				id: buddy.id,
				profile: buddyView(buddy),
				member: current,
				workspaces,
			});
			members.set(
				buddy.id,
				current ? memberView(current) : buddy.fresh ? defaultMember() : null,
			);
			if (buddy.fresh)
				effects.push({
					resource: "buddy",
					id: buddy.id,
					before: null,
					after: {
						...buddyView(buddy),
						soulHash: hash(
							creations.get(refs.get(buddy.id)?.creationKey)?.soul ??
								create.find(
									(c) => token({ creationKey: c.creationKey }) === buddy.id,
								)?.soul,
						),
					},
				});
		}
		const seenMembers = new Set();
		(config.memberships ?? []).forEach((row, i) => {
			const buddy = resolved.get(token(row.buddy));
			if (!buddy) return;
			requireActive(buddy, `memberships.${i}`);
			if (seenMembers.has(buddy.id))
				add(
					"duplicate_membership",
					`memberships.${i}`,
					"Duplicate membership configuration.",
					"Combine the settings into one entry.",
				);
			seenMembers.add(buddy.id);
			const before = members.get(buddy.id),
				after = { ...(before ?? defaultMember()) };
			for (const name of ["incoming", "dispatch", "readAllWork"])
				if (row[name] !== undefined) after[name] = row[name];
			if (hash(before) !== hash(after) || buddy.fresh)
				effects.push({
					resource: "membership",
					id: buddy.id,
					before: buddy.fresh ? null : before,
					after,
				});
			members.set(buddy.id, after);
		});
		// New identities always receive their home membership, even without an explicit patch.
		for (const buddy of buddies.filter(
			(b) => b.fresh && !seenMembers.has(b.id),
		))
			effects.push({
				resource: "membership",
				id: buddy.id,
				before: null,
				after: members.get(buddy.id),
			});
		const requiredMember = (buddy, path) => {
			requireActive(buddy, path);
			if (buddy && !members.get(buddy.id))
				add(
					"workspace_membership_required",
					path,
					`${buddy.name} is not admitted to this workspace.`,
					"Include an explicit membership in this workspace.",
				);
		};
		const originalEdges = this.db
			.prepare(
				"SELECT from_buddy_id,to_buddy_id,kind FROM buddy_relationships WHERE kind IN ('manager','consults') ORDER BY kind,from_buddy_id,to_buddy_id",
			)
			.all();
		snapshot.relationships = originalEdges;
		let proposed = originalEdges.map((e) => ({
			fromBuddyId: e.from_buddy_id,
			toBuddyId: e.to_buddy_id,
			kind: e.kind,
		}));
		const seenEdges = new Set(),
			managers = new Map();
		(config.relationships ?? []).forEach((row, i) => {
			const from = resolved.get(token(row.from)),
				to = resolved.get(token(row.to));
			if (!from || !to) return;
			const path = `relationships.${i}`,
				edgeKey = `${row.kind}:${from.id}:${to.id}`;
			requiredMember(from, `${path}.from`);
			requiredMember(to, `${path}.to`);
			if (from.id === to.id)
				add(
					"self_relationship",
					path,
					"An identity cannot relate to itself.",
					"Select distinct participants.",
				);
			if (seenEdges.has(edgeKey))
				add(
					"duplicate_relationship",
					path,
					"Duplicate relationship setting.",
					"Use one setting per edge.",
				);
			seenEdges.add(edgeKey);
			if (row.kind === "manager" && row.present) {
				if (managers.has(to.id))
					add(
						"multiple_managers",
						path,
						"Multiple managers requested for the same report.",
						"Choose one manager.",
					);
				managers.set(to.id, from.id);
				const targetWorkspaces = to.fresh
					? [workspaceId]
					: this.listBuddyWorkspaces(to.id).map((w) => w.id);
				for (const workspace of targetWorkspaces)
					if (
						workspace !== workspaceId &&
						(from.fresh || !this.getCoordinationMembership(from.id, workspace))
					)
						add(
							"manager_workspace_required",
							path,
							`The manager must already belong to report workspace ${workspace}.`,
							"Explicitly admit the manager in that workspace in a separately scoped command.",
						);
			}
			// Evaluate the complete proposed graph rather than transient order.
			proposed = proposed.filter(
				(e) =>
					!(
						e.kind === row.kind &&
						e.fromBuddyId === from.id &&
						e.toBuddyId === to.id
					) &&
					!(
						row.kind === "manager" &&
						row.present &&
						e.kind === "manager" &&
						e.toBuddyId === to.id
					),
			);
			if (row.present)
				proposed.push({
					fromBuddyId: from.id,
					toBuddyId: to.id,
					kind: row.kind,
				});
		});
		const parent = new Map(
			proposed
				.filter((e) => e.kind === "manager")
				.map((e) => [e.toBuddyId, e.fromBuddyId]),
		);
		for (const start of parent.keys()) {
			let cursor = start;
			const seen = new Set();
			while (parent.has(cursor)) {
				if (seen.has(cursor)) {
					add(
						"management_cycle",
						"relationships",
						"The proposed complete reporting graph contains a cycle.",
						"Remove or change the conflicting appointment.",
					);
					break;
				}
				seen.add(cursor);
				cursor = parent.get(cursor);
			}
			if (blockers.some((b) => b.code === "management_cycle")) break;
		}
		const edgeId = (e) => `${e.kind}:${e.fromBuddyId}:${e.toBuddyId}`;
		const oldMap = new Map(
				originalEdges.map((e) => {
					const n = {
						fromBuddyId: e.from_buddy_id,
						toBuddyId: e.to_buddy_id,
						kind: e.kind,
					};
					return [edgeId(n), n];
				}),
			),
			newMap = new Map(proposed.map((e) => [edgeId(e), e]));
		for (const id of new Set([...oldMap.keys(), ...newMap.keys()]))
			if (oldMap.has(id) !== newMap.has(id)) {
				const edge = oldMap.get(id) ?? newMap.get(id),
					target = buddies.find((b) => b.id === edge.toBuddyId);
				const value = {
					...edge,
					present: true,
					affectedWorkspaceIds: target?.fresh
						? [workspaceId]
						: this.listBuddyWorkspaces(edge.toBuddyId)
								.map((w) => w.id)
								.sort(),
				};
				effects.push({
					resource: "relationship",
					id,
					before: oldMap.has(id) ? value : null,
					after: newMap.has(id) ? value : null,
				});
			}
		const compileGrant = (grantee, target, row, path, staff = false) => {
			if (!grantee || !target) return;
			const targetId = staff ? workspaceId : target.id,
				id = `${grantee.id}:${targetId}`;
			if (grants.has(id)) {
				add(
					"duplicate_grant",
					path,
					"Duplicate grant configuration.",
					"Combine permission settings into one entry.",
				);
				return;
			}
			const current =
				grantee.fresh || (!staff && target.fresh)
					? null
					: this.getBuddyAccess(grantee.id, workspaceId, targetId);
			snapshot.grants.push({ id, current });
			if (row.baseRevision !== undefined && row.baseRevision !== (current?.revision ?? 0))
				add(
					"grant_revision_conflict",
					`${path}.baseRevision`,
					`Saved permissions changed since this editor was loaded (current revision ${current?.revision ?? 0}).`,
					"Reload the saved permissions and review your changes again.",
				);
			const caps = new Set(current?.capabilities ?? []),
				set = (cap, enabled) => (enabled ? caps.add(cap) : caps.delete(cap));
			if (staff) {
				set("staff.create", row.enabled);
				if (!row.enabled && row.createdBuddyIncoming === true)
					add(
						"staffing_dependency",
						path,
						"Future-hire incoming work requires staff creation.",
						"Enable staffing or remove createdBuddyIncoming.",
					);
			} else {
				for (const [name, cap] of [
					["relationships", "relationship.write"],
					["incoming", "execution.manage"],
					["schedules", "schedule.manage"],
				])
					if (row[name] !== undefined) set(cap, row[name]);
				for (const name of ["profile", "soul", "memory"])
					if (row[name] !== undefined) {
						set(`${name}.read`, row[name] === "read" || row[name] === "write");
						set(`${name}.write`, row[name] === "write" || row[name] === "write_only");
					}
				// Preserve the original shorthand, but explicit read revocations must
				// remain exact. The operation boundary enforces its read prerequisite.
				if (row.incoming === true && row.profile === undefined)
					caps.add("profile.read");
			}
			// Owners must be able to remove saved authority after lifecycle or
			// membership changes. A retained capability still needs active members.
			if (!current || caps.size > 0 || row.createdBuddyIncoming === true) {
				requiredMember(grantee, `${path}.grantee`);
				if (!staff) requiredMember(target, `${path}.target`);
			}
			const targetWorkspaces = staff
				? [workspaceId]
				: target.fresh
					? [workspaceId]
					: this.listBuddyWorkspaces(target.id)
							.map((w) => w.id)
							.sort();
			const before = grantView(current, targetWorkspaces),
				after = {
					granteeId: grantee.id,
					targetId,
					capabilities: [...caps].sort(),
					revision: current?.revision ?? 0,
					expiresAt:
						row.expiresAt === undefined
							? (current?.expires_at ?? null)
							: row.expiresAt === null
								? null
								: new Date(row.expiresAt).toISOString(),
					reason: config.reason,
					createdBuddyIncoming:
						staff && row.enabled
							? (row.createdBuddyIncoming ?? !!current?.created_buddy_incoming)
							: false,
					affectedWorkspaceIds: targetWorkspaces,
				};
			// A fully revoked grant has no active lifetime to preserve.
			if (!after.capabilities.length) after.expiresAt = null;
			if (
				after.capabilities.length &&
				after.expiresAt &&
				after.expiresAt <= now()
			)
				add(
					"grant_expired",
					path,
					"Existing grant has expired; setup preserves its expiration.",
					"Explicitly set expiresAt to a future date, or null for no expiration, under the owner instruction.",
				);
			// Intent changes permission state, not reason/revision-only churn.
			const changed = !current
				? after.capabilities.length > 0
				: hash([
						before.capabilities,
						before.createdBuddyIncoming,
						before.expiresAt,
					]) !==
					hash([
						after.capabilities,
						after.createdBuddyIncoming,
						after.expiresAt,
					]);
			if (changed) {
				after.revision++;
				effects.push({ resource: "grant", id, before, after });
			}
			grants.set(id, after);
		};
		(config.access ?? []).forEach((row, i) =>
			compileGrant(
				resolved.get(token(row.grantee)),
				resolved.get(token(row.target)),
				row,
				`access.${i}`,
			),
		);
		(config.staffing ?? []).forEach((row, i) => {
			const grantee = resolved.get(token(row.grantee));
			compileGrant(grantee, grantee, row, `staffing.${i}`, true);
		});
		const activating = new Set(
			effects
				.filter(
					(e) =>
						e.resource === "membership" &&
						e.after?.incoming &&
						!e.before?.incoming,
				)
				.map((e) => e.id),
		);
		const queuedRuns = this.db
			.prepare(
				"SELECT id,input_kind,input_id,buddy_id FROM buddy_runs WHERE workspace_id=? AND status='queued' ORDER BY id",
			)
			.all(workspaceId)
			.filter((r) => activating.has(r.buddy_id))
			.map((r) => ({
				runId: r.id,
				inputKind: r.input_kind,
				inputId: r.input_id,
				buddyId: r.buddy_id,
				state: "queued",
			}));
		snapshot.queue = queuedRuns;
		// Include any former manager's retained grants in the preview without silently
		// revoking unrelated authority. No-op effects intentionally display retained access.
		for (const edge of effects.filter(
			(e) =>
				e.resource === "relationship" &&
				e.before?.kind === "manager" &&
				!e.after,
		)) {
			const { fromBuddyId, toBuddyId } = edge.before,
				id = `${fromBuddyId}:${toBuddyId}`;
			if (!grants.has(id)) {
				const current = this.getBuddyAccess(
					fromBuddyId,
					workspaceId,
					toBuddyId,
				);
				snapshot.grants.push({ id, current });
				if (current?.capabilities.length) {
					const view = grantView(current, edge.before.affectedWorkspaceIds);
					effects.push({ resource: "grant", id, before: view, after: view });
				}
			}
		}
		const resolvedBuddies = [...resolved.entries()]
			.filter(([, buddy]) => buddy)
			.map(([key, buddy]) => ({
				ref: refs.get(key),
				id: buddy.fresh ? null : buddy.id,
				name: buddy.name,
			}));
		const readiness = this.teamConfigurationReadiness({
			workspaceId,
			buddyIds: buddies.filter((b) => !b.fresh).map((b) => b.id),
		});
		const affectedWork = readiness.messages
			.filter((m) => activating.has(m.recipientId))
			.map(({ returnBuddyId, returnIncoming, ...m }) => m);
		return {
			workspaceId,
			contractVersion: this.getTeamContractVersion(),
			key,
			planHash: hash({
				configuration: config,
				contractVersion: this.getTeamContractVersion(),
				snapshot,
			}),
			canApply: !blockers.length,
			blockers,
			effects,
			resolvedBuddies,
			affectedWork,
			queuedRuns,
			receipt: null,
			readiness,
			drift: false,
		};
	},

	teamConfigurationReadiness({ workspaceId, buddyIds }) {
		const ids = [...new Set(buddyIds)],
			blockers = [];
		const participants = ids.map((buddyId) => {
			const buddy = this.getBuddy(buddyId),
				member = this.getCoordinationMembership(buddyId, workspaceId);
			return {
				buddyId,
				name: buddy?.name ?? buddyId,
				incoming: !!member?.background_enabled,
				dispatch: !!member?.dispatch,
				readAllWork: !!member?.read_all_work,
				active: buddy?.status === "active",
			};
		});
		for (const p of participants) {
			if (!p.active)
				blockers.push(
					fail(
						"inactive_buddy",
						p.buddyId,
						`${p.name} is not active.`,
						"Inspect identity lifecycle.",
					),
				);
			if (!p.incoming)
				blockers.push(
					fail(
						"background_disabled",
						p.buddyId,
						`${p.name} cannot receive incoming work or result turns.`,
						"Enable incoming work for the requested participants.",
					),
				);
			const member = this.getCoordinationMembership(p.buddyId, workspaceId);
			if (member?.background_paused_reason)
				blockers.push(
					fail(
						"background_paused",
						p.buddyId,
						member.background_paused_reason,
						"Inspect and clear the runtime pause with existing execution controls.",
					),
				);
		}
		const rows = this.db
			.prepare(
				"SELECT id,from_buddy_id,to_buddy_id,source_workspace_id,workspace_id,parent_conversation_id,expects_reply FROM buddy_messages WHERE workspace_id=? ORDER BY id",
			)
			.all(workspaceId)
			.filter(
				(m) => ids.includes(m.to_buddy_id) || ids.includes(m.from_buddy_id),
			);
		const messages = rows.map((message) => {
			const execution = this.getMessageExecution(message.id),
				returnBuddyId = message.expects_reply ? message.from_buddy_id : null;
			if (
				execution.runId &&
				this.getBuddyRun(execution.runId)?.status === "queued"
			)
				blockers.push(
					...this.inspectBuddyAdmission({
						buddyId: message.to_buddy_id,
						workspaceId: message.workspace_id,
						runId: execution.runId,
					}).blockers,
				);
			if (["failed", "cancelled"].includes(execution.state))
				blockers.push(
					fail(
						`run_${execution.state}`,
						message.id,
						execution.error ?? `The existing attempt ${execution.state}.`,
						"Inspect the original result and explicitly decide whether to retry.",
						"lead",
					),
				);
			const returnMember = returnBuddyId
				? this.getCoordinationMembership(
						returnBuddyId,
						message.source_workspace_id ?? message.workspace_id,
					)
				: null;
			if (returnBuddyId && !returnMember?.background_enabled)
				blockers.push(
					fail(
						"return_background_disabled",
						message.id,
						"The returning lead cannot receive the result turn.",
						"Enable incoming work in the lead source workspace.",
					),
				);
			if (returnBuddyId && !message.parent_conversation_id)
				blockers.push(
					fail(
						"return_conversation_missing",
						message.id,
						"The message has no source conversation for a result turn.",
						"Inspect the original route; setup does not invent a return conversation.",
						"lead",
					),
				);
			if (
				execution.code &&
				!["background_disabled", "awaiting_admission"].includes(execution.code)
			)
				blockers.push(
					fail(
						execution.code,
						message.id,
						execution.reason ?? execution.code,
						execution.remedy ?? "Inspect the existing execution receipt.",
						"runtime",
					),
				);
			return {
				messageId: message.id,
				runId: execution.runId,
				recipientId: message.to_buddy_id ?? "owner",
				state: execution.state,
				code: execution.code,
				returnBuddyId,
				returnIncoming: returnBuddyId
					? !!returnMember?.background_enabled
					: null,
				projectId: execution.projectId,
				acknowledgedAt: execution.acknowledgedAt,
				acceptedAt: execution.acceptedAt,
				completionEvidence: execution.completionEvidence,
			};
		});
		return { ready: !blockers.length, blockers, participants, messages };
	},

	// Host only: the app must verify its ephemeral owner capability and workspace
	// scope immediately before invoking this synchronous atomic commit.
	applyTeamConfiguration(
		{ key, configuration, expectedPlanHash },
		{ ownerInputId, conversationId },
	) {
		string(key, "key");
		string(ownerInputId, "originating owner input");
		if (conversationId !== null) string(conversationId, "owner conversation");
		const config = validateTeamConfiguration(configuration),
			workspaceId = config.workspaceId;
		let replayed = true;
		let stored;
		try {
			stored = this.coordinationCommand(
				{
					actor: OWNER,
					workspaceId,
					key,
					payload: { operation: "configure_team", configuration: config },
				},
				() => {
					replayed = false;
					const plan = this.prepareTeamConfiguration({
						key,
						configuration: config,
					});
					if (!plan.canApply)
						throw Object.assign(new Error("Team configuration rejected"), {
							teamConfigurationResult: plan,
						});
					if (expectedPlanHash !== plan.planHash)
						throw Object.assign(new Error("Stale team configuration"), {
							teamConfigurationResult: {
								...plan,
								canApply: false,
								blockers: [
									...plan.blockers,
									fail(
										"stale_plan",
										"expectedPlanHash",
										"Configuration or the affected queue changed after preparation.",
										"Prepare again and assess all changed effects before applying.",
									),
								],
							},
						});
					const ids = new Map(
						plan.resolvedBuddies
							.filter((b) => b.id)
							.map((b) => [token(b.ref), b.id]),
					);
					for (const input of config.create ?? []) {
						const ref = token({ creationKey: input.creationKey });
						if (ids.has(ref)) continue;
						const slug = `${
							input.name
								.toLowerCase()
								.replace(/[^a-z0-9]+/g, "-")
								.replace(/^-|-$/g, "")
								.slice(0, 48) || "buddy"
						}-${hash([creationScope(workspaceId), input.creationKey]).slice(0, 12)}`;
						const result = this.createBuddyFromBuilder({
							...creationInput(input),
							slug,
							conversationId: creationScope(workspaceId),
							creationKey: input.creationKey,
							requestFingerprint: hash(creationInput(input)),
							project: workspaceId,
							deferProjection: true,
						});
						ids.set(ref, result.buddy.id);
					}
					const resolveId = (id) => ids.get(id) ?? id;
					for (const effect of plan.effects.filter(
						(e) => e.resource === "membership",
					)) {
						const id = resolveId(effect.id);
						if (!this.getCoordinationMembership(id, workspaceId))
							this.assignBuddyToWorkspace({
								buddy: id,
								workspace: workspaceId,
								role: this.getBuddy(id).role,
							});
						const current = memberView(
							this.getCoordinationMembership(id, workspaceId),
						);
						const patch = {};
						for (const [field, column] of [
							["incoming", "background_enabled"],
							["dispatch", "dispatch"],
							["readAllWork", "read_all_work"],
						])
							if (current[field] !== effect.after[field])
								patch[column] = effect.after[field];
						if (Object.keys(patch).length)
							this.setCoordinationMembership(id, workspaceId, patch);
					}
					// Remove the old graph first, then apply the validated final graph; swaps
					// must not trip on a cycle that exists only in an intermediate tree.
					for (const effect of plan.effects.filter(
						(e) => e.resource === "relationship" && e.before && !e.after,
					))
						this.db
							.prepare(
								"DELETE FROM buddy_relationships WHERE from_buddy_id=? AND to_buddy_id=? AND kind=?",
							)
							.run(
								resolveId(effect.before.fromBuddyId),
								resolveId(effect.before.toBuddyId),
								effect.before.kind,
							);
					for (const effect of plan.effects.filter(
						(e) => e.resource === "relationship" && e.after,
					))
						this.setBuddyRelationship({
							fromBuddy: resolveId(effect.after.fromBuddyId),
							toBuddy: resolveId(effect.after.toBuddyId),
							kind: effect.after.kind,
						});
					for (const effect of plan.effects.filter(
						(e) => e.resource === "grant" && hash(e.before) !== hash(e.after),
					)) {
						const after = effect.after;
						this.setBuddyAccess({
							granteeId: resolveId(after.granteeId),
							workspaceId,
							targetBuddyId:
								after.targetId === workspaceId
									? undefined
									: resolveId(after.targetId),
							capabilities: after.capabilities,
							...(after.targetId === workspaceId
								? { createdBuddyIncoming: after.createdBuddyIncoming }
								: {}),
							baseRevision: effect.before?.revision ?? 0,
							key: `team:${hash([key, effect.id])}`,
							reason: config.reason,
							...(after.expiresAt ? { expiresAt: after.expiresAt } : {}),
						});
					}
					const resolvedBuddies = plan.resolvedBuddies.map((b) => ({
						...b,
						id: resolveId(token(b.ref)),
					}));
					const auditBuddy = resolvedBuddies[0]?.id;
					if (!auditBuddy)
						throw new Error("Team configuration needs at least one identity");
					const audit = this.recordAuditEvent({
						buddy: auditBuddy,
						workspace: workspaceId,
						operation: "owner.configure_team",
						payload: {
							key,
							ownerInputId,
							conversationId,
							configuration: config,
							planHash: plan.planHash,
							effects: plan.effects,
							resolvedBuddies,
						},
					});
					return {
						configuration: config,
						configurationState: configurationState(this, config),
						result: {
							...plan,
							resolvedBuddies,
							receipt: {
								auditId: audit.id,
								appliedAt: audit.created_at,
								replayed: false,
							},
						},
					};
				},
			);
		} catch (error) {
			if (error.teamConfigurationResult) return error.teamConfigurationResult;
			throw error;
		}
		// Soul files are projections of the committed document ledger. Materialize
		// after the configuration commit; replay repairs missing views, never edits.
		const projectionBlockers = [];
		for (const input of config.create ?? []) {
			try {
				this.createBuddyFromBuilder({
					...creationInput(input),
					conversationId: creationScope(workspaceId),
					creationKey: input.creationKey,
					requestFingerprint: hash(creationInput(input)),
					project: workspaceId,
				});
			} catch (error) {
				projectionBlockers.push(
					fail(
						"profile_projection_failed",
						`create.${input.creationKey}`,
						error.message,
						"Retry the same setup key to repair the committed profile projection.",
						"runtime",
					),
				);
			}
		}
		return this.refreshTeamConfigurationResult(
			stored.result,
			replayed,
			projectionBlockers,
		);
	},

	refreshTeamConfigurationResult(result, replayed = false, extraBlockers = []) {
		const workspaceId = result.workspaceId;
		const ids = result.resolvedBuddies.map((b) => b.id).filter(Boolean);
		const readiness = this.teamConfigurationReadiness({
			workspaceId,
			buddyIds: ids,
		});
		readiness.blockers.push(...extraBlockers);
		for (const entry of result.resolvedBuddies.filter(
			(b) => b.ref.creationKey,
		)) {
			const buddy = this.getBuddy(entry.id);
			if (buddy?.soul_path && !existsSync(buddy.soul_path))
				readiness.blockers.push(
					fail(
						"profile_projection_missing",
						entry.id,
						"The committed initial profile file has not been materialized.",
						"Replay the original setup to recover its file projection.",
						"runtime",
					),
				);
		}
		readiness.ready = !readiness.blockers.length;
		const row = this.db
			.prepare(
				"SELECT result FROM buddy_command_receipts WHERE actor=? AND workspace_id=? AND command_key=?",
			)
			.get(OWNER, workspaceId, result.key);
		const stored = row ? JSON.parse(row.result) : null;
		const drift = stored?.configurationState
			? hash(stored.configurationState) !==
				hash(configurationState(this, stored.configuration))
			: false;
		return {
			...result,
			receipt: { ...result.receipt, replayed },
			readiness,
			drift,
		};
	},

	getTeamConfiguration({ workspaceId, key }) {
		string(workspaceId, "workspaceId");
		string(key, "key");
		const row = this.db
			.prepare(
				"SELECT result FROM buddy_command_receipts WHERE actor=? AND workspace_id=? AND command_key=?",
			)
			.get(OWNER, workspaceId, key);
		if (!row) return null;
		const stored = JSON.parse(row.result);
		if (stored.rejected) return null;
		return this.refreshTeamConfigurationResult(stored.result, true);
	},
};
