import { createHash } from 'node:crypto';
const digest = value => createHash('sha256').update(JSON.stringify(value)).digest('hex');

export function migrateMailbox(db) {
  db.exec(`CREATE TABLE IF NOT EXISTS buddy_mail_effects (
    id TEXT PRIMARY KEY, workspace_id TEXT NOT NULL REFERENCES projects(id), actor_id TEXT NOT NULL REFERENCES buddies(id),
    account_id TEXT NOT NULL, fingerprint TEXT NOT NULL, payload TEXT NOT NULL, status TEXT NOT NULL,
    authorized INTEGER NOT NULL DEFAULT 0, provider_receipt TEXT, updated_at TEXT NOT NULL
  ) STRICT;
  CREATE TABLE IF NOT EXISTS buddy_mail_inbound (
    account_id TEXT NOT NULL, event_id TEXT NOT NULL, workspace_id TEXT NOT NULL REFERENCES projects(id),
    payload TEXT NOT NULL, received_at TEXT NOT NULL, PRIMARY KEY(account_id,event_id)
  ) STRICT;`);
}
function visible(store, row, {actor,workspaceId}) {
  if (!row || row.workspace_id !== workspaceId || (actor !== 'owner' && actor !== row.actor_id) || !store.getCoordinationMembership(row.actor_id,workspaceId))
    throw new Error('Mail effect is unavailable in this scope');
  return {...row,payload:JSON.parse(row.payload),provider_receipt:row.provider_receipt ? JSON.parse(row.provider_receipt):null};
}
export const mailboxMethods = {
  prepareMailEffect(input, {actor,workspaceId,key}) {
    if (actor === 'owner' || !this.getCoordinationMembership(actor,workspaceId)) throw new Error('A draft requires an in-scope employee');
    if (!input.accountId || !Array.isArray(input.to) || !input.to.length || input.to.length > 20 || input.to.some(x=>typeof x!=='string' || !/^[^\s@]+@[^\s@]+$/.test(x)) || !input.subject?.trim() || !input.text?.trim() || JSON.stringify(input).length > 64000 || !input.demo?.projectId || !Number.isInteger(input.demo.revision)) throw new Error('Mail requires an account, bounded exact draft, and pinned accepted demo');
    const id=`mail_${digest([actor,workspaceId,key])}`;
    const fingerprint=digest(input);
    const old=this.db.prepare('SELECT * FROM buddy_mail_effects WHERE id=?').get(id);
    if (old && old.fingerprint!==fingerprint) throw new Error('Effect key conflicts with a different draft');
    if (!old) this.db.prepare('INSERT INTO buddy_mail_effects VALUES (?,?,?,?,?,?,?,0,NULL,?)').run(id,workspaceId,actor,input.accountId,fingerprint,JSON.stringify(input),'prepared',new Date().toISOString());
    return this.getMailEffect(id,{actor,workspaceId});
  },
  getMailEffect(id,authority) { return visible(this,this.db.prepare('SELECT * FROM buddy_mail_effects WHERE id=?').get(id),authority); },
  authorizeMailEffect({id,fingerprint,authorized,reason},authority) {
    if (authority.actor!=='owner' || !authority.ownerInputId || !reason?.trim() || typeof authorized!=='boolean') throw new Error('Current explicit owner send authority is required');
    const effect=this.getMailEffect(id,authority);
    if (effect.fingerprint!==fingerprint) throw new Error('Approval does not match this exact draft');
    this.db.prepare('UPDATE buddy_mail_effects SET authorized=?,updated_at=? WHERE id=?').run(Number(authorized),new Date().toISOString(),id);
    this.recordAuditEvent({buddy:effect.actor_id,workspace:effect.workspace_id,operation:'owner.mail.authorize',payload:{id,fingerprint,authorized,reason,ownerInputId:authority.ownerInputId}});
    return this.getMailEffect(id,authority);
  },
  claimMailEffect(id,authority) {
    return this.coordinationTransaction(()=>{
      const effect=this.getMailEffect(id,authority);
      if (effect.status!=='prepared') return {claimed:false,effect};
      if (!effect.authorized) throw new Error('This exact draft has no current owner send authorization');
      const demo=this.getBuddyProject(effect.payload.demo.projectId);
      const evidence=demo ? JSON.parse(demo.completion_evidence) : []; 
      if (!demo || demo.workspace_id!==effect.workspace_id || demo.revision!==effect.payload.demo.revision || demo.status!=='done' || !Array.isArray(evidence) || !evidence.length || digest({criteria:demo.definition_of_done,evidence})!==effect.payload.demo.evidenceHash) throw new Error('Pinned demo acceptance changed or is incomplete');
      this.db.prepare("UPDATE buddy_mail_effects SET status='unknown',updated_at=? WHERE id=?").run(new Date().toISOString(),id);
      return {claimed:true,effect:this.getMailEffect(id,authority)};
    });
  },
  settleMailEffect(id,receipt,authority) {
    const effect=this.getMailEffect(id,authority);
    if (effect.status!=='unknown') return effect;
    if (!receipt || !['sent','not_sent','unknown'].includes(receipt.status)) throw new Error('Invalid provider reconciliation');
    if (receipt.status==='sent' && !receipt.providerId) throw new Error('A sent effect requires a provider receipt');
    // Definitive not_sent is terminal. A new logical send needs a new draft/key
    // and renewed owner authority. Unknown is never silently retried.
    this.db.prepare('UPDATE buddy_mail_effects SET status=?,provider_receipt=?,updated_at=? WHERE id=?').run(receipt.status,JSON.stringify(receipt),new Date().toISOString(),id);
    return this.getMailEffect(id,authority);
  },
  recordInboundMail({accountId,eventId,payload},authority) {
    if (!authority.workspaceId || !accountId || !eventId || JSON.stringify(payload).length>256000) throw new Error('Invalid account event');
    const old=this.db.prepare('SELECT * FROM buddy_mail_inbound WHERE account_id=? AND event_id=?').get(accountId,eventId);
    if (old && old.workspace_id!==authority.workspaceId) throw new Error('Account event is outside workspace');
    if (!old) this.db.prepare('INSERT INTO buddy_mail_inbound VALUES (?,?,?,?,?)').run(accountId,eventId,authority.workspaceId,JSON.stringify(payload),new Date().toISOString());
    return {accountId,eventId,duplicate:!!old};
  },
};
