const now = () => new Date().toISOString();
const active = new Set(["claimed", "running", "cancel_requested"]);
const evidence = (value) =>
	Array.isArray(value) ? value : JSON.parse(value || "[]");

export function migrateBackgroundWork(db) {
	if (db.prepare("PRAGMA user_version").get().user_version >= 24) return;
	db.exec("SAVEPOINT background_work");
	try {
		if (
			!db
				.prepare("PRAGMA table_info(buddy_todos)")
				.all()
				.some((c) => c.name === "completion_evidence")
		)
			db.exec(
				"ALTER TABLE buddy_todos ADD COLUMN completion_evidence TEXT NOT NULL DEFAULT '[]'",
			);
		db.exec("PRAGMA user_version=24; RELEASE background_work");
	} catch (error) {
		db.exec("ROLLBACK TO background_work; RELEASE background_work");
		throw error;
	}
}

export function normalizeBackgroundExecution(input) {
	if (input === undefined) return undefined;
	if (
		!input ||
		input.mode !== "until_done" ||
		Object.keys(input).some(
			(k) => !["mode", "maxRuns", "maxDurationSeconds"].includes(k),
		)
	)
		throw new Error("Invalid background execution configuration");
	const { maxRuns = 20, maxDurationSeconds = 3600 } = input;
	if (
		!Number.isInteger(maxRuns) ||
		maxRuns < 1 ||
		maxRuns > 100 ||
		!Number.isInteger(maxDurationSeconds) ||
		maxDurationSeconds < 1 ||
		maxDurationSeconds > 86400
	)
		throw new Error("Background execution limits are out of bounds");
	return { mode: "until_done", maxRuns, maxDurationSeconds };
}

export const backgroundWorkMethods = {
	getBackgroundWork(messageId) {
		const rows = this.db
			.prepare(
				"SELECT id FROM buddy_runs WHERE input_kind='message_request' AND input_id=? AND json_extract(policy,'$.interruption_report_of_run_id') IS NULL ORDER BY rowid",
			)
			.all(messageId);
		const runs = rows.map((r) => this.getBuddyRun(r.id));
		const execution = runs[0]?.policy.execution;
		if (execution?.mode !== "until_done") return null;
		const message = this.getMessage(messageId);
		const project = this.getBuddyProject(message.buddy_project_id);
		const admitted = runs.filter((r) => r.started_at);
		const budgetOrigin = runs[0]?.policy.recovery_origin_message_id ?? messageId;
    const budgetAdmitted = this.db.prepare(`SELECT started_at FROM buddy_runs
      WHERE input_kind='message_request' AND started_at IS NOT NULL
      AND json_extract(policy,'$.interruption_report_of_run_id') IS NULL
      AND (input_id=? OR json_extract(policy,'$.recovery_origin_message_id')=?)`).all(budgetOrigin,budgetOrigin);
    const startedAt = budgetAdmitted.map((r) => r.started_at).sort()[0] ?? null;
		const deadline = startedAt
			? new Date(
					Date.parse(startedAt) + execution.maxDurationSeconds * 1000,
				).toISOString()
			: null;
		const children = this.db
			.prepare(`SELECT m.id FROM buddy_messages m JOIN buddy_runs r ON m.caused_by_run_id=r.id
      WHERE r.input_kind='message_request' AND r.input_id=? AND m.expects_reply=1 AND m.id<>?`)
			.all(messageId, messageId)
			.map((m) => this.getMessage(m.id));
		const waiting = children.filter(
			(m) =>
				["pending", "active"].includes(m.status) &&
				!this.db
					.prepare(
						"SELECT 1 FROM buddy_runs WHERE input_id=? AND input_kind='message_request' AND status IN ('failed','cancelled') AND NOT EXISTS (SELECT 1 FROM buddy_runs n WHERE n.input_id=? AND n.status IN ('queued','claimed','running','cancel_requested'))",
					)
					.get(m.id, m.id),
		);
		const latest = runs.at(-1);
		const unreadChildResult = children.some(
			(m) =>
				m.caused_by_run_id === admitted.at(-1)?.id &&
				!waiting.some((w) => w.id === m.id),
		);
		const unfinishedTodos =
			project?.todos.filter((t) => !["done", "cancelled"].includes(t.status)) ??
			[];
		const complete =
			waiting.length === 0 &&
			!!project &&
			project.status === "done" &&
			evidence(project.completion_evidence).length > 0 &&
			project.todos.every(
				(t) =>
					t.status === "cancelled" ||
					(t.status === "done" &&
						!!t.definition_of_done?.trim() &&
						evidence(t.completion_evidence).length > 0),
			);
		let disposition = "continuing";
		let reason = null;
		if (message.status === "replied") disposition = message.outcome;
		else if (
			message.status === "cancelled" ||
			this.getMessage(message.root_message_id)?.root_stopped_at
		)
			disposition = "cancelled";
		else if (runs.some((r) => active.has(r.status))) disposition = "running";
		else if (latest?.status === "failed" || latest?.status === "cancelled") {
			disposition = latest.status === "failed" && latest.error_code === "max_runtime_timeout" &&
        budgetAdmitted.length < execution.maxRuns && (!deadline || deadline > now()) ? "recoverable" : latest.status;
			reason =
				latest.error ||
				`Last attempt ${latest.status}; inspect effects before retrying.`;
		} else if (complete) disposition = "done";
		else if (!project || project.buddy_id !== message.to_buddy_id) {
			disposition = "blocked";
			reason = "Project ownership no longer matches the assigned recipient.";
		} else if (
			project.status === "cancelled" ||
			project.execution_state === "cancelled"
		)
			disposition = "cancelled";
		else if (project.status === "blocked") {
			disposition = "blocked";
			reason = project.blocked_reason || "Project is blocked.";
		} else if (
			!waiting.length &&
			!unreadChildResult &&
			unfinishedTodos.length &&
			unfinishedTodos.every((t) => t.status === "blocked")
		) {
			disposition = "blocked";
			reason = unfinishedTodos
				.map((t) => `${t.title}: ${t.blocked_reason}`)
				.join("; ");
		} else if (deadline && deadline <= now()) {
			disposition = "limit_reached";
			reason = "Background work duration limit reached.";
		} else if (
			project.execution_state !== "enabled" ||
			this.projectAncestors(project.id).some(
				(p) => p.execution_state !== "enabled",
			)
		) {
			disposition = "held";
			reason = "Project execution is paused or transferring ownership.";
		} else if (budgetAdmitted.length >= execution.maxRuns) {
			disposition = "limit_reached";
			reason = "Background work run limit reached.";
		} else if (waiting.length) {
			disposition = "waiting";
			reason = "Waiting for replies to delegated work.";
		} else if (runs.some((r) => r.status === "queued")) disposition = "queued";
		else if (latest?.error_code === "continuation_held") {
			disposition = "held";
			reason = latest.error;
		}
		return {
			message,
			project,
			runs,
			latest,
			complete,
			reason,
			execution,
			disposition,
			startedAt,
			deadline,
			runsUsed: budgetAdmitted.length,
			waitingMessageIds: waiting.map((m) => m.id),
		};
	},

	getProjectBackgroundExecution(projectId) {
		const row = this.db
			.prepare(`SELECT m.id FROM buddy_messages m JOIN buddy_runs r ON r.input_id=m.id
      WHERE m.buddy_project_id=? AND r.input_kind='message_request' AND json_extract(r.policy,'$.execution.mode')='until_done'
      ORDER BY m.rowid DESC LIMIT 1`)
			.get(projectId);
		if (!row) return null;
		const state = this.getBackgroundWork(row.id);
		return { message: state.message, runs: state.runs };
	},

	backgroundParentMessage(message) {
		if (!message.caused_by_run_id) return null;
		const run = this.getBuddyRun(message.caused_by_run_id);
		if (
			run?.input_kind !== "message_request" ||
			run.policy.execution?.mode !== "until_done"
		)
			return null;
		const parent = this.getMessage(run.input_id);
		return parent && ["pending", "active"].includes(parent.status)
			? parent.id
			: null;
	},

	assertBackgroundReply(message, outcome) {
		const state = this.getBackgroundWork(message.id);
		if (!state) return;
		// Provider completion claims are checked against canonical work, never against prose.
		if (state.complete) return;
		if (state.project?.status === "blocked" && outcome === "blocked") return;
		if (
			["failed", "cancelled", "limit_reached", "blocked"].includes(
				state.disposition,
			) &&
			outcome === state.disposition
		)
			return;
		throw new Error(
			"Background request is unfinished; update the project and task evidence, or send an informational progress message.",
		);
	},

	reconcileBackgroundWork(messageId) {
		this.reconcileInterruptionReports();
		const ids = messageId
			? [messageId]
			: this.db
					.prepare(`SELECT DISTINCT m.id FROM buddy_messages m JOIN buddy_runs r ON r.input_id=m.id
      WHERE (m.status IN ('pending','active') OR (m.status='replied' AND r.error_code='return_held')) AND r.input_kind='message_request' AND json_extract(r.policy,'$.execution.mode')='until_done'`)
					.all()
					.map((m) => m.id);
		return ids
			.map((id) =>
				this.coordinationTransaction(() => {
					const state = this.getBackgroundWork(id);
					if (!state) return null;
					const { message, project, latest, disposition } = state;
					if (
						message.status === "replied" &&
						latest?.error_code === "return_held"
					) {
						this.deliverBackgroundReply(message);
						return this.getMessageExecution(id);
					}
					if (
						!["pending", "active"].includes(message.status) ||
						state.runs.some((r) => active.has(r.status))
					)
						return this.getMessageExecution(id);
					if (this.getMessage(message.root_message_id)?.root_stopped_at)
						return this.getMessageExecution(id);
					if (
						[
							"done",
							"blocked",
							"failed",
							"cancelled",
							"limit_reached",
						].includes(disposition)
					) {
						// Cancel unstarted successors before recording the final return. No provider is adopted or replayed.
						this.db
							.prepare(
								"UPDATE buddy_runs SET status='cancelled',ended_at=? WHERE input_kind='message_request' AND input_id=? AND status='queued'",
							)
							.run(now(), id);
						const proof =
							disposition === "done"
								? [
										...evidence(project.completion_evidence),
										...project.todos.flatMap((t) =>
											evidence(t.completion_evidence),
										),
									].slice(0, 31)
								: [
										`project:${message.buddy_project_id}`,
										...(latest ? [`run:${latest.id}`] : []),
									];
						// A limit changes queued rows above; preserve the truthful previously-derived disposition for validation.
						this.settleBackgroundReply(
							message,
							disposition,
							state.reason || `Background work ${disposition}.`,
							proof,
						);
					} else if (
						disposition === "continuing" ||
						(disposition === "held" &&
							latest.error_code === "continuation_held" &&
							state.reason === latest.error)
					) {
						try {
							this.enqueueBuddyRun({
								inputKey: `message:${id}:step:${state.runs.length + 1}`,
								inputKind: "message_request",
								inputId: id,
								buddyId: message.to_buddy_id,
								workspaceId: message.workspace_id,
								conversationId: message.child_conversation_id,
								projectId: message.buddy_project_id,
								rootMessageId: message.root_message_id,
								afterRunId: latest.id,
								policy: { ...state.runs[0].policy },
							});
							if (latest.error_code === "continuation_held")
								this.db
									.prepare(
										"UPDATE buddy_runs SET error=NULL,error_code=NULL WHERE id=?",
									)
									.run(latest.id);
						} catch (error) {
							this.db
								.prepare(
									"UPDATE buddy_runs SET error=?,error_code='continuation_held' WHERE id=?",
								)
								.run(
									error instanceof Error ? error.message : String(error),
									latest.id,
								);
						}
					}
					return this.getMessageExecution(id);
				}),
			)
			.filter(Boolean);
	},

	// Host settlement from canonical work/run state. This is not an MCP mutation surface.
	settleBackgroundReply(message, outcome, body, proof) {
		const at = now();
		this.db
			.prepare(`UPDATE buddy_messages SET status='replied',outcome=?,reply_body=?,reply_evidence=?,replied_by=?,replied_at=?,updated_at=?,wait_status=CASE WHEN wait_status='waiting' THEN 'replied' ELSE wait_status END
      WHERE id=? AND status IN ('pending','active')`)
			.run(
				outcome,
				body,
				JSON.stringify(proof),
				message.to_buddy_id,
				at,
				at,
				message.id,
			);
		this.recordAuditEvent({
			buddy: message.to_buddy_id,
			workspace: message.workspace_id,
			project: message.buddy_project_id,
			operation: "buddy.background_settlement",
			payload: { messageId: message.id, outcome, evidence: proof },
		});
		this.deliverBackgroundReply(this.getMessage(message.id));
	},

	deliverBackgroundReply(message) {
		const state = this.getBackgroundWork(message.id);
		try {
			this.enqueueMessageReply(message);
			if (state.latest.error_code === "return_held")
				this.db
					.prepare(
						"UPDATE buddy_runs SET error=NULL,error_code=NULL WHERE id=?",
					)
					.run(state.latest.id);
		} catch (error) {
			this.db
				.prepare(
					"UPDATE buddy_runs SET error=?,error_code='return_held' WHERE id=?",
				)
				.run(
					error instanceof Error ? error.message : String(error),
					state.latest.id,
				);
		}
	},
};
